import { createAction, props } from '@ngrx/store';

import { EntitiesRequest } from '../../../shared/interfaces/entities.request';
import { EntitiesList, EntityPartialDetails } from '../../../shared/interfaces/entities.response';
import { EntityToRoleRequest } from '../interfaces/entity-to-role';
import { SelectEntityBy } from '../interfaces/select-by-enum';

import { GridEntityGroup } from './../../../pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity-group';
import { EntityGroupsList } from './../../../shared/interfaces/entities.response';
import { EntityGroupsRequest } from './../../../shared/interfaces/entity-groups.request';

export enum EntitySelectorActionTypes {
    ChangeStatus = `[Entity Selector] Change Status`,
    SelectBy = `[Entity Selector] Select by`,
    LoadEntities = `[Entity Selector] Load Entities`,
    LoadEntitiesSuccess = `[Entity Selector] Load Entities Success`,
    LoadEntitiesFailure = `[Entity Selector] Load Entities Failure`,
    LoadEntityGroups = `[Entity Selector] Load Entity Groups`,
    LoadEntityGroupsSuccess = `[Entity Selector] Load Entity Groups Success`,
    LoadEntityGroupsFailure = `[Entity Selector] Load Entity Groups Failure`,
    AddEntityToRole = `[Entity Selector] Add Entity to Role`,
    AddEntitySuccess = `[Entity Selector] Add Entity to Role Success`,
    AddEntityFailure = `[Entity Selector] Add Entity to Role Failure`,
    SelectEntiites = '[Entity Selector] Select Entities',
    DeselectEntities = '[Entity Selector] Deselect Entities',
    ClearEntities = '[Entity Selector] Clear Entitites',
    ClearRoleSelectedEntities = '[Entity Selector] Clear Selected Entities',
    ClearUserSelectedEntities = '[Entity Selector] Clear Selected Entities',
    ClearAllData = '[Entity Selector] Clear All Data',
    ClearSelectedEntitites = '[Entity Selector] Clear All Selected Entities'
}
export const entitySelectorChangeStatus = createAction(
    EntitySelectorActionTypes.ChangeStatus,
    props<{ open: boolean }>()
);

export const entitySelectBy = createAction(
    EntitySelectorActionTypes.SelectBy,
    props<{ select: SelectEntityBy }>()
);

export const loadEntities = createAction(
    EntitySelectorActionTypes.LoadEntities,
    props<{ payload: EntitiesRequest }>()
);
export const loadEntitiesSuccess = createAction(
    EntitySelectorActionTypes.LoadEntitiesSuccess,
    props<{ data: EntitiesList }>()
);
export const loadEntititesFailure = createAction(
    EntitySelectorActionTypes.LoadEntitiesFailure,
    props<{ errorMessage: string }>()
);

export const loadEntityGroups = createAction(
    EntitySelectorActionTypes.LoadEntityGroups,
    props<{ payload: EntityGroupsRequest }>()
);
export const loadEntityGroupsSuccess = createAction(
    EntitySelectorActionTypes.LoadEntityGroupsSuccess,
    props<{ data: EntityGroupsList }>()
);
export const loadEntityGroupsFailure = createAction(
    EntitySelectorActionTypes.LoadEntityGroupsFailure,
    props<{ errorMessage: string }>()
);

export const addEntityToRole = createAction(
    EntitySelectorActionTypes.AddEntityToRole,
    props<EntityToRoleRequest>()
);
export const selectEntities = createAction(
    EntitySelectorActionTypes.SelectEntiites,
    props<{ payload: { [key: string]: Array<GridEntityGroup> } }>()
);
export const deselectEntities = createAction(
    EntitySelectorActionTypes.DeselectEntities,
    props<{ payload: Array<EntityPartialDetails> }>()
);
export const clearEntities = createAction(
    EntitySelectorActionTypes.ClearEntities
);
export const clearRoleSelectedEntities = createAction(
    EntitySelectorActionTypes.ClearRoleSelectedEntities,
    props<{ role: string }>()
);

export const clearUserSelectedEntities = createAction(
    EntitySelectorActionTypes.ClearUserSelectedEntities,
    props<{ user: string }>()
);

export const clearAllData = createAction(
    EntitySelectorActionTypes.ClearAllData
);
export const clearSelectedEntities = createAction(
    EntitySelectorActionTypes.ClearSelectedEntitites
);
