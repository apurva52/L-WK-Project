import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';

import { Entity } from '../../../pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity';
import { SelectEntityBy } from '../interfaces/select-by-enum';
import { SelectedEntities } from '../interfaces/selected-entities';

import { EntityGroup } from './../../../pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity-group';
import {
    EntitiesList,
    EntityGroupsList
} from './../../../shared/interfaces/entities.response';

export const ENTITY_SELECTOR_FEATURE_KEY = 'entitySelectorFeatureKey';

export interface EntityInputMultiselectItem extends InputMultiselectItem {
    value?: Entity | EntityGroup;
}

export interface EntitySelectorState {
    loading: boolean;
    isOpen: boolean;
    selectBy: null | undefined | SelectEntityBy;
    entities: EntitiesList;
    entityGroups: EntityGroupsList;
    selectedEntities: SelectedEntities;
    error: {
        message: string;
        active: boolean;
    };
}
