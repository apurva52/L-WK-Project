import { SelectEntityBy } from '../interfaces/select-by-enum';
import { entitiesPartialMock } from '../stubs/entities-partial-details';
import { mockSelectedEntities } from '../stubs/selected-entities';

import {
    clearAllData,
    clearEntities,
    clearRoleSelectedEntities,
    entitySelectBy,
    entitySelectorChangeStatus,
    loadEntitiesSuccess,
    loadEntityGroups,
    loadEntityGroupsFailure,
    loadEntityGroupsSuccess,
    selectEntities
} from './entity-selector.actions';
import { entitySelectorReducer, initialState } from './entity-selector.reducers';
import { EntitySelectorState } from './entity-selector.state';

describe('Entity selector reducers', () => {
    const roleId = 123;

    it('should select change selector status', () => {
        const currentState: EntitySelectorState = { ...initialState };
        const params = { open: true };
        expect(entitySelectorReducer(currentState, entitySelectorChangeStatus(params))).toEqual({ ...currentState, isOpen: true });
    });

    it('should select entitySelect by change', () => {
        const currentState: EntitySelectorState = { ...initialState };
        const params = { select: SelectEntityBy.group };
        expect(entitySelectorReducer(currentState, entitySelectBy(params))).toEqual({ ...currentState, selectBy: SelectEntityBy.group });
    });

    it('should load entities successful', () => {
        const currentState: EntitySelectorState = { ...initialState };
        expect(entitySelectorReducer(currentState, loadEntitiesSuccess({ data: entitiesPartialMock }))).toEqual({
            ...currentState,
            entities: entitiesPartialMock
        });
    });

    it('should select entities by role', () => {
        const customerGroup: any = {
            entity_group_id: 99,
            edh_entity_group_id: 99,
            edh_entity_group_guid: '99',
            edh_entity_group_name: 'Test Group 99',
            edh_entity_group_type: 'C',
            entity_type: '',
            entity_status: '',
            jurisdiction: '',
            entities: []
        };
        const allEntitiesGroup: any = {
            entity_group_id: -1,
            edh_entity_group_id: -1,
            edh_entity_group_guid: '-1',
            edh_entity_group_name: '',
            edh_entity_group_type: 'I',
            entity_type: '',
            entity_status: '',
            jurisdiction: '',
            entities: [],
            isAllEntitiesGroup: true
        };
        const implicitGroup: any = {
            entity_group_id: -1,
            edh_entity_group_id: -1,
            edh_entity_group_guid: '-1',
            edh_entity_group_name: '',
            edh_entity_group_type: 'I',
            entity_type: '',
            entity_status: '',
            jurisdiction: '',
            isAllEntitiesGroup: false,
            entities: [{
                entity_id: 1,
                entity_guid: '1',
                active_foreign_jurisdictions_count: 0,
                total_foreign_jurisdictions_count: 0,
                domestic_jurisdiction: 'Alabama',
                entity_type: 'LLC',
                entity_name: 'Entity 1',
                entity_country: 'Unated States'
            }]
        };
        const currentState: EntitySelectorState = { ...initialState, entities: [...entitiesPartialMock] };
        expect(entitySelectorReducer(currentState, selectEntities({ payload: { [roleId]: mockSelectedEntities[roleId] } }))).toEqual({
            ...currentState,
            selectedEntities: mockSelectedEntities
        });
        const currentState2: EntitySelectorState = { ...initialState, selectedEntities: { [roleId]: [...mockSelectedEntities[roleId]] } };
        expect(entitySelectorReducer(currentState2, selectEntities({ payload: { [roleId]: mockSelectedEntities[roleId] } }))).toEqual({
            ...currentState2,
            selectedEntities: mockSelectedEntities
        });
        const currentState3: EntitySelectorState = { ...initialState, selectedEntities: { [roleId]: [customerGroup] } };
        expect(entitySelectorReducer(currentState3, selectEntities({ payload: { [roleId]: mockSelectedEntities[roleId] } }))).toEqual({
            ...currentState3,
            selectedEntities: { [roleId]: [...mockSelectedEntities[roleId], customerGroup] }
        });
        const currentState4: EntitySelectorState = { ...initialState, selectedEntities: { [roleId]: [implicitGroup, customerGroup] } };
        expect(entitySelectorReducer(currentState4, selectEntities({ payload: { [roleId]: [customerGroup, allEntitiesGroup] } }))).toEqual({
            ...currentState4,
            selectedEntities: {
                [roleId]: [allEntitiesGroup, customerGroup]
            }
        });
        const currentState5: EntitySelectorState = { ...initialState, selectedEntities: { [roleId]: [customerGroup] } };
        expect(entitySelectorReducer(currentState5, selectEntities({ payload: { [roleId]: [implicitGroup] } }))).toEqual({
            ...currentState5,
            selectedEntities: {
                [roleId]: [customerGroup, implicitGroup]
            }
        });
        const currentState6: EntitySelectorState = { ...initialState, selectedEntities: { [roleId]: [implicitGroup] } };
        expect(entitySelectorReducer(currentState6, selectEntities({ payload: { [roleId]: [implicitGroup, customerGroup] } }))).toEqual({
            ...currentState6,
            selectedEntities: {
                [roleId]: [implicitGroup, customerGroup]
            }
        });
    });

    it('should select entities by role when have previous selection', () => {
        const currentState: EntitySelectorState = {
            ...initialState,
            entities: [...entitiesPartialMock],
            selectedEntities: mockSelectedEntities
        };
        const payload = { [roleId]: mockSelectedEntities[roleId] };
        expect(entitySelectorReducer(currentState, selectEntities({ payload })).selectedEntities[roleId].length)
            .toBe(mockSelectedEntities[roleId].length);
    });

    it('should call clear entities', () => {
        const currentState: EntitySelectorState = {
            ...initialState,
            entities: [...entitiesPartialMock]
        };
        expect(entitySelectorReducer(currentState, clearEntities())).toEqual({ ...currentState, entities: [] });
    });

    it('should clear selected entitites from role', () => {
        const currentState: EntitySelectorState = {
            ...initialState,
            selectedEntities: {
                '123': [],
                '1234': []
            }
        };

        expect(entitySelectorReducer(currentState, clearRoleSelectedEntities({ role: roleId.toString() }))).toEqual({
            ...initialState,
            selectedEntities: { '1234': [] }
        });
    });

    it('should load entity groups', () => {
        const currentState: EntitySelectorState = { ...initialState };
        expect(entitySelectorReducer(currentState, loadEntityGroups({ payload: {} }))).toEqual({
            ...currentState,
            loading: true
        });
    });

    it('should load entity groups success', () => {
        const currentState: EntitySelectorState = { ...initialState };
        expect(entitySelectorReducer(currentState, loadEntityGroupsSuccess({ data: mockSelectedEntities[roleId] }))).toEqual({
            ...currentState,
            entityGroups: mockSelectedEntities[roleId],
            loading: false
        });
    });

    it('should load entity groups failure', () => {
        const currentState: EntitySelectorState = { ...initialState };
        expect(entitySelectorReducer(currentState, loadEntityGroupsFailure({ errorMessage: 'Error' }))).toEqual({
            ...currentState,
            loading: false,
            error: {
                active: true,
                message: 'Error'
            }
        });
    });

    it('should clear all data', () => {
        const currentState: EntitySelectorState = {
            ...initialState,
            selectBy: SelectEntityBy.single,
            selectedEntities: {
                '1': []
            }
        };
        expect(entitySelectorReducer(currentState, clearAllData())).toEqual({
            ...initialState
        });
    });
});
