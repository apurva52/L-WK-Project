import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { of, ReplaySubject, throwError } from 'rxjs';

import { EntitiesService } from '../../../shared/services/entities/entities.service';

import { EntitySelectorActionTypes } from './entity-selector.actions';
import { EntitySelectorEffects } from './entity-selector.effects';
import { initialState } from './entity-selector.reducers';
import { ENTITY_SELECTOR_FEATURE_KEY } from './entity-selector.state';

describe('EntitySelectorEffects', () => {
    const actions: ReplaySubject<any> = new ReplaySubject();
    let entitySelectorEffects: EntitySelectorEffects;
    let result: any = null;
    let error: any = null;

    const entitiesService = jasmine.createSpyObj<any>('EntitiesService', ['getEntitiesList', 'getEntityGroupList']);

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                provideMockStore({
                    initialState: {
                        [ENTITY_SELECTOR_FEATURE_KEY]: initialState
                    }
                }),
                provideMockActions(() => actions),
                EntitySelectorEffects,
                {
                    provide: EntitiesService,
                    useValue: entitiesService
                }
            ]
        });
        entitySelectorEffects = TestBed.inject(EntitySelectorEffects);
    });

    describe('getEntities$', () => {
        it('should load entities', () => {
            const expectedResult = { type: EntitySelectorActionTypes.LoadEntitiesSuccess };
            entitiesService.getEntitiesList.and.returnValue(of({}));
            actions.next({ type: EntitySelectorActionTypes.LoadEntities });
            entitySelectorEffects.getEntities$.subscribe((_result: any) => (result = _result));
            expect(result.type).toEqual(expectedResult.type);
        });
        it('should fail loading entities', () => {
            const expectedResult = { type: EntitySelectorActionTypes.LoadEntitiesFailure };
            entitiesService.getEntitiesList.and.returnValue(throwError('Error'));
            actions.next({ type: EntitySelectorActionTypes.LoadEntities });
            entitySelectorEffects.getEntities$.subscribe((_error: any) => (error = _error));
            expect(error.type).toEqual(expectedResult.type);
        });
    });

    describe('getEntyGroups$', () => {
        it('should load entity groups', () => {
            const expectedResult = { type: EntitySelectorActionTypes.LoadEntityGroupsSuccess };
            entitiesService.getEntityGroupList.and.returnValue(of({}));
            actions.next({ type: EntitySelectorActionTypes.LoadEntityGroups });
            entitySelectorEffects.getEntyGroups$.subscribe((_result: any) => (result = _result));
            expect(result.type).toEqual(expectedResult.type);
        });
        it('should fail loading entity groups', () => {
            const expectedResult = { type: EntitySelectorActionTypes.LoadEntityGroupsFailure };
            entitiesService.getEntityGroupList.and.returnValue(throwError('Error'));
            actions.next({ type: EntitySelectorActionTypes.LoadEntityGroups });
            entitySelectorEffects.getEntyGroups$.subscribe((_error: any) => (error = _error));
            expect(error.type).toEqual(expectedResult.type);
        });
    });
});
