/* tslint:disable:max-line-length */
import { createReducer, on } from '@ngrx/store';
import { unionWith } from 'lodash';
import { Entity } from 'src/pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity';
import { GridEntityGroup } from 'src/pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity-group';

import { SelectedEntities } from '../interfaces/selected-entities';

import {
    clearAllData,
    clearEntities,
    clearRoleSelectedEntities,
    clearSelectedEntities,
    entitySelectBy,
    entitySelectorChangeStatus,
    loadEntitiesSuccess,
    loadEntityGroups,
    loadEntityGroupsFailure,
    loadEntityGroupsSuccess,
    selectEntities
} from './entity-selector.actions';
import { EntitySelectorState } from './entity-selector.state';

export const initialState: EntitySelectorState = {
    loading: false,
    isOpen: false,
    selectBy: null,
    entities: [],
    entityGroups: [],
    selectedEntities: {},
    error: {
        message: '',
        active: false
    }
};

export const entitySelectorReducer = createReducer(
    initialState,
    on(entitySelectorChangeStatus, (state, { open }) => ({
        ...state,
        isOpen: open
    })),
    on(entitySelectBy, (state, { select }) => ({
        ...state,
        selectBy: select
    })),
    on(loadEntitiesSuccess, (state, { data }) => ({
        ...state,
        entities: data
    })),
    on(selectEntities, (state, { payload }) => ({
        ...state,
        selectedEntities: {
            ...state.selectedEntities,
            ...calculateSelectedEntities(state, payload)
        }
    })),
    on(clearEntities, (state => ({
        ...state,
        entities: []
    }))),
    on(loadEntityGroups, (state) => ({
        ...state,
        loading: true
    })),
    on(loadEntityGroupsSuccess, (state, { data }) => ({
        ...state,
        entityGroups: data,
        loading: false
    })),
    on(loadEntityGroupsFailure, (state, action) => ({
        ...state,
        loading: false,
        error: {
            active: true,
            message: action.errorMessage
        }
    })),
    on(clearRoleSelectedEntities, (state, { role }) => {
        delete state.selectedEntities[role];
        return state;
    }),
    on(clearAllData, (state => ({
        ...initialState
    }))),
    on(clearSelectedEntities, (state) => ({
        ...state,
        selectedEntities: {}
    }))
);

function groupsComparator(group1: GridEntityGroup, group2: GridEntityGroup): boolean {
    return group1.edh_entity_group_id === group2.edh_entity_group_id &&
        group1.edh_entity_group_guid === group2.edh_entity_group_guid;
}

function entitiesComparator(entity1: Entity, entity2: Entity): boolean {
    return entity1.entity_id === entity2.entity_id && entity1.entity_guid === entity2.entity_guid;
}

function getImplicitGroup(
    stateImplicitGroup: GridEntityGroup,
    requestImplicitGroup: GridEntityGroup
): GridEntityGroup {
    if (stateImplicitGroup) {
        const newImplicitGroupEntities = unionWith(requestImplicitGroup.entities, stateImplicitGroup.entities || [], entitiesComparator);
        const isAllEntitiesGroup = stateImplicitGroup.isAllEntitiesGroup || requestImplicitGroup.isAllEntitiesGroup;
        return {
            ...stateImplicitGroup,
            entities: isAllEntitiesGroup ? [] : newImplicitGroupEntities,
            isAllEntitiesGroup: isAllEntitiesGroup
        };
    }
    return requestImplicitGroup;
}

function calculateSelectedEntities(
    state: EntitySelectorState,
    payload: SelectedEntities
): SelectedEntities {
    const newSelectedEntities = {};
    Object.entries(payload).forEach(([key, entityGroups]) => {
        if (!!state.selectedEntities[key]) {
            const requestImplicitGroupIndex = entityGroups.findIndex(entityGroup => entityGroup.edh_entity_group_id === -1);
            const requestHasImplicitGroups = requestImplicitGroupIndex !== -1;
            const newEntityGroups = unionWith(entityGroups, state.selectedEntities[key], groupsComparator);
            if (requestHasImplicitGroups) {
                const stateImplicitGroupIndex = state.selectedEntities[key].findIndex(entityGroup => entityGroup.edh_entity_group_id === -1);
                const stateImplicitGroup = state.selectedEntities[key][stateImplicitGroupIndex];
                const stateHasImplicitGroups = !!stateImplicitGroup;
                newSelectedEntities[key] = state.selectedEntities[key];
                const newImplicitGroup = getImplicitGroup(stateImplicitGroup, entityGroups[requestImplicitGroupIndex]);
                if (stateHasImplicitGroups) {
                    newSelectedEntities[key][stateImplicitGroupIndex] = newImplicitGroup;
                }
                else {
                    newSelectedEntities[key].push(newImplicitGroup);
                }
                const nonImplicitGroupsToAdd = newEntityGroups.filter(entityGroup =>
                    entityGroup.edh_entity_group_type !== 'I' &&
                    !newSelectedEntities[key].find(item => groupsComparator(item, entityGroup))
                );
                if (nonImplicitGroupsToAdd.length) {
                    newSelectedEntities[key].push(...nonImplicitGroupsToAdd);
                }
            }
            else {
                newSelectedEntities[key] = newEntityGroups;
            }
            newSelectedEntities[key] = [...(newSelectedEntities[key] || [])];
        }
        else {
            newSelectedEntities[key] = entityGroups;
        }
    });
    return newSelectedEntities;
}
