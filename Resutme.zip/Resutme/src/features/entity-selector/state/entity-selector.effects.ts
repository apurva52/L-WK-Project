import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { from, of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';

import { EntitiesService } from '../../../shared/services/entities/entities.service';

import { loadEntities, loadEntitiesSuccess, loadEntititesFailure, loadEntityGroups, loadEntityGroupsFailure, loadEntityGroupsSuccess } from './entity-selector.actions';

@Injectable()
export class EntitySelectorEffects {
    getEntities$ = createEffect(() => (this.actions$.pipe(
        ofType(loadEntities),
        switchMap(({ payload }) => from(this.entitiesService.getEntitiesList(payload)).pipe(
            map((data) => loadEntitiesSuccess({ data })),
            catchError(err => of(loadEntititesFailure({ errorMessage: err }))
            )
        )))));

    getEntyGroups$ = createEffect(() => (this.actions$.pipe(
        ofType(loadEntityGroups),
        switchMap(({ payload }) => from(this.entitiesService.getEntityGroupList(payload)).pipe(
            map((data) => loadEntityGroupsSuccess({ data })),
            catchError(err => of(loadEntityGroupsFailure({ errorMessage: err }))
            )
        )))));

    constructor(private actions$: Actions, private entitiesService: EntitiesService) { }
}
