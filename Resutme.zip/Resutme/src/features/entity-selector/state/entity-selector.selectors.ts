import { createFeatureSelector, createSelector } from '@ngrx/store';

import { EntitiesList, EntityGroupsList } from './../../../shared/interfaces/entities.response';
import { ENTITY_SELECTOR_FEATURE_KEY, EntityInputMultiselectItem, EntitySelectorState } from './entity-selector.state';

export const selectRootFeature = createFeatureSelector<EntitySelectorState>(ENTITY_SELECTOR_FEATURE_KEY);

export const selectEntitySelectorStatus = createSelector(selectRootFeature, (state: EntitySelectorState) => state.isOpen);

export const selectEntityBy = createSelector(selectRootFeature, (state: EntitySelectorState) => state?.selectBy);

export const getEntitiesLoading = createSelector(selectRootFeature, (state: EntitySelectorState): boolean => state.loading);

export const getEntitiesForMultiSelect = createSelector(
    selectRootFeature,
    (state: EntitySelectorState): Array<EntityInputMultiselectItem> => convertEntitiesToMultiselectItems(state.entities)
);

export const getEntityGroupsForMultiSelect = createSelector(
    selectRootFeature,
    (state: EntitySelectorState): Array<EntityInputMultiselectItem> => convertEntityGroupsToMultiselectItems(state.entityGroups)
);

export const getSelectedEntities = createSelector(selectRootFeature, (state: EntitySelectorState) => state.selectedEntities);

export const getRoleSelectedEntities = createSelector(
    selectRootFeature,
    (state: EntitySelectorState, { role }) => state.selectedEntities[role]
);

export const convertEntitiesToMultiselectItems = (entities: EntitiesList): Array<EntityInputMultiselectItem> => {
    return (
        entities?.map((entity) => ({
            id: entity.entity_id.toString(),
            label: entity.entity_name,
            isSelected: false,
            value: entity
        })) || []
    );
};

export const convertEntityGroupsToMultiselectItems = (entityGroups: EntityGroupsList): Array<EntityInputMultiselectItem> => {
    return (
        entityGroups?.map((entityGroup) => ({
            id: entityGroup.edh_entity_group_id.toString(),
            label: entityGroup.edh_entity_group_name,
            isSelected: false,
            value: entityGroup
        })) || []
    );
};
