import { IServerSideGetRowsParams } from '@ag-grid-community/core';
import { LoadSuccessParams } from '@ag-grid-enterprise/all-modules';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { I18nTestingModule } from '@ct/core-ui-ng/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { AppState } from '../../../app/state/app.state';
import { AccordionTypes } from '../../../shared/interfaces/accordion-types-enum';
import {
    entitySelectorChangeStatus,
    selectEntities
} from '../state/entity-selector.actions';
import { initialState } from '../state/entity-selector.reducers';
import { getRoleSelectedEntities } from '../state/entity-selector.selectors';
import { ENTITY_SELECTOR_FEATURE_KEY } from '../state/entity-selector.state';
import { mockSelectedEntities } from '../stubs/selected-entities';

import { RoleEntitiesAccordion } from './role-entities-accordion.component';

describe('RoleEntitiesAccordion', () => {
    let component: RoleEntitiesAccordion;
    let fixture: ComponentFixture<RoleEntitiesAccordion>;
    let store$: MockStore<AppState>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [RoleEntitiesAccordion],
            imports: [
                TranslateModule.forRoot(),
                I18nTestingModule,
                CommonModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [ENTITY_SELECTOR_FEATURE_KEY]: initialState
                    },
                    selectors: [
                        { selector: getRoleSelectedEntities, value: [] }
                    ]
                })
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();

        store$ = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(RoleEntitiesAccordion);
        component = fixture.componentInstance;
        component.roleId = '123';
    });

    it('should be defined', () => {
        fixture.detectChanges();
        expect(component).toBeDefined();
    });
    it('should open entity selector', () => {
        const spy = spyOn(store$, 'dispatch').and.callThrough();
        fixture.detectChanges();

        component.onAddEntity(true);
        expect(spy).toHaveBeenCalledWith(
            entitySelectorChangeStatus({ open: true })
        );
    });

    it('should call add Entity Completed', () => {
        const roleId = 123;
        const spy = spyOn(store$, 'dispatch').and.callThrough();
        component.getRowsParams = {
            success: jasmine.createSpy()
        } as any;
        fixture.detectChanges();
        component.gridData = mockSelectedEntities[roleId];
        component.onAddEntityCompleted(mockSelectedEntities[roleId]);
        expect(spy).toHaveBeenCalledWith(
            selectEntities({
                payload: {
                    [component.roleId]: mockSelectedEntities[roleId]
                }
            })
        );
    });

    it('should call initGridData', () => {
        store$.overrideSelector(
            getRoleSelectedEntities,
            mockSelectedEntities[component.roleId]
        );
        fixture.detectChanges();
        expect(component.gridData.length).toBeGreaterThanOrEqual(1);
    });

    it('should cancel activated Form', () => {
        component.isActivated = true;
        fixture.detectChanges();
        component.onAddEntityCanceled();
        expect(component.isActivated).toEqual(false);
    });

    it('should call onGetRows', () => {
        const params = {
            success: (params: LoadSuccessParams) => {}
        } as IServerSideGetRowsParams;
        component.onGetRows(params);
        fixture.detectChanges();
        expect(component.getRowsParams).toEqual(params);
    });

    it('should call onGetRows', () => {
        const params = {
            request: {
                groupKeys: ['19']
            },
            success: (params: LoadSuccessParams) => {}
        } as IServerSideGetRowsParams;
        const spy = spyOn(component['store$'], 'dispatch');
        component.onGetRows(params);
        fixture.detectChanges();
        expect(spy).toHaveBeenCalled();
    });
    it('should toggle accordion', () => {
        const spy = spyOn(component.toggleEvent, 'emit').and.callThrough();
        component.onToggleAccordion(true);
        expect(spy).toHaveBeenCalled();
    });

    it('should toggle accordion', () => {
        const spy = spyOn(component.toggleEvent, 'emit').and.callThrough();
        component.onToggleAccordion(true);
        expect(spy).toHaveBeenCalled();
    });

    it('should change isReady status', () => {
        component.ready = false;
        expect(component.isReady).toEqual(false);
        component.ready = true;
        expect(component.isReady).toEqual(true);
    });

    it('should change accordion style', () => {
        component.open = false;
        expect(component.accordionStyle).toEqual(AccordionTypes.Disabled);
        component.open = true;
        expect(component.accordionStyle).toEqual(AccordionTypes.Expanded);
    });

    it('should change accordion type', () => {
        component.ready = true;
        component.open = false;
        expect(component.accordionType).toEqual('todo');
        component.open = true;
        expect(component.accordionType).toEqual('default');
    });

    it('should call mapServerSideEntitiesDataToGridData', () => {
        const emptyData = [];
        const mockData = [
            {
                entityId: 123,
                entityGuid: 'fae3df31-86c7-497b-81b2-e0995bc6e090',
                entityName: 'ABCB Capital Management, LP.',
                entityTypeId: 30008,
                entityTypeDesc: 'Association',
                countryId: 50001,
                countryDesc: 'United States',
                countryShortName: 'USA',
                domesticJurisdictionId: 8,
                domesticJurisdictionDesc: 'Delaware',
                domesticJurisdictionCode: 'DE',
                activeForeignJurisCount: 0,
                totalForeignJurisCount: 0
            }
        ];
        const group = {
            entity_group_id: 0,
            edh_entity_group_id: 0,
            edh_entity_group_guid: '',
            edh_entity_group_name: '',
            edh_entity_group_type: 'I' as any,
            entity_type: '',
            entity_status: '',
            jurisdiction: '',
            entities: []
        };
        const testEmptyResponse = component[
            'mapServerSideEntitiesDataToGridData'
        ](emptyData, group);
        const testMockResponse = component[
            'mapServerSideEntitiesDataToGridData'
        ](mockData, group);
        expect(testEmptyResponse.length).toEqual(0);
        expect(testMockResponse[0].domestic_jurisdiction).toEqual('Delaware');
    });
});
