// tslint:disable max-file-line-count
import {
    IServerSideGetRowsParams,
    LoadSuccessParams
} from '@ag-grid-community/core';
import {
    Component,
    EventEmitter,
    Input,
    OnDestroy,
    OnInit,
    Output
} from '@angular/core';
import {
    BulkOption,
    SSRMEntityDataItem
} from '@ct/platform-common-uicomponents/entities-grids';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { Observable, Subject } from 'rxjs';
import { filter, take, takeUntil } from 'rxjs/operators';

import { AppState } from '../../../app/state/app.state';
import {
    RolePermissions,
    rolePermissionsInitialState
} from '../../../pages/users-and-roles/roles-management/details/state/role-details.state';
import { roleDetailsState } from '../../../pages/users-and-roles/roles-management/state/role-management.selectors';
import { AccordionTypes } from '../../../shared/interfaces/accordion-types-enum';
import {
    entitySelectorChangeStatus,
    selectEntities
} from '../state/entity-selector.actions';
import { getRoleSelectedEntities } from '../state/entity-selector.selectors';

import { EntityGroup, GridEntityGroup } from './../../../pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity-group';
import {
    userGetRoleIdFromAccordianAction,
    userManagementLoadEntityGroupEntitiesAction,
    userManagementLoadEntityGroupEntitiesFailureAction,
    userManagementLoadEntityGroupEntitiesSuccessAction
} from './../../../pages/users-and-roles/users-management/state/user-management.actions';
import { SpecificGroupEntityItem } from './../../../shared/interfaces/entitites-for-specific-group.response';

@Component({
    selector: 'ct-role-entities-accordion',
    templateUrl: './role-entities-accordion.component.html',
    styleUrls: ['./role-entities-accordion.component.scss']
})
export class RoleEntitiesAccordion implements OnInit, OnDestroy {
    @Input()
    set open(value: boolean) {
        this._open = value;
    }
    get isOpen(): boolean {
        return this._open;
    }

    @Input()
    set ready(value: boolean) {
        this._ready = value;
    }

    get isReady(): boolean {
        return this._ready;
    }

    get accordionStyle(): AccordionTypes {
        return this.isOpen ? AccordionTypes.Expanded : AccordionTypes.Disabled;
    }

    get accordionType(): string {
        return this.isReady && !this.isOpen ? 'todo' : 'default';
    }

    _open = false;
    _ready = false;

    @Input() isActive: boolean = false;
    @Output() toggleEvent: EventEmitter<void> = new EventEmitter<void>();
    @Input() gridData: Array<any> = [];
    @Input() roleTitle: string;
    @Input() roleId: string;
    @Input() userId: string;
    @Input() addEntityBtnLabel: string;
    @Input() bulkOptions: Array<BulkOption> | boolean = false;
    @Input() disabled: boolean = false;
    @Input() displayApplyToAllUsers: boolean = false;

    initialGridData: Array<EntityGroup> = [];
    loadEntitiesInProgress = false;

    destroyed$: Subject<boolean> = new Subject<boolean>();
    selectedItems$: Observable<Array<EntityGroup>>;
    isActivated: boolean = false;
    getRowsParams: IServerSideGetRowsParams;
    rolePermissions: RolePermissions;
    roleDetailsPermissionsData$ = this.store$.select(roleDetailsState);

    constructor(
        private store$: Store<AppState>,
        private actionsListener$: ActionsSubject
    ) {}

    onToggleAccordion($event): void {
        this.toggleEvent.emit();
        this.open = $event;
    }

    ngOnInit(): void {
        this.store$
            .select(getRoleSelectedEntities, { role: this.roleId?.toString() })
            .pipe(takeUntil(this.destroyed$))
            .subscribe((selected) => {
                this.gridData = selected || [];
            });
        this.rolePermissions = rolePermissionsInitialState;
    }

    onAddEntity($event): void {
        this.isActivated = true;
        this.store$.dispatch(entitySelectorChangeStatus({ open: true }));
        this.store$.dispatch(
            userGetRoleIdFromAccordianAction({ accordianRoleId: this.roleId })
        );
    }

    onAddEntityCompleted($event: Array<GridEntityGroup>): void {
        this.isActivated = false;
        this.store$.dispatch(
            selectEntities({ payload: { [this.roleId]: $event } })
        );
        this.getRowsParams.success({
            rowData: this.mapServerSideEntityGroupsDataToGridData(this.gridData)
        });
    }

    onAddEntityCanceled(): void {
        this.isActivated = false;
    }

    ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    onGetRows(params): void {
        const shouldLoadChildrenEntities =
            params.request?.groupKeys?.length > 0;
        if (shouldLoadChildrenEntities) {
            const group = params.request.groupKeys.at(-1);
            this.subscribeChildEntitiesLoadedState(group, params.success);
            this.store$.dispatch(
                userManagementLoadEntityGroupEntitiesAction({
                    roleId: parseInt(this.roleId),
                    groupGuid: group.edh_entity_group_guid
                })
            );
        } else {
            this.getRowsParams = params;
            this.getRowsParams.success({
                rowData: this.gridData
                    ? this.mapServerSideEntityGroupsDataToGridData(
                          this.gridData
                      )
                    : [],
                rowCount: this.gridData ? this.gridData.length : 0
            });
        }
    }

    mapServerSideEntityGroupsDataToGridData(
        data: Array<EntityGroup>
    ): Array<SSRMEntityDataItem> {
        return data.reduce((previousValue, entityGroup: EntityGroup) => {
            const treeEntityGroup =
                entityGroup.edh_entity_group_type !== 'I'
                    ? [
                          {
                              entity_name: [entityGroup.edh_entity_group_name],
                              entity_type: '',
                              entity_country: '',
                              domestic_jurisdiction: '',
                              foreign_jurisdictions: '',
                              entity_group: entityGroup,
                              is_group: true
                          }
                      ]
                    : [];
            const treeEntities = entityGroup.entities?.length
                ? entityGroup.entities.map((entity) => ({
                      ...entity,
                      entity_name:
                          entityGroup.edh_entity_group_type !== 'I'
                              ? [
                                    entityGroup.edh_entity_group_name,
                                    entity.entity_name
                                ]
                              : [entity.entity_name],
                      entity_group: entityGroup,
                      is_group: false
                  }))
                : [];
            return previousValue.concat([...treeEntityGroup, ...treeEntities]);
        }, []);
    }

    private subscribeChildEntitiesLoadedState(
        group: EntityGroup,
        successCallback: (params: LoadSuccessParams) => void
    ): void {
        this.actionsListener$
            .pipe(
                ofType(
                    userManagementLoadEntityGroupEntitiesSuccessAction,
                    userManagementLoadEntityGroupEntitiesFailureAction
                ),
                filter(
                    (data: any) =>
                        parseInt(this.roleId) &&
                        data.groupGuid === group.edh_entity_group_guid
                ),
                take(1)
            )
            .subscribe((data) => {
                const rowData = this.mapServerSideEntitiesDataToGridData(
                    data['result']?.data || [],
                    group
                );
                successCallback({
                    rowData,
                    rowCount: rowData.length
                });
            });
    }

    private mapServerSideEntitiesDataToGridData(
        data: Array<SpecificGroupEntityItem>,
        group: EntityGroup
    ): Array<SSRMEntityDataItem> {
        if (!data?.length) {
            return [];
        }
        return data.map(
            (entity) =>
                ({
                    entity_id: entity.entityId,
                    entity_guid: entity.entityGuid,
                    entity_type: entity.entityTypeDesc,
                    entity_country: entity.countryShortName,
                    domestic_jurisdiction: entity.domesticJurisdictionDesc,
                    foreign_jurisdiction: [],
                    entity_name: [entity.entityName],
                    entity_group: group,
                    is_group: false
                } as any)
        );
    }
}
