export const entitiesPartialMock = [
    {
        entity_id: 123,
        entity_guid: '',
        active_foreign_jurisdictions_count: 0,
        total_foreign_jurisdictions_count: 0,
        domestic_jurisdiction: 'Alabama',
        entity_type: 'LLC',
        entity_name: 'Entity 1',
        entity_country: 'Unated States'
    },
    {
        entity_id: 1234,
        entity_guid: '',
        active_foreign_jurisdictions_count: 0,
        total_foreign_jurisdictions_count: 0,
        domestic_jurisdiction: 'Alabama',
        entity_type: 'LLC',
        entity_name: 'Entity 1',
        entity_country: 'Unated States'
    }

];
