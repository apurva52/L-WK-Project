import { SelectedEntities } from '../interfaces/selected-entities';

import { entitiesPartialMock } from './entities-partial-details';

export const mockSelectedEntities: SelectedEntities = {
    '123': [
        {
            entity_group_id: -1,
            edh_entity_group_id: -1,
            edh_entity_group_guid: '-1',
            edh_entity_group_name: '',
            edh_entity_group_type: 'I',
            entity_type: '',
            entity_status: '',
            jurisdiction: '',
            entities: entitiesPartialMock,
            isAllEntitiesGroup: false
        },
        {
            entity_group_id: 7777,
            edh_entity_group_id: 7777,
            edh_entity_group_guid: '157324',
            edh_entity_group_name: 'Test Expl Group',
            edh_entity_group_type: 'C',
            entity_type: '',
            entity_status: '',
            jurisdiction: '',
            entities: []
        }
    ]
};
