import { EntityMultiselectItem } from '@ct/platform-common-uicomponents/entity-reference';

export const mockEntitiesMultiselectItems: Array<EntityMultiselectItem> = [
    {
        entityId: '123',
        entityGuid: '6e9237b8-02b6-4fc1-9fd2-1ab58c137387',
        entityName: 'Entity 1',
        countryId: 42,
        countryShortName: 'USA',
        countryDesc: 'United States',
        domesticJurisidictionId: 202,
        domesticJurisdictionDesc: 'Alabama',
        domesticJurisdictionShortName: 'AL',
        entityTypeId: 'LLC',
        entityTypeDesc: 'LLC',
        entityTypeShortName: 'LLC',
        activeForeingJurisCount: 0,
        value: 'Entity 1',
        checked: false
    }
];
