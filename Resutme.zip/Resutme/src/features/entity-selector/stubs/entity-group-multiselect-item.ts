import { EntityGroupMultiselectItem } from '@ct/platform-common-uicomponents//entity-reference';

export const mockEntityGroupMultiselectItem: Array<EntityGroupMultiselectItem> =
    [
        {
            groupdId: '123',
            groupGuid: '58db0de6-8436-41a2-851e-91616ee8c2ec',
            groupName: 'dyn test',
            groupType: 'C',
            createdBy: null,
            createdDate: null,
            value: 'dyn test',
            checked: false
        }
    ];
