import { GridEntityGroup } from './../../../pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity-group';

export interface SelectedEntities {
    [key: string] : Array<GridEntityGroup>;
}
