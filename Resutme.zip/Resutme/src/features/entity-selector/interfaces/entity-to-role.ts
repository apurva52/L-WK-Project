export interface EntityToRoleRequest {
    jurisdiction: string;
    entityType: string;
    entities: Array<string>;
}
