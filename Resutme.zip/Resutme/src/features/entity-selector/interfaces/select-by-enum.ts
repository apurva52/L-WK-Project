export enum SelectEntityBy {
    single = 'single',
    group = 'group'
}
