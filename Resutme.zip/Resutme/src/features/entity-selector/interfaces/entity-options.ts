export interface EntityOptions {
    id: string;
    label: string;
    isSelected: boolean;
}
