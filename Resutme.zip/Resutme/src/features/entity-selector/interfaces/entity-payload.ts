export interface EntityPayload {
    jurisdiction: string;
    entityType: string;
}
