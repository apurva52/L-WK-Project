export interface TreeEntity {
    entity_id?: number;
    entity_guid?: string;
    entity_name: Array<string>;
    entity_type: string;
    entity_country: string;
    domestic_jurisdiction: string;
    foreign_jurisdiction: string;
}
