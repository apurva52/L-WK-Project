/* tslint:disable max-file-line-count */
import { LazyElementsLoaderService, LazyElementsModule } from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';
import { provideMockActions } from '@ngrx/effects/testing';
import { Action, MemoizedSelector } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import mockAllEntities from 'src/pages/users-and-roles/users-management/state/test-values/mock-all-entities.json';
import { AccountService } from 'src/shared/services/account/account.service';
import { EntitiesService } from 'src/shared/services/entities/entities.service';

import { AppState } from '../../../../../app/state/app.state';
import { getAllEntitiesState } from '../../../../../pages/users-and-roles/users-management/state/user-management.selectors';
import { SelectEntityBy } from '../../../interfaces/select-by-enum';
import { EntitySelectorEffects } from '../../../state/entity-selector.effects';
import { initialState } from '../../../state/entity-selector.reducers';
import {
    convertEntitiesToMultiselectItems,
    convertEntityGroupsToMultiselectItems,
    getEntitiesForMultiSelect,
    getEntitiesLoading,
    getEntityGroupsForMultiSelect,
    selectEntitySelectorStatus
} from '../../../state/entity-selector.selectors';
import { ENTITY_SELECTOR_FEATURE_KEY } from '../../../state/entity-selector.state';
import { mockEntitiesMultiselectItems } from '../../../stubs/entities-multiselect-items';
import { entitiesPartialMock } from '../../../stubs/entities-partial-details';
import { mockEntityGroupMultiselectItem } from '../../../stubs/entity-group-multiselect-item';
import { mockSelectedEntities } from '../../../stubs/selected-entities';

import { SelectEntitiesByComponent } from './select-entities-by.component';

describe('SelectEntitiesByComponent', () => {
    let component: SelectEntitiesByComponent;
    let fixture: ComponentFixture<SelectEntitiesByComponent>;
    let store$: MockStore<AppState>;
    const actions$ = new Observable<Action>();
    let effects$: EntitySelectorEffects;
    let mockEntitiesSelector: MemoizedSelector<
        AppState,
        Array<InputMultiselectItem>
    >;
    let debugElement: DebugElement;
    const accountServiceMock = jasmine.createSpyObj('AccountService', ['accountHasHcueSubscription']);
    const roleId = 123;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [SelectEntitiesByComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [ENTITY_SELECTOR_FEATURE_KEY]: initialState
                    },
                    selectors: [
                        { selector: selectEntitySelectorStatus, value: false },
                        { selector: getEntitiesForMultiSelect, value: [] },
                        { selector: getEntityGroupsForMultiSelect, value: [] },
                        { selector: getEntitiesLoading, value: false },
                        { selector: getAllEntitiesState, value: { data: mockAllEntities.result.data, loading: false } }
                    ]
                }),
                EntitySelectorEffects,
                provideMockActions(() => actions$),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                },
                EntitiesService,
                {
                    provide: AccountService,
                    useValue: accountServiceMock
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        accountServiceMock.accountHasHcueSubscription.and.returnValue(Promise.resolve(true));
        store$ = TestBed.inject(MockStore);
        effects$ = TestBed.inject(EntitySelectorEffects);
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(SelectEntitiesByComponent);
        component = fixture.componentInstance;
        mockEntitiesSelector = store$.overrideSelector(
            getEntitiesForMultiSelect,
            convertEntitiesToMultiselectItems(entitiesPartialMock)
        );
        debugElement = fixture.debugElement;
        spyOn(component.canceled, 'emit');
        component.addEntityForm = new FormGroup({
            jurisdiction: new FormControl(null, {
                validators: [Validators.required]
            }),
            entityType: new FormControl(),
            entity: new FormControl(null, {
                validators: [Validators.required]
            }),
            entityGroup: new FormControl(null, {
                validators: [Validators.required]
            })
        });
        fixture.detectChanges();
    });

    it('should be defined', () => {
        expect(component).toBeDefined();
    });


    it('should call change radioSelector', () => {
        const storeSpy = spyOn(store$, 'dispatch').and.callThrough();
        component.radioChangeHandler(SelectEntityBy.single);
        fixture.detectChanges();
        expect(storeSpy).toHaveBeenCalled();
    });

    it('should trigger onSelectJurisdition', () => {
        const mockSelectedJurisdictions = {
            name: 'Jurisdiction 1',
            shortName: 'JUR1'
        };

        component.onSelectJurisdition(mockSelectedJurisdictions);
        expect(component.selectedJurisdiction).toEqual(
            mockSelectedJurisdictions.shortName
        );
        expect(component.selectedJurisdictionName).toEqual(
            mockSelectedJurisdictions.name
        );
    });

    it('should call onSelectEntityType', () => {
        const mockSelectedEntityType = {
            entityTypeShortName: 'Type 1'
        };
        component.onSelectEntityType(mockSelectedEntityType);
        expect(component.selectedEntityType).toEqual(
            mockSelectedEntityType.entityTypeShortName
        );
    });

    it('should call onSelectEntities', () => {
        component.onSelectEntities(mockEntitiesMultiselectItems);
        expect(component.selectedEntities.length).toBe(1);
    });

    it('should call onCancelAddEntity', () => {
        component.addEntityForm.patchValue({
            jurisdiction: 'Alabama',
            entityTpe: 'Type 1',
            entity: ['1', '2'],
            entityGroup: ['1', '2', '3']
        });
        fixture.detectChanges();
        expect(component.addEntityForm.valid).toEqual(true);
        component.onCancelAddEntity();
        fixture.detectChanges();
        expect(component.addEntityForm.valid).toEqual(false);
    });

    it('should call onCompleteAddEntity', () => {
        const spyCompleted = spyOn(component.completed, 'emit');
        const entitiesItems =
            convertEntitiesToMultiselectItems(entitiesPartialMock);

        fixture.detectChanges();
        component.onSelectEntities(mockEntitiesMultiselectItems);
        component.onCompleteAddEntity();

        expect(spyCompleted).toHaveBeenCalled();
    });

    it('should call onAddAllEntitiesChanged', () => {
        const allEntityBoolean = true;
        component.onAddAllEntitiesChanged({ target: { checked: allEntityBoolean } });
        expect(component.addAllEntitiesControl).toEqual(allEntityBoolean);
    });

    it('should call onCompleteAddEntity', () => {
        const spyCompleted = spyOn(component.completed, 'emit');
        const entitiesItems =
            convertEntitiesToMultiselectItems(entitiesPartialMock);

        fixture.detectChanges();
        component.onSelectEntities(mockEntitiesMultiselectItems);
        component.onCompleteAddEntity();

        expect(spyCompleted).toHaveBeenCalled();
    });

    it('should call onCompleteAddEntityGroups', () => {
        const spyCompleted = spyOn(component.completed, 'emit');
        const entitiesItems = convertEntityGroupsToMultiselectItems(
            mockSelectedEntities[roleId].splice(0, 1)
        );

        fixture.detectChanges();
        component.onSelectEntityGroups(mockEntityGroupMultiselectItem);
        component.onCompleteAddEntity();

        expect(spyCompleted).toHaveBeenCalled();
    });

    it('should trigger form controls', () => {
        component.addEntityForm.patchValue({
            jurisdiction: 'Alabama',
            entityTpe: 'Type 1',
            entity: ['1', '2'],
            entityGroup: ['1', '2', '3']
        });

        expect(component.entityControl.value).toEqual(['1', '2']);
        expect(component.jurisdictionControl.value).toEqual('Alabama');
        expect(component.entityGroupControl.value).toEqual(['1', '2', '3']);
    });

    it('should validate from with single entitites selection', async () => {
        component.selectBy$ = of(SelectEntityBy.single);
        await component.ngOnInit();
        component.selectBy$.subscribe((_selectBy) => {
            component.addEntityForm.patchValue({
                jurisdiction: 'Alabama',
                entityTpe: 'Type 1',
                entity: ['1', '2']
            });
            expect(component.addEntityForm.valid).toBeTruthy();
        });
    });

    it('should validate from with entity groups selection', async () => {
        spyOn(component['store$'], 'dispatch');
        component.selectBy$ = of(SelectEntityBy.group);
        await component.ngOnInit();
        component.selectBy$.subscribe((_selectBy) => {
            component.addEntityForm.patchValue({
                entityGroup: ['1', '2', '3']
            });
            expect(component.addEntityForm.valid).toBeTruthy();
        });
    });

    it('should destroy', async () => {
        const destroyedSpy = spyOn(component.destroyed$, 'complete');
        await component.ngOnDestroy();
        expect(destroyedSpy).toHaveBeenCalled();
    });
});
