// tslint:disable max-file-line-count
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { EntityGroupMultiselectItem, EntityMultiselectItem } from '@ct/platform-common-uicomponents/server';
import { RadioComboboxOption } from '@ct/platform-primitives-uicomponents/primitives/radio-combobox/interfaces/radio-combobox-options.interface';
import { Store } from '@ngrx/store';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';
import { AccountService } from 'src/shared/services/account/account.service';

import { AppState } from '../../../../../app/state/app.state';
import { getAllEntitiesState } from '../../../../../pages/users-and-roles/users-management/state/user-management.selectors';
import {
    clearEntities,
    entitySelectBy,
    entitySelectorChangeStatus } from '../../../state/entity-selector.actions';

import { Entity } from './../../../../../pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity';
import { GridEntityGroup } from './../../../../../pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity-group';
import { SelectEntityBy } from './../../../interfaces/select-by-enum';
import * as entitySelectorSelectors from './../../../state/entity-selector.selectors';

@Component({
    selector: 'ct-select-entities-by',
    templateUrl: './select-entities-by.component.html',
    styleUrls: ['./select-entities-by.component.scss']
})
export class SelectEntitiesByComponent implements OnInit, OnDestroy {
    get entityControl(): FormControl {
        return this.addEntityForm.get('entity') as FormControl;
    }

    get jurisdictionControl(): FormControl {
        return this.addEntityForm.get('jurisdiction') as FormControl;
    }

    get entityGroupControl(): FormControl {
        return this.addEntityForm.get('entityGroup') as FormControl;
    }

    @Input() allEntityFlag = false;
    @Input() selectEntityOptionsValue: string;
    @Input() addEntityForm: FormGroup;
    @Input() isAddEntityDisabled = false;

    @Output() completed: EventEmitter<Array<GridEntityGroup>> = new EventEmitter();
    @Output() canceled: EventEmitter<void> = new EventEmitter();
    @Output() onSelectEntityOptionChange: EventEmitter<{ value: string }> =
        new EventEmitter();

    addAllEntitiesControl: boolean = false;
    isLoaded: boolean = false;
    selectedEntityType: string;
    selectedJurisdiction: string;
    selectedJurisdictionName: string;
    selectedEntities: Array<GridEntityGroup> = [];
    selectedAllEntities: Array<GridEntityGroup> = [];

    entitySelectorOpts: Array<RadioComboboxOption> = [
        {
            label: 'Entity',
            value: SelectEntityBy.single,
            checked: false,
            disabled: false
        }
    ];

    allEntitiesState$ = this.store$.select(getAllEntitiesState);
    destroyed$: Subject<boolean> = new Subject();
    selectBy$: Observable<SelectEntityBy> = this.store$.select(entitySelectorSelectors.selectEntityBy);
    accountHasHcueSubscriptionValidated: boolean = false;
    readonly SelectEntityBy = SelectEntityBy;
    readonly COUNTRY_USA_ID = 50001; // hardcoded no country selector provided in UX
    private entityGroupSelectorOption: RadioComboboxOption = {
        label: 'Entity Group(s)',
        value: SelectEntityBy.group,
        checked: false,
        disabled: false
    };
    private defaultImplicitGroup: GridEntityGroup = {
        entity_group_id: -1,
        edh_entity_group_id: -1,
        edh_entity_group_guid: '00000000-0000-0000-0000-000000000000',
        edh_entity_group_name: '00000000-0000-0000-0000-000000000000',
        edh_entity_group_type: 'I',
        entity_type: '',
        entity_status: '',
        jurisdiction: '',
        isAllEntitiesGroup: false
    };

    constructor(
        private store$: Store<AppState>,
        private accountService: AccountService
    ) { }

    async ngOnInit(): Promise<void> {
        const accountHasHcueSubscription = await this.accountService.accountHasHcueSubscription();
        if (accountHasHcueSubscription) {
            this.entitySelectorOpts.push(this.entityGroupSelectorOption);
        }
        this.accountHasHcueSubscriptionValidated = true;
        this.selectBy$
            .pipe(
                takeUntil(this.destroyed$),
                filter((selectBy) => !!selectBy)
            )
            .subscribe((selectBy: SelectEntityBy) => {
                if (selectBy === SelectEntityBy.group) {
                    this.jurisdictionControl.setValidators([]);
                    this.entityControl.setValidators([]);
                    this.entityGroupControl.setValidators([
                        Validators.required
                    ]);
                } else {
                    this.jurisdictionControl.setValidators([
                        Validators.required
                    ]);
                    this.entityControl.setValidators([Validators.required]);
                    this.entityGroupControl.setValidators([]);
                }
                this.jurisdictionControl.reset();
                this.entityControl.reset();
                this.entityGroupControl.reset();
                this.jurisdictionControl.updateValueAndValidity();
                this.entityControl.updateValueAndValidity();
                this.entityGroupControl.updateValueAndValidity();
            });
    }

    ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    radioChangeHandler($event): void {
        this.store$.dispatch(entitySelectBy({ select: $event.value }));
    }

    onAddAllEntitiesChanged(event): void {
        this.addAllEntitiesControl = event?.target?.checked;

    }

    onSelectEntityType($event): void {
        this.selectedEntityType = $event.entityTypeShortName;
    }

    onSelectJurisdition($event): void {
        this.selectedJurisdiction = $event.shortName;
        this.selectedJurisdictionName = $event.name;
        this.isLoaded = false;
        this.addEntityForm.patchValue(
            {
                entityType: '',
                entity: ''
            },
            { emitEvent: false }
        );
    }

    onSelectEntities($event: Array<EntityMultiselectItem>): void {
        this.addEntityForm.patchValue({ entity: $event }, { emitEvent: true });
        this.selectedEntities = this.getImplicitEntityGroup($event);
    }

    onSelectEntityGroups($event: Array<EntityGroupMultiselectItem>): void {
        this.addEntityForm.patchValue(
            { entityGroup: $event },
            { emitEvent: true }
        );
        this.selectedEntities = this.getExplicitEntityGroup($event);
    }

    onCancelAddEntity(): void {
        this.resetSelectedOptions();
        this.closeEntityForm();
        this.canceled.emit();
    }

    onCompleteAddEntity(): void {
        this.defaultImplicitGroup.isAllEntitiesGroup = this.allEntityFlag;
        this.completed.emit(this.allEntityFlag && !this.isAddEntityDisabled ? [this.defaultImplicitGroup] : this.selectedEntities);
        this.resetSelectedOptions();
        this.closeEntityForm();
    }

    private closeEntityForm(): void {
        this.store$.dispatch(entitySelectorChangeStatus({ open: false }));
        this.store$.dispatch(entitySelectBy({ select: null }));
        this.onSelectEntityOptionChange.emit({ value: null });
    }

    private resetSelectedOptions(): void {
        this.store$.dispatch(clearEntities());
        this.selectedEntities = [];
        this.selectedJurisdiction = '';
        this.selectedJurisdictionName = undefined;
        this.allEntityFlag = false;

        this.addEntityForm.patchValue(
            {
                jurisdiction: null,
                entityType: null,
                entity: null
            },
            {
                emitEvent: false
            }
        );
    }

    private getImplicitEntityGroup(
        entities: Array<EntityMultiselectItem>
    ): Array<GridEntityGroup> {
        this.defaultImplicitGroup.entities = entities.map(
            (entity) =>
            ({
                entity_id: Number(entity.entityId),
                entity_guid: entity.entityGuid,
                entity_name: entity.entityName,
                entity_type: entity.entityTypeDesc,
                entity_country: entity.domesticJurisdictionDesc,
                domestic_jurisdiction: entity.domesticJurisdictionShortName,
                active_foreign_jurisdictions_count: entity.activeForeingJurisCount
            } as Entity)
        );
        return [{ ...this.defaultImplicitGroup, isAllEntitiesGroup: this.allEntityFlag }];
    }

    private getExplicitEntityGroup(
        entityGroups: Array<EntityGroupMultiselectItem>
    ): Array<GridEntityGroup> {
        return entityGroups.map(
            (group) =>
            ({
                edh_entity_group_id: Number(group.groupdId),
                edh_entity_group_guid: group.groupGuid,
                edh_entity_group_name: group.groupName,
                edh_entity_group_type: group.groupType,
                entities: []
            } as GridEntityGroup)
        );
    }
}
