import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { isEqual } from 'lodash';
import { filter, take } from 'rxjs/operators';
import { SpecificGroupEntityItem } from 'src/shared/interfaces/entitites-for-specific-group.response';

import {
    userManagementLoadEntityGroupAllEntitiesAction,
    userManagementLoadEntityGroupAllEntitiesFailureAction,
    userManagementLoadEntityGroupAllEntitiesSuccessAction,
    userManagementLoadRoleEntitiesAction,
    userManagementLoadRoleEntitiesFailureAction,
    userManagementLoadRoleEntitiesSuccessAction
} from '../../../../../pages/users-and-roles/users-management/state/user-management.actions';
import { usersFromRoles } from '../../../../../pages/users-and-roles/users-management/state/user-management.selectors';

import { Entity } from './../../../../../pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity';
import { EntityGroup } from './../../../../../pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity-group';

@Component({
    selector: 'ct-copy-entities-from-user',
    templateUrl: './copy-entities-from-user.component.html',
    styleUrls: ['./copy-entities-from-user.component.scss']
})
export class CopyEntitiesFromUserComponent implements OnInit {
    @Input() roleId: string;
    @Output() completed: EventEmitter<Array<EntityGroup>> = new EventEmitter();

    controlUsers = new FormControl('');
    usersFromRole: Array<{ name: string; id: string }> = [];
    initialGridData: Array<EntityGroup> = [];
    loadEntitiesInProgress = false;

    constructor(
        private store$: Store,
        private actionsListener$: ActionsSubject
    ) {}

    ngOnInit(): void {
        this.store$
            .select(usersFromRoles(this.roleId))
            .subscribe((data) => this.updateUsersFromRoleData(data));
    }

    userSelectChanged(userId: string): void {
        this.loadEntitiesInProgress = true;
        this.subscribeRoleEntitiesLoadedState();
        this.store$.dispatch(
            userManagementLoadRoleEntitiesAction({
                userId,
                roleId: +this.roleId
            })
        );
    }

    onClearUserEntities(): void {
        this.controlUsers.setValue('');
        this.initialGridData = [];
    }

    onCopyUserEntities(): void {
        const implicitGroupsToPreload = this.initialGridData.filter(group =>
            group.edh_entity_group_type === 'I' && group.edh_entity_group_id !== -1
        );
        if (implicitGroupsToPreload.length) {
            this.loadEntitiesInProgress = true;
            this.preloadEntitiesForImplicitGroups(implicitGroupsToPreload);
        } else {
            this.completed.emit(this.initialGridData);
        }
    }

    private preloadEntitiesForImplicitGroups(implicitGroupsToPreload: Array<EntityGroup>): void {
        const implicitGroup = implicitGroupsToPreload.shift();
        this.loadAllEntitiesForGroup(implicitGroup, (entities) => {
            implicitGroup.edh_entity_group_id = -1;
            implicitGroup.edh_entity_group_guid = '-1';
            implicitGroup.entities = entities;
            if (implicitGroupsToPreload.length) {
                this.preloadEntitiesForImplicitGroups(implicitGroupsToPreload);
            } else {
                this.loadEntitiesInProgress = false;
                this.completed.emit(this.initialGridData);
            }
        });
    }

    private subscribeRoleEntitiesLoadedState(): void {
        this.actionsListener$
            .pipe(
                ofType(
                    userManagementLoadRoleEntitiesSuccessAction,
                    userManagementLoadRoleEntitiesFailureAction
                ),
                filter(
                    (data) =>
                        data.roleId === +this.roleId &&
                        data.userId === this.controlUsers.value
                ),
                take(1)
            )
            .subscribe((data) =>
                this.updateInitialGridData(data['result']?.data)
            );
    }

    private updateInitialGridData(entityGroups: Array<EntityGroup>): void {
        this.loadEntitiesInProgress = false;
        this.initialGridData = [...(entityGroups || [])];
    }

    private updateUsersFromRoleData(
        data: Array<{ name: string; id: string }>
    ): void {
        if (!isEqual(this.usersFromRole, data)) {
            this.usersFromRole = data;
        }
    }

    private loadAllEntitiesForGroup(group: EntityGroup, callback: (data: Array<Entity>) => void): void {
        this.actionsListener$
            .pipe(
                ofType(
                    userManagementLoadEntityGroupAllEntitiesSuccessAction,
                    userManagementLoadEntityGroupAllEntitiesFailureAction
                ),
                filter(
                    (data) =>
                        data.roleId === +this.roleId &&
                        data.groupGuid === group.edh_entity_group_guid
                ),
                take(1)
            )
            .subscribe((response) =>
                callback(this.mapEntityGroupEntitiesDataToEntities(response['result']?.data || []))
            );
        this.store$.dispatch(
            userManagementLoadEntityGroupAllEntitiesAction({
                roleId: +this.roleId,
                groupGuid: group.edh_entity_group_guid
            })
        );
    }

    private mapEntityGroupEntitiesDataToEntities(
        dataArray: Array<SpecificGroupEntityItem>
    ): Array<Entity> {
        if (!dataArray?.length) {
            return [];
        }
        return dataArray.map(
            (entityItem) =>
                ({
                    entity_id: entityItem.entityId,
                    entity_guid: entityItem.entityGuid,
                    entity_name: entityItem.entityName,
                    entity_type: entityItem.entityTypeDesc,
                    entity_country: entityItem.countryShortName,
                    domestic_jurisdiction: entityItem.domesticJurisdictionDesc,
                    active_foreign_jurisdictions_count: entityItem.activeForeignJurisCount,
                    total_foreign_jurisdictions_count: entityItem.totalForeignJurisCount
                })
        );
    }
}
