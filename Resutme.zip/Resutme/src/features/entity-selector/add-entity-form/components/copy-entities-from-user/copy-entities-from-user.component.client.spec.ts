/* tslint:disable:max-file-line-count */
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';

import { EntityGroup } from '../../../../../pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity-group';
import { userManagementLoadEntityGroupAllEntitiesFailureAction, userManagementLoadEntityGroupAllEntitiesSuccessAction, userManagementLoadRoleEntitiesSuccessAction } from '../../../../../pages/users-and-roles/users-management/state/user-management.actions';
import { initialState } from '../../../../../pages/users-and-roles/users-management/state/user-management.reducers';
import { USER_MANAGEMENT_FEATURE_KEY } from '../../../../../pages/users-and-roles/users-management/state/user-management.state';

import { CopyEntitiesFromUserComponent } from './copy-entities-from-user.component';

describe('CopyEntitiesFromUserComponent', () => {
    let component: CopyEntitiesFromUserComponent;
    let fixture: ComponentFixture<CopyEntitiesFromUserComponent>;
    const actions$: Observable<any> = of();

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CopyEntitiesFromUserComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockActions(() => actions$),
                provideMockStore({
                    initialState: {
                        [USER_MANAGEMENT_FEATURE_KEY]: initialState
                    }
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CopyEntitiesFromUserComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should be defined', () => {
        expect(component).toBeDefined();
    });

    it('should call select users from roles', () => {
        const storeSelectSpy = spyOn(
            component['store$'],
            'select'
        ).and.callThrough();
        component.ngOnInit();
        fixture.detectChanges();
        expect(storeSelectSpy).toHaveBeenCalled();
    });

    it('should dispatch action on user selection change', () => {
        const storeDispatchSpy = spyOn(
            component['store$'],
            'dispatch'
        ).and.callThrough();
        component.userSelectChanged('1');
        fixture.detectChanges();
        expect(component.loadEntitiesInProgress).toEqual(true);
        expect(storeDispatchSpy).toHaveBeenCalled();
    });

    it('should call updateInitialGridData when role entities loaded', () => {
        const expectedCalls = 1;
        const updateInitialGridDataSpy = spyOn(
            component as any,
            'updateInitialGridData'
        ).and.callThrough();
        component.roleId = '1';
        component.controlUsers.setValue('user1');
        component['subscribeRoleEntitiesLoadedState']();
        component['actionsListener$'].next(
            userManagementLoadRoleEntitiesSuccessAction({
                roleId: 2,
                userId: 'user1',
                result: { data: [] } as any
            })
        );
        component['actionsListener$'].next(
            userManagementLoadRoleEntitiesSuccessAction({
                roleId: +component.roleId,
                userId: component.controlUsers.value,
                result: { data: [] } as any
            })
        );
        fixture.detectChanges();
        expect(updateInitialGridDataSpy).toHaveBeenCalledTimes(expectedCalls);
    });

    it('should update initial grid data', () => {
        const gridData: Array<EntityGroup> = [
            {
                entity_group_id: 1,
                edh_entity_group_id: 1,
                edh_entity_group_guid: '1',
                edh_entity_group_name: 'Test group 1',
                edh_entity_group_type: 'I',
                entities: [
                    {
                        entity_id: 1,
                        entity_guid: '1',
                        entity_name: 'Test entity 1',
                        entity_country: '',
                        domestic_jurisdiction: ''
                    }
                ]
            }
        ];
        component['updateInitialGridData'](gridData);
        expect(component.initialGridData).toEqual(gridData);

        const emptyArray = [];
        component['updateInitialGridData'](null);
        expect(component.initialGridData).toEqual(emptyArray);
        expect(component.loadEntitiesInProgress).toBeFalsy();
    });

    it('should update users from role data', () => {
        const data = [
            { name: '1', id: '1' },
            { name: '2', id: '2' },
            { name: '3', id: '3' }
        ];
        component['updateUsersFromRoleData'](data);
        expect(component.usersFromRole).toEqual(data);
    });

    it('should clear selected user', () => {
        component.controlUsers.setValue('1');
        component.onClearUserEntities();
        expect(component.controlUsers.value).toBe('');
        expect(component.initialGridData).toEqual([]);
    });

    it('should emit event during onCopyUserEntities call', () => {
        const eventSpy = spyOn(component.completed, 'emit');
        const implicitGroup: EntityGroup = {
            entity_group_id: 1,
            edh_entity_group_id: 1,
            edh_entity_group_guid: '1',
            edh_entity_group_name: 'Test group 1',
            edh_entity_group_type: 'I',
            entities: [{
                entity_id: 1,
                entity_guid: '1',
                entity_name: 'Test entity 1',
                entity_country: '',
                domestic_jurisdiction: ''
            }]
        };
        const customerGroup: EntityGroup = {
            entity_group_id: 2,
            edh_entity_group_id: 2,
            edh_entity_group_guid: '2',
            edh_entity_group_name: 'Test group 2',
            edh_entity_group_type: 'C',
            entities: []
        };
        const expectedCallsCount = 2;

        component.initialGridData = [customerGroup];
        component.onCopyUserEntities();

        component.initialGridData = [implicitGroup, implicitGroup];
        spyOn(component as any, 'loadAllEntitiesForGroup').and
            .callFake((group, callback) => callback([]));
        component.onCopyUserEntities();

        expect(eventSpy).toHaveBeenCalledTimes(expectedCallsCount);
    });

    it('should load all entities for group', () => {
        const eventSpy = spyOn(component['store$'], 'dispatch');
        const group: EntityGroup = {
            entity_group_id: 1,
            edh_entity_group_id: 1,
            edh_entity_group_guid: '1',
            edh_entity_group_name: 'Test group 1',
            edh_entity_group_type: 'I',
            entities: []
        };
        const groupEntitiesMock = [{
            entityId: 10,
            entityGuid: '10',
            entityName: '10',
            entityTypeId: 10,
            entityTypeDesc: '10',
            countryId: 10,
            countryDesc: '10',
            countryShortName: '10',
            domesticJurisdictionId: 10,
            domesticJurisdictionDesc: '10',
            domesticJurisdictionCode: '10',
            activeForeignJurisCount: 10,
            totalForeignJurisCount: 10
        }];
        const roleId = '1';
        const callback = jasmine.createSpy();
        const expectedCallsCount = 3;
        component.roleId = roleId;

        component['loadAllEntitiesForGroup'](group, callback);
        expect(eventSpy).toHaveBeenCalled();
        component['actionsListener$'].next(
            userManagementLoadEntityGroupAllEntitiesSuccessAction({
                roleId: +roleId,
                groupGuid: group.edh_entity_group_guid,
                result: {
                    data: groupEntitiesMock
                } as any
            })
        );

        component['loadAllEntitiesForGroup'](group, callback);
        expect(eventSpy).toHaveBeenCalled();
        component['actionsListener$'].next(
            userManagementLoadEntityGroupAllEntitiesSuccessAction({
                roleId: +roleId,
                groupGuid: group.edh_entity_group_guid,
                result: {
                    data: []
                } as any
            })
        );

        component['loadAllEntitiesForGroup'](group, callback);
        expect(eventSpy).toHaveBeenCalled();
        component['actionsListener$'].next(
            userManagementLoadEntityGroupAllEntitiesFailureAction({
                roleId: +roleId,
                groupGuid: group.edh_entity_group_guid,
                errorMessage: ''
            })
        );

        expect(callback).toHaveBeenCalledTimes(expectedCallsCount);
    });
});
