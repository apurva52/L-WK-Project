import {
    Component,
    EventEmitter,
    OnDestroy,
    OnInit,
    Output
} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { RadioComboboxOption } from '@ct/platform-primitives-uicomponents/primitives/radio-combobox/interfaces/radio-combobox-options.interface';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { takeUntil } from 'rxjs/operators';

import { AppState } from '../../../app/state/app.state';
import {
    getRoleIdFromAccordianState
} from '../../../pages/users-and-roles/users-management/state/user-management.selectors';
import { SelectEntityBy } from '../interfaces/select-by-enum';
import {
    getEntitiesForMultiSelect,
    getEntitiesLoading,
    getEntityGroupsForMultiSelect,
    selectEntityBy,
    selectEntitySelectorStatus
} from '../state/entity-selector.selectors';

import { GridEntityGroup } from './../../../pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity-group';

@Component({
    selector: 'ct-addentity-form',
    templateUrl: './add-entity-form.component.html',
    styleUrls: ['./add-entity-form.component.scss']
})
export class AddEntityFormComponent implements OnInit, OnDestroy {
    formGroup: FormGroup;
    selectEntityOptionsValue = '';
    roleId: string;

    isOpen$ = this.store$.select(selectEntitySelectorStatus);
    selectBy$: Observable<SelectEntityBy> = this.store$.select(selectEntityBy);
    entities$ = this.store$.select(getEntitiesForMultiSelect);
    entityGroups$ = this.store$.select(getEntityGroupsForMultiSelect);
    entitiesLoading$ = this.store$.select(getEntitiesLoading);
    getRoleIdFromAccordianState$ = this.store$.select(
        getRoleIdFromAccordianState
    );

    selectEntityOptions: Array<RadioComboboxOption> = [
        {
            label: 'Search and Add Entity',
            value: 'searchAddEntity',
            checked: false,
            disabled: false
        },
        {
            label: 'Copy Entities from Another User with this Role',
            value: 'copyEntity',
            checked: false,
            disabled: false
        }
    ];

    destroyed$: Subject<boolean> = new Subject();

    @Output() completed: EventEmitter<Array<GridEntityGroup>> = new EventEmitter();
    @Output() canceled: EventEmitter<void> = new EventEmitter();

    addAllEntitiesControl: boolean = false;

    constructor(private store$: Store<AppState>) {}

    ngOnInit(): void {
        this.formInitialSetup();
        this.getRoleIdFromAccordianState$
            .pipe(takeUntil(this.destroyed$))
            .subscribe((roleId) => (this.roleId = roleId));

        this.store$
            .select(selectEntitySelectorStatus)
            .pipe(takeUntil(this.destroyed$))
            .subscribe((isOpen) => {
                if (isOpen) this.selectEntityOptionsValue = '';
            });
    }

    formInitialSetup(): void {
        this.formGroup = new FormGroup({
            jurisdiction: new FormControl(null, {
                validators: [Validators.required]
            }),
            entityType: new FormControl(),
            entity: new FormControl(null, {
                validators: [Validators.required]
            }),
            entityGroup: new FormControl(null, {
                validators: [Validators.required]
            })
        });
    }

    onSelectEntityOptionChange($event): void {
        this.selectEntityOptionsValue = $event.value;
    }

    onAddAllEntitiesChanged(event): void {
        this.addAllEntitiesControl = event?.target?.checked;
    }

    ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
