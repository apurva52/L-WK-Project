import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';
import { provideMockActions } from '@ngrx/effects/testing';
import { Action, MemoizedSelector } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { Observable } from 'rxjs';
import { getRoleIdFromAccordianState } from 'src/pages/users-and-roles/users-management/state/user-management.selectors';
import { EntitiesService } from 'src/shared/services/entities/entities.service';

import { AppState } from '../../../app/state/app.state';
import * as usersState from '../../../pages/users-and-roles/users-management/state/user-management.reducers';
import { USER_MANAGEMENT_FEATURE_KEY } from '../../../pages/users-and-roles/users-management/state/user-management.state';
import { EntitySelectorEffects } from '../state/entity-selector.effects';
import { initialState } from '../state/entity-selector.reducers';
import { ENTITY_SELECTOR_FEATURE_KEY } from '../state/entity-selector.state';
import * as mocks from '../stubs/entities-partial-details';

import {
    convertEntitiesToMultiselectItems,
    getEntitiesForMultiSelect,
    getEntitiesLoading,
    getEntityGroupsForMultiSelect,
    selectEntityBy,
    selectEntitySelectorStatus
} from './../state/entity-selector.selectors';
import { AddEntityFormComponent } from './add-entity-form.component';

describe('AddEntityFormComponent', () => {
    let component: AddEntityFormComponent;
    let fixture: ComponentFixture<AddEntityFormComponent>;
    let store$: MockStore<AppState>;
    const actions$ = new Observable<Action>();
    let effects$: EntitySelectorEffects;
    let mockEntitiesSelector: MemoizedSelector<
        AppState,
        Array<InputMultiselectItem>
    >;
    let debugElement: DebugElement;
    const roleId = 123;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [AddEntityFormComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [ENTITY_SELECTOR_FEATURE_KEY]: initialState,
                        [USER_MANAGEMENT_FEATURE_KEY]: usersState.initialState
                    },
                    selectors: [
                        { selector: selectEntitySelectorStatus, value: false },
                        { selector: getEntitiesForMultiSelect, value: [] },
                        { selector: getEntityGroupsForMultiSelect, value: [] },
                        { selector: getEntitiesLoading, value: false },
                        { selector: selectEntityBy, value: null },
                        { selector: getRoleIdFromAccordianState, value: '' }
                    ]
                }),
                EntitySelectorEffects,
                provideMockActions(() => actions$),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                },
                EntitiesService
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store$ = TestBed.inject(MockStore);
        effects$ = TestBed.inject(EntitySelectorEffects);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AddEntityFormComponent);
        component = fixture.componentInstance;
        store$ = TestBed.inject(MockStore);
        mockEntitiesSelector = store$.overrideSelector(
            getEntitiesForMultiSelect,
            convertEntitiesToMultiselectItems(mocks.entitiesPartialMock)
        );
        debugElement = fixture.debugElement;
        spyOn(component.canceled, 'emit');
        fixture.detectChanges();
    });

    it('should be defined', () => {
        expect(component).toBeDefined();
    });

    it('should call onAddAllEntitiesChanged', () => {
        const allEntityBoolean = true;
        component.onAddAllEntitiesChanged({
            target: { checked: allEntityBoolean }
        });
        expect(component.addAllEntitiesControl).toEqual(allEntityBoolean);
    });

    it('should call change radioCopyEntity', () => {
        component.onSelectEntityOptionChange(component.selectEntityOptions[0]);
        fixture.detectChanges();
        expect(component.selectEntityOptionsValue).toEqual(
            component.selectEntityOptions[0].value
        );
    });
    it('should call change radioCopyEntity', () => {
        const expectedValue = store$.overrideSelector(
            selectEntitySelectorStatus,
            true
        );
        fixture.detectChanges();
        expect(component.selectEntityOptionsValue).toEqual('');
    });
});
