import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EntitiesGridsModule } from '@ct/platform-common-uicomponents/entities-grids';
import {
    EntityMultiselectModule,
    EntityReferenceModule
} from '@ct/platform-common-uicomponents/entity-reference';
import {
    ReferenceControlsModule,
    ReferenceService } from '@ct/platform-common-uicomponents/reference-controls';
import { CtPrimitivesModule } from '@ct/platform-primitives-uicomponents/primitives';
import { TranslateModule } from '@ngx-translate/core';

import { EntityAssociateGridModule } from '../entities-associate-grid/entities-associate-grid.module';
import { ModulesAndPermissionsGridModule } from '../modules-and-permissions-grid/modules-and-permissions-grid.module';

import { AddEntityFormComponent } from './add-entity-form/add-entity-form.component';
import { CopyEntitiesFromUserComponent } from './add-entity-form/components/copy-entities-from-user/copy-entities-from-user.component';
import { SelectEntitiesByComponent } from './add-entity-form/components/select-entiies-by/select-entities-by.component';
import { RoleEntitiesAccordion } from './role-entities-accordion/role-entities-accordion.component';

@NgModule({
    declarations: [
        AddEntityFormComponent,
        RoleEntitiesAccordion,
        SelectEntitiesByComponent,
        CopyEntitiesFromUserComponent
    ],
    exports: [
        AddEntityFormComponent,
        RoleEntitiesAccordion,
        SelectEntitiesByComponent,
        CopyEntitiesFromUserComponent
    ],
    imports: [
        CtPrimitivesModule,
        EntitiesGridsModule,
        ReferenceControlsModule,
        FormsModule,
        ReactiveFormsModule,
        TranslateModule.forChild(),
        CommonModule,
        EntityReferenceModule,
        ModulesAndPermissionsGridModule,
        EntityMultiselectModule,
        EntityAssociateGridModule
    ],
    providers: [ReferenceService],

    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class EntitySelectorModule {}
