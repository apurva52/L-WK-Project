import mockRolePermissions from '../../../../pages/users-and-roles/roles-management/details/state/test-values/role-details-mock.json';

import { initialDXState } from './digital-experience.reducers';
import {
    selectNavigationItems,
    selectNavigationItemsForTreeGrid
} from './digital-experience.selectors';
import { DigitalExperienceState } from './digital-experience.state';
import mockDigitalExperience from './test-values/digital-experience-mock.json';

describe('Digital Experience selectors', () => {
    it('should return current navigation items', () => {
        const currentData = selectNavigationItems.projector(initialDXState);
        expect(currentData).toEqual(initialDXState.navigationItems);
    });

    it('should return navigation items from Digital experience for tree grid', () => {
        const currentState: DigitalExperienceState = {
            ...initialDXState,
            loaded: true,
            data: mockDigitalExperience.data.modules as any
        };
        const currentData = selectNavigationItemsForTreeGrid(true).projector(currentState);
        expect(currentData).toBeDefined();
    });

    it('should return navigation items from Role permissions for tree grid', () => {
        const currentState: DigitalExperienceState = {
            ...initialDXState,
            loaded: true,
            data: mockDigitalExperience.data.modules as any
        };
        const currentData = selectNavigationItemsForTreeGrid(
            false,
            true,
            mockRolePermissions.data
        ).projector(currentState);
        expect(currentData).toBeDefined();
    });
});
