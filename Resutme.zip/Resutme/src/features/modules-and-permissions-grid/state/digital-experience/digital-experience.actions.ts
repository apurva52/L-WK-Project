import { createAction, props } from '@ngrx/store';

import { DataNavigationItem } from './../../interfaces/permission-module.interface';
import { DigitalExperienceModules } from './digital-experience.state';

export enum DigitalExperienceActionTypes {
    GetDigitalExperience = `[Digital Experience] Get Modules And Permissions`,
    GetDigitalExperienceSuccess = `[Digital Experience] Get Modules And Permissions Success`,
    GetDigitalExperienceFailure = `[Digital Experience] Get Modules And Permissions Failure`,
    RestoreDigitalExperience = `[Digital Experience] Get Modules And Permissions Restore`
}

export const getDigitalExperienceAction = createAction(
    DigitalExperienceActionTypes.GetDigitalExperience,
    props<{ navigationItems: Array<DataNavigationItem> }>()
);
export const getDigitalExperienceSuccessAction = createAction(
    DigitalExperienceActionTypes.GetDigitalExperienceSuccess,
    props<{ data: DigitalExperienceModules }>()
);
export const getDigitalExperienceFailureAction = createAction(
    DigitalExperienceActionTypes.GetDigitalExperienceFailure,
    props<{ errorMessage: string }>()
);
export const restoreDigitalExperienceAction = createAction(
    DigitalExperienceActionTypes.RestoreDigitalExperience
);


