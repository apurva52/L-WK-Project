// tslint:disable max-file-line-count
// tslint:disable:max-line-length
import { createReducer, on } from '@ngrx/store';
import { get } from 'lodash';
import { RolePermissions } from 'src/pages/users-and-roles/roles-management/details/state/role-details.state';

import {
    FilterNavigationItemsParams,
    GetNavigationItemsParameters,
    SetAccessAndPermissionValueParameters,
    ShouldDisplayPermissionParameters
} from '../../interfaces/modules-and-permissions-parameters.interface';
import { DataNavigationItem, ModulePermissionValue, PermissionModule, PermissionValue } from '../../interfaces/permission-module.interface';

import {
    getDigitalExperienceAction,
    getDigitalExperienceFailureAction,
    getDigitalExperienceSuccessAction,
    restoreDigitalExperienceAction
} from './digital-experience.actions';
import { DigitalExperienceState, ModuleLevel } from './digital-experience.state';

const setAccessAndPermissionValue = ({
    navigationItem,
    rolePermissions,
    basePath }: SetAccessAndPermissionValueParameters): void => {
    const permissionValue = get(rolePermissions, `${basePath}${navigationItem.id}`, navigationItem.permission);
    navigationItem.access = !!permissionValue;
    navigationItem.permission = permissionValue;
};

const shouldDisplayPermission = ({
    rolePermissions,
    path }: ShouldDisplayPermissionParameters): boolean => {
    return get(rolePermissions, path) !== undefined;
};

const filterNavItemFromPermission = ({
    navigationItems,
    rolePermissions,
    basePath,
    mapCallback = (_navigationItem: DataNavigationItem) => { } }: FilterNavigationItemsParams): Array<DataNavigationItem> => {
    return navigationItems
        .filter((item: DataNavigationItem) => item.display ??
            shouldDisplayPermission({ rolePermissions, path: `${basePath}${item.id}` }))
        .map((navigationItem: DataNavigationItem) => {
            mapCallback(navigationItem);
            return navigationItem;
        });
};

const getNavigationItemsFromRolePermissions = (
    navigationItems: Array<DataNavigationItem>,
    rolePermissions: RolePermissions
): Array<DataNavigationItem> => {
    const basePath = `${ModuleLevel.MODULES}.`;
    return filterNavItemFromPermission({
        rolePermissions, navigationItems, basePath, mapCallback: (navigationItem: DataNavigationItem) => {
            setAccessAndPermissionValue({ navigationItem, rolePermissions, basePath });
            if (navigationItem.sub_modules) {
                const subModulesBasePath = `${ModuleLevel.SUB_MODULES}.${navigationItem.id}.`;
                navigationItem.sub_modules = filterNavItemFromPermission({
                    rolePermissions,
                    navigationItems: navigationItem.sub_modules,
                    basePath: subModulesBasePath,
                    mapCallback: (subModule: DataNavigationItem) => {
                        setAccessAndPermissionValue({ rolePermissions, navigationItem: subModule, basePath: subModulesBasePath });
                        if (subModule.modules_sections) {
                            const moduleSectionsBasePath = `${ModuleLevel.MODULE_SECTIONS}.${navigationItem.id}.${subModule.id}.`;
                            subModule.modules_sections = filterNavItemFromPermission({
                                rolePermissions,
                                navigationItems: subModule.modules_sections,
                                basePath: moduleSectionsBasePath,
                                mapCallback: (moduleSection: DataNavigationItem) => {
                                    setAccessAndPermissionValue({
                                        rolePermissions,
                                        navigationItem: moduleSection,
                                        basePath: moduleSectionsBasePath
                                    });
                                }
                            });
                        }
                    }
                });
            }
        }
    });
};

const filterNavigationItemsFromDigitalExperience = ({
    navigationItems,
    digitalExperience,
    basePath,
    mapCallback = (_navigationItem: DataNavigationItem) => { } }: FilterNavigationItemsParams): Array<DataNavigationItem> => {
    return navigationItems
        .filter((item: DataNavigationItem) => item.display ??
            (get(digitalExperience, `${basePath}${item.id}`)?.access || false))
        .map((navigationItem: DataNavigationItem) => {
            mapCallback(navigationItem);
            return navigationItem;
        });
};

const getNavigationItemsFromDigitalExperience = (
    navigationItems: Array<DataNavigationItem>,
    digitalExperience
): Array<DataNavigationItem> => {
    let basePath = '';
    return filterNavigationItemsFromDigitalExperience({
        navigationItems, digitalExperience, basePath, mapCallback: (navigationItem: DataNavigationItem) => {
            if (navigationItem.sub_modules) {
                basePath = `${navigationItem.id}.${ModuleLevel.SUB_MODULES}.`;
                navigationItem.sub_modules = filterNavigationItemsFromDigitalExperience({
                    navigationItems: navigationItem.sub_modules,
                    digitalExperience,
                    basePath,
                    mapCallback: (subModule: DataNavigationItem) => {
                        if (subModule.modules_sections) {
                            basePath = `${navigationItem.id}.${ModuleLevel.SUB_MODULES}.${subModule.id}.${ModuleLevel.MODULES_SECTIONS}.`;
                            subModule.modules_sections = filterNavigationItemsFromDigitalExperience({
                                navigationItems: subModule.modules_sections,
                                digitalExperience,
                                basePath
                            });
                        }
                    }
                });
            }
        }
    });
};

export const filterNavigationItems = ({
    digitalExperience,
    rolePermissions,
    navigationItems,
    basedOnDigitalExperience
}: GetNavigationItemsParameters): Array<DataNavigationItem> => {
    if (basedOnDigitalExperience) {
        return getNavigationItemsFromDigitalExperience(navigationItems, digitalExperience);
    }
    return getNavigationItemsFromRolePermissions(navigationItems, rolePermissions);
};

export const getTreeDataFromGridData = (gridData: Array<DataNavigationItem>): Array<PermissionModule> => {
    const treeData = [], itemsToVirtualParents = [];
    updateTreeDataValuesFromGridData(gridData, treeData, itemsToVirtualParents);
    updateTreeDataValuesFromGridDataToVirtualParents(itemsToVirtualParents, treeData);
    removeUnusedTreeDataValues(treeData);
    return treeData;
};

const updateTreeDataValuesFromGridData = (
    gridData: Array<DataNavigationItem>,
    treeData: Array<PermissionModule> = [],
    itemsToVirtualParents: Array<DataNavigationItem> = [],
    parentModuleName: Array<string> | string = [],
    parentModuleId: Array<string> | string = [],
    keyForDifferentChildren: string = ModuleLevel.SUB_MODULES,
    skipVirtualParentCheck = false
): void => {
    gridData.forEach((navigationItem: DataNavigationItem) => {
        if (!skipVirtualParentCheck && navigationItem.virtual_parent_ids?.length) {
            navigationItem.parentIds = parentModuleId && (Array.isArray(parentModuleId) ? parentModuleId : [parentModuleId]);
            itemsToVirtualParents.push(navigationItem);
            return;
        }

        const parentModule = createTreeDataItem(navigationItem, parentModuleName, parentModuleId, keyForDifferentChildren);
        treeData.push(parentModule);

        if (navigationItem.sub_modules) {
            updateTreeDataValuesFromGridData(
                navigationItem.sub_modules,
                treeData,
                itemsToVirtualParents,
                parentModule.module_name,
                parentModule.id,
                ModuleLevel.MODULES_SECTIONS
            );
        }

        if (navigationItem.modules_sections) {
            updateTreeDataValuesFromGridData(
                navigationItem.modules_sections,
                treeData,
                itemsToVirtualParents,
                parentModule.module_name,
                parentModule.id
            );
        }

        if (navigationItem.nested_content) {
            updateTreeDataValuesFromGridData(
                navigationItem.nested_content,
                treeData,
                itemsToVirtualParents,
                parentModule.module_name,
                parentModule.id
            );
        }
    });
};

const createTreeDataItem = (
    navigationItem: DataNavigationItem,
    parentModuleName: Array<string> | string = [],
    parentModuleId: Array<string> | string = [],
    keyForDifferentChildren: string = ModuleLevel.SUB_MODULES
): PermissionModule => {
    let permission = navigationItem.permission;
    if (navigationItem.sub_modules) {
        const childrenValues = navigationItem.sub_modules
            .filter((submodule) => submodule.permission !== undefined)
            .map((submodule) =>
                submodule.permission === ModulePermissionValue.ACCESS_YES ?
                    PermissionValue.VIEW_ONLY : submodule.permission);
        if (childrenValues.length > 0 && permission !== PermissionValue.NONE) {
            permission = Math.max(...childrenValues);
        }
    }
    const treeDataItem: PermissionModule = {
        id: [...parentModuleId, navigationItem.id],
        virtual_id: [...(navigationItem.virtual_parent_ids || parentModuleId), navigationItem.id],
        iconName: navigationItem.iconName,
        module_name: [...parentModuleName, navigationItem.text],
        value: navigationItem.value,
        access: navigationItem.access || false,
        order: navigationItem.order,
        controls: navigationItem.controls,
        hasHyperlink: navigationItem.hasHyperlink,
        permission,
        hasChildrenDifferentSelection: navigationItem[keyForDifferentChildren]?.some(
            (item, _index, arr) => item.permission !== arr[0].permission
        )
    };
    if (navigationItem.allowed_permissions) {
        treeDataItem.allowed_permissions = navigationItem.allowed_permissions;
    }
    return treeDataItem;
};

const updateTreeDataValuesFromGridDataToVirtualParents = (
    itemsToVirtualParents: Array<DataNavigationItem> = [],
    treeData: Array<PermissionModule> = []
): void => {
    if (itemsToVirtualParents.length) {
        itemsToVirtualParents.forEach((item) => {
            const parent = treeData.find((data) => data.id.toString() === item.virtual_parent_ids.toString());
            if (parent) {
                const newTreeDataItems = [];
                const newItemsToVirtualParents = [];
                updateTreeDataValuesFromGridData(
                    [item],
                    newTreeDataItems,
                    newItemsToVirtualParents,
                    parent.module_name,
                    item.parentIds,
                    item.parentIds?.length ? ModuleLevel.MODULES_SECTIONS : ModuleLevel.SUB_MODULES,
                    true
                );
                treeData.splice(treeData.indexOf(parent), 0, ...newTreeDataItems);
                updateTreeDataValuesFromGridDataToVirtualParents(newItemsToVirtualParents, treeData);
            }
        });
    }
};

const removeUnusedTreeDataValues = (treeData: Array<PermissionModule> = []): void => {
    const itemsWithoutControls = treeData.filter((item) => !item.controls.access && !item.controls.permission);
    itemsWithoutControls.forEach((item) => {
        const index = treeData.indexOf(item);
        const itemModuleName = Array.isArray(item.module_name) ? item.module_name : [item.module_name];
        const childItems = [], parentItems = [];
        treeData.forEach((dataItem, i) => {
            if (i !== index) {
                const dataItemModuleName = Array.isArray(dataItem.module_name) ? dataItem.module_name : [dataItem.module_name];
                if (itemModuleName.every((name) => dataItemModuleName.includes(name))) {
                    childItems.push(dataItem);
                } else if (itemModuleName.length > 1 && itemModuleName.slice(0, -1).every((name) => dataItemModuleName.includes(name))) {
                    parentItems.push(dataItem);
                }
            }
        });
        if (!childItems.length && !parentItems.length) {
            treeData.splice(index, 1);
        }
    });
};

export const initialDXState: DigitalExperienceState = {
    navigationItems: [],
    data: null,
    loading: false,
    loaded: false,
    error: {
        active: false,
        message: ''
    }
};

export const digitalExperienceReducer = createReducer(
    initialDXState,
    on(getDigitalExperienceAction, (state, { navigationItems }) => ({
        ...state,
        navigationItems,
        loading: true,
        loaded: false
    })),
    on(getDigitalExperienceSuccessAction, (state, { data }) => {
        return {
            ...state,
            data,
            loading: false,
            loaded: true
        };
    }),
    on(getDigitalExperienceFailureAction, (state, { errorMessage: message }) => ({
        ...state,
        loading: false,
        loaded: false,
        error: {
            active: true,
            message
        }
    })),
    on(restoreDigitalExperienceAction, () => (initialDXState))
);
