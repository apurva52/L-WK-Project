// tslint:disable:max-line-length
import mockModules from '../modules-and-permissions/test-values/modules-mock-data.json';

import {
    getDigitalExperienceAction,
    getDigitalExperienceFailureAction,
    getDigitalExperienceSuccessAction,
    restoreDigitalExperienceAction
} from './digital-experience.actions';
import {
    digitalExperienceReducer,
    getTreeDataFromGridData,
    initialDXState
} from './digital-experience.reducers';
import mockDigitalExperience from './test-values/digital-experience-mock.json';

describe('Digital Experience management reducer', () => {
    it('should process Digital Experience load', () => {
        const currentState = { ...initialDXState };
        expect(
            digitalExperienceReducer(
                currentState,
                getDigitalExperienceAction({ navigationItems: mockModules })
            )
        ).toEqual({
            ...currentState,
            navigationItems: mockModules,
            loading: true
        });
    });
    it('should process Digital Experience load success', () => {
        const currentState = { ...initialDXState };
        expect(
            digitalExperienceReducer(
                currentState,
                getDigitalExperienceSuccessAction({
                    data: {
                        ...mockDigitalExperience.data.modules,
                        activities: {
                            ...mockDigitalExperience.data.modules.activities,
                            sub_modules: (mockDigitalExperience.data.modules.activities as any).sub_modules || []
                        }
                    } as any
                })
            )
        ).toBeDefined();
    });
    it('should process Digital Experience load failure', () => {
        const currentState = { ...initialDXState };
        expect(
            digitalExperienceReducer(
                currentState,
                getDigitalExperienceFailureAction({
                    errorMessage: 'Unit Test error'
                })
            )
        ).toEqual({
            ...currentState,
            error: {
                active: true,
                message: 'Unit Test error'
            }
        });
    });
    it('should restore Digital Experience', () => {
        const currentState = { ...initialDXState };
        expect(
            digitalExperienceReducer(
                currentState,
                restoreDigitalExperienceAction()
            )
        ).toEqual(initialDXState);
    });
    it('should get tree data from grid data', () => {
        const gridDataMock = [
            {
                id: 'module1',
                text: 'Module 1',
                iconName: 'cubes',
                link: '',
                order: 0,
                access: false,
                permission: 0,
                controls: {
                    access: true,
                    permission: false
                }
            },
            {
                id: 'module_virtual',
                text: 'Module virtual',
                iconName: 'cubes',
                link: '',
                order: 1,
                display: true,
                access: false,
                permission: 0,
                controls: {
                    access: false,
                    permission: false
                }
            },
            {
                id: 'module_unused',
                text: 'Module unused',
                iconName: 'cubes',
                link: '',
                order: 2,
                display: true,
                access: false,
                permission: 0,
                controls: {
                    access: false,
                    permission: false
                }
            },
            {
                id: 'module2',
                text: 'Module 2',
                iconName: 'cubes',
                link: '',
                order: 3,
                access: false,
                permission: 0,
                controls: {
                    access: true,
                    permission: true
                },
                virtual_parent_ids: ['module_virtual'],
                sub_modules: [
                    {
                        id: 'sub_module1',
                        text: 'Sub-module 1',
                        link: '',
                        order: 0,
                        display: true,
                        access: false,
                        permission: 0,
                        controls: {
                            access: true,
                            permission: false
                        },
                        virtual_parent_ids: ['module_virtual']
                    },
                    {
                        id: 'sub_module2',
                        text: 'Sub-module 2',
                        link: '',
                        order: 1,
                        access: false,
                        permission: 0,
                        controls: {
                            access: false,
                            permission: true
                        }
                    },
                    {
                        id: 'sub_module3',
                        text: 'Sub-module 3',
                        link: '',
                        order: 2,
                        access: false,
                        permission: 0,
                        controls: {
                            access: false,
                            permission: false
                        },
                        virtual_parent_ids: ['module2', 'sub_module2']
                    }
                ]
            }
        ];
        const expectedLength = 6;
        const treeData = getTreeDataFromGridData(gridDataMock);
        expect(treeData.length).toBe(expectedLength);

        const treeDataEmpty = getTreeDataFromGridData([]);
        expect(treeDataEmpty.length).toBeFalsy();
    });
});
