import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { of, ReplaySubject, throwError } from 'rxjs';

import { AuthorizationManagementService } from '../../../../shared/services/authorization-management/authorization-management.service';

import { DigitalExperienceActionTypes } from './digital-experience.actions';
import { DigitalExperienceEffects } from './digital-experience.effects';
import { initialDXState } from './digital-experience.reducers';
import { DIGITAL_EXPERIENCE_FEATURE_KEY } from './digital-experience.state';
import mockDigitalExperience from './test-values/digital-experience-mock.json';

describe('EntityDetailsEffects', () => {
    const actions: ReplaySubject<any> = new ReplaySubject();
    let digitalExperienceEffects: DigitalExperienceEffects;
    let result: any = null;
    let error: any = null;

    const authorizationManagementService = jasmine.createSpyObj<any>(
        'AuthorizationManagementService',
        ['getDigitalExperience']
    );

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                provideMockStore({
                    initialState: {
                        [DIGITAL_EXPERIENCE_FEATURE_KEY]: initialDXState
                    }
                }),
                provideMockActions(() => actions),
                DigitalExperienceEffects,
                {
                    provide: AuthorizationManagementService,
                    useValue: authorizationManagementService
                }
            ]
        });
        digitalExperienceEffects = TestBed.inject(DigitalExperienceEffects);
    });

    it('should load digital experience', () => {
        const expectedResult = {
            type: DigitalExperienceActionTypes.GetDigitalExperienceSuccess,
            data: mockDigitalExperience.data.modules
        };
        authorizationManagementService.getDigitalExperience.and.returnValue(
            of(mockDigitalExperience)
        );
        actions.next({
            type: DigitalExperienceActionTypes.GetDigitalExperience
        });
        digitalExperienceEffects.loadDigitalExperience$.subscribe(
            (_result: any) => (result = _result)
        );
        expect(result.type).toEqual(expectedResult.type);
    });

    it('should fail loading digital experience', () => {
        const expectedResult = {
            type: DigitalExperienceActionTypes.GetDigitalExperienceFailure,
            data: mockDigitalExperience.data.modules
        };
        authorizationManagementService.getDigitalExperience.and.returnValue(
            throwError('Error')
        );
        actions.next({
            type: DigitalExperienceActionTypes.GetDigitalExperience
        });
        digitalExperienceEffects.loadDigitalExperience$.subscribe(
            (_error: any) => (error = _error)
        );
        expect(error.type).toEqual(expectedResult.type);
    });
});
