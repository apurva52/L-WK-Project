import { DataNavigationItem } from '../../interfaces/permission-module.interface';

export const DIGITAL_EXPERIENCE_FEATURE_KEY = 'digitalExperience';

export interface ErrorState {
    active: boolean;
    message: string;
}

export enum ModuleLevel {
    MODULES = 'modules',
    SUB_MODULES = 'sub_modules',
    MODULE_SECTIONS = 'module_sections',
    MODULES_SECTIONS = 'modules_sections',
    NESTED_CONTENT = 'nested_content'
}

export interface DigitalExperienceModule {
    access: boolean;
}

export interface DigitalExperienceModules {
    place_new_order: DigitalExperienceModule;
    activities: {
        access: boolean;
        sub_modules: {
            ct_activities_all_account: DigitalExperienceModule;
            ct_updates: DigitalExperienceModule;
            hcue_pending_updates: DigitalExperienceModule;
            to_dos_all_account: DigitalExperienceModule;
        };
    };
    compliance_events: {
        access: boolean;
        sub_modules: {
            system_created: DigitalExperienceModule;
            custom_events: DigitalExperienceModule;
        };
    };
    orders: {
        access: boolean;
        sub_modules: {
            all_account_orders: DigitalExperienceModule;
        };
    };
    invoice_and_payments: {
        access: boolean;
        sub_modules: {
            all_account_invoices: DigitalExperienceModule;
        };
    };
    entities: {
        access: boolean;
        sub_modules: {
            org_charts: DigitalExperienceModule;
            access_to_entities: DigitalExperienceModule;
            basic_info: DigitalExperienceModule;
            summary: {
                access: boolean;
                modules_sections: {
                    summary_vitals: DigitalExperienceModule;
                    summary_details: DigitalExperienceModule;
                };
            };
            jurisdictions: {
                access: boolean;
                modules_sections: {
                    jurisdiction_vitals: DigitalExperienceModule;
                    jurisdiction_details: DigitalExperienceModule;
                };
            };
            associations: {
                access: boolean;
                modules_sections: {
                    people: DigitalExperienceModule;
                    businesses: DigitalExperienceModule;
                    addresses: DigitalExperienceModule;
                    locations: DigitalExperienceModule;
                    properties: DigitalExperienceModule;
                };
            };
            related_assumed_names: DigitalExperienceModule;
            governance: DigitalExperienceModule;
            historical_info: {
                access: boolean;
                modules_sections: {
                    former_names: DigitalExperienceModule;
                    notes_history_entity_organizational_history: DigitalExperienceModule;
                };
            };
            company_officials: DigitalExperienceModule;
            cap_structure_and_ownership: {
                access: boolean;
                modules_sections: {
                    general_info_cap_structure_stock_splits: DigitalExperienceModule;
                    owners_ownership_holdings: DigitalExperienceModule;
                    pending_activities: DigitalExperienceModule;
                };
            };
            entity_bank: DigitalExperienceModule;
        };
    };
    documents: {
        access: boolean;
        sub_modules: {
            tbd: DigitalExperienceModule;
        };
    };
    account_tools: {
        access: boolean;
        sub_modules: {
            users_roles: DigitalExperienceModule;
            account_settings: {
                access: boolean;
                modules_sections: {
                    billing: DigitalExperienceModule;
                };
            };
            associations: {
                access: boolean;
                modules_sections: {
                    people: DigitalExperienceModule;
                    businesses: DigitalExperienceModule;
                    addresses: DigitalExperienceModule;
                    locations: DigitalExperienceModule;
                    properties: DigitalExperienceModule;
                    registered_agent: DigitalExperienceModule;
                    sop_di: DigitalExperienceModule;
                };
            };
            custom_fields: {
                access: boolean;
                modules_sections: {
                    create: DigitalExperienceModule;
                    edit: DigitalExperienceModule;
                };
            };
            groups: DigitalExperienceModule;
            reference_tables: DigitalExperienceModule;
        };
    };
    managed_services: {
        access: boolean;
        sub_modules: {
            quotes_and_contracts: DigitalExperienceModule;
            subscriptions: DigitalExperienceModule;
        };
    };
    support_and_resources: DigitalExperienceModule;
    sop: DigitalExperienceModule;
    ucc: DigitalExperienceModule;
    business_licenses: DigitalExperienceModule;
    sec: {
        access: boolean;
        sub_modules: {
            issuer_edgar_information: DigitalExperienceModule;
            insider_information: DigitalExperienceModule;
        };
    };
    reports: {
        access: boolean;
        sub_modules: {
            reports: DigitalExperienceModule;
            audit_logs: DigitalExperienceModule;
        }
    };
}

export interface DigitalExperienceResponse {
    data: {
        modules: DigitalExperienceModules;
    };
}

export interface DigitalExperienceState {
    loading: boolean;
    loaded: boolean;
    navigationItems: Array<DataNavigationItem>;
    data: DigitalExperienceModules;
    error: ErrorState;
}
