import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { from, of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';

import { AuthorizationManagementService } from '../../../../shared/services/authorization-management/authorization-management.service';

import {
    getDigitalExperienceAction,
    getDigitalExperienceFailureAction,
    getDigitalExperienceSuccessAction
} from './digital-experience.actions';

@Injectable()
export class DigitalExperienceEffects {
    loadDigitalExperience$ = createEffect(() =>
        this.actions$.pipe(
            ofType(getDigitalExperienceAction),
            switchMap(() => {
                return from(this.authorizationManagementService.getDigitalExperience()).pipe(
                    map((response) => {
                        return getDigitalExperienceSuccessAction({ data: response?.data?.modules });
                    }),
                    catchError((err) => of(getDigitalExperienceFailureAction({ errorMessage: err })))
                );
            })
        )
    );

    constructor(
        private actions$: Actions,
        private authorizationManagementService: AuthorizationManagementService
    ) { }
}
