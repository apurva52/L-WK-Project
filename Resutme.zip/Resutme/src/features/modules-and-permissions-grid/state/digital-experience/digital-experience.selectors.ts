import { createFeatureSelector, createSelector } from '@ngrx/store';
import { cloneDeep } from 'lodash';

import { RolePermissions } from '../../../../pages/users-and-roles/roles-management/details/state/role-details.state';
import { DataNavigationItem } from '../../interfaces/permission-module.interface';
import modulesMock from '../modules-and-permissions/test-values/modules-mock-data.json';

import { filterNavigationItems, getTreeDataFromGridData } from './digital-experience.reducers';
import { DIGITAL_EXPERIENCE_FEATURE_KEY, DigitalExperienceState } from './digital-experience.state';

export const selectRootFeature = createFeatureSelector<DigitalExperienceState>(DIGITAL_EXPERIENCE_FEATURE_KEY);

export const selectNavigationItems = createSelector(selectRootFeature, (state: DigitalExperienceState) => state.navigationItems);
export const selectAcoountToolsPermissions =
    createSelector(selectRootFeature, (state: DigitalExperienceState) => state.data?.account_tools);


export const selectNavigationItemsForTreeGrid = (
    basedOnDigitalExperience: boolean,
    accountHasHcueSubscription?: boolean,
    rolePermissions?: RolePermissions) =>
    createSelector(selectRootFeature, (state: DigitalExperienceState) => {
        if (basedOnDigitalExperience && !state?.loaded) {
            return [];
        }
        const navigationItems = cloneDeep(modulesMock);
        let filteredNavigationItems: Array<DataNavigationItem> = filterNavigationItems({
            basedOnDigitalExperience,
            navigationItems,
            rolePermissions,
            digitalExperience: state.data });
        if (!accountHasHcueSubscription) {
            filteredNavigationItems = filteredNavigationItems.filter(item => item.id === 'documents' ? delete item.sub_modules : item);
        }
        return getTreeDataFromGridData(filteredNavigationItems);
    });

