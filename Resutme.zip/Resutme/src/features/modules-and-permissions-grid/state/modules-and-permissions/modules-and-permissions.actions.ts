import { createAction, props } from '@ngrx/store';

import { RoleDetails } from '../../../../pages/users-and-roles/roles-management/details/state/role-details.state';

import { DocumentsStateData } from './modules-and-permissions.state';

export enum ModulesAndPermissionsActionsTypes {
    GetDocumentsMetadata = `[Modules And Permissions][Documents] Get Documents Metadata`,
    GetDocumentsMetadataSuccess = `[Modules And Permissions][Documents] Get Documents Metadata Success`,
    GetDocumentsMetadataFailure = `[Modules And Permissions][Documents] Get Documents Metadata Failure`,
    GetRoleDetails = `[Modules And Permissions][Role Details] Get Role Details`,
    GetRoleDetailsSuccess = `[Modules And Permissions][Role Details] Get Role Details Success`,
    GetRoleDetailsFailure = `[Modules And Permissions][Role Details] Get Role Details Failure`
}

export const getDocumentsMetadataAction = createAction(
    ModulesAndPermissionsActionsTypes.GetDocumentsMetadata
);
export const getDocumentsMetadataSuccessAction = createAction(
    ModulesAndPermissionsActionsTypes.GetDocumentsMetadataSuccess,
    props<{ data: DocumentsStateData }>()
);
export const getDocumentsMetadataFailureAction = createAction(
    ModulesAndPermissionsActionsTypes.GetDocumentsMetadataFailure,
    props<{ errorMessage: string }>()
);
export const getRoleDetailsAction = createAction(
    ModulesAndPermissionsActionsTypes.GetRoleDetails,
    props<{ roleId: string }>()
);
export const getRoleDetailsSuccessAction = createAction(
    ModulesAndPermissionsActionsTypes.GetRoleDetailsSuccess,
    props<{ roleId: string, data: RoleDetails }>()
);
export const getRoleDetailsFailureAction = createAction(
    ModulesAndPermissionsActionsTypes.GetRoleDetailsFailure,
    props<{ roleId: string, errorMessage: string }>()
);

