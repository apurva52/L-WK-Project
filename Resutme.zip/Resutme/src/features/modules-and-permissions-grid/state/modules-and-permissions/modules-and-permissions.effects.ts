import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { forkJoin, from, of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';

import { AuthorizationManagementService } from '../../../../shared/services/authorization-management/authorization-management.service';

import { ReferenceTypesService } from './../../../../shared/services/reference-types/reference-types.service';
import {
    getDocumentsMetadataAction,
    getDocumentsMetadataFailureAction,
    getDocumentsMetadataSuccessAction,
    getRoleDetailsAction,
    getRoleDetailsFailureAction,
    getRoleDetailsSuccessAction
} from './modules-and-permissions.actions';


@Injectable()
export class ModulesAndPermissionsEffects {

    loadDocumentTypeMetadata$ = createEffect(() =>
        this.actions$.pipe(
            ofType(getDocumentsMetadataAction),
            switchMap(() => {
                return forkJoin({
                    documentType: this.referenceTypesService.getDocumentTypeMetadata(),
                    documentStatus: this.referenceTypesService.getDocumentStatusMetadata(),
                    documentCategory: this.referenceTypesService.getDocumentCategoryMetadata()
                }).pipe(
                    map((response) => {
                        return getDocumentsMetadataSuccessAction({ data: {
                            documentType: response.documentType?.data,
                            documentStatus: response.documentStatus?.data,
                            documentCategory: response.documentCategory?.data
                        } });
                    }),
                    catchError((err) => of(getDocumentsMetadataFailureAction({ errorMessage: err })))
                );
            })
        )
    );

    getRoleDetails$ = createEffect(() =>
            this.actions$.pipe(
                ofType(getRoleDetailsAction),
                switchMap( ({roleId}) => {
                    return from(this.authzManagementService.getRoleDetails(parseInt(roleId)))
                        .pipe(
                            map(({data}) => getRoleDetailsSuccessAction({ roleId, data }) ),
                            catchError( (err) => of(getRoleDetailsFailureAction({ roleId, errorMessage: err })))
                            );
                })
            )
    );

    constructor(
        private actions$: Actions,
        private referenceTypesService: ReferenceTypesService,
        private authzManagementService: AuthorizationManagementService
    ) { }
}
