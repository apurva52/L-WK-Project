import  * as mockRoleDetails from '../../../../pages/users-and-roles/roles-management/details/state/test-values/role-details-mock.json';

import { initialModulesAndPermissionsState as initialState } from './modules-and-permissions.reducers';
import {
    selectDocumentMetadataForm,
    selectDocumentMetadataLoaded,
    selectDocumentMetadataLoading,
    selectRoleErrorState,
    selectRoleState
} from './modules-and-permissions.selectors';

describe('Modules and Permissions selectors', () => {
    it('should return loading documents metadata', () => {
        const loadingState = selectDocumentMetadataLoading.projector({
            ...initialState,
            documents: {
                ...initialState.documents,
                loading: true
            }
        });
        expect(loadingState).toBeTruthy();
    });
    it('should return loaded documents metadata', () => {
        const loadedState = selectDocumentMetadataLoaded.projector({
            ...initialState,
            documents: {
                ...initialState.documents,
                loading: false,
                data: {
                    ...initialState.documents.data,
                    documentCategory: [{ id: 1 }]
                }
            }
        });
        expect(loadedState).toBeTruthy();
    });
    it('should metadata as form', () => {
        const defaultRestrictedDocumentsMetadata = {
            'restricted_document_types': [],
            'restricted_document_statuses': [],
            'restricted_document_categories': []
        };
        const state = selectDocumentMetadataForm(defaultRestrictedDocumentsMetadata).projector({
            ...initialState,
            documents: {
                ...initialState.documents,
                loading: false,
                data: {
                    ...initialState.documents.data,
                    documentCategory: [{ guid: 'UNIT_TEST', name: 'Unit Test' }]
                }
            }
        });
        expect(state.form).toBeDefined();
    });

    it('should get role details state', () => {
        const roleId = 123;
        const currentState = {
            ...initialState,
            role: {
                roleDetails: {
                    [roleId]: mockRoleDetails.data
                }
            }
        };

        const state = selectRoleState.projector(currentState);
        expect(Object.keys(state.roleDetails).length).toBeTruthy();
    });

    it('should get role details state', () => {
        const currentState = {
            ...initialState,
            role: {
                roleDetails: {
                },
                error: {
                    active: false,
                    message: 'Unit Test'
                }
            }
        };

        const state = selectRoleErrorState.projector(currentState);
        expect(Object.keys(state.error).length).toBeTruthy();
    });
});
