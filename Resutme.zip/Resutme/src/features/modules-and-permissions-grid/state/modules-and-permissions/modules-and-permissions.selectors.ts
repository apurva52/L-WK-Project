// tslint:disable:max-line-length
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { MultiselectItem } from '@wk/components-angular11';

import {
    DocumentsState,
    DocumentsStateDataItems,
    DocumentsStateForRole,
    MODULES_AND_PERMISSIONS_FEATURE_KEY,
    ModulesAndPermissionsState
} from './modules-and-permissions.state';

const isDocumentsLoaded = (state: DocumentsState) => !state.loading &&
    (!!state.data.documentType.length || !!state.data.documentStatus.length || !!state.data.documentCategory.length);
const filterMetadataDocuments = (documentMetadata: Array<MultiselectItem>): Array<string> => {
    return documentMetadata.filter(documentMetadata => !documentMetadata.isSelected).map(documentMetadata => documentMetadata.id);
};

export const filterCheckedMetadataDocumentsToService = (formValue: DocumentsStateDataItems): DocumentsStateForRole => {
    return {
        restricted_document_types: filterMetadataDocuments(formValue.documentType),
        restricted_document_statuses: filterMetadataDocuments(formValue.documentStatus),
        restricted_document_categories: filterMetadataDocuments(formValue.documentCategory)
    };
};

const getFlattenedRestrictedDocumentsMetadata = (restrictedDocumentsMetadata: DocumentsStateForRole): Array<string> =>
    Object.keys(restrictedDocumentsMetadata).map(key => (restrictedDocumentsMetadata[key])).flat();

export const buildDocumentsForm = (documentsState: DocumentsState, restrictedDocumentsMetadata: DocumentsStateForRole): FormGroup => {
    const flattenedRestrictedDocumentsMetadata = getFlattenedRestrictedDocumentsMetadata(restrictedDocumentsMetadata);
    const formArrays = Object.entries(documentsState.data).reduce((currentValue, [key, documentMetadata]) => {
        const formMetadataArray = new FormArray(
            documentMetadata.map(
                documentRef => new FormGroup({
                    id: new FormControl(documentRef.guid, [Validators.required]),
                    label: new FormControl(documentRef.name, [Validators.required]),
                    isSelected: new FormControl(flattenedRestrictedDocumentsMetadata.indexOf(documentRef.guid) === -1, [Validators.required])
                })
            )
        );
        return { ...currentValue, [key]: formMetadataArray };
    }, {});
    return new FormGroup(formArrays);
};

export const selectRootFeature = createFeatureSelector<ModulesAndPermissionsState>(MODULES_AND_PERMISSIONS_FEATURE_KEY);
export const selectDocumentMetadataLoading = createSelector(
    selectRootFeature, (state: ModulesAndPermissionsState): boolean =>
    state.documents.loading);
export const selectDocumentMetadataLoaded = createSelector(
    selectRootFeature, (state: ModulesAndPermissionsState): boolean =>
    isDocumentsLoaded(state.documents));
export const selectDocumentMetadataForm = (restrictedDocumentsMetadata: DocumentsStateForRole) => createSelector(
    selectRootFeature, (state: ModulesAndPermissionsState): { loaded: boolean, form: FormGroup } => ({
        loaded: isDocumentsLoaded(state.documents),
        form: buildDocumentsForm(state.documents, restrictedDocumentsMetadata)
    }));
export const selectRoleState = createSelector(
    selectRootFeature,
    (state: ModulesAndPermissionsState) => state.role
);
export const selectRoleErrorState = createSelector(
    selectRootFeature,
    (state: ModulesAndPermissionsState) => state.role
);
