import { MultiselectItem } from '@wk/components-angular11';

import { RoleDetails } from '../../../../pages/users-and-roles/roles-management/details/state/role-details.state';

export const MODULES_AND_PERMISSIONS_FEATURE_KEY = 'modulesAndPermissions';

export interface ErrorState {
    active: boolean;
    message: string;
}

export interface DocumentReference {
    id: number;
    guid: string;
    name: string;
    sysDefinedInd: 'Y' | 'N';
    displayOrderNo: number;
    checked: boolean;
}

export interface DocumentsStateData {
    documentType: Array<DocumentReference>;
    documentStatus: Array<DocumentReference>;
    documentCategory: Array<DocumentReference>;
}

export interface DocumentsStateDataItems {
    documentType: Array<MultiselectItem>;
    documentStatus: Array<MultiselectItem>;
    documentCategory: Array<MultiselectItem>;
}

export interface DocumentsStateForRole {
    restricted_document_types: Array<string>;
    restricted_document_statuses: Array<string>;
    restricted_document_categories: Array<string>;
}

export interface DocumentsState {
    loading: boolean;
    error: ErrorState;
    data: DocumentsStateData;
}

export interface RoleState {
    loading: boolean;
    error: ErrorState;
    roleDetails: Record<string, RoleDetails>;
}
export interface ModulesAndPermissionsState {
    documents: DocumentsState;
    role: RoleState;
}

export interface DocumentResponse {
    totalRecordCount: number;
    page: number;
    pageSize: number;
    data: Array<DocumentReference>;
}
