// tslint:disable:max-line-length
import  * as mockRoleDetails from '../../../../pages/users-and-roles/roles-management/details/state/test-values/role-details-mock.json';

import {
    getDocumentsMetadataAction,
    getDocumentsMetadataFailureAction,
    getDocumentsMetadataSuccessAction,
    getRoleDetailsAction,
    getRoleDetailsFailureAction,
    getRoleDetailsSuccessAction
} from './modules-and-permissions.actions';
import { initialModulesAndPermissionsState as initialState, modulesAndPermissionsReducer } from './modules-and-permissions.reducers';

describe('Modules and Permissions reducer', () => {
    it('should process Modules and Permissions load', () => {
        const currentState = { ...initialState };
        expect(modulesAndPermissionsReducer(currentState, getDocumentsMetadataAction())).toEqual({
            ...currentState,
            documents: {
                ...currentState.documents,
                loading: true
            }
        });
    });
    it('should process Modules and Permissions loaded', () => {
        const currentState = { ...initialState };
        expect(
            modulesAndPermissionsReducer(
                currentState,
                getDocumentsMetadataSuccessAction({
                    data: {
                        documentType: [],
                        documentStatus: [],
                        documentCategory: []
                    }
                })
            )
        ).toEqual({
            ...currentState,
            documents: {
                ...currentState.documents,
                loading: false,
                data: {
                    documentType: [],
                    documentStatus: [],
                    documentCategory: []
                }
            }
        });
    });
    it('should process Modules and Permissions failure', () => {
        const currentState = { ...initialState };
        const errorMessage = 'UNIT TEST ERROR';
        expect(modulesAndPermissionsReducer(currentState, getDocumentsMetadataFailureAction({ errorMessage }))).toEqual({
            ...currentState,
            documents: {
                ...currentState.documents,
                error: {
                    active: true,
                    message: errorMessage
                }
            }
        });
    });
    describe('Get Role Details', () => {
        it('should test getRoleDetailsAction', () => {
            const currentState = {...initialState};
            expect(modulesAndPermissionsReducer(currentState, getRoleDetailsAction({roleId: '123'}))).toEqual({
                ...currentState,
                role: {
                    ...currentState.role,
                    loading: true
                }
            });
        });
        it('should test getRoleDetailsSuccessAction', () => {
            const currentState = {...initialState};
            expect(modulesAndPermissionsReducer(currentState, getRoleDetailsSuccessAction({
                roleId: '123',
                data: mockRoleDetails.data
            }))).toEqual({
                ...currentState,
                role: {
                    ...currentState.role,
                    loading: false,
                    roleDetails: {
                        ...currentState.role.roleDetails,
                        123 : mockRoleDetails.data
                    }
                }
            });
        });

        it('should test getRoleDetailsFailureAction', () => {
            const currentState = { ...initialState };
            const errorMessage = 'UNIT TEST ERROR';
            const roleId = '123';
            expect(modulesAndPermissionsReducer(currentState, getRoleDetailsFailureAction({ roleId, errorMessage }))).toEqual({
                ...currentState,
                role: {
                    ...currentState.role,
                    error: {
                        active: true,
                        message: errorMessage
                    }
                }
            });
        });
    });
});
