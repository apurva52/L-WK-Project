import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { Observable, of, ReplaySubject, throwError } from 'rxjs';

import { AuthorizationManagementService } from '../../../../shared/services/authorization-management/authorization-management.service';
import { ReferenceTypesService } from '../../../../shared/services/reference-types/reference-types.service';

import { ModulesAndPermissionsActionsTypes } from './modules-and-permissions.actions';
import { ModulesAndPermissionsEffects } from './modules-and-permissions.effects';
import { initialModulesAndPermissionsState } from './modules-and-permissions.reducers';
import { MODULES_AND_PERMISSIONS_FEATURE_KEY } from './modules-and-permissions.state';


describe('ModulesAndPermissionsEffects', () => {
    let actions$: Observable<any>;
    let modulesAndPermissionsEffects: ModulesAndPermissionsEffects;
    let result: any = null;
    let error: any = null;

    const referenceTypesService = jasmine.createSpyObj<any>(
        'ReferenceTypesService',
        [
            'getDocumentTypeMetadata',
            'getDocumentStatusMetadata',
            'getDocumentCategoryMetadata'
        ]
    );

    const authorizationManagementService = jasmine.createSpyObj<any>(
        'AuthorizationManagementService',
        [
            'getRoleDetails'
        ]
    );

    const mockSuccessResponse = of({ data: [] });

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                provideMockStore({
                    initialState: {
                        [MODULES_AND_PERMISSIONS_FEATURE_KEY]:
                            initialModulesAndPermissionsState
                    }
                }),
                provideMockActions(() => actions$),
                ModulesAndPermissionsEffects,
                {
                    provide: AuthorizationManagementService,
                    useValue: authorizationManagementService
                },
                {
                    provide: ReferenceTypesService,
                    useValue: referenceTypesService
                }
            ]
        });
        modulesAndPermissionsEffects = TestBed.inject(
            ModulesAndPermissionsEffects
        );
    });

    it('should load documents metadata', () => {
        const expectedResult = {
            type: ModulesAndPermissionsActionsTypes.GetDocumentsMetadataSuccess
        };
        referenceTypesService.getDocumentTypeMetadata.and.returnValue(
            mockSuccessResponse
        );
        referenceTypesService.getDocumentStatusMetadata.and.returnValue(
            mockSuccessResponse
        );
        referenceTypesService.getDocumentCategoryMetadata.and.returnValue(
            mockSuccessResponse
        );
        actions$ = of({
            type: ModulesAndPermissionsActionsTypes.GetDocumentsMetadata
        });
        modulesAndPermissionsEffects.loadDocumentTypeMetadata$.subscribe(
            (_result: any) => (result = _result)
        );
        expect(result.type).toEqual(expectedResult.type);
    });

    it('should fail loading documents metadata', () => {
        const expectedResult = {
            type: ModulesAndPermissionsActionsTypes.GetDocumentsMetadataFailure
        };
        referenceTypesService.getDocumentTypeMetadata.and.returnValue(
            mockSuccessResponse
        );
        referenceTypesService.getDocumentStatusMetadata.and.returnValue(
            mockSuccessResponse
        );
        referenceTypesService.getDocumentCategoryMetadata.and.returnValue(
            throwError('Error')
        );

        actions$ = of({
            type: ModulesAndPermissionsActionsTypes.GetDocumentsMetadata
        });
        modulesAndPermissionsEffects.loadDocumentTypeMetadata$.subscribe(
            (_error: any) => (error = _error)
        );
        expect(error.type).toEqual(expectedResult.type);
    });
    describe('GetRoleDetails', () => {

        it('should load role details success', () => {

            const expectedResult = {
                type: ModulesAndPermissionsActionsTypes.GetRoleDetailsSuccess
            };
            authorizationManagementService.getRoleDetails.and.returnValue(
                of({})
            );
            actions$ = of({ type: ModulesAndPermissionsActionsTypes.GetRoleDetails });

            modulesAndPermissionsEffects.getRoleDetails$.subscribe(
                (_result: any) =>  (result = _result)
            );
            expect(result.type).toEqual(expectedResult.type);
        });

        it('should fail getting role details ', () => {
            const expectedResult = {
                type: ModulesAndPermissionsActionsTypes.GetRoleDetailsFailure
            };
            authorizationManagementService.getRoleDetails.and.returnValue(
                throwError('Error')
            );
            actions$ = of({ type: ModulesAndPermissionsActionsTypes.GetRoleDetails });
            modulesAndPermissionsEffects.getRoleDetails$.subscribe(
                (_error: any) => (error = _error)
            );
            expect(error.type).toEqual(expectedResult.type);
        });

    });

});
