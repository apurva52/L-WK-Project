// tslint:disable max-file-line-count
import { createReducer, on } from '@ngrx/store';

import {
    getDocumentsMetadataAction,
    getDocumentsMetadataFailureAction,
    getDocumentsMetadataSuccessAction,
    getRoleDetailsAction,
    getRoleDetailsFailureAction,
    getRoleDetailsSuccessAction
} from './modules-and-permissions.actions';
import { ModulesAndPermissionsState } from './modules-and-permissions.state';

export const initialModulesAndPermissionsState: ModulesAndPermissionsState = {
    documents: {
        loading: false,
        error: {
            active: false,
            message: ''
        },
        data: {
            documentType: [],
            documentStatus: [],
            documentCategory: []
        }
    },
    role: {
        loading: false,
        error: {
            active: false,
            message: ''
        },
        roleDetails: {}
    }
};

export const modulesAndPermissionsReducer = createReducer(
    initialModulesAndPermissionsState,
    on(getDocumentsMetadataAction, (state) => ({
        ...state,
        documents: {
            ...state.documents,
            loading: true
        }
    })),
    on(getDocumentsMetadataSuccessAction, (state, { data }) => ({
        ...state,
        documents: {
            ...state.documents,
            loading: false,
            data
        }
    })),
    on(getDocumentsMetadataFailureAction, (state, { errorMessage }) => ({
        ...state,
        documents: {
            ...state.documents,
            loading: false,
            error: {
                active: true,
                message: errorMessage
            }
        }
    })),
    on(getRoleDetailsAction, (state) => ({
        ...state,
        role: {
            ...state.role,
            loading: true
        }
    })),
    on(getRoleDetailsSuccessAction, (state, {roleId, data}) => ({
        ...state,
        role: {
            ...state.role,
            loading: false,
            roleDetails: {
                ...state.role.roleDetails,
                [roleId] : data
            }
        }
    })),
    on(getRoleDetailsFailureAction, (state, { errorMessage }) => ({
        ...state,
        role: {
            loading: false,
            roleDetails: {
                ...state.role.roleDetails
            },
            error: {
                active: true,
                message: errorMessage
            }
        }
    }))
);
