/* tslint:disable:max-file-line-count */
/* tslint:disable:max-line-length */
import {
    CellValueChangedEvent,
    ColDef,
    GridApi,
    GridOptions,
    GridReadyEvent,
    ICellRendererParams,
    IClientSideRowModel,
    RowNode,
    ValueGetterParams,
    ValueSetterParams
} from '@ag-grid-community/core';
import {
    Component,
    EventEmitter,
    Input,
    OnDestroy,
    OnInit,
    Output
} from '@angular/core';
import {
    CTGridColumnDefinition,
    CustomHeaderComponent
} from '@ct/platform-primitives-uicomponents/grid';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { cloneDeep, isEqual, set } from 'lodash';
import { fromEvent, Observable, Subject, Subscription } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AccountService } from 'src/shared/services/account/account.service';

import {
    RolePermissions,
    rolePermissionsInitialState
} from '../../pages/users-and-roles/roles-management/details/state/role-details.state';
import { AccordionTypes } from '../../shared/interfaces/accordion-types-enum';

import { CheckboxGroupCellRendererComponent } from './cell-renderers/check-group-cell-renderer/check-group-cell-renderer.component';
import { DocumentsCellRendererComponent } from './cell-renderers/documents-cell-renderer/documents-cell-renderer.component';
import { EmptyCellRendererComponent } from './cell-renderers/empty-cell-renderer/empty-cell-renderer.component';
import { HcuePendingUpdatesRendererComponent } from './cell-renderers/hcue-pending-updates-renderer/hcue-pending-updates-renderer.component';
import { ListViewCellRendererComponent } from './cell-renderers/list-view-cell-renderer/list-view-cell-renderer.component';
import { ModuleNameCellRendererComponent } from './cell-renderers/module-name-cell-renderer/module-name-cell-renderer.component';
import { CustomRendererColumn } from './interfaces/custom-renderer-column.interface';
import {
    DataNavigationItem,
    ModulePermissionValue,
    PermissionModule,
    PermissionValue
} from './interfaces/permission-module.interface';
import {
    getDigitalExperienceAction,
    restoreDigitalExperienceAction
} from './state/digital-experience/digital-experience.actions';
import { selectNavigationItemsForTreeGrid } from './state/digital-experience/digital-experience.selectors';
import { getRoleDetailsAction } from './state/modules-and-permissions/modules-and-permissions.actions';
import { selectRoleErrorState, selectRoleState } from './state/modules-and-permissions/modules-and-permissions.selectors';
import { DocumentsStateForRole } from './state/modules-and-permissions/modules-and-permissions.state';
import mockModules from './state/modules-and-permissions/test-values/modules-mock-data.json';
type EvalType = 'some' | 'every';

interface ExpectedValue {
    key: string;
    value: any;
    evalType: EvalType;
}

interface ValidateParentValueFromChildrenParams {
    parentNode: RowNode;
    expectedValues: Array<ExpectedValue>;
}

interface AreChildrenNodesInTheSameStateParams {
    parentNode: RowNode;
    expectedValue: ExpectedValue;
}

@Component({
    selector: 'ct-modules-and-permissions-grid',
    templateUrl: './modules-and-permissions-grid.component.html',
    styleUrls: ['./modules-and-permissions-grid.component.scss']
})
export class ModulesAndPermissionsGridComponent implements OnInit, OnDestroy {
    errorFlag: boolean;
    private get rootNode(): RowNode {
        if (this.gridApi) {
            const gridRowModel = this.gridApi.getModel();
            if (gridRowModel && gridRowModel['getRootNode']) {
                return (gridRowModel as IClientSideRowModel).getRootNode();
            }
        }
        return null;
    }
    private get allNodesOriginalData(): Array<PermissionModule> {
        return this.rootNode?.allLeafChildren.map((child) => child.data) || [];
    }
    private get allNodesData(): Array<PermissionModule> {
        return this.allNodesOriginalData.map((dataItem) => {
            const data = cloneDeep(dataItem) as any;
            const { id, access, permission, controls } = data;
            const isParent = id.length === 1;
            const isValidParentPermission =
                permission === ModulePermissionValue.ACCESS_NO ||
                permission === ModulePermissionValue.ACCESS_YES;
            const isOnlyAccessModule = controls.access && !controls.permission;
            const accessValue = typeof access === 'boolean' ? access : access.value;
            const hasAccessModule = accessValue && isOnlyAccessModule;

            if (hasAccessModule || (isParent && !isValidParentPermission)) {
                data.permission = ModulePermissionValue.ACCESS_YES;
            }
            return data;
        });
    }
    @Input()
    set collapsed(value: boolean) {
        this._collapsed = value;
    }

    get isCollapsed(): boolean {
        return this._collapsed;
    }

    get accordionType(): AccordionTypes {
        if (this.disabled) {
            return AccordionTypes.Collapsed;
        }
        return this._collapsed
            ? AccordionTypes.Collapsed
            : AccordionTypes.Expanded;
    }

    private get restrictedDocumentsMetadata(): {
        restricted_documents_metadata: DocumentsStateForRole;
    } {
        return this.allNodesData.find(
            (module: PermissionModule) =>
                (module.id as Array<string>).join('/') === this.DOCUMENTS_ID
        )?.value;
    }
    @Input()
    set disabled(value: boolean) {
        this._disabled = value;
        this.updateAccessDisable();
    }
    get disabled(): boolean {
        return this._disabled;
    }

    cellRendererParams = {
        checkboxButtonOptions: [
            {
                label: '',
                value: PermissionValue.NONE,
                checked: false,
                disabled: false,
                disabledFn: (params) =>
                    this.isPermissionRadioDisabled(params, PermissionValue.NONE)
            },
            {
                label: '',
                value: PermissionValue.VIEW_ONLY,
                checked: false,
                disabled: false,
                disabledFn: (params) =>
                    this.isPermissionRadioDisabled(
                        params,
                        PermissionValue.VIEW_ONLY
                    )
            },
            {
                label: '',
                value: PermissionValue.VIEW_EDIT,
                checked: false,
                disabled: false,
                disabledFn: (params) =>
                    this.isPermissionRadioDisabled(
                        params,
                        PermissionValue.VIEW_EDIT
                    )
            },
            {
                label: '',
                value: PermissionValue.VIEW_EDIT_CREATE,
                checked: false,
                disabled: false,
                disabledFn: (params) =>
                    this.isPermissionRadioDisabled(
                        params,
                        PermissionValue.VIEW_EDIT_CREATE
                    )
            },
            {
                label: '',
                value: PermissionValue.VIEW_EDIT_CREATE_DELETE,
                checked: false,
                disabled: false,
                disabledFn: (params) =>
                    this.isPermissionRadioDisabled(
                        params,
                        PermissionValue.VIEW_EDIT_CREATE_DELETE
                    )
            }
        ]
    };

    dependentModuleSectionsPermissions: Array<{
        moduleSection: string;
        dependedOnModuleSection?: string;
        dependedOnSubModule?: string;
    }> = [
        {
            moduleSection: 'summary_vitals',
            dependedOnSubModule: 'summary'
        },
        {
            moduleSection: 'summary_details',
            dependedOnModuleSection: 'summary_vitals',
            dependedOnSubModule: 'summary'
        },
        {
            moduleSection: 'jurisdiction_vitals',
            dependedOnSubModule: 'jurisdictions'
        },
        {
            moduleSection: 'jurisdiction_details',
            dependedOnModuleSection: 'jurisdiction_vitals',
            dependedOnSubModule: 'jurisdictions'
        }
    ];

    gridDefinition: Array<CTGridColumnDefinition> = [
        {
            dataType: 'CUSTOM',
            colDef: {
                headerName: this.translateService.instant(
                    'modulesAndPermissionsGrid.grid.header.access'
                ),
                field: 'access',
                cellClass: 'grid-cell-centered grid-cell-access',
                minWidth: 120,
                maxWidth: 120,
                cellRendererSelector:
                    this.getAccessCellRendererSelector.bind(this)
            }
        },
        {
            dataType: 'STRING',
            colDef: {
                headerName: this.translateService.instant(
                    'modulesAndPermissionsGrid.grid.header.permissions'
                ),
                field: 'permission',
                minWidth: 430,
                headerComponentFramework: CustomHeaderComponent,
                headerComponentParams: {
                    headerTooltipData: this.getPermissionsHeaderTooltipData()
                },
                cellRendererSelector:
                    this.getPermissionCellRendererSelector.bind(this),
                cellRendererParams: this.cellRendererParams
            },
            cellRendererOptions: {
                useCellRenderer: 'checkCellRenderer'
            }
        },
        {
            dataType: 'STRING',
            colDef: {
                headerName: '',
                field: 'hasChildrenDifferentSelection',
                hide: true,
                minWidth: 400
            }
        }
    ];

    gridOptions: GridOptions = {
        rowClass: 'ct-row-style',
        rowModelType: 'clientSide',
        treeData: true,
        animateRows: true,
        suppressHorizontalScroll: false,
        getRowNodeId: (data) => data.id.join('/'),
        getDataPath: (data) => data.module_name,
        defaultColDef: {
            flex: 1,
            resizable: false,
            suppressMenu: true,
            sortable: false,
            filter: false
        }
    };

    autoGroupColumnDef: ColDef = {
        headerName: this.translateService.instant(
            'modulesAndPermissionsGrid.grid.header.modules'
        ),
        autoHeight: true,
        cellClass: (params) => {
            const cellClasses = ['inherit-overflow'];

            const customRendererColumn = this.getCustomRendererColumnById(
                params.node.id
            );
            if (customRendererColumn) {
                cellClasses.push('ag-cell-full-width');
            }

            return cellClasses;
        },
        cellRendererParams: {
            suppressCount: true,
            innerRenderer: 'moduleNameRenderer'
        },
        colSpan: (params) => {
            const customRendererColumn = this.getCustomRendererColumnById(
                params.node.id
            );
            if (customRendererColumn) {
                return customRendererColumn.colspan;
            }
            return 1;
        },
        cellRendererSelector: (params) => {
            const { id } = params.node;
            const isParentNode = params.node.level === 0;
            const customRendererChildColumn =
                this.getCustomRendererColumnById(id);

            if (this.isListViewCustomRender(id)) {
                params.data.hyperlinkText = this.translateService.instant(
                    `modulesAndPermissionsGrid.list_view.${
                        id === this.PEOPLE_ID
                            ? 'peopleHypelink'
                            : 'businessHyperlink'
                    }`
                );
            }

            if (!!customRendererChildColumn && !isParentNode) {
                return {
                    component: customRendererChildColumn.component,
                    params
                };
            }

            return { component: 'agGroupCellRenderer', params };
        },
        valueGetter: (params: ValueGetterParams) => {
            if (params?.data === undefined) return '...';
            const customRendererColumn = this.getCustomRendererColumnById(
                params.node.id
            );
            if (customRendererColumn?.valueGetter) {
                return customRendererColumn.valueGetter(params);
            }
            return params.data.permission;
        },
        valueSetter: (params: ValueSetterParams) =>
            !isEqual(params.newValue, params.oldValue)
    };

    customCellRendererComponents = {
        moduleNameRenderer: ModuleNameCellRendererComponent,
        documentsCellRenderer: DocumentsCellRendererComponent,
        checkCellRenderer: CheckboxGroupCellRendererComponent,
        listViewRenderer: ListViewCellRendererComponent,
        emptyRenderer: EmptyCellRendererComponent,
        hcuePendingUpdatesRenderer: HcuePendingUpdatesRendererComponent
    };

    treeData: Observable<Array<PermissionModule>>;

    _collapsed = false;


    @Input() gridData: Array<DataNavigationItem> = mockModules;
    @Input() rolePermissions: RolePermissions;
    @Input() basedOnDigitalExperience: boolean;
    @Input() headerIconClass: string;
    @Input() discardChangesEvent: Observable<void>;
    @Input() roleId: string;

    @Output() cellValueChanged: EventEmitter<PermissionModule> =
        new EventEmitter();
    @Output() permissionsChanged: EventEmitter<RolePermissions> =
        new EventEmitter();
    accordionStyle: AccordionTypes = AccordionTypes.Collapsed;

    isInitialized = false;
    loading = false;
    private _disabled: boolean;

    private readonly PERMISSION_KEY = 'permission';
    private readonly ACCESS_KEY = 'access';
    private readonly PEOPLE_ID = 'account_tools/associations/people/list_view';
    private readonly BUSINESS_ID =
        'account_tools/associations/businesses/list_view';
    private readonly DOCUMENTS_ID = 'documents/documents_metadata';
    private readonly DOCUMENTS_METADATA_ID =
        'documents/documents_metadata/documents_metadata_children';
    private customRendererColumns: Array<CustomRendererColumn> = [
        {
            id: 'activities/hcue_pending_updates',
            colspan: this.gridDefinition.length,
            component: 'hcuePendingUpdatesRenderer',
            valueGetter: (params) => params.data.permission
        },
        {
            id: this.DOCUMENTS_METADATA_ID,
            colspan: this.gridDefinition.length,
            component: 'documentsCellRenderer',
            valueGetter: () =>
                this.rolePermissions?.restricted_documents_metadata || {}
        },
        {
            id: this.PEOPLE_ID,
            colspan: this.gridDefinition.length,
            component: 'listViewRenderer'
        },
        {
            id: this.BUSINESS_ID,
            colspan: this.gridDefinition.length,
            component: 'listViewRenderer'
        }
    ];

    private gridApi: GridApi;
    private readonly levelsToUpdateMap = {
        1: 'modules',
        2: 'sub_modules',
        3: 'module_sections',
        4: 'nested_content'
    };

    private sortedItemsSubcription: Subscription;
    private destroyed$: Subject<boolean> = new Subject();
    private accountHasHcueSubscription: boolean;

    constructor(
        private translateService: TranslateService,
        private store$: Store,
        private accountService: AccountService
    ) {}

    async ngOnInit(): Promise<void> {
        this.accountHasHcueSubscription =
            await this.accountService.accountHasHcueSubscription();
        this.subscribeToDiscardChangesEvent();
        !this.isCollapsed && this.rolePermissions && this.initialize();
    }

    ngOnDestroy(): void {
        if (this.gridApi) {
            this.gridApi.removeEventListener(
                'firstDataRendered',
                this.updatePermissionsData
            );
        }
        if (this.sortedItemsSubcription) {
            this.sortedItemsSubcription.unsubscribe();
        }

        this.destroyed$.next();
        this.destroyed$.complete();
        if (this.basedOnDigitalExperience) {
            this.store$.dispatch(restoreDigitalExperienceAction());
        }
    }

    onToggleAccordion(): void {
        this._collapsed = !this._collapsed;
        this.accordionStyle = this._collapsed
            ? AccordionTypes.Collapsed
            : AccordionTypes.Expanded;
        !this.isInitialized && this.subscribeToRoleDetails();
    }

    onCellValueChanged(cell: CellValueChangedEvent): void {
        const { node, data, colDef, source } = cell;
        if (!!source) {
            return;
        }
        this.updatePermissionValue(node, colDef.field, data);
        this.updateAccessValue(node, colDef.field, data);
        this.validateParentValuesFromChildrenNode(node);
        this.validateParentValuesFromChildrenNode(node, true);

        this.cellValueChanged.emit(data);
        this.updatePermissionsData();
    }

    onGridReady(event: GridReadyEvent): void {
        this.gridApi = event.api;
        this.gridApi.setDomLayout('autoHeight');
        this.gridApi.setSideBarVisible(false);
        this.gridApi.showLoadingOverlay();
        fromEvent(window, 'resize')
            .pipe(takeUntil(this.destroyed$))
            .subscribe(() => {
                this.gridApi.sizeColumnsToFit();
            });
        this.gridApi.addEventListener(
            'firstDataRendered',
            this.updatePermissionsData.bind(this)
        );
    }

    refreshTable(): void {
        this.errorFlag = false;
        this.subscribeToRoleDetails();
    }

    filterUnsuportedModulesTemp(updatedPermissions): RolePermissions {
        const filteredPermissions = cloneDeep(rolePermissionsInitialState);
        Object.keys(this.levelsToUpdateMap).forEach((level) => {
            const levelId = this.levelsToUpdateMap[level];
            Object.keys(filteredPermissions[levelId]).forEach((moduleId) => {
                const currentModule = updatedPermissions[levelId]?.[moduleId];
                const filteredModule = filteredPermissions[levelId][moduleId];
                if (!!currentModule) {
                    filteredPermissions[levelId][moduleId] =
                        typeof currentModule === 'number'
                            ? currentModule
                            : { ...filteredModule, ...currentModule };
                }
            });
        });
        return filteredPermissions;
    }

    getNodeFromParent(parentNode: RowNode, nodeId: string): RowNode {
        if (!parentNode || !nodeId) {
            return null;
        }
        return parentNode.childrenAfterGroup.find(
            (child) => child.data.id.at(-1) === nodeId
        );
    }

    getPermissionCellRendererSelector(params: ICellRendererParams): {
        component: string;
        params: ICellRendererParams;
    } {
        const isAllowedPermission = params.data.controls.permission;
        params.colDef.cellRendererParams = {};
        if (isAllowedPermission) {
            params.colDef.cellRendererParams = this.cellRendererParams;
        }
        return { component: 'checkCellRenderer', params };
    }

    getAccessCellRendererSelector(params: ICellRendererParams): {
        component: string;
        params: ICellRendererParams;
    } {
        if (params.data.controls.access) {
            return { component: 'switchCellRenderer', params };
        }
        return { component: 'emptyRenderer', params };
    }

    overrideHiddenChildrenPermissions(
        currentPermissions: RolePermissions
    ): RolePermissions {
        const modulesWithOverridePermissions = mockModules.filter(
            ({ sub_modules }) => {
                return sub_modules?.some(
                    (sub) => sub.overrideSubmodulePermissions
                );
            }
        );

        modulesWithOverridePermissions.forEach((module) => {
            const moduleId = module.id;
            const modulePermission = currentPermissions.modules[moduleId];
            module?.sub_modules.forEach((sub) => {
                const submoduleId = sub.id;
                currentPermissions.sub_modules[moduleId][submoduleId] =
                    modulePermission === ModulePermissionValue.ACCESS_YES
                        ? PermissionValue.VIEW_EDIT_CREATE_DELETE
                        : PermissionValue.NONE;
            });
        });

        return currentPermissions;
    }

    private validateParentValuesFromChildrenNode(
        node: RowNode,
        realParent: boolean = false
    ): void {
        const isParentNode = node.level === 0;
        const parent = realParent
            ? this.getNodeById(node.data.id.slice(0, -1))
            : node.parent;
        if (!isParentNode && !parent) {
            return;
        }
        if (!isParentNode) {
            this.validateParentValueFromChildren({
                parentNode: parent,
                expectedValues: [
                    {
                        key: this.PERMISSION_KEY,
                        value: PermissionValue.NONE,
                        evalType: 'every'
                    },
                    {
                        key: this.PERMISSION_KEY,
                        value: PermissionValue.VIEW_ONLY,
                        evalType: 'every'
                    },
                    {
                        key: this.PERMISSION_KEY,
                        value: PermissionValue.VIEW_EDIT,
                        evalType: 'every'
                    },
                    {
                        key: this.PERMISSION_KEY,
                        value: PermissionValue.VIEW_EDIT_CREATE,
                        evalType: 'every'
                    },
                    {
                        key: this.PERMISSION_KEY,
                        value: PermissionValue.VIEW_EDIT_CREATE_DELETE,
                        evalType: 'every'
                    }
                ]
            });
        }
        this.validateParentPermissionValue(isParentNode ? node : parent);
        if (!isParentNode && parent) {
            this.validateParentValuesFromChildrenNode(parent, realParent);
        }
    }

    private subscribeToRoleDetails(): void {
        this.loading = true;
        this.store$.dispatch(getRoleDetailsAction({ roleId: this.roleId }));
        this.store$
            .select(selectRoleState)
            .pipe(takeUntil(this.destroyed$))
            .subscribe(({ loading, roleDetails }) => {
                if (loading) return;
                this.rolePermissions = roleDetails[this.roleId];
                this.initialize();
            });
        this.store$
            .select(selectRoleErrorState)
            .pipe(takeUntil(this.destroyed$))
            .subscribe(({ loading, roleDetails, error }) => {
                if (loading) return;
                if (!error.active) return;
                this.isInitialized = false;
                this.loading = false;
                this.errorFlag = true;
            });
    }
    private subscribeToDiscardChangesEvent(): void {
        if (!this.discardChangesEvent) return;
        this.discardChangesEvent
            .pipe(takeUntil(this.destroyed$))
            .subscribe(() => {
                this.isInitialized = false;
                this.loading = true;
                this.initialize();
            });
    }

    private initialize(): void {
        if (this.isInitialized) return;
        this.treeData = this.store$.select(
            selectNavigationItemsForTreeGrid(
                this.basedOnDigitalExperience,
                this.accountHasHcueSubscription,
                this.rolePermissions
            )
        );
        if (this.sortedItemsSubcription) {
            this.sortedItemsSubcription.unsubscribe();
        }
        this.sortedItemsSubcription = this.treeData
            ?.pipe(takeUntil(this.destroyed$))
            .subscribe((data) => {
                data.sort((a, b) => a.order - b.order);
                data.forEach((item) => {
                    if (typeof item.access === 'boolean') {
                        item.access = {
                            value: item.access,
                            disabled: !!this.disabled
                        };
                    } else {
                        item.access.disabled = !!this.disabled;
                    }
                });
            });
        if (this.basedOnDigitalExperience) {
            this.store$.dispatch(
                getDigitalExperienceAction({ navigationItems: this.gridData })
            );
        }
        this.isInitialized = true;
        this.loading = false;
        this.errorFlag = false;
    }

    private updateAccessDisable(): void {
        this.allNodesOriginalData.forEach((dataItem) => {
            if (typeof dataItem.access === 'boolean') {
                dataItem.access = {
                    value: dataItem.access,
                    disabled: !!this.disabled
                };
            } else {
                dataItem.access = {
                    ...dataItem.access,
                    disabled: !!this.disabled
                };
            }
        });
        this.gridApi?.redrawRows();
    }

    private updatePermissionsData(): void {
        const updatedPermissions = {};
        this.allNodesData.forEach((module: PermissionModule) => {
            const levelToUpdate = this.levelsToUpdateMap[module.id.length];
            const pathToUpdate = `${levelToUpdate}.${(
                module.id as Array<string>
            ).join('.')}`;
            set(updatedPermissions, pathToUpdate, module.permission);
        });
        const filteredPermissions =
            this.filterUnsuportedModulesTemp(updatedPermissions);

        this.permissionsChanged.emit({
            ...this.overrideHiddenChildrenPermissions(filteredPermissions),
            ...this.restrictedDocumentsMetadata
        });
    }

    private updateChildrenNodesValue(
        node: RowNode,
        key: string,
        value: any
    ): void {
        if (node) {
            this.updateSpecificChildrenNodesValue(node, key, value);
            this.updateSpecificChildrenNodesValue(node, key, value, true);
        }
    }

    private updateSpecificChildrenNodesValue(
        node: RowNode,
        key: string,
        value: any,
        realChildren?: boolean
    ): void {
        const children = realChildren
            ? this.getChildrenNodesByParentNodeId(node.data.id)
            : node.childrenAfterGroup;
        (children || []).forEach((childNode) => {
            this.setChildNodeAllowedValue(childNode, key, value);
            this.updateChildrenNodesValue(childNode, key, value);
        });
    }

    private setChildNodeAllowedValue(
        childNode: RowNode,
        key: string,
        value: any
    ): void {
        let valueToSet = value;
        if (
            key === this.PERMISSION_KEY &&
            childNode.data?.allowed_permissions &&
            !childNode.data.allowed_permissions.includes(value)
        ) {
            const maxAllowed = Math.max(...childNode.data.allowed_permissions);
            valueToSet =
                maxAllowed < value
                    ? maxAllowed
                    : Math.min(...childNode.data.allowed_permissions);
        }
        if (
            key === this.ACCESS_KEY ||
            childNode.data?.controls?.permission === true
        ) {
            childNode.setDataValue(key, valueToSet, 'side-effect');
        }
    }

    private updateParentNodesValue(
        node: RowNode,
        key: string,
        value: any
    ): void {
        if (node) {
            this.updateSpecificParentNodesValue(node, key, value);
            this.updateSpecificParentNodesValue(node, key, value, true);
        }
    }

    private updateSpecificParentNodesValue(
        node: RowNode,
        key: string,
        value: any,
        realParent: boolean = false
    ): void {
        const parent = realParent
            ? this.getNodeById(node.data.id.slice(0, -1))
            : node.parent;
        if (parent && parent.level >= 0) {
            if (
                key === this.ACCESS_KEY &&
                (value ||
                    (!value &&
                        parent.childrenAfterGroup.every((node) =>
                            typeof node.data.access === 'boolean'
                                ? node.data.access === value
                                : node.data.access.value === value
                        )))
            ) {
                const disabled =
                    typeof parent.data.access === 'boolean'
                        ? false
                        : parent.data.access.disabled;
                parent.setDataValue(key, { value, disabled }, 'side-effect');
                this.updateParentNodesValue(parent, key, value);
            }
        }
    }

    private updatePermissionValue(
        node: RowNode,
        eventSource: string,
        value: { access: boolean; permission: PermissionValue }
    ): void {
        let permission = value.permission;
        if (eventSource === this.ACCESS_KEY) {
            permission = value.access
                ? PermissionValue.VIEW_ONLY
                : PermissionValue.NONE;
            node.setDataValue(this.PERMISSION_KEY, permission, 'side-effect');
        }
        this.updateChildrenNodesValue(node, this.PERMISSION_KEY, permission);
        setTimeout(() =>
            this.validateDependedModuleSectionPermissions(node, permission)
        );
    }

    private updateAccessValue(
        node: RowNode,
        eventSource: string,
        value: { access: boolean | any; permission: PermissionValue }
    ): void {
        if (eventSource === this.PERMISSION_KEY) {
            const access = value.permission !== PermissionValue.NONE;
            const disabled =
                typeof node.data.access === 'boolean'
                    ? false
                    : node.data.access.disabled;
            node.setDataValue(
                this.ACCESS_KEY,
                { value: access, disabled },
                'side-effect'
            );
        }
    }

    private validateParentPermissionValue(parentNode: RowNode): void {
        const childrenAfterGroup = [
            ...this.getChildrenNodesByParentNodeId(parentNode.data.id),
            ...(parentNode.childrenAfterGroup || [])
        ];
        const hasChildrenDifferentSelection = childrenAfterGroup.some(
            ({ data }: RowNode, _index, arr) => {
                const isOnlyAccessModule =
                    data.controls.access && !data.controls.permission;
                return (
                    data.permission !== arr[0].data.permission &&
                    !isOnlyAccessModule
                );
            }
        );
        parentNode.setDataValue(
            'hasChildrenDifferentSelection',
            hasChildrenDifferentSelection,
            'side-effect'
        );
        if (hasChildrenDifferentSelection) {
            const childrenValues = childrenAfterGroup.map((node) =>
                node.data.permission === ModulePermissionValue.ACCESS_YES
                    ? PermissionValue.VIEW_ONLY
                    : node.data.permission
            );
            parentNode.setDataValue(
                this.PERMISSION_KEY,
                Math.max(...childrenValues),
                'side-effect'
            );
        }

        childrenAfterGroup.forEach((node) =>
            this.validateParentPermissionValue(node)
        );
    }

    private areChildrenNodesInTheSameState({
        parentNode,
        expectedValue
    }: AreChildrenNodesInTheSameStateParams): boolean {
        const allChildren = [
            ...this.getChildrenNodesByParentNodeId(parentNode.data.id),
            ...(parentNode.childrenAfterGroup || [])
        ];
        return allChildren[expectedValue.evalType]((childNode: RowNode) => {
            const isObject =
                typeof childNode.data[expectedValue.key] === 'object';
            const accessValue = isObject
                ? childNode.data[expectedValue.key].value
                : childNode.data[expectedValue.key];
            return accessValue === expectedValue.value;
        });
    }

    private validateParentValueFromChildren({
        parentNode,
        expectedValues
    }: ValidateParentValueFromChildrenParams): void {
        expectedValues.forEach((expectedValue) => {
            const isValueExpected = this.areChildrenNodesInTheSameState({
                parentNode,
                expectedValue
            });
            if (isValueExpected) {
                parentNode.setDataValue(
                    expectedValue.key,
                    expectedValue.value,
                    'side-effect'
                );
            }
        });
    }

    private validateDependedModuleSectionPermissions(
        node: RowNode,
        value: PermissionValue
    ): void {
        const moduleSectionIdCount = 3;
        if (node?.data?.id && node.data.id.length === moduleSectionIdCount) {
            const dependedSubModule =
                this.dependentModuleSectionsPermissions.find(
                    (item) =>
                        item.dependedOnModuleSection === node.data.id.at(-1)
                );
            if (dependedSubModule) {
                const dependedNode = this.getNodeFromParent(
                    node.parent,
                    dependedSubModule.moduleSection
                );
                if (dependedNode.data.permission > value) {
                    dependedNode.setDataValue(this.PERMISSION_KEY, value);
                }
            }
        }
    }

    private isPermissionRadioDisabled(
        { node }: ICellRendererParams,
        value: PermissionValue
    ): boolean {
        if (
            this.disabled ||
            (node?.data?.allowed_permissions &&
                !node.data.allowed_permissions.includes(value))
        ) {
            return true;
        }
        const moduleSectionIdCount = 3;
        if (node?.data?.id && node.data.id.length === moduleSectionIdCount) {
            const dependedModuleSection =
                this.dependentModuleSectionsPermissions.find(
                    (item) => item.moduleSection === node.data.id.at(-1)
                );
            if (dependedModuleSection) {
                const dependedOnModuleSectionNode = this.getNodeFromParent(
                    node.parent,
                    dependedModuleSection.dependedOnModuleSection
                );
                const dependedOnSubModuleNode = this.getNodeFromParent(
                    node.parent?.parent,
                    dependedModuleSection.dependedOnSubModule
                );
                return (
                    (dependedOnModuleSectionNode &&
                        dependedOnModuleSectionNode.data.permission < value) ||
                    (dependedOnSubModuleNode &&
                        dependedOnSubModuleNode.data.permission < value)
                );
            }
        }
        return false;
    }

    private getPermissionsHeaderTooltipData(): string {
        return `
            <ul><li><span>N</span> <span class="margin-style-n">= ${this.translateService.instant(
                'modulesAndPermissionsGrid.grid.tooltip.N'
            )}</span></li>
            <li><span>V</span> <span class="margin-style-v">= ${this.translateService.instant(
                'modulesAndPermissionsGrid.grid.tooltip.V'
            )}</span></li>
            <li><span>V/E</span> <span class="margin-style-ve">= ${this.translateService.instant(
                'modulesAndPermissionsGrid.grid.tooltip.VE'
            )}</span></li>
            <li><span>V/E/C</span> <span class="margin-style-vec">= ${this.translateService.instant(
                'modulesAndPermissionsGrid.grid.tooltip.VEC'
            )}</span></li>
            <li><span>V/E/C/D</span> <span class="margin-style-vecd">= ${this.translateService.instant(
                'modulesAndPermissionsGrid.grid.tooltip.VECD'
            )}</span></li></ul>
        `;
    }

    private getCustomRendererColumnById(
        columnId: string
    ): CustomRendererColumn {
        return this.customRendererColumns.find(
            (customRendererColumn) => customRendererColumn.id === columnId
        );
    }

    private isListViewCustomRender(nodeId: string): boolean {
        return nodeId === this.PEOPLE_ID || nodeId === this.BUSINESS_ID;
    }

    private getNodeById(id: Array<string>): RowNode {
        return this.rootNode?.allLeafChildren.find(
            (child) => child.data.id.toString() === id.toString()
        );
    }

    private getChildrenNodesByParentNodeId(
        parentNodeId: Array<string>
    ): Array<RowNode> {
        return (
            this.rootNode?.allLeafChildren.filter(
                (n) =>
                    n.data.id.slice(0, -1).toString() ===
                    parentNodeId.toString()
            ) || []
        );
    }
}
