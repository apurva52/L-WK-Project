import { ValueGetterParams } from '@ag-grid-community/core';
export interface CustomRendererColumn {
    id: string;
    colspan?: number;
    component: string;
    valueGetter?: (params: ValueGetterParams) => any;
}
