import { NavigationItem } from '@wk/components';

export interface PermissionModuleAccess {
    value: boolean;
    disabled: boolean;
}

export enum ModulePermissionValue {
    ACCESS_NO = 0,
    ACCESS_YES = 13
}

export enum PermissionValue {
    NONE = 0,
    VIEW_ONLY = 1,
    VIEW_EDIT = 3,
    VIEW_EDIT_CREATE = 5,
    VIEW_EDIT_CREATE_DELETE = 8
}

export interface DataNavigationItem extends NavigationItem {
    value?: any;
    sub_modules?: Array<DataNavigationItem>;
    modules_sections?: Array<DataNavigationItem>;
    nested_content?: Array<DataNavigationItem>;
    access?: PermissionModuleAccess | boolean;
    permission?: PermissionValue | ModulePermissionValue;
    order?: number;
    hasHyperlink?: boolean;
    display?: boolean;
    allowed_permissions?: Array<number>;
    overrideSubmodulePermissions?: boolean;
    controls: {
        access: boolean;
        permission: boolean;
    };
    virtual_parent_ids?: Array<string>;
}

export interface PermissionModule {
    id: Array<string> | string;
    virtual_id: Array<string>;
    module_name: Array<string> | string;
    iconName?: string;
    value: any;
    access: PermissionModuleAccess | boolean;
    permission: PermissionValue | ModulePermissionValue;
    hasChildrenDifferentSelection?: boolean;
    order?: number;
    hasHyperlink?: boolean;
    allowed_permissions?: Array<number>;
    controls: {
        access: boolean;
        permission: boolean;
    };
}
