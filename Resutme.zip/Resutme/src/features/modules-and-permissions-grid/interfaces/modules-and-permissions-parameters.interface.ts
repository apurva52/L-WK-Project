import { RolePermissions } from 'src/pages/users-and-roles/roles-management/details/state/role-details.state';

import { DigitalExperienceModules } from '../state/digital-experience/digital-experience.state';

import { DataNavigationItem } from './permission-module.interface';

export interface ModulesAndPermissionsParams {
    digitalExperience?: DigitalExperienceModules;
    rolePermissions?: RolePermissions;
    navigationItems: Array<DataNavigationItem>;
}

export interface GetNavigationItemsParameters extends ModulesAndPermissionsParams {
    basedOnDigitalExperience: boolean;
}

export interface FilterNavigationItemsParams extends ModulesAndPermissionsParams {
    basePath: string;
    mapCallback?: Function;
}

export interface RolePermissionsParameters {
    rolePermissions: RolePermissions;
}
export interface SetAccessAndPermissionValueParameters extends RolePermissionsParameters {
    basePath: string;
    navigationItem: DataNavigationItem;
}
export interface ShouldDisplayPermissionParameters extends RolePermissionsParameters {
    path: string;
}


