/* tslint:disable:max-file-line-count */
/* tslint:disable:max-line-length */
import {
    CellClassFunc,
    ValueGetterFunc,
    ValueGetterParams,
    ValueSetterFunc,
    ValueSetterParams
} from '@ag-grid-community/all-modules';
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
    AclClaimsBasedDefinitionService,
    AclDefinitionService,
    AuthorizationService
} from '@ct/core-ui-ng';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { of } from 'rxjs';
import { AccountService } from 'src/shared/services/account/account.service';

import { roleDetailsInitialState, RolePermissions } from '../../pages/users-and-roles/roles-management/details/state/role-details.state';
import mockRolePermissions from '../../pages/users-and-roles/roles-management/details/state/test-values/role-details-mock.json';
import { AccordionTypes } from '../../shared/interfaces/accordion-types-enum';

import { ModuleNameCellRendererComponent } from './cell-renderers/module-name-cell-renderer/module-name-cell-renderer.component';
import {
    ModulePermissionValue,
    PermissionValue
} from './interfaces/permission-module.interface';
import { ModulesAndPermissionsGridComponent } from './modules-and-permissions-grid.component';
import { restoreDigitalExperienceAction } from './state/digital-experience/digital-experience.actions';
import { initialDXState } from './state/digital-experience/digital-experience.reducers';
import { selectNavigationItemsForTreeGrid } from './state/digital-experience/digital-experience.selectors';
import {
    DIGITAL_EXPERIENCE_FEATURE_KEY,
    DigitalExperienceState
} from './state/digital-experience/digital-experience.state';
import { initialModulesAndPermissionsState } from './state/modules-and-permissions/modules-and-permissions.reducers';
import { selectRoleErrorState, selectRoleState } from './state/modules-and-permissions/modules-and-permissions.selectors';
import { MODULES_AND_PERMISSIONS_FEATURE_KEY } from './state/modules-and-permissions/modules-and-permissions.state';
import mockModules from './state/modules-and-permissions/test-values/modules-mock-data.json';

describe('ModulesAndPermissionsGridComponent', () => {
    let component: ModulesAndPermissionsGridComponent;
    let fixture: ComponentFixture<ModulesAndPermissionsGridComponent>;
    const authorizationServiceMock = jasmine.createSpyObj(
        'AuthorizationService',
        ['getModuleClaims', 'getFieldClaims']
    );
    let store$: MockStore<DigitalExperienceState>;
    const roleId = 123;
    const accountServiceMock = jasmine.createSpyObj('AccountService', ['accountHasHcueSubscription']);

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                ModulesAndPermissionsGridComponent,
                ModuleNameCellRendererComponent
            ],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                {
                    provide: AclDefinitionService,
                    useClass: AclClaimsBasedDefinitionService
                },
                {
                    provide: AuthorizationService,
                    useValue: authorizationServiceMock
                },
                provideMockStore({
                    initialState: {
                        [DIGITAL_EXPERIENCE_FEATURE_KEY]: initialDXState,
                        [MODULES_AND_PERMISSIONS_FEATURE_KEY]:
                            initialModulesAndPermissionsState
                    },
                    selectors: [
                        {
                            selector: selectNavigationItemsForTreeGrid(
                                false,
                                true,
                                mockRolePermissions.data
                            ),
                            value: []
                        },
                        {
                            selector: selectRoleState,
                            value: {
                                loading: false,
                                error: null,
                                roleDetails: {
                                    [roleId]: roleDetailsInitialState
                                }
                            }
                        },
                        {
                            selector: selectRoleErrorState,
                            value: {
                                loading: false,
                                error: {
                                    active: true,
                                    message: 'Unit Test'
                                },
                                roleDetails: {
                                }
                            }
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                },
                {
                    provide: AccountService,
                    useValue: accountServiceMock
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        accountServiceMock.accountHasHcueSubscription.and.returnValue(Promise.resolve(true));
        store$ = TestBed.inject(MockStore);
        TestBed.inject(AuthorizationService);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ModulesAndPermissionsGridComponent);
        component = fixture.componentInstance;
        component['discardChangesEventSubcription'] = of(null).subscribe();
        component['discardChangesEvent'] = of(null);
        component.rolePermissions = mockRolePermissions.data;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
        component.ngOnDestroy();
    });

    it('should get a disabled accordion type', () => {
        component.disabled = true;
        expect(component.accordionType).toEqual(AccordionTypes.Collapsed);
        component.ngOnDestroy();
    });

    it('should set collapsed status', () => {
        component.collapsed = true;
        expect(component._collapsed).toBeTruthy();
        component.ngOnDestroy();
    });

    it('should destroy based on Digital Experience', () => {
        spyOn(store$, 'dispatch');
        component.basedOnDigitalExperience = true;
        component.ngOnDestroy();
        expect(store$.dispatch).toHaveBeenCalledWith(
            restoreDigitalExperienceAction()
        );
    });

    it('should get all nodes', () => {
        component['gridApi'] = {
            removeEventListener: jasmine.createSpy(),
            getModel: () => ({
                getRootNode: () => ({
                    allLeafChildren: [
                        {
                            data: {
                                id: ['1'],
                                access: true,
                                permission: 123,
                                controls: { access: true, permission: false }
                            }
                        }
                    ]
                })
            })
        } as any;
        expect(component['allNodesData']).toBeDefined();
        component.ngOnDestroy();
    });

    it('should get api from gridReady', () => {
        const mockEvent = {
            api: {
                setSideBarVisible: jasmine.createSpy(),
                sizeColumnsToFit: jasmine.createSpy(),
                setDomLayout: jasmine.createSpy(),
                showLoadingOverlay: jasmine.createSpy(),
                getRowNode: jasmine.createSpy().and.returnValue({
                    updateData: jasmine.createSpy()
                }),
                addEventListener: (eventType, listener) => {},
                removeEventListener: () => {}
            }
        };
        component.onGridReady(mockEvent as any);
        expect(component['gridApi']).toBeDefined();
    });

    describe('Cell renderer selector', () => {
        it('should render a normal row', () => {
            const { component: componentName } =
                component.autoGroupColumnDef.cellRendererSelector({
                    node: { id: 'place_new_order' }
                } as any);
            expect(componentName).toBe('agGroupCellRenderer');
        });
        it('should render a document row', () => {
            const { component: componentName } =
                component.autoGroupColumnDef.cellRendererSelector({
                    node: { id: component['DOCUMENTS_METADATA_ID'] },
                    data: {
                        restricted_documents_metadata: {
                            restricted_document_types: [],
                            restricted_document_statuses: [],
                            restricted_document_categories: []
                        }
                    }
                } as any);
            expect(componentName).toBe('documentsCellRenderer');
        });
        it('should render a people nested content', () => {
            const { component: componentName, params } =
                component.autoGroupColumnDef.cellRendererSelector({
                    node: { id: component['PEOPLE_ID'], level: 1 },
                    data: {}
                } as any);
            expect(componentName).toBe('listViewRenderer');
            expect(params.data.hyperlinkText).toBeDefined();
        });
        it('should render a business nested content', () => {
            const { component: componentName, params } =
                component.autoGroupColumnDef.cellRendererSelector({
                    node: { id: component['BUSINESS_ID'], level: 1 },
                    data: {}
                } as any);
            expect(componentName).toBe('listViewRenderer');
            expect(params.data.hyperlinkText).toBeDefined();
        });
    });

    describe('Cell changes', () => {
        it('should change a parent cell value from access field ON', () => {
            const data = {
                id: ['place_new_order'],
                permission: '1',
                access: { value: true, disabled: false }
            };
            const node = {
                data,
                setDataValue: jasmine.createSpy()
            };
            const source = 'side-effect';
            component.onCellValueChanged({ node, source } as any);
            expect(node.setDataValue).not.toHaveBeenCalled();
        });

        it('should change a child cell value from access field ON', () => {
            const data = {
                id: ['compliance_events', 'system_created'],
                access: true,
                permission: '1',
                controls: { access: true, permission: true }
            };
            const node = {
                data,
                level: 0,
                setDataValue: jasmine.createSpy(),
                childrenAfterGroup: [
                    { data, level: 1, setDataValue: jasmine.createSpy() }
                ]
            };
            const colDef = { field: 'access' };
            const source = null;
            component.onCellValueChanged({ node, data, colDef, source } as any);
            expect(node.setDataValue).toHaveBeenCalled();
        });
        it('should change a parent cell value from access field OFF', () => {
            const parentData = {
                id: ['entities'],
                access: false,
                permission: '1',
                controls: { access: true, permission: true }
            };
            const nodeData = {
                id: ['entities', 'summary'],
                access: false,
                permission: '1',
                controls: { access: false, permission: true }
            };
            const data = {
                id: ['entities', 'summary', 'summary_vitals'],
                access: false,
                permission: '1',
                controls: { access: false, permission: true }
            };
            const childNode = {
                data,
                level: 1,
                setDataValue: jasmine.createSpy()
            };
            const node = {
                parentData,
                data: nodeData,
                level: 0,
                setDataValue: jasmine.createSpy(),
                childrenAfterGroup: [childNode]
            };
            const colDef = { field: 'access' };
            const source = null;
            component.gridData = mockModules;
            component.onCellValueChanged({ node, data, colDef, source } as any);
            expect(node.setDataValue).toHaveBeenCalled();
        });
        it('should change a parent cell value from permission field', () => {
            const data = {
                id: ['place_new_order'],
                access: true,
                permission: '2',
                controls: { access: false, permission: true }
            };
            const node = {
                data,
                level: 0,
                setDataValue: jasmine.createSpy(),
                childrenAfterGroup: [
                    { data, level: 1, setDataValue: jasmine.createSpy() }
                ]
            };
            const colDef = { field: 'permission' };
            const source = null;
            component.onCellValueChanged({ node, data, colDef, source } as any);
            expect(
                node.childrenAfterGroup[0].setDataValue
            ).toHaveBeenCalledWith('permission', '2', 'side-effect');
        });
        it('should change a parent cell value from a child access field', () => {
            const data = {
                id: ['place_new_order'],
                access: true,
                permission: '1',
                controls: { access: false, permission: true }
            };
            const parentNode = {
                data,
                level: 0,
                setDataValue: jasmine.createSpy(),
                childrenAfterGroup: []
            };
            const node = {
                data,
                level: 1,
                setDataValue: jasmine.createSpy(),
                parent: parentNode,
                childrenAfterGroup: []
            };
            parentNode.childrenAfterGroup.push(node);
            const colDef = { field: 'access' };
            const source = null;
            component.onCellValueChanged({ node, data, colDef, source } as any);
            expect(node.setDataValue).toHaveBeenCalled();
        });

        it('should update permissions data with nodes', () => {
            component['gridApi'] = {
                removeEventListener: jasmine.createSpy(),
                getModel: () => ({
                    getRootNode: () => ({
                        allLeafChildren: [
                            {
                                data: {
                                    id: ['1'],
                                    permission: 123,
                                    access: true,
                                    controls: {
                                        access: true,
                                        permission: false
                                    }
                                }
                            }
                        ]
                    })
                })
            } as any;
            spyOn(component.permissionsChanged, 'emit');
            component['updatePermissionsData']();
            expect(component.permissionsChanged.emit).toHaveBeenCalled();
            expect(component['allNodesData'].length).toEqual(1);
        });
    });

    it('should get node parent', () => {
        const rowNode = { childrenAfterGroup: [{ data: { id: '1' } }] } as any;
        const parentNode = component['getNodeFromParent'](rowNode, '1');
        expect(parentNode).toBeDefined();
    });

    it('should NOT get node parent', () => {
        const parentNode = component['getNodeFromParent'](null, null);
        expect(parentNode).toBeNull();
    });

    it('should get checkbox cell renderer selector with params', () => {
        const params: any = {
            data: {
                id: ['entities'],
                controls: {
                    permission: true
                }
            },
            colDef: { cellRendererParams: {} },
            node: { level: 0 }
        };
        const cellRenderer =
            component.getPermissionCellRendererSelector(params);
        expect(cellRenderer.component).toEqual('checkCellRenderer');
        expect(cellRenderer.params.colDef.cellRendererParams).not.toEqual({});
    });

    it('should remove params of check cell renderer', () => {
        const params: any = {
            data: {
                id: ['other'],
                controls: {
                    permission: false
                }
            },
            colDef: { cellRendererParams: {} },
            node: { level: 0 }
        };
        const cellRenderer =
            component.getPermissionCellRendererSelector(params);
        expect(cellRenderer.component).toEqual('checkCellRenderer');
        expect(cellRenderer.params.colDef.cellRendererParams).toEqual({});
    });

    it('should remove params of not allowed children check cell renderer', () => {
        const params: any = {
            data: {
                id: ['documents'],
                controls: {
                    permission: false
                }
            },
            colDef: { cellRendererParams: {} },
            node: { level: 1, id: 'documents/esignature' }
        };
        const cellRenderer =
            component.getPermissionCellRendererSelector(params);
        expect(cellRenderer.component).toEqual('checkCellRenderer');
        expect(cellRenderer.params.colDef.cellRendererParams).toEqual({});
    });

    it('should toggle accordion', () => {
        component.onToggleAccordion();
        expect(component._collapsed).toBeTruthy();
        expect(component.accordionStyle).toEqual(AccordionTypes.Collapsed);
    });

    it('should validate Depended ModuleSection Permissions', () => {
        spyOn(component, 'getNodeFromParent').and.returnValue({
            data: { permission: PermissionValue.VIEW_EDIT_CREATE_DELETE },
            setDataValue: jasmine.createSpy()
        } as any);
        const node = {
            data: { id: ['entities', 'summary', 'summary_vitals'] }
        };
        component['validateDependedModuleSectionPermissions'](
            node as any,
            PermissionValue.VIEW_EDIT
        );
        expect(component.getNodeFromParent).toHaveBeenCalled();
    });

    it('should refresh table', () => {
        component.isInitialized = false;
        component.refreshTable();
        expect(component.loading).toEqual(false);
        expect(component.errorFlag).toEqual(true);
    });

    it('should validate if check permission is disabled', () => {
        spyOn(component, 'getNodeFromParent').and.returnValue({
            data: { permission: 0 }
        } as any);
        const isDisabled = component['isPermissionRadioDisabled'](
            {
                node: {
                    data: { id: ['entities', 'summary', 'summary_vitals'] }
                }
            } as any,
            PermissionValue.VIEW_EDIT_CREATE_DELETE
        );
        expect(isDisabled).toBeTruthy();

        const isDisabled1 = component['isPermissionRadioDisabled'](
            {
                node: {
                    data: {
                        id: ['entities', 'summary', 'summary_vitals'],
                        allowed_permissions: [
                            PermissionValue.NONE,
                            PermissionValue.VIEW_ONLY
                        ]
                    }
                }
            } as any,
            PermissionValue.VIEW_EDIT_CREATE_DELETE
        );
        expect(isDisabled1).toBeTruthy();

        component.disabled = true;
        const isDisabled2 = component['isPermissionRadioDisabled'](
            {
                node: {
                    data: { id: ['entities', 'summary', 'summary_vitals'] }
                }
            } as any,
            PermissionValue.NONE
        );
        expect(isDisabled2).toBeTruthy();
    });

    it('should validate if check permission is disabled', () => {
        const isDisabled = component['isPermissionRadioDisabled'](
            { node: { data: { id: ['other'] } } } as any,
            PermissionValue.VIEW_EDIT_CREATE_DELETE
        );
        expect(isDisabled).toBeFalsy();
    });

    it('should get restricted metadata from node values', () => {
        component['gridApi'] = {
            removeEventListener: jasmine.createSpy(),
            getModel: () => ({
                getRootNode: () => ({
                    allLeafChildren: [
                        {
                            data: {
                                id: component['DOCUMENTS_ID'].split('/'),
                                value: 'UNIT TEST',
                                access: true,
                                controls: {
                                    access: true,
                                    permission: true
                                }
                            }
                        }
                    ]
                })
            })
        } as any;
        expect(component['restrictedDocumentsMetadata']).toBeDefined();
    });

    it('should update access disable on disabled field change', () => {
        const nodesDataMock = [
            {
                id: ['module1'],
                access: {
                    value: true,
                    disabled: false
                },
                permission: PermissionValue.VIEW_EDIT_CREATE,
                order: 1
            },
            {
                id: ['module1'],
                access: false,
                permission: PermissionValue.VIEW_EDIT_CREATE,
                order: 2
            }
        ];
        const gridApiMock: any = {
            redrawRows: (data: any) => {}
        };
        Object.defineProperty(component, 'allNodesOriginalData', {
            get: () => nodesDataMock
        });
        component['gridApi'] = gridApiMock;
        component.disabled = true;
        nodesDataMock.forEach((nodeData) => {
            expect((nodeData.access as any).disabled).toBeTruthy();
        });
    });
    it('should subscribe to roleDetails', () => {
        const spy = spyOn(store$, 'dispatch').and.callThrough();
        component._collapsed = true;
        component.isInitialized = false;
        component.onToggleAccordion();
        expect(spy).toHaveBeenCalled();
    });

    it('should get access cell renderer for specific submodules', () => {
        const params: any = {
            node: {
                level: 1
            },
            data: {
                controls: {
                    access: true
                }
            }
        };
        const { component: componentRenderer } =
            component.getAccessCellRendererSelector(params);
        expect(componentRenderer).toEqual('switchCellRenderer');
    });

    it('should get empty renderer for a regular submodule', () => {
        const params: any = {
            node: {
                level: 1
            },
            data: {
                controls: {
                    access: false
                }
            }
        };
        const { component: componentRenderer } =
            component.getAccessCellRendererSelector(params);
        expect(componentRenderer).toEqual('emptyRenderer');
    });

    it('should get full cellspan class from a default renderer', () => {
        const params: any = {
            node: {
                id: 'test'
            }
        };
        const cellClass = component.autoGroupColumnDef
            .cellClass as unknown as CellClassFunc;
        const className = cellClass(params);
        expect(className).not.toContain('ag-cell-full-width');
    });

    it('should get full cellspan class from a custom renderer', () => {
        const params: any = {
            node: {
                id: component['DOCUMENTS_METADATA_ID']
            }
        };
        const cellClass = component.autoGroupColumnDef
            .cellClass as unknown as CellClassFunc;
        const className = cellClass(params);
        expect(className).toContain('ag-cell-full-width');
    });

    it('should get colspan class from a default renderer', () => {
        const params: any = {
            node: {
                id: 'test'
            }
        };
        const colspan = component.autoGroupColumnDef.colSpan(params);
        expect(colspan).toEqual(1);
    });

    it('should get colspan class from a default renderer', () => {
        const params: any = {
            node: {
                id: 'activities/hcue_pending_updates'
            }
        };
        const colspan = component.autoGroupColumnDef.colSpan(params);
        expect(colspan).toEqual(component.gridDefinition.length);
    });

    it('should get value getter from custom column without valueGetter handler', () => {
        const params = {
            node: {
                id: 'activities/to_dos_all_account',
                level: 1
            },
            data: {
                permission: 8
            }
        } as unknown as ValueGetterParams;
        const valueGetter = component.autoGroupColumnDef
            .valueGetter as unknown as ValueGetterFunc;
        expect(valueGetter(params)).toEqual(params.data.permission);
    });

    it('should get value getter from custom column with valueGetter handler', () => {
        const params = {
            node: {
                id: component['DOCUMENTS_METADATA_ID'],
                level: 1,
                parent: {
                    data: {
                        value: { restricted_documents_metadata: {} }
                    }
                }
            },
            data: {
                permission: 13
            }
        } as unknown as ValueGetterParams;
        const valueGetter = component.autoGroupColumnDef
            .valueGetter as unknown as ValueGetterFunc;
        expect(valueGetter(params)).toEqual({});
    });

    it('should get value getter from another module', () => {
        const params = {
            node: {
                id: 'test',
                level: 1
            },
            data: {
                permission: 1
            }
        } as unknown as ValueGetterParams;
        const valueGetter = component.autoGroupColumnDef
            .valueGetter as unknown as ValueGetterFunc;
        expect(valueGetter(params)).toEqual(params.data.permission);
    });

    it('should get value setter', () => {
        const params = {
            newValue: 1,
            oldValue: 0
        } as unknown as ValueSetterParams;
        const valueSetter = component.autoGroupColumnDef
            .valueSetter as unknown as ValueSetterFunc;
        expect(valueSetter(params)).toBeTruthy();
    });

    it('should return root node', () => {
        const expectedRootNode = {
            level: -1
        };
        const gridApiMock = {
            getModel: () => ({})
        };
        const gridApiWithRootNodeMock = {
            getModel: () => ({
                getRootNode: () => expectedRootNode
            })
        };
        expect((component as any).rootNode).toEqual(null);
        (component as any).gridApi = gridApiMock;
        expect((component as any).rootNode).toEqual(null);
        (component as any).gridApi = gridApiWithRootNodeMock;
        expect((component as any).rootNode).toEqual(expectedRootNode);
    });

    it('should return all nodes original data', () => {
        const rootNodeMock = {
            allLeafChildren: [
                {
                    data: {
                        id: ['module1']
                    }
                }
            ]
        };
        expect((component as any).allNodesOriginalData).toEqual([]);
        spyOnProperty(component as any, 'rootNode').and.returnValue(
            rootNodeMock
        );
        expect((component as any).allNodesOriginalData.length).toBe(
            rootNodeMock.allLeafChildren.length
        );
    });

    it('should return node by id', () => {
        const expectedNode = {
            data: {
                id: ['module1']
            }
        };
        const rootNodeMock = {
            allLeafChildren: [expectedNode]
        };
        spyOnProperty(component as any, 'rootNode').and.returnValue(
            rootNodeMock
        );
        const nodeById = (component as any).getNodeById(expectedNode.data.id);
        expect(nodeById).toEqual(expectedNode);
    });

    it('should return children nodes by parent node id', () => {
        const parentNode = {
            data: {
                id: ['module1']
            }
        };
        const expectedNodes = [
            {
                data: {
                    id: [parentNode.data.id, 'sub-module1']
                }
            },
            {
                data: {
                    id: [parentNode.data.id, 'sub-module2']
                }
            }
        ];
        const rootNodeMock = {
            allLeafChildren: [parentNode, ...expectedNodes]
        };
        spyOnProperty(component as any, 'rootNode').and.returnValue(
            rootNodeMock
        );
        const childrenNodes = (component as any).getChildrenNodesByParentNodeId(
            parentNode.data.id
        );
        expect(childrenNodes).toEqual(expectedNodes);
    });

    it('set child node should not be called when permission = false', () => {
        const childNode: any = {
            data: {
                id: ['sub-module1'],
                controls : { permission : false }
            },
            setDataValue: jasmine.createSpy()
        };
        const permissionKey = 'permission';
        const accessKey = 'access';
        const allowedPermission = PermissionValue.VIEW_ONLY;

        component['setChildNodeAllowedValue'](
            childNode,
            permissionKey,
            PermissionValue.NONE
        );
        expect(childNode.setDataValue).not.toHaveBeenCalled();
        component['setChildNodeAllowedValue'](
            childNode,
            accessKey,
            ModulePermissionValue.ACCESS_YES
        );
        expect(childNode.setDataValue).toHaveBeenCalledWith(
            accessKey,
            ModulePermissionValue.ACCESS_YES,
            jasmine.anything()
        );
    });

    it('should set child node allowed value', () => {
        const childNode: any = {
            data: {
                id: ['sub-module1'],
                controls : { permission : true }
            },
            setDataValue: jasmine.createSpy()
        };
        const accessKey = 'access';
        const permissionKey = 'permission';
        const allowedPermission = PermissionValue.VIEW_ONLY;

        component['setChildNodeAllowedValue'](
            childNode,
            accessKey,
            ModulePermissionValue.ACCESS_YES
        );
        expect(childNode.setDataValue).toHaveBeenCalledWith(
            accessKey,
            ModulePermissionValue.ACCESS_YES,
            jasmine.anything()
        );

        component['setChildNodeAllowedValue'](
            childNode,
            permissionKey,
            PermissionValue.VIEW_EDIT_CREATE_DELETE
        );
        expect(childNode.setDataValue).toHaveBeenCalledWith(
            permissionKey,
            PermissionValue.VIEW_EDIT_CREATE_DELETE,
            jasmine.anything()
        );

        childNode.data.allowed_permissions = [allowedPermission];
        component['setChildNodeAllowedValue'](
            childNode,
            permissionKey,
            PermissionValue.VIEW_EDIT_CREATE_DELETE
        );
        expect(childNode.setDataValue).toHaveBeenCalledWith(
            permissionKey,
            allowedPermission,
            jasmine.anything()
        );

        component['setChildNodeAllowedValue'](
            childNode,
            permissionKey,
            PermissionValue.NONE
        );
        expect(childNode.setDataValue).toHaveBeenCalledWith(
            permissionKey,
            allowedPermission,
            jasmine.anything()
        );
    });
    it('should overrideHiddenChildrenPermissions', () => {
        const filteredPermissions: RolePermissions = {
            modules: {
                account_tools: 13,
                orders: 13,
                invoice_and_payments: 0
            },
            sub_modules: {
                account_tools: {
                    users_roles: 0
                },
                orders: {
                    all_account_orders: 0
                },
                invoice_and_payments: {
                    all_account_invoices: 0
                }
            }
        };
        const underTest = component['overrideHiddenChildrenPermissions'](filteredPermissions);

        expect(underTest.sub_modules.orders.all_account_orders).toBe(PermissionValue.VIEW_EDIT_CREATE_DELETE);
        expect(underTest.sub_modules.account_tools.users_roles).toBe(PermissionValue.NONE);
        expect(underTest.sub_modules.invoice_and_payments.all_account_invoices).toBe(PermissionValue.NONE);
    });
});
