import { AgRendererComponent } from '@ag-grid-community/angular';
import { Component } from '@angular/core';

import {
    CheckboxCellRendererParams,
    createPermissionsForm,
    permissionsChecks,
    permissionsChecksIndexMap
} from './check-group-cell-renderer.config';

@Component({
    selector: 'ct-checkbox-group-cell-renderer',
    templateUrl: './check-group-cell-renderer.component.html',
    styleUrls: ['./check-group-cell-renderer.component.scss']
})
export class CheckboxGroupCellRendererComponent implements AgRendererComponent {
    get checkboxButtonGroupName(): string {
        let id = 0;
        if (this.params?.data?.id) {
            id = Array.isArray(this.params.data?.id)
                ? this.params.data?.id.join('_')
                : this.params.data?.id;
        }
        return `checkbox_button_group_${this.params.node.parent?.level ?? 0}_${
            this.params.rowIndex
        }_${id}`;
    }

    get hasChildrenDifferentSelection(): boolean {
        return this.params.data?.hasChildrenDifferentSelection;
    }
    params: CheckboxCellRendererParams = null;
    currentValue: any;
    permissions = permissionsChecks;
    form = createPermissionsForm();
    agInit(params: CheckboxCellRendererParams): void {
        this.params = params;
        this.setValue(params);
    }

    refresh(params: CheckboxCellRendererParams): boolean {
        this.params = params;
        this.setValue(params);
        return true;
    }

    onCheckboxClicked(index: any): void {
        const value = permissionsChecksIndexMap[index];
        this.form.patchValue(this.permissions[value]);
        this.setValue({ value } as CheckboxCellRendererParams);
        this.params.setValue(value);
    }

    private setValue({
        value: checkboxValue
    }: CheckboxCellRendererParams): void {
        const isObject = typeof checkboxValue === 'object';
        this.currentValue = isObject ? checkboxValue.value : checkboxValue;
        this.form.patchValue(this.permissions[this.currentValue]);
    }
}
