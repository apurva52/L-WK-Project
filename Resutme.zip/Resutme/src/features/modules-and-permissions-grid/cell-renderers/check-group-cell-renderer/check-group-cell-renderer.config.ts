import { ICellRendererParams } from '@ag-grid-community/core';
import { FormArray, FormControl } from '@angular/forms';
export interface CheckboxCellRendererParams extends ICellRendererParams {
    checkboxButtonOptions: any;
    trustedValue: boolean;
}
export const permissionsChecksIndexMap = {
    0: 0,
    1: 1,
    2: 3,
    3: 5,
    4: 8,
    5: 13
};

export const permissionsChecks = {
    0: [true, false, false, false, false],
    1: [false, true, false, false, false],
    3: [false, true, true, false, false],
    5: [false, true, true, true, false],
    8: [false, true, true, true, true],
    13: [false, true, true, true, true]
};

export function createPermissionsForm(): FormArray {
    return new FormArray([
        new FormControl(false),
        new FormControl(false),
        new FormControl(false),
        new FormControl(false),
        new FormControl(false)
    ]);
}
