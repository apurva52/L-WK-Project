import { ChangeDetectionStrategy } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { PermissionValue } from '../../interfaces/permission-module.interface';

import { CheckboxGroupCellRendererComponent } from './check-group-cell-renderer.component';
import {
    CheckboxCellRendererParams,
    createPermissionsForm
} from './check-group-cell-renderer.config';

describe('CheckboxGroupCellRendererComponent', () => {
    let component: CheckboxGroupCellRendererComponent;
    let fixture: ComponentFixture<CheckboxGroupCellRendererComponent>;
    const params = {
        data: { id: 0 },
        value: 0,
        rowIndex: 0,
        node: {
            parent: {
                level: 0
            }
        }
    } as CheckboxCellRendererParams;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CheckboxGroupCellRendererComponent],
            imports: [FormsModule, ReactiveFormsModule]
        })
            .overrideComponent(CheckboxGroupCellRendererComponent, {
                set: { changeDetection: ChangeDetectionStrategy.Default }
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CheckboxGroupCellRendererComponent);
        component = fixture.componentInstance;
        component.params = params;
        component.form = createPermissionsForm();
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should agInit', () => {
        component.form = { patchValue: jasmine.createSpy() } as any;
        component.agInit(params);
        fixture.detectChanges();
        expect(component.form.patchValue).toHaveBeenCalled();
    });

    it('should refresh', () => {
        component.form = { patchValue: jasmine.createSpy() } as any;
        component.refresh(params);
        fixture.detectChanges();
        expect(component.form.patchValue).toHaveBeenCalled();
    });

    it('should check for checkboxButtonGroupName', () => {
        const actual = component.checkboxButtonGroupName;
        expect(actual).toEqual('checkbox_button_group_0_0_0');
    });

    it('should check for checkboxButtonGroupName for array of ids', () => {
        const ids = [
            PermissionValue.NONE,
            PermissionValue.VIEW_ONLY,
            PermissionValue.VIEW_EDIT
        ];
        component.params = {
            ...params,
            data: {
                id: ids
            }
        };
        const actual = component.checkboxButtonGroupName;
        expect(actual).toEqual('checkbox_button_group_0_0_0_1_3');
    });

    it('should emit a checkbox change', () => {
        component.params = { setValue: jasmine.createSpy() } as any;
        component.onCheckboxClicked(0);
        expect(component.params.setValue).toHaveBeenCalled();
    });
});
