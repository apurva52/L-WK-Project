/* tslint:disable:no-unused-variable */
/* tslint:disable:max-file-line-count */
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { KeyValuePipe } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormGroup } from '@angular/forms';
import { FormArray } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { initialModulesAndPermissionsState } from './../../state/modules-and-permissions/modules-and-permissions.reducers';
import {
    selectDocumentMetadataForm,
    selectDocumentMetadataLoaded,
    selectDocumentMetadataLoading
} from './../../state/modules-and-permissions/modules-and-permissions.selectors';
import { MODULES_AND_PERMISSIONS_FEATURE_KEY } from './../../state/modules-and-permissions/modules-and-permissions.state';
import { DocumentsCellRendererComponent } from './documents-cell-renderer.component';

describe('DocumentsCellRendererComponent', () => {
    let component: DocumentsCellRendererComponent;
    let fixture: ComponentFixture<DocumentsCellRendererComponent>;
    const defaultRestrictedDocumentsMetadata = {
        restricted_document_types: [],
        restricted_document_statuses: [],
        restricted_document_categories: []
    };
    const mockDocuments = [
        {
            id: 'UNIT_TEST_0',
            label: 'Unit Test 0',
            isSelected: true
        },
        {
            id: 'UNIT_TEST_1',
            label: 'Unit Test 1',
            isSelected: true
        }
    ];

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [DocumentsCellRendererComponent],
            providers: [
                KeyValuePipe,
                provideMockStore({
                    initialState: {
                        [MODULES_AND_PERMISSIONS_FEATURE_KEY]: {
                            ...initialModulesAndPermissionsState,
                            documents: {
                                ...initialModulesAndPermissionsState.documents,
                                data: {
                                    ...initialModulesAndPermissionsState
                                        .documents.data,
                                    documentType: mockDocuments.map( document => ({ guid: document.id, label: document.label })),
                                    documentStatus: [],
                                    documentCategory: []
                                }
                            }
                        }
                    },
                    selectors: [
                        {
                            selector: selectDocumentMetadataForm(
                                defaultRestrictedDocumentsMetadata
                            ),
                            value: {
                                loaded: true,
                                form: new FormGroup({})
                            }
                        },
                        {
                            selector: selectDocumentMetadataLoading,
                            value: false
                        },
                        {
                            selector: selectDocumentMetadataLoaded,
                            value: true
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DocumentsCellRendererComponent);
        component = fixture.componentInstance;
        spyOn(component['store$'], 'dispatch').and.callThrough();
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should refresh data', () => {
        expect(component.refresh(component.params)).toBeTruthy();
    });

    it('should do anything due to a not visible cell', () => {
        const clock = jasmine.clock();
        clock.install();
        component.agInit({
            setValue: jasmine.createSpy(),
            node: {
                updateData: jasmine.createSpy()
            },
            value: {
                restricted_documents_metadata:
                    defaultRestrictedDocumentsMetadata
            }
        } as any);
        clock.tick(1);
        clock.uninstall();
        expect(component.form).toBeDefined();
        expect(component['store$'].dispatch).toHaveBeenCalled();
    });

    it('should emit a checkbox change', () => {
        const clock = jasmine.clock();
        clock.install();
        component.agInit({
            setValue: jasmine.createSpy(),
            node: {
                parent: {
                    data: {},
                    updateData: jasmine.createSpy()
                }
            },
            value: {
                restricted_documents_metadata:
                    defaultRestrictedDocumentsMetadata
            }
        } as any);
        const parentKey = 'documentType';
        const elementIndex = 0;
        clock.tick(1);
        clock.uninstall();
        component.handleChange(parentKey, { ...mockDocuments[0], isSelected: false });
        expect(
            (component.form.get(parentKey) as FormArray).at(elementIndex)
        ).toBeTruthy();
        expect(component.params.setValue).toHaveBeenCalled();
    });

    it('should clear selection of any multiselect', () => {
        const clock = jasmine.clock();
        clock.install();
        component.agInit({
            setValue: jasmine.createSpy(),
            node: {
                parent: {
                    data: {},
                    updateData: jasmine.createSpy()
                }
            },
            value: {
                restricted_documents_metadata:
                    defaultRestrictedDocumentsMetadata
            }
        } as any);
        const parentKey = 'documentType';
        const elementIndex = 0;
        clock.tick(1);
        clock.uninstall();
        component.clearAll(parentKey);
        const metadataFormArray = component.form.get(parentKey) as FormArray;
        const allUnselected = metadataFormArray.controls.every(control => control.value.isSelected === false);
        expect(allUnselected).toBeTruthy();
        expect(component.params.setValue).toHaveBeenCalled();
    });

    it('Should order specific groups', () => {
        const groups = [
            { key: 'documentStatus' },
            { key: 'documentCategory' },
            { key: 'documentType' }
        ];
        groups.sort(component.compareParentGroups);
        expect(groups).toEqual([
            { key: 'documentType' },
            { key: 'documentStatus' },
            { key: 'documentCategory' }
        ]);
    });

    it('get Documents Module Access', () => {
        const clock = jasmine.clock();
        clock.install();
        component.agInit({
            setValue: jasmine.createSpy(),
            node: {
                parent: {
                    parent: {
                        data: {
                            access: {
                                value: true
                            }
                        }
                    },
                    data: {},
                    updateData: jasmine.createSpy()
                }
            },
            value: {
                restricted_documents_metadata:
                    defaultRestrictedDocumentsMetadata
            },
            data: {
                access: {
                    disabled: false
                }
            }
        } as any);
        clock.tick(1);
        clock.uninstall();
        expect(component['getDocumentsModuleAccess']()).toEqual(true);
        expect(component['disabled']).toEqual(false);
    });

    it('get Documents Module Access -ve case', () => {
        const clock = jasmine.clock();
        clock.install();
        component.agInit({
            setValue: jasmine.createSpy(),
            node: {
                parent: {
                    parent: {
                        data: {
                            access: false
                        }
                    },
                    data: {},
                    updateData: jasmine.createSpy()
                }
            },
            value: {
                restricted_documents_metadata:
                    defaultRestrictedDocumentsMetadata
            },
            data: {
                access: false
            }
        } as any);
        clock.tick(1);
        clock.uninstall();
        expect(component['getDocumentsModuleAccess']()).toEqual(false);
        expect(component['disabled']).toEqual(true);
    });
});
