import { AgRendererComponent } from '@ag-grid-community/angular';
import { ICellRendererParams } from '@ag-grid-community/core';
import { Component } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';
import { MultiselectItem } from '@wk/components-angular11';
import { Subject } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { filter, takeUntil } from 'rxjs/operators';

import { getDocumentsMetadataAction } from '../../state/modules-and-permissions/modules-and-permissions.actions';
import {
    filterCheckedMetadataDocumentsToService,
    selectDocumentMetadataForm,
    selectDocumentMetadataLoaded,
    selectDocumentMetadataLoading
} from '../../state/modules-and-permissions/modules-and-permissions.selectors';

import { DocumentsStateDataItems } from './../../state/modules-and-permissions/modules-and-permissions.state';

@Component({
    selector: 'ct-documents-cell-renderer',
    templateUrl: './documents-cell-renderer.component.html',
    styleUrls: ['./documents-cell-renderer.component.scss']
})
export class DocumentsCellRendererComponent implements AgRendererComponent {
    params: ICellRendererParams = null;
    form: FormGroup = new FormGroup({});
    initialFormValue;

    documentMetadataForm$: Observable<{ loaded: boolean, form: FormGroup }>;
    documentMetadataLoading$: Observable<boolean> = this.store$.select(selectDocumentMetadataLoading);
    documentMetadataLoaded$: Observable<boolean> = this.store$.select(selectDocumentMetadataLoaded);
    private destroyed$: Subject<boolean> = new Subject();

    get disabled(): boolean {
        return this.params.data.access?.disabled || !this.getDocumentsModuleAccess();
    }

    constructor(private store$: Store) { }

    ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    agInit(params: ICellRendererParams): void {
        this.params = params;
        this.store$.dispatch(getDocumentsMetadataAction());
        this.documentMetadataForm$ = this.store$.select(selectDocumentMetadataForm(this.params.value));
        this.documentMetadataForm$.pipe(filter(({ loaded }) => loaded), takeUntil(this.destroyed$)).subscribe(
            ({ form }) => {
                this.form = form;
                this.initialFormValue = { ...this.form.value };
            }
        );
    }

    refresh(params: ICellRendererParams): boolean {
        this.params = params;
        return true;
    }


    compareParentGroups(c1: any, c2: any): number {
        const parentGroupsOrder = ['documentType', 'documentStatus', 'documentCategory'];
        return parentGroupsOrder.indexOf(c1.key) - parentGroupsOrder.indexOf(c2.key);
    }

    handleChange(parentKey: string, { id, isSelected }: MultiselectItem): void {
        const metadataFormArray = this.form.get(parentKey) as FormArray;
        const elementIndex = metadataFormArray.value.findIndex((element: MultiselectItem) => element.id === id);
        metadataFormArray.at(elementIndex).patchValue({ isSelected: isSelected });
        this.setValue(this.form.value);
    }

    clearAll(parentKey: string): void {
        const metadataFormArray = this.form.get(parentKey) as FormArray;
        metadataFormArray.controls.forEach((control: FormGroup) => {
            control.patchValue({ isSelected: false });
        });
        this.setValue(this.form.value);
    }

    private setValue(formValue: DocumentsStateDataItems): void {
        const restricted_documents_metadata = filterCheckedMetadataDocumentsToService(formValue);
        this.params.node.parent.updateData({ ...this.params.node.parent.data, value: { restricted_documents_metadata } });
        this.params.setValue(formValue);
    }

    private getDocumentsModuleAccess(): boolean {
        const documentsData = this.params.node.parent.parent.data;
        return typeof documentsData.access === 'boolean'
            ? documentsData.access
            : documentsData.access.value;
    }
}
