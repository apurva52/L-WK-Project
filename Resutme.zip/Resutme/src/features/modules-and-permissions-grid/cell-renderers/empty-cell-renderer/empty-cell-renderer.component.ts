import { AgRendererComponent } from '@ag-grid-community/angular';
import { ICellRendererParams } from '@ag-grid-community/core';
import { Component } from '@angular/core';


@Component({
    selector: 'ct-empty-cell-renderer',
    templateUrl: './empty-cell-renderer.component.html',
    styleUrls: ['./empty-cell-renderer.component.scss']
})
export class EmptyCellRendererComponent implements AgRendererComponent {
    agInit(_params: ICellRendererParams): void {
        return;
    }

    refresh(_params: ICellRendererParams): boolean {
        return true;
    }
}
