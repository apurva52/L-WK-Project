import { ICellRendererParams } from '@ag-grid-community/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmptyCellRendererComponent } from './empty-cell-renderer.component';

describe('EmptyCellRendererComponent', () => {
  let component: EmptyCellRendererComponent;
  let fixture: ComponentFixture<EmptyCellRendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmptyCellRendererComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmptyCellRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should init', () => {
      const result = component.agInit({} as unknown as ICellRendererParams);
      expect(result).toBeUndefined();
  });
  it('should refresh', () => {
      expect(component.refresh({} as unknown as ICellRendererParams)).toBeTruthy();
  });
});
