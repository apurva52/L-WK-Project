import { ICellRendererParams } from '@ag-grid-community/core';
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { TranslateModule } from '@ngx-translate/core';

import { ListViewCellRendererComponent } from './list-view-cell-renderer.component';

describe('ListViewCellRendererComponent', () => {
    let component: ListViewCellRendererComponent;
    let fixture: ComponentFixture<ListViewCellRendererComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ListViewCellRendererComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(ListViewCellRendererComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be defined', () => {
        expect(component).toBeDefined();
    });
    it('should init', () => {
        component.agInit({} as ICellRendererParams);
        expect(component.params).toBeDefined();
    });
    it('should refresh', () => {
        expect(component.refresh({} as ICellRendererParams)).toEqual(true);
    });
});
