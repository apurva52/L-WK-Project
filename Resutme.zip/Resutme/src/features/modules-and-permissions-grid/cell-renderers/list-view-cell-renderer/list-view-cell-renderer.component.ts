import { AgRendererComponent } from '@ag-grid-community/angular';
import { ICellRendererParams } from '@ag-grid-community/core';
import { Component } from '@angular/core';

@Component({
    selector: 'ct-list-view-renderer',
    templateUrl: './list-view-cell-renderer.component.html',
    styleUrls: ['./list-view-cell-renderer.component.scss']
})
export class ListViewCellRendererComponent implements AgRendererComponent {
    params: ICellRendererParams;

    agInit(params: ICellRendererParams): void {
        this.params = params;
    }

    refresh(params: ICellRendererParams): boolean {
        this.params = params;
        return true;
    }
}
