import { AgRendererComponent } from '@ag-grid-community/angular';
import { ICellRendererParams } from '@ag-grid-community/core';
import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
    selector: 'ct-module-name-cell-renderer',
    templateUrl: './module-name-cell-renderer.component.html',
    styleUrls: ['./module-name-cell-renderer.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ModuleNameCellRendererComponent implements AgRendererComponent {
    params: ICellRendererParams;
    hyperlinkText: string;

    agInit(params: ICellRendererParams): void {
        this.params = params;
        this.hyperlinkText = params.data?.hyperlinkText || '';
    }

    refresh(params: ICellRendererParams): boolean {
        this.params = params;
        return true;
    }

    onHyperlinkAction(): void {
        this.params.node.setExpanded(true);
    }
}
