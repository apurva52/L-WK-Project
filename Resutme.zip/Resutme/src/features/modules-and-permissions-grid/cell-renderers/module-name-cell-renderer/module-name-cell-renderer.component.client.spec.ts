/* tslint:disable:no-unused-variable */
import { ChangeDetectionStrategy, CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { JumpstartComponentsModule } from '@wk/components-angular11';

import { ModuleNameCellRendererComponent } from './module-name-cell-renderer.component';

describe('ModuleNameCellRendererComponent', () => {
    let component: ModuleNameCellRendererComponent;
    let fixture: ComponentFixture<ModuleNameCellRendererComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ModuleNameCellRendererComponent],
            imports: [JumpstartComponentsModule],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        })
            .overrideComponent(ModuleNameCellRendererComponent, {
                set: { changeDetection: ChangeDetectionStrategy.Default }
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ModuleNameCellRendererComponent);
        component = fixture.componentInstance;
    });

    it('should create', () => {
        component.agInit({ value: false, data: { iconName: '', module_name: ['TEST']  } } as any);
        fixture.detectChanges();
        expect(component.params).toBeDefined();
    });

    it('should init with hyperlinkText', () => {
        const text = 'People hyperlink';
        component.agInit({ value: false, data: { iconName: '', module_name: ['TEST'],  hyperlinkText: text } } as any);
        fixture.detectChanges();
        expect(component.hyperlinkText).toBe(text);
    });

    it('should update', () => {
        const result = component.refresh({ value: false, data: { iconName: '', module_name: ['TEST'] } } as any);
        fixture.detectChanges();
        expect(result).toBeTruthy();
        expect(component.params).toBeDefined();
    });

    it('should call onHyperlinkAction', () => {
        const spy =  jasmine.createSpy().and.callThrough();
        component.agInit({
            node: {
                setExpanded: spy
            },
            data: { iconName: '', module_name: ['TEST'] }
        } as any);
        fixture.detectChanges();
        component.onHyperlinkAction();
        expect(spy).toHaveBeenCalledWith(true);
    });
});
