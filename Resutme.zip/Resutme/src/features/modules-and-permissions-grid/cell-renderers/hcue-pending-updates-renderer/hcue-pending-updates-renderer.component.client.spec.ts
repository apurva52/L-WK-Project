/* tslint:disable:no-unused-variable */
import { ICellRendererParams } from '@ag-grid-community/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';

import { HcuePendingUpdatesRendererComponent } from './hcue-pending-updates-renderer.component';

describe('HcuePendingUpdatesRendererComponent', () => {
    let component: HcuePendingUpdatesRendererComponent;
    let fixture: ComponentFixture<HcuePendingUpdatesRendererComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HcuePendingUpdatesRendererComponent],
            imports: [TranslateModule.forRoot()],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HcuePendingUpdatesRendererComponent);
        component = fixture.componentInstance;
        component.params = {
            value: 0,
            setValue: jasmine.createSpy('setValue'),
            node: {
                updateData: jasmine.createSpy('updateData')
            },
            data: {
                module_name: ['TEST'],
                access: false,
                permission: 0
            }
        } as unknown as ICellRendererParams;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('should init', () => {
        component.agInit(component.params);
        expect(component.params).toBeDefined();
        expect(component.selected).toEqual(0);
    });
    it('should refresh', () => {
        expect(component.refresh(component.params)).toEqual(true);
        expect(component.selected).toEqual(0);
    });
    it('should handle change selection', () => {
        const expectedResult = 13;
        const mockEvent = { target: { value: '13' } };
        component.handleOnChange(mockEvent as unknown as Event);
        expect(component.selected).toEqual(expectedResult);
        expect(component.params.setValue).toHaveBeenCalled();
    });
});
