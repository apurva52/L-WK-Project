import { AgRendererComponent } from '@ag-grid-community/angular';
import { ICellRendererParams } from '@ag-grid-community/core';
import { Component } from '@angular/core';

interface Option {
    value: number;
    label: string;
}

@Component({
    selector: 'ct-hcue-pending-updates-renderer',
    templateUrl: './hcue-pending-updates-renderer.component.html',
    styleUrls: ['./hcue-pending-updates-renderer.component.scss']
})
export class HcuePendingUpdatesRendererComponent implements AgRendererComponent {
    params: ICellRendererParams;
    selected: number;
    options: Array<Option> = [
        { value: 0, label: 'None' },
        { value: 13, label: 'Approver' },
        { value: 1, label: 'Requires Approval' }
    ];
    get disabled(): boolean {
        return this.params.data.access?.disabled;
    }

    agInit(params: ICellRendererParams): void {
        this.params = params;
        this.selected = this.params.value;
    }

    refresh(params: ICellRendererParams): boolean {
        this.params = params;
        this.selected = this.params.value;
        return true;
    }

    handleOnChange(event: Event): void {
        this.selected = parseInt((event.target as HTMLInputElement).value, 10);
        const access: boolean = this.selected !== 0;
        this.params.setValue(this.selected);
        this.params.node.updateData({ ...this.params.data, access, permission: this.selected });
    }
}


