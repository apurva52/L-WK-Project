import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthorizationModule } from '@ct/core-ui-ng';
import { CtGridModule } from '@ct/platform-primitives-uicomponents/grid';
import { CtPrimitivesModule } from '@ct/platform-primitives-uicomponents/primitives';
import { TranslateModule } from '@ngx-translate/core';
import { JumpstartComponentsModule } from '@wk/components-angular11';

import { ListViewGridsModule } from '../list-view-grids/list-view-grids.module';

import { CheckboxGroupCellRendererComponent } from './cell-renderers/check-group-cell-renderer/check-group-cell-renderer.component';
import { DocumentsCellRendererComponent } from './cell-renderers/documents-cell-renderer/documents-cell-renderer.component';
import { EmptyCellRendererComponent } from './cell-renderers/empty-cell-renderer/empty-cell-renderer.component';
import { HcuePendingUpdatesRendererComponent } from './cell-renderers/hcue-pending-updates-renderer/hcue-pending-updates-renderer.component';
import { ListViewCellRendererComponent } from './cell-renderers/list-view-cell-renderer/list-view-cell-renderer.component';
import { ModuleNameCellRendererComponent } from './cell-renderers/module-name-cell-renderer/module-name-cell-renderer.component';
import { ModulesAndPermissionsGridComponent } from './modules-and-permissions-grid.component';

@NgModule({
    declarations: [
        ModuleNameCellRendererComponent,
        ModulesAndPermissionsGridComponent,
        DocumentsCellRendererComponent,
        CheckboxGroupCellRendererComponent,
        ListViewCellRendererComponent,
        EmptyCellRendererComponent,
        HcuePendingUpdatesRendererComponent
    ],
    imports: [
        CommonModule,
        CtPrimitivesModule,
        CtGridModule,
        TranslateModule.forChild(),
        JumpstartComponentsModule,
        FormsModule,
        ReactiveFormsModule,
        AuthorizationModule,
        ListViewGridsModule
    ],
    exports: [ModulesAndPermissionsGridComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ModulesAndPermissionsGridModule {}
