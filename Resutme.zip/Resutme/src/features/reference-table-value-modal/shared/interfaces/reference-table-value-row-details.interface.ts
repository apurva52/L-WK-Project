export interface ValueRowDetails {
    id: number;
    guid: string;
    name: string;
    sysDefinedInd: string;
    displayOrderNo: number | null;
}