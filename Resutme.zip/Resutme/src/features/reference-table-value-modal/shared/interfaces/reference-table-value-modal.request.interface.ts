export interface RTAddValuePostModel {
    displayOrderNo: number;
    name: string;
}