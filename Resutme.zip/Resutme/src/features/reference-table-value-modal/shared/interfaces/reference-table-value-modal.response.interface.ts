export interface RTValueAddSuccessResponse {
    result: string;
}

export interface RTValueAddErrorResponse {
    code: string;
    message: string;
}

export interface FormError {
    [key: string]: string;
}