export const ReferenceValueAddModalModel = {
    title: 'ReferenceTableModule.referenceValueModal.addTitle',
    confirmText: 'ReferenceTableModule.referenceValueModal.confirmText',
    cancelText: 'ReferenceTableModule.referenceValueModal.cancelText',
    closeText: 'ReferenceTableModule.referenceValueModal.closeText',
    cancelToLeft: true
};

export const ReferenceValueEditModalModel = {
    title: 'ReferenceTableModule.referenceValueModal.editTitle',
    confirmText: 'ReferenceTableModule.referenceValueModal.confirmText',
    cancelText: 'ReferenceTableModule.referenceValueModal.cancelText',
    closeText: 'ReferenceTableModule.referenceValueModal.closeText',
    cancelToLeft: true
};