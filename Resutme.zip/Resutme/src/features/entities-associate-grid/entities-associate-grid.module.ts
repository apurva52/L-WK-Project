import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { EntitiesGridsModule } from '@ct/platform-common-uicomponents/entities-grids';
import { TranslateModule } from '@ngx-translate/core';

import { UserEntitiesAssociateGridComponent } from './components/user-entities-associate-grid/user-entities-associate-grid.component';

@NgModule({
    declarations: [UserEntitiesAssociateGridComponent],
    exports: [UserEntitiesAssociateGridComponent],
    imports: [EntitiesGridsModule, TranslateModule.forChild(), CommonModule],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class EntityAssociateGridModule {}
