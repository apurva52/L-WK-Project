// tslint:disable max-file-line-count
// tslint:disable:max-line-length
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { SSRMEntityDataItem } from '@ct/platform-common-uicomponents/entities-grids';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { roleManagementGetEntitiesFailureAction, roleManagementGetEntitiesSuccessAction } from 'src/pages/users-and-roles/roles-management/state/role-management.actions';

import { UserEntitiesAssociateGridComponent } from './user-entities-associate-grid.component';

function createSSRMEntityDataItems(count: number): Array<SSRMEntityDataItem> {
    const ssrmEntityDataItems = [];
    for (let i = 0; i < count; i++) {
        ssrmEntityDataItems.push({
            entity_id: i,
            entity_guid: `${i}`,
            entity_type: '',
            entity_country: '',
            domestic_jurisdiction: '',
            foreign_jurisdiction: [],
            entity_name: [i],
            entity_group: null,
            is_group: false
        });
    }
    return ssrmEntityDataItems;
}

describe('UserEntitiesAssociateGridComponent', () => {
    let fixture: ComponentFixture<UserEntitiesAssociateGridComponent>;
    let component: UserEntitiesAssociateGridComponent;
    const actions$: Observable<any> = of();

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            declarations: [
                UserEntitiesAssociateGridComponent,
                UserEntitiesAssociateGridComponent
            ],
            providers: [
                provideMockActions(() => actions$),
                provideMockStore({
                    initialState: {
                        'users-and- roles': {}
                    }
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        });

        fixture = TestBed.createComponent(UserEntitiesAssociateGridComponent);
        component = fixture.componentInstance;
    });

    it('should create User Entities Associate Grid Component component', () => {
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });

    it('should update grid data on initialData change', () => {
        const customGroup = {
            entity_group_id: 1,
            edh_entity_group_id: 1,
            edh_entity_group_guid: '1',
            edh_entity_group_name: 'Test group 1',
            edh_entity_group_type: 'C',
            entities: [
                {
                    entity_id: 1,
                    entity_guid: '1',
                    entity_name: 'Test entity 1',
                    entity_country: '',
                    domestic_jurisdiction: ''
                }
            ]
        };
        const internalGroup = {
            entity_group_id: 2,
            edh_entity_group_id: 2,
            edh_entity_group_guid: '2',
            edh_entity_group_name: 'Test internal group',
            edh_entity_group_type: 'I',
            entities: []
        };
        const internalNewGroup = {
            entity_group_id: -1,
            edh_entity_group_id: -1,
            edh_entity_group_guid: '-1',
            edh_entity_group_name: 'Test internal new group',
            edh_entity_group_type: 'I',
            entities: [
                {
                    entity_id: 1,
                    entity_guid: '1',
                    entity_name: 'Test entity 1',
                    entity_country: '',
                    domestic_jurisdiction: ''
                }
            ]
        };
        const allEntitiesGroup = {
            entity_group_id: -1,
            edh_entity_group_id: -1,
            edh_entity_group_guid: '00000000-0000-0000-0000-0000000000',
            edh_entity_group_name: 'Test all entities group',
            edh_entity_group_type: 'I',
            entities: [],
            isAllEntitiesGroup: true
        };
        const gridApiMock: any = {
            refreshServerSideStore: (data: any) => {}
        };
        component['gridApi'] = gridApiMock;
        component.initialData = [];
        component.allEntitiesGroup = null;
        component['implicitGroup'] = null;
        component.ngOnChanges({});
        expect(component['gridData'].length).toBe(0);
        expect(component.allEntitiesGroup).toBeFalsy();
        expect(component['implicitGroup']).toBeFalsy();

        component.allEntitiesGroup = null;
        component['implicitGroup'] = null;
        component.ngOnChanges({
            initialData: {
                currentValue: [customGroup],
                previousValue: component.initialData,
                firstChange: false,
                isFirstChange: () => false
            }
        });
        expect(component['gridData'].length).toBeGreaterThan(0);
        expect(component.allEntitiesGroup).toBeFalsy();
        expect(component['implicitGroup']).toBeFalsy();

        component.allEntitiesGroup = null;
        component['implicitGroup'] = null;
        component.ngOnChanges({
            initialData: {
                currentValue: [internalGroup],
                previousValue: component.initialData,
                firstChange: false,
                isFirstChange: () => false
            }
        });
        expect(component['gridData'].length).toBe(0);
        expect(component.allEntitiesGroup).toBeFalsy();
        expect(component['implicitGroup']).toBeTruthy();

        component.allEntitiesGroup = null;
        component['implicitGroup'] = null;
        component.ngOnChanges({
            initialData: {
                currentValue: [internalNewGroup],
                previousValue: component.initialData,
                firstChange: false,
                isFirstChange: () => false
            }
        });
        expect(component['gridData'].length).toBeGreaterThan(0);
        expect(component.allEntitiesGroup).toBeFalsy();
        expect(component['implicitGroup']).toBeFalsy();

        component.allEntitiesGroup = null;
        component['implicitGroup'] = null;
        component.ngOnChanges({
            initialData: {
                currentValue: [allEntitiesGroup],
                previousValue: component.initialData,
                firstChange: false,
                isFirstChange: () => false
            }
        });
        expect(component['gridData'].length).toBe(0);
        expect(component.allEntitiesGroup).toBeTruthy();
        expect(component['implicitGroup']).toBeFalsy();
    });

    it('should set gridApi value on grid ready', () => {
        component.onGridReady({
            api: undefined
        });
        expect((component as any).gridApi).toBeUndefined();
        component.onGridReady({
            api: {}
        });
        expect((component as any).gridApi).toBeDefined();
    });

    it('should return gridData on calling onGetRows', () => {
        const getRowsEvent = {
            request: {
                groupKeys: []
            },
            success: (params) => {}
        };
        const gridData = createSSRMEntityDataItems(1);
        component.allEntitiesGroup = null;
        component['implicitGroup'] = null;
        component['gridData'] = gridData;
        const successSpy = spyOn(getRowsEvent, 'success');
        component.onGetRows(getRowsEvent);
        fixture.detectChanges();
        expect(successSpy).toHaveBeenCalledWith({
            rowData: gridData,
            rowCount: gridData.length
        });
        component.onGetRows({
            ...getRowsEvent,
            request: {
                ...getRowsEvent.request,
                startRow: component.PAGE_SIZE,
                endRow: component.PAGE_SIZE * 2
            }
        });
        fixture.detectChanges();
        expect(successSpy).toHaveBeenCalledWith({
            rowData: [],
            rowCount: gridData.length
        });
        const pageSize = 10;
        const gridData2 = createSSRMEntityDataItems(pageSize + 1);
        component['gridData'] = gridData2;
        component.onGetRows({
            ...getRowsEvent,
            request: {
                ...getRowsEvent.request,
                startRow: 0,
                endRow: pageSize
            }
        });
        fixture.detectChanges();
        expect(successSpy).toHaveBeenCalledWith({
            rowData: gridData2.splice(0, pageSize),
            rowCount: null
        });
    });

    it('should dispatch load entities for specific group', () => {
        const group = {
            entity_group_id: 1,
            edh_entity_group_id: 1,
            edh_entity_group_guid: '123456789',
            edh_entity_group_name: 'Test group',
            edh_entity_group_type: 'C',
            entities: []
        };
        const getRowsEvent = {
            request: {
                groupKeys: [group]
            },
            success: (params) => {}
        };
        const bigEntitiesData = createSSRMEntityDataItems(component.PAGE_SIZE);
        const smallEntitiesData = createSSRMEntityDataItems(1);

        const actionSpy = spyOn((component as any).store$, 'dispatch');
        const successSpy = spyOn(getRowsEvent, 'success');
        const subscribeEntityGroupEntitiesLoadedStateSpy = spyOn(component as any, 'subscribeEntityGroupEntitiesLoadedState');

        subscribeEntityGroupEntitiesLoadedStateSpy.and.callFake((group, callback) => callback(bigEntitiesData));
        component.onGetRows(getRowsEvent);
        fixture.detectChanges();
        expect(actionSpy).toHaveBeenCalled();
        expect(successSpy).toHaveBeenCalledWith({
            rowData: bigEntitiesData,
            rowCount: null
        });

        subscribeEntityGroupEntitiesLoadedStateSpy.and.callFake((group, callback) => callback(smallEntitiesData));
        component.onGetRows(getRowsEvent);
        fixture.detectChanges();
        expect(actionSpy).toHaveBeenCalled();
        expect(successSpy).toHaveBeenCalledWith({
            rowData: smallEntitiesData,
            rowCount: smallEntitiesData.length
        });
    });

    it('should dispatch load entities for internal group', () => {
        const internalGroup: any = {
            entity_group_id: 1,
            edh_entity_group_id: 1,
            edh_entity_group_guid: '123456789',
            edh_entity_group_name: 'Test internal group',
            edh_entity_group_type: 'I',
            entities: []
        };
        const gridData: Array<any> = [
            {
                entity_name: ['Test name'],
                entity_country: '',
                entity_type: '',
                domestic_jurisdiction: '',
                foreign_jurisdiction: '',
                entity_group: null,
                is_group: true
            }
        ];
        const getRowsEvent = {
            request: {
                groupKeys: [],
                startRow: 0,
                endRow: component.PAGE_SIZE
            },
            success: (params) => {}
        };
        const bigEntitiesData = createSSRMEntityDataItems(component.PAGE_SIZE);
        const smallEntitiesData = createSSRMEntityDataItems(1);

        const actionSpy = spyOn((component as any).store$, 'dispatch');
        const successSpy = spyOn(getRowsEvent, 'success');
        const subscribeEntityGroupEntitiesLoadedStateSpy = spyOn(component as any, 'subscribeEntityGroupEntitiesLoadedState');
        component.allEntitiesGroup = null;
        component['implicitGroup'] = internalGroup;

        subscribeEntityGroupEntitiesLoadedStateSpy.and.callFake((group, callback) => callback(bigEntitiesData));
        component['gridData'] = [];
        component.onGetRows(getRowsEvent);
        fixture.detectChanges();
        expect(actionSpy).toHaveBeenCalled();
        expect(successSpy).toHaveBeenCalledWith({
            rowData: bigEntitiesData,
            rowCount: null
        });

        subscribeEntityGroupEntitiesLoadedStateSpy.and.callFake((group, callback) => callback(smallEntitiesData));
        component['gridData'] = [];
        component.onGetRows(getRowsEvent);
        fixture.detectChanges();
        expect(actionSpy).toHaveBeenCalled();
        expect(successSpy).toHaveBeenCalledWith({
            rowData: smallEntitiesData,
            rowCount: smallEntitiesData.length
        });

        subscribeEntityGroupEntitiesLoadedStateSpy.and.callFake((group, callback) => callback(smallEntitiesData));
        component['gridData'] = gridData;
        component.onGetRows(getRowsEvent);
        fixture.detectChanges();
        expect(actionSpy).toHaveBeenCalled();
        expect(successSpy).toHaveBeenCalledWith({
            rowData: [ ...gridData, ...smallEntitiesData ],
            rowCount: smallEntitiesData.length + gridData.length
        });
    });

    it('should dispatch load entities for all entities group', () => {
        const gridData: Array<any> = [
            {
                entity_name: ['Test name'],
                entity_country: '',
                entity_type: '',
                domestic_jurisdiction: '',
                foreign_jurisdiction: '',
                entity_group: null,
                is_group: true
            }
        ];
        const allEntitiesGroup: any = {
            entity_group_id: -1,
            edh_entity_group_id: -1,
            edh_entity_group_guid: '00000000-0000-0000-0000-0000000000',
            edh_entity_group_name: 'Test all entities group',
            edh_entity_group_type: 'I',
            entities: [],
            isAllEntitiesGroup: true
        };
        const getRowsEvent = {
            request: {
                groupKeys: []
            },
            success: (params) => {}
        };
        const bigEntitiesData = createSSRMEntityDataItems(component.PAGE_SIZE);
        const smallEntitiesData = createSSRMEntityDataItems(1);

        const actionSpy = spyOn((component as any).store$, 'dispatch');
        const successSpy = spyOn(getRowsEvent, 'success');
        const subscribeGetEntitiesStateSpy = spyOn(component as any, 'subscribeGetEntitiesState');
        component.allEntitiesGroup = allEntitiesGroup;
        component['implicitGroup'] = null;

        subscribeGetEntitiesStateSpy.and.callFake((callback) => callback(bigEntitiesData));
        component['gridData'] = [];
        component.onGetRows(getRowsEvent);
        fixture.detectChanges();
        expect(actionSpy).toHaveBeenCalled();
        expect(successSpy).toHaveBeenCalledWith({
            rowData: bigEntitiesData,
            rowCount: null
        });

        subscribeGetEntitiesStateSpy.and.callFake((callback) => callback(smallEntitiesData));
        component['gridData'] = [];
        component.onGetRows(getRowsEvent);
        fixture.detectChanges();
        expect(actionSpy).toHaveBeenCalled();
        expect(successSpy).toHaveBeenCalledWith({
            rowData: smallEntitiesData,
            rowCount: smallEntitiesData.length
        });

        subscribeGetEntitiesStateSpy.and.callFake((callback) => callback(smallEntitiesData));
        component['gridData'] = gridData;
        component.onGetRows(getRowsEvent);
        fixture.detectChanges();
        expect(actionSpy).toHaveBeenCalled();
        expect(successSpy).toHaveBeenCalledWith({
            rowData: [ ...gridData, ...smallEntitiesData ],
            rowCount: smallEntitiesData.length + gridData.length
        });
    });

    it('should set and clear selected entities', () => {
        const selectEventSpy = spyOn(component.entitiesSelectionChange, 'emit');
        const clearEventSpy = spyOn(component.entitiesSelectionCleared, 'emit');
        const data = [{
            entity_id: '1',
            entity_guid: '1',
            entity_type: '',
            entity_country: '',
            domestic_jurisdiction: '',
            foreign_jurisdiction: [],
            entity_name: ['1'],
            entity_group: {
                entity_group_id: 3,
                edh_entity_group_id: 3,
                edh_entity_group_guid: '23f77391-b001-41a8-a528-ec3c3dc3c5a0',
                edh_entity_group_name: 'Entity Group 3',
                edh_entity_group_type: 'C',
                entity_type: 'LLC',
                entity_status: 'Active',
                jurisdiction: 'FL, GA, AL, SC, NC, MI, LA',
                entities: []
            },
            is_group: false
        }] as any;

        component.onEntitiesSelectionChange({ total: 1, selected: data });
        expect(component['selectedItems'].length).toBeTruthy();
        expect(selectEventSpy).toHaveBeenCalled();

        component.onEntitiesSelectionCleared();
        expect(component['selectedItems'].length).toBeFalsy();
        expect(clearEventSpy).toHaveBeenCalled();
    });

    it('should init data and clear selection', () => {
        const selectedItems = [{
            entity_id: '1',
            entity_guid: '1',
            entity_type: '',
            entity_country: '',
            domestic_jurisdiction: '',
            foreign_jurisdiction: [],
            entity_name: ['1'],
            entity_group: {
                entity_group_id: 3,
                edh_entity_group_id: 3,
                edh_entity_group_guid: '23f77391-b001-41a8-a528-ec3c3dc3c5a0',
                edh_entity_group_name: 'Entity Group 3',
                edh_entity_group_type: 'C',
                entity_type: 'LLC',
                entity_status: 'Active',
                jurisdiction: 'FL, GA, AL, SC, NC, MI, LA',
                entities: []
            },
            is_group: false
        }] as any;
        const entityGroups = [{
            entity_group_id: 1,
            edh_entity_group_id: 1,
            edh_entity_group_guid: '3fd77391-b001-41a8-a528-ec3c3dc3c5a9',
            edh_entity_group_name: 'Entity Group 1',
            edh_entity_group_type: 'C',
            entity_type: 'LLC',
            entity_status: 'Active',
            jurisdiction: 'FL, GA, AL, SC, NC, MI, LA',
            entities: [{
                entity_id: 96000005937,
                entity_guid: '11f28063-f227-41a2-b1fd-cc75b2586172',
                entity_name: 'Entity Name 1',
                entity_type: 'Corp',
                entity_country: 'US',
                domestic_jurisdiction: 'Delaware',
                foreign_jurisdiction: 'Delaware'
            }]
        }] as any;
        component.entitiesGridComponent = { clearSelection: jasmine.createSpy() } as any;
        component['selectedItems'] = selectedItems;
        component['gridApi'] = { refreshServerSideStore: (data: any) => {} } as any;
        component['initGridData'](entityGroups);
        expect(component.entitiesGridComponent.clearSelection).toHaveBeenCalled();
    });

    it('should sort entity groups', () => {
        const internalGroup = {
            entity_group_id: 1,
            edh_entity_group_id: 1,
            edh_entity_group_guid: '1',
            edh_entity_group_name: 'Internal group',
            edh_entity_group_type: 'I',
            entities: []
        };
        const customGroup1 = {
            entity_group_id: 2,
            edh_entity_group_id: 2,
            edh_entity_group_guid: '2',
            edh_entity_group_name: 'Custom group 1',
            edh_entity_group_type: 'C',
            entities: []
        };
        const customGroup2 = {
            entity_group_id: 3,
            edh_entity_group_id: 3,
            edh_entity_group_guid: '3',
            edh_entity_group_name: 'Custom group 2',
            edh_entity_group_type: 'C',
            entities: []
        };
        const groupsArray = [customGroup2, internalGroup, customGroup1];
        groupsArray.sort((component as any).sortEntityGroupsFn);
        expect(groupsArray).toEqual([
            customGroup1,
            customGroup2,
            internalGroup
        ]);
    });

    it('should build a tree grid data', () => {
        const expectedCount = 6;
        const gridData = [
            {
                entity_group_id: 1,
                edh_entity_group_id: 1,
                edh_entity_group_guid: '3fd77391-b001-41a8-a528-ec3c3dc3c5a9',
                edh_entity_group_name: 'Entity Group 1',
                edh_entity_group_type: 'C',
                entity_type: 'LLC',
                entity_status: 'Active',
                jurisdiction: 'FL, GA, AL, SC, NC, MI, LA',
                entities: [
                    {
                        entity_id: 96000005937,
                        entity_guid: '11f28063-f227-41a2-b1fd-cc75b2586172',
                        entity_name: 'Entity Name 1',
                        entity_type: 'Corp',
                        entity_country: 'US',
                        domestic_jurisdiction: 'Delaware',
                        foreign_jurisdiction: 'Delaware'
                    },
                    {
                        entity_id: 96000005938,
                        entity_guid: '11f28063-f227-41a2-b1fd-cc75b2589876',
                        entity_name: 'Entity Name 2',
                        entity_type: 'LLC',
                        entity_country: 'US',
                        domestic_jurisdiction: 'New York',
                        foreign_jurisdiction: 'Delaware'
                    }
                ]
            },
            {
                entity_group_id: 2,
                edh_entity_group_id: 2,
                edh_entity_group_guid: '3fd77391-b001-41a8-a528-ec3c3dc3c5a9',
                edh_entity_group_name: 'Entity Group 2',
                edh_entity_group_type: 'I',
                entity_type: 'LLC',
                entity_status: 'Active',
                jurisdiction: 'FL, GA, AL, SC, NC, MI, LA',
                entities: [
                    {
                        entity_id: 96000005939,
                        entity_guid: '11f28063-f227-41a2-b1fd-cc75b2586172',
                        entity_name: 'Entity Name 3',
                        entity_type: 'Corp',
                        entity_country: 'US',
                        domestic_jurisdiction: 'Delaware',
                        foreign_jurisdiction: 'Delaware'
                    },
                    {
                        entity_id: 96000005940,
                        entity_guid: '11f28063-f227-41a2-b1fd-cc75b2589876',
                        entity_name: 'Entity Name 4',
                        entity_type: 'LLC',
                        entity_country: 'US',
                        domestic_jurisdiction: 'New York',
                        foreign_jurisdiction: 'Delaware'
                    }
                ]
            },
            {
                entity_group_id: 3,
                edh_entity_group_id: 3,
                edh_entity_group_guid: '23f77391-b001-41a8-a528-ec3c3dc3c5a0',
                edh_entity_group_name: 'Entity Group 3',
                edh_entity_group_type: 'C',
                entity_type: 'LLC',
                entity_status: 'Active',
                jurisdiction: 'FL, GA, AL, SC, NC, MI, LA',
                entities: []
            }
        ];
        const data = (component as any).mapEntityGroupsDataToGridData(gridData);
        fixture.detectChanges();
        expect(data.length).toBe(expectedCount);
    });

    it('should build a tree grid data from specific group entities', () => {
        const expectedCount1 = 0;
        const expectedCount2 = 2;
        const data = [
            {
                entityId: 1,
                entityGuid: '1',
                entityName: '1',
                entityTypeId: 1,
                entityTypeDesc: '',
                countryId: 1,
                countryDesc: '',
                countryShortName: 'US',
                domesticJurisdictionId: 1,
                domesticJurisdictionDesc: '',
                domesticJurisdictionCode: '',
                activeForeignJurisCount: 0,
                totalForeignJurisCount: 0
            },
            {
                entityId: 2,
                entityGuid: '2',
                entityName: '2',
                entityTypeId: 2,
                entityTypeDesc: '',
                countryId: 2,
                countryDesc: '',
                countryShortName: 'DE',
                domesticJurisdictionId: 2,
                domesticJurisdictionDesc: '',
                domesticJurisdictionCode: '',
                activeForeignJurisCount: 0,
                totalForeignJurisCount: 0
            }
        ];
        const result1 = (component as any).mapEntitiesDataToGridData(
            null,
            null
        );
        fixture.detectChanges();
        expect(result1.length).toBe(expectedCount1);

        const result2 = (component as any).mapEntitiesDataToGridData(
            data,
            null
        );
        fixture.detectChanges();
        expect(result2.length).toBe(expectedCount2);
    });

    it('should call callback when entities loaded', () => {
        const expectedCallsCount = 2;
        const callbackMock = jasmine.createSpy();
        const entitiesListMock = [{
            entity_id: 1,
            entity_guid: '1',
            entity_type: '',
            entity_name: '1',
            entity_country: '',
            domestic_jurisdiction: '',
            domestic_jurisdiction_abbr: ''
        }];
        component.roleId = 1;
        const key = `${component.roleId}${component['guid']}`;

        component['subscribeGetEntitiesState'](callbackMock);
        component['actionsListener$'].next(
            roleManagementGetEntitiesSuccessAction({
                data: entitiesListMock,
                key
            })
        );
        component['subscribeGetEntitiesState'](callbackMock);
        component['actionsListener$'].next(
            roleManagementGetEntitiesFailureAction({
                error: 'error',
                key
            })
        );
        expect(callbackMock).toHaveBeenCalledTimes(expectedCallsCount);
    });

    it('should destroy', () => {
        const nextSpy = spyOn(component['destroyed$'], 'next');
        const completeSpy = spyOn(component['destroyed$'], 'complete');
        component.ngOnDestroy();
        expect(nextSpy).toHaveBeenCalled();
        expect(completeSpy).toHaveBeenCalled();
    });
});
