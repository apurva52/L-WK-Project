/* tslint:disable:max-file-line-count */
import { GridApi } from '@ag-grid-community/core';
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges, ViewChild } from '@angular/core';
import { BulkOption, EntitiesGridComponent, SSRMEntityDataItem } from '@ct/platform-common-uicomponents/entities-grids';
import { SelectedEvent } from '@ct/platform-common-uicomponents/entities-grids/shared/interfaces/selected-event.interface';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { filter, take } from 'rxjs/operators';
import { generateUUID } from 'src/shared/util';

import { selectIsInternal } from '../../../../app/state/app.selectors';
import {
    roleManagementGetEntitiesAction,
    roleManagementGetEntitiesFailureAction,
    roleManagementGetEntitiesSuccessAction
} from '../../../../pages/users-and-roles/roles-management/state/role-management.actions';
import { Entity } from '../../../../pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity';
import { GridEntityGroup } from '../../../../pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity-group';
import {
    userManagementLoadEntityGroupEntitiesAction,
    userManagementLoadEntityGroupEntitiesFailureAction,
    userManagementLoadEntityGroupEntitiesSuccessAction
} from '../../../../pages/users-and-roles/users-management/state/user-management.actions';
import { SpecificGroupEntityItem } from '../../../../shared/interfaces/entitites-for-specific-group.response';

@Component({
    selector: 'ct-user-entities-associate-grid',
    templateUrl: './user-entities-associate-grid.component.html',
    styleUrls: ['./user-entities-associate-grid.component.scss']
})
export class UserEntitiesAssociateGridComponent implements OnChanges {
    readonly PAGE_SIZE = 200;

    @Input() roleId: number;
    @Input() initialData: Array<GridEntityGroup> = [];
    @Input() bulkOptions: Array<BulkOption> = [];
    @Input() showLoading: boolean;
    @Input() lazyLoading: boolean = true;
    @Output() entitiesSelectionChange = new EventEmitter<SelectedEvent>();
    @Output() entitiesSelectionCleared = new EventEmitter();

    @ViewChild('entitiesGrid') entitiesGridComponent: EntitiesGridComponent;

    isInternalUser$ = this.store$.select(selectIsInternal);

    allEntitiesGroup: GridEntityGroup;
    private implicitGroup: GridEntityGroup;
    private guid = generateUUID();
    private selectedItems = [];
    private gridData: Array<SSRMEntityDataItem> = [];
    private gridApi: GridApi;
    private destroyed$: Subject<boolean> = new Subject<boolean>();

    constructor(
        private store$: Store,
        private actionsListener$: ActionsSubject
    ) {}

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.initialData) {
            this.initGridData([...changes.initialData.currentValue]);
        }
    }

    ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    onGridReady(params): void {
        this.gridApi = params.api;
    }

    onGetRows(event): void {
        const pageSize = event.request.endRow - event.request.startRow || this.PAGE_SIZE;
        const page = Math.ceil(event.request.endRow / pageSize) || 1;
        if (event.request?.groupKeys?.length) {
            const group = event.request.groupKeys.at(-1);
            this.getSpecialGroupRows(group, page, pageSize, event);
        } else if (this.allEntitiesGroup) {
            this.getAllEntitiesGroupRows(page, pageSize, event);
        } else if (this.implicitGroup) {
            this.getImplicitGroupRows(page, pageSize, event);
        } else {
            event.success({
                rowData: this.gridData.slice((page - 1) * pageSize,  page * pageSize) || [],
                rowCount: this.gridData.length < page * pageSize ? this.gridData.length : null
            });
        }
    }

    onEntitiesSelectionChange(data: SelectedEvent): void {
        this.selectedItems = data.selected;
        this.entitiesSelectionChange.emit(data);
    }

    onEntitiesSelectionCleared(): void {
        this.selectedItems = [];
        this.entitiesSelectionCleared.emit();
    }

    private initGridData(entitiGroups: Array<GridEntityGroup>): void {
        entitiGroups.sort(this.sortEntityGroupsFn);
        this.allEntitiesGroup = entitiGroups.find(group =>
            group.edh_entity_group_type === 'I' && group.edh_entity_group_id === -1 && group.isAllEntitiesGroup
        );
        const implicitGroup = !this.allEntitiesGroup && entitiGroups.find(group =>
            group.edh_entity_group_type === 'I' && group.edh_entity_group_id !== -1
        );
        this.gridData = this.mapEntityGroupsDataToGridData(entitiGroups);
        if (implicitGroup && implicitGroup.edh_entity_group_id > -1) {
            this.implicitGroup = implicitGroup;
        }
        if (
            this.selectedItems.some((item) => !this.gridData.find((dataItem) => item.is_group
                ? dataItem.entity_group.edh_entity_group_id === item.entity_group.edh_entity_group_id
                : (dataItem as any).entity_id === item.entity_id))
        ) {
            this.entitiesGridComponent?.clearSelection();
        }
        if (this.gridApi) {
            this.gridApi.refreshServerSideStore({ purge: true });
        }
    }

    private sortEntityGroupsFn(
        group1: GridEntityGroup,
        group2: GridEntityGroup
    ): number {
        if (group1.edh_entity_group_type === 'I') {
            return 1;
        }
        if (group2.edh_entity_group_type === 'I') {
            return -1;
        }
        const group1Name = group1.edh_entity_group_name || '';
        const group2Name = group2.edh_entity_group_name || '';
        return group1Name.toLowerCase().localeCompare(group2Name.toLowerCase());
    }

    private sortEntitiesFn(entity1: Entity, entity2: Entity): number {
        const entity1Name = entity1.entity_name || '';
        const entity2Name = entity2.entity_name || '';
        return entity1Name.toLowerCase().localeCompare(entity2Name.toLowerCase());
    }

    private subscribeEntityGroupEntitiesLoadedState(
        group: GridEntityGroup,
        callback: (params: Array<SSRMEntityDataItem>) => void
    ): void {
        this.actionsListener$
            .pipe(
                ofType(
                    userManagementLoadEntityGroupEntitiesSuccessAction,
                    userManagementLoadEntityGroupEntitiesFailureAction
                ),
                filter(
                    (data) =>
                        data.roleId === this.roleId &&
                        data.groupGuid === group.edh_entity_group_guid
                ),
                take(1)
            )
            .subscribe((response) => {
                const gridData = this.mapEntitiesDataToGridData(
                    response['result']?.data || [],
                    group
                );
                callback(gridData);
            });
    }

    private mapEntityGroupsDataToGridData(
        dataArray: Array<GridEntityGroup>
    ): Array<SSRMEntityDataItem> {
        return dataArray.reduce((previousValue, group: GridEntityGroup) => {
            const treeGroup =
                group.edh_entity_group_type !== 'I'
                    ? [
                          {
                              entity_name: [group.edh_entity_group_name],
                              entity_type: '',
                              entity_country: '',
                              domestic_jurisdiction: '',
                              foreign_jurisdictions: '',
                              entity_group: group,
                              is_group: true
                          }
                      ]
                    : [];
            let entities = [];
            if (group.entities?.length) {
                group.entities.sort(this.sortEntitiesFn);
                entities = group.entities.map((item) => ({
                    ...item,
                    entity_name:
                        group.edh_entity_group_type !== 'I'
                            ? [group.edh_entity_group_name, item.entity_name]
                            : [item.entity_name],
                    entity_group: group,
                    is_group: false
                }));
            }
            return previousValue.concat([...treeGroup, ...entities]);
        }, []);
    }

    private mapEntitiesDataToGridData(
        dataArray: Array<SpecificGroupEntityItem>,
        entityGroup: GridEntityGroup
    ): Array<SSRMEntityDataItem> {
        if (!dataArray?.length) {
            return [];
        }
        return dataArray.map(
            (entityItem) =>
                ({
                    ...entityItem,
                    entity_id: entityItem.entityId,
                    entity_guid: entityItem.entityGuid,
                    entity_type: entityItem.entityTypeDesc,
                    entity_country: entityItem.countryShortName,
                    domestic_jurisdiction: entityItem.domesticJurisdictionDesc,
                    foreign_jurisdiction: [],
                    entity_name: [entityItem.entityName],
                    entity_group: entityGroup,
                    is_group: false
                } as any)
        );
    }

    private subscribeGetEntitiesState(callback: (data: Array<SSRMEntityDataItem>) => void): void {
        this.actionsListener$
            .pipe(
                ofType(
                    roleManagementGetEntitiesSuccessAction,
                    roleManagementGetEntitiesFailureAction
                ),
                filter((data) => data.key === `${this.roleId}${this.guid}`),
                take(1)
            )
            .subscribe((response) => {
                const entities: Array<any> = response['data'] || [];
                const treeData = entities.map(
                    (entityItem) =>
                        ({
                            ...entityItem,
                            entity_id: entityItem.entity_id,
                            entity_guid: entityItem.entity_guid,
                            entity_type: entityItem.entity_type,
                            entity_country: entityItem.entity_country,
                            domestic_jurisdiction: entityItem.domestic_jurisdiction,
                            foreign_jurisdiction: [],
                            entity_name: [entityItem.entity_name],
                            entity_group: this.allEntitiesGroup,
                            is_group: false
                        })
                );
                callback(treeData);
            });
    }

    private getSpecialGroupRows(
        group: GridEntityGroup,
        page: number,
        pageSize: number,
        event: any
    ): void {
        this.store$.dispatch(
            userManagementLoadEntityGroupEntitiesAction({
                roleId: this.roleId,
                groupGuid: group.edh_entity_group_guid,
                page,
                pageSize
            })
        );
        this.subscribeEntityGroupEntitiesLoadedState(group, (data) => {
            const lastRow = data.length < pageSize ? (page - 1) * pageSize + data.length : null;
            event.success({ rowData: data, rowCount: lastRow });
        });
    }

    private getAllEntitiesGroupRows(
        page: number,
        pageSize: number,
        event: any
    ): void {
        this.store$.dispatch(roleManagementGetEntitiesAction({
            page,
            pageSize,
            key: `${this.roleId}${this.guid}`
        }));
        this.subscribeGetEntitiesState(
            (data) => this.processInternalAndAllGroupEntitiesLoad(data, page, pageSize, event.success)
        );
    }

    private getImplicitGroupRows(
        page: number,
        pageSize: number,
        event: any
    ): void {
        this.store$.dispatch(
            userManagementLoadEntityGroupEntitiesAction({
                roleId: this.roleId,
                groupGuid: this.implicitGroup.edh_entity_group_guid,
                page,
                pageSize
            })
        );
        this.subscribeEntityGroupEntitiesLoadedState(
            this.implicitGroup,
            (data) => this.processInternalAndAllGroupEntitiesLoad(data, page, pageSize, event.success)
        );
    }

    private processInternalAndAllGroupEntitiesLoad(
        data: Array<any>,
        page: number,
        pageSize: number,
        eventSuccess: Function
    ): void {
        let rowCount = data.length < pageSize ? (page - 1) * pageSize + data.length : null;
        let rowData = data;
        if (page === 1) {
            const gridDataGroups = this.gridData.filter(d => d.is_group);
            rowData = [...gridDataGroups, ...data];
            if (rowCount && gridDataGroups.length) {
                rowCount += gridDataGroups.length;
            }
        }
        eventSuccess({ rowData, rowCount });
    }
}
