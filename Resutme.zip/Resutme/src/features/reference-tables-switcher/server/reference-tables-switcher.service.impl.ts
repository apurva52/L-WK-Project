import { appSettingsSection } from '@ct/core-ui/server';
import {
    QuickSwitcherApiService,
    SwitcherData,
    SwitcherItem
} from '@ct/platform-common-uicomponents/server';

import {
    QUICK_SWITCHER_REFERENCE_TYPES,
    QUICK_SWITCHER_ROLES,
    QUICK_SWITCHER_USERS,
    QUICK_SWITCHER_USERS_PAGE_SIZE
} from '../../../shared/config/quick-switcher.config';
import { ReferenceTypesServiceImpl } from '../../../shared/services/reference-types/reference-types.service.impl';

export class QuickSwitcherApiServiceImpl
    extends ReferenceTypesServiceImpl
    implements QuickSwitcherApiService
{
    @appSettingsSection('apiUrls')
    apiUrls: Promise<{ [key: string]: string }>;

    async getList(params): Promise<SwitcherData> {
        let response: any;
        switch (params.controlId) {
            case QUICK_SWITCHER_REFERENCE_TYPES:
                response = await this.getTypesList({
                    page: params.pageNumber,
                    pageSize: 200,
                    sortBy: params.sortBy,
                    sortOrder: params.sortKey
                });
                break;
            case QUICK_SWITCHER_USERS:
                response = await this.getUsersList({
                    controlId: params.controlId,
                    page: Math.ceil(params.pageNumber),
                    pageSize: params.pageSize || QUICK_SWITCHER_USERS_PAGE_SIZE,
                    sortBy: params.sortBy,
                    sortKey: params.sortKey,
                    userName: params.searchValue
                } as any);
                const data = response.data.map((user) => {
                    return {
                        ...user,
                        roleCounter: user.roles.length
                            .toString()
                            .padStart(2, '0')
                    };
                });
                response.data = data;
                break;
            case QUICK_SWITCHER_ROLES:
                response = await this.getRolesList(params);
                break;
            default:
                break;
        }

        return {
            data: response.data as unknown as Array<SwitcherItem>,
            page: response.page,
            pageSize: response.pageSize
        };
    }
}
