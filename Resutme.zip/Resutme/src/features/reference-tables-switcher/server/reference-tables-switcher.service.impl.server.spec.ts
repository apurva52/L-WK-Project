jest.mock('@wk/edge-services', () => {
    const module = jest.requireActual('@wk/edge-services');

    return {
        __esModule: true,
        ...module,
        getRequest: () => undefined
    };
});

import * as serverCore from '@ct/core-ui/server';
import { EdgeFetchOptions } from '@ct/core-ui/src/edge-fetch/interfaces/edge-fetch-options';

import { groupsListMock } from '../../../pages/groups/shared';
import { ReferenceTablesResponseData } from '../../../pages/reference-tables/shared/mock/referenceTablesStub-data.mock';
import {
    QUICK_SWITCHER_ENTITY_GROUPS,
    QUICK_SWITCHER_REFERENCE_TYPES
} from '../../../shared/config/quick-switcher.config';

import { QuickSwitcherApiServiceImpl } from './reference-tables-switcher.service.impl';

const mockRequest = {
    controlId: QUICK_SWITCHER_REFERENCE_TYPES,
    pageNumber: 1,
    pageSize: 100,
    sortKey: 'asc',
    sortBy: 'referenceDesc'
};

const groupMockRequest = {
    controlId: QUICK_SWITCHER_ENTITY_GROUPS,
    pageNumber: 1,
    pageSize: 100,
    sortKey: 'asc',
    sortBy: 'entityGroupName',
    queryParams: [{ field: 'type', value: 'D' }]
};

describe('Quick switcher service', () => {
    let service: QuickSwitcherApiServiceImpl;
    const testApiUrls = {
        EMAccountServiceUrl: 'https://example.com'
    };
    const testSubscriptionKey = 'test';

    beforeEach(() => {
        jest.restoreAllMocks();
        service = new QuickSwitcherApiServiceImpl();
        Reflect.defineProperty(service, 'apiUrls', {
            value: Promise.resolve(testApiUrls)
        });
        Reflect.defineProperty(service, 'subscriptionKey', {
            value: Promise.resolve(testSubscriptionKey)
        });
    });

    describe('Quick switcher service', () => {
        beforeEach(() => {
            jest.spyOn(serverCore, 'edgeFetch').mockImplementation(
                (url: any, options: EdgeFetchOptions<object>) => {
                    return Promise.resolve({
                        result: {
                            url: url.toString(),
                            options
                        }
                    });
                }
            );
        });

        it('should construct url with params', (done) => {
            spyOn(service, 'getTypesList').and.returnValue(
                new Promise((resolve) => {
                    resolve(ReferenceTablesResponseData);
                })
            );
            service.getList(mockRequest).then((result) => {
                expect(service.getTypesList).toHaveBeenCalled();
                expect(result).toEqual({
                    data: ReferenceTablesResponseData.data,
                    page: ReferenceTablesResponseData.page,
                    pageSize: ReferenceTablesResponseData.pageSize
                });
                done();
            });
        });
    });
});
