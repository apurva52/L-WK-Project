import { SwitcherListItemType } from '@ct/platform-common-uicomponents/quick-switcher';

export const groupControlId = 'switcher-reference-types';

export const groupSwitcherConfig = {
    defaultSortField: 'entityGroupName',
    enableInfiniteScroll: false,
    expanded: true,
    hideFilter: false,
    i18nBase: 'GroupsModule.QuickSwitcherComponent',
    idField: 'entityGroupGuid',
    searchField: 'entityGroupName',
    rowDefinition: [
        {
            cellType: SwitcherListItemType.Text,
            propertyName: 'entityGroupName'
        },
        {
            cellType: SwitcherListItemType.Tag,
            propertyName: 'groupType'
        }
    ],
    queryParams: []
};
