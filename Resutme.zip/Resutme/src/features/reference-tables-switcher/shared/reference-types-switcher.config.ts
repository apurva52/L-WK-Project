import {
    SwitcherConfig,
    SwitcherListItemType
} from '@ct/platform-common-uicomponents/quick-switcher';

export const controlId = 'switcher-reference-types';

export const switcherConfig: SwitcherConfig = {
    defaultSortField: 'referenceDesc',
    enableInfiniteScroll: false,
    expanded: true,
    hideFilter: false,
    i18nBase: 'ReferenceTypesModule.QuickSwitcherComponent',
    idField: 'referenceId',
    searchField: 'referenceDesc',
    rowDefinition: [
        {
            cellType: SwitcherListItemType.Text,
            propertyName: 'referenceDesc'
        }
    ]
};
