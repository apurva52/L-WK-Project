/* tslint:disable:no-unused-variable */
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';

import { PeopleGridComponent } from './people-grid.component';

describe('PeopleGridComponent', () => {
    let component: PeopleGridComponent;
    let fixture: ComponentFixture<PeopleGridComponent>;
    const actions$: Observable<any> = of();

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [PeopleGridComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockActions(() => actions$),
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    }
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(PeopleGridComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should cancel notification', () => {
        component.onCancelNotification();
        expect(component._showNotification).toEqual(false);
    });
    it('should remove visibility', () => {
        component.onRemoveVisibility();
        expect(component._showNotification).toEqual(true);
    });
    it('should change selected person', () => {
        const selectionEvent = {
            selected: ['Person one']
        };
        component.onSelectionChange(selectionEvent);
        expect(component.selectedNodes.length).toEqual(1);
    });

    it('should clear selected people', () => {
        component.selectedNodes = ['Person 1', 'Person 2'];
        component.onClearSelection();
        expect(component.selectedNodes.length).toEqual(0);
    });
    it('should close notification after confirm action', () => {
        component.showNotification();
        component.onConfirmNotification();
        expect(component._showNotification).toEqual(false);
    });
});
