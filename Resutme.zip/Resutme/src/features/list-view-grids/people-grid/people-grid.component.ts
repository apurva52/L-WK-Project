import { GridOptions } from '@ag-grid-community/core';
import { Component, OnInit } from '@angular/core';
import { CTGridColumnDefinition } from '@ct/platform-primitives-uicomponents/grid';
import {
    NotificationModel,
    NotificationType
} from '@ct/platform-primitives-uicomponents/primitives';

@Component({
    selector: 'ct-people-grid',
    templateUrl: './people-grid.component.html',
    styleUrls: ['./people-grid.component.scss']
})
export class PeopleGridComponent implements OnInit {
    NotificationType = NotificationType;
    notification: NotificationModel;
    _showNotification = false;
    rowHeight = 48;
    selectedNodes = [];
    gridData: Array<any> = [
        {
            person_name: 'Frank Yellow',
            category: 'Officer',
            email: 'frank@mail.com',
            isActive: false
        },
        {
            person_name: 'Betty White',
            category: 'Officer',
            email: 'Betty@mail.com',
            isActive: true
        },
        {
            person_name: 'Ann Brown',
            category: 'Officer',
            email: 'ann@mail.com',
            isActive: false
        },
        {
            person_name: 'Mary Black',
            category: 'Officer',
            email: 'mary@mail.com',
            isActive: true
        }
    ];

    gridOptions: GridOptions = {
        rowModelType: 'clientSide',
        rowSelection: 'multiple',
        getRowNodeId: (params) => this.getRowId(params),
        suppressDragLeaveHidesColumns: true,
        suppressCellSelection: true,
        suppressMultiRangeSelection: false,
        suppressMenuHide: true,
        suppressRowClickSelection: true,
        isRowSelectable: (params) => {
            return params.data?.isActive;
        },
        defaultColDef: {
            sortable: false,
            resizable: false,
            filter: false,
            suppressMenu: true,
            cellStyle: (params) => {
                return (
                    !params.data?.isActive && {
                        opacity: 0.25
                    }
                );
            },
            filterParams: {
                caseSensitive: false
            }
        },
        rowStyle: {
            'border-top': 'white 4px solid',
            'border-bottom': 'white 4px solid'
        }
    };

    gridDefinition: Array<CTGridColumnDefinition> = [
        {
            colDef: {
                headerName: 'Name',
                field: 'person_name',
                checkboxSelection: true
            },
            dataType: 'CUSTOM'
        },
        {
            colDef: {
                headerName: 'Category',
                field: 'category'
            },
            dataType: 'CUSTOM'
        },
        {
            colDef: {
                headerName: 'Email',
                field: 'email'
            },
            dataType: 'CUSTOM'
        }
    ];

    get isNotificationVisible(): boolean {
        return this._showNotification;
    }

    get isNodeSelected(): boolean {
        return this.selectedNodes.length > 0;
    }

    ngOnInit(): void {
        this.notification = {
            title: 'Warning',
            content:
                'Are you sure you want to remove visibility of selected users?',
            confirmationText: 'Confirm',
            cancelationText: 'Cancel'
        };
    }

    onCancelNotification(): void {
        this.hideNotification();
    }
    onConfirmNotification(): void {
        this.hideNotification();
    }
    showNotification(): void {
        this._showNotification = true;
    }
    hideNotification(): void {
        this._showNotification = false;
    }
    onSelectionChange($event): void {
        this.selectedNodes = $event.selected;
    }
    onClearSelection(): void {
        this.selectedNodes = [];
    }
    onRemoveVisibility(): void {
        this.showNotification();
    }

    private getRowId(person): string {
        return person.email;
    }
}
