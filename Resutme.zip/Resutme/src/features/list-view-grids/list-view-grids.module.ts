import { AgGridModule } from '@ag-grid-community/angular';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CtGridModule } from '@ct/platform-primitives-uicomponents/grid';
import { CtPrimitivesModule } from '@ct/platform-primitives-uicomponents/primitives';

import { PeopleGridComponent } from './people-grid/people-grid.component';

@NgModule({
    declarations: [PeopleGridComponent],
    imports: [CtPrimitivesModule, CtGridModule, AgGridModule],
    exports: [PeopleGridComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ListViewGridsModule {}
