export interface WidgetData {
    title: string;
    primaryCount?: string;
    primaryLabel?: string;
    secondaryCount?: string;
    secondaryLabel?: string;
    description?: string;
    link: string;
}
