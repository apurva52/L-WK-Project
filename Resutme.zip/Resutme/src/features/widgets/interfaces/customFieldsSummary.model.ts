export interface customFieldsSummary {
    totalNumber: string;
    requiredFields: string;
}