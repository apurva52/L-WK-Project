import {
    Component,
    EventEmitter,
    HostListener,
    Input,
    OnInit,
    Output
} from '@angular/core';
import { FormControl } from '@angular/forms';
import { MultiselectItem } from '@wk/components-angular11';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
    selector: 'ct-lazy-multiselect',
    templateUrl: './lazy-multiselect.component.html',
    styleUrls: ['./lazy-multiselect.component.scss']
})
export class LazyMultiselectComponent implements OnInit {
    @Input() itemsState$: Observable<Array<MultiselectItem>>;
    @Input() isOpen: boolean = false;
    @Input() disabled: boolean = false;
    @Input() pillLabel: string;
    @Input() totalItems: number;
    @Input() loading: boolean = false;
    @Input() placeholder: string = 'Select';
    @Input() loadingText: string = 'Loading...';
    @Input() control: FormControl = new FormControl();
    @Input() placement: 'wk-dropdown-up' | 'wk-dropdown-down' =
        'wk-dropdown-down';

    @Output() onScrollBottom: EventEmitter<void> = new EventEmitter();

    get selectedItemsText(): string {
        if (this.selectedItems.length === 1) {
            return this.selectedItems[0].label;
        }
        return (
            this.pillLabel ||
            this.selectedItems.map((item) => item.label).join(', ')
        );
    }

    items: Array<MultiselectItem> = [];
    selectedItems: Array<MultiselectItem> = [];

    private unselectAllPressed = false;
    private readonly LOAD_ITEMS_OFFSET = 200;
    private destroyed$: Subject<boolean> = new Subject<boolean>();

    ngOnInit(): void {
        this.itemsState$
            ?.pipe(takeUntil(this.destroyed$))
            .subscribe((items) => {
                this.items.push(...items);
            });
        this.selectedItems = this.control.value || [];
    }

    ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    toggleDropdown(): void {
        if (this.disabled) {
            return;
        }
        if (!this.unselectAllPressed) {
            this.isOpen = !this.isOpen;
        }
        this.unselectAllPressed = false;
    }

    toggleSelect(item: MultiselectItem, checked: boolean): void {
        const itemSelectedIndex = this.selectedItems.findIndex(
            (selectedItem: MultiselectItem) => selectedItem.id === item.id
        );
        if (checked) {
            this.selectedItems.push(item);
        } else {
            this.selectedItems.splice(itemSelectedIndex, 1);
        }
        this.control.setValue(this.selectedItems);
    }

    unselectAllOptions(): void {
        this.items.forEach((item) => (item.isSelected = false));
        this.unselectAllPressed = true;
        this.control.setValue([]);
        this.selectedItems = [];
    }

    @HostListener('scroll', ['$event'])
    onScroll($event: Event): void {
        const target = $event.target as HTMLInputElement;
        const { scrollHeight, scrollTop, clientHeight } = target;
        const isAtBottomScroll: boolean =
            this.LOAD_ITEMS_OFFSET >= scrollHeight - scrollTop - clientHeight;
        if (
            isAtBottomScroll &&
            !this.loading &&
            this.items.length < this.totalItems
        ) {
            this.onScrollBottom.emit();
        }
    }
}
