/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';

import { LazyMultiselectComponent } from './lazy-multiselect.component';

describe('LazyMultiselectComponent', () => {
    let component: LazyMultiselectComponent;
    let fixture: ComponentFixture<LazyMultiselectComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [LazyMultiselectComponent]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(LazyMultiselectComponent);
        component = fixture.componentInstance;
    });

    it('should create', () => {
        component.itemsState$ = of([]);
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });

    describe('selectedItemsText', () => {
        it('should get Selected Items when is only One', () => {
            const label = 'UNIT_TEST';
            component.control.setValue([
                {
                    label,
                    id: 'test',
                    isSelected: true
                }
            ]);
            fixture.detectChanges();
            expect(component.selectedItemsText).toEqual(label);
        });

        it('should get pill label from get Selected Items', () => {
            component.pillLabel = 'UNIT_TEST';
            fixture.detectChanges();
            expect(component.selectedItemsText).toEqual(component.pillLabel);
        });

        it('should get multiple labels from get Selected Items', () => {
            component.control.setValue([
                {
                    label: 'UT1',
                    id: 'test1',
                    isSelected: true
                },
                {
                    label: 'UT2',
                    id: 'test2',
                    isSelected: true
                }
            ]);
            fixture.detectChanges();
            expect(component.selectedItemsText).toEqual(
                component.selectedItems.map((item) => item.label).join(', ')
            );
        });
    });

    describe('toggleDropdown', () => {
        it('should toggle dropdown', () => {
            component.isOpen = false;
            component.toggleDropdown();
            expect(component.isOpen).toBeTruthy();
        });
        it('should not toggle dropdown from unselectAllPressed', () => {
            component.isOpen = true;
            component['unselectAllPressed'] = true;
            component.toggleDropdown();
            expect(component.isOpen).toBeTruthy();
        });
        it('should not toggle dropdown from disable state', () => {
            component.isOpen = false;
            component.disabled = true;
            component.toggleDropdown();
            expect(component.isOpen).toBeFalsy();
        });
    });

    describe('toggleSelect', () => {
        it('should toggle select', () => {
            const item = {
                label: 'UT1',
                id: 'test1',
                isSelected: false
            };
            component.toggleSelect(item, true);
            expect(component.selectedItems).toContain(item);
        });

        it('should toggle select', () => {
            component.control.setValue([
                {
                    label: 'UT1',
                    id: 'test1',
                    isSelected: true
                },
                {
                    label: 'UT2',
                    id: 'test2',
                    isSelected: true
                }
            ]);
            const [item] = component.control.value;
            fixture.detectChanges();
            component.toggleSelect(item, false);
            expect(component.selectedItems).not.toContain(item);
        });
    });

    it('should unselect all', () => {
        component.items = [
            {
                label: 'UT1',
                id: 'test1',
                isSelected: true
            },
            {
                label: 'UT2',
                id: 'test2',
                isSelected: true
            }
        ];
        component.unselectAllOptions();
        expect(component.items.every((item) => item.isSelected)).toBeFalsy();
    });

    describe('onScroll', () => {
        it('should scroll without emit load more items', () => {
            const TOTAL_ITEMS = 100;
            component.totalItems = TOTAL_ITEMS;
            const event: any = {
                target: {
                    scrollTop: 0,
                    scrollHeight: 500,
                    clientHeight: 50
                }
            };
            spyOn(component.onScrollBottom, 'emit');
            component.onScroll(event);
            expect(component.onScrollBottom.emit).not.toHaveBeenCalled();
        });

        it('should scroll with emit load more items', () => {
            const TOTAL_ITEMS = 100;
            component.totalItems = TOTAL_ITEMS;
            const event: any = {
                target: {
                    scrollHeight: 400,
                    scrollTop: 150,
                    clientHeight: 150
                }
            };
            spyOn(component.onScrollBottom, 'emit');
            component.onScroll(event);
            expect(component.onScrollBottom.emit).toHaveBeenCalled();
        });
    });
});
