import { customFieldsSummary } from '../interfaces/customFieldsSummary.model';
export const WIDGETS_FEATURE_KEY = 'widgets';

export interface WidgetState {
    loading: boolean;
    customFieldsSummary: customFieldsSummary;
    error: any;
}

export const initialWidgetState: WidgetState = {
    loading: false,
    customFieldsSummary: {
        requiredFields: '0',
        totalNumber: '0'
    },
    error: null
};
