import { createFeatureSelector, createSelector } from '@ngrx/store';

import { WIDGETS_FEATURE_KEY, WidgetState } from './widget.state';

export const selectWidgetFeature = createFeatureSelector<WidgetState>(WIDGETS_FEATURE_KEY);

export const selectCustomFieldsSummary = createSelector(
    selectWidgetFeature,
    (state: WidgetState) => state.customFieldsSummary
);

export const selectCustomFieldsTotalNumber = createSelector(
    selectWidgetFeature,
    (state: WidgetState) => state.customFieldsSummary.totalNumber
);

export const selectCustomFieldsRequiredFields = createSelector(
    selectWidgetFeature,
    (state: WidgetState) => state.customFieldsSummary.requiredFields
);
