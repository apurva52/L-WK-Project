import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { from, of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';

import { CustomFieldsService } from '../../../shared/services/custom-fields/customFields.service';

import { widgetActions } from './widget.actions';


@Injectable()
export class WidgetEffects {

    loadCustomFieldsSummary$ = createEffect(() => this.actions$.pipe(
        ofType(widgetActions.loadCustomFieldsSummary),
        switchMap(() => {
            return from(
                this.customFieldsService.getSummary()
            ).pipe(
                map((response) => widgetActions.loadCustomFieldsSummarySuccess({
                    summary: response
                })),
                catchError((err) => of(widgetActions.loadCustomFieldsSummaryFailure({ error: err })))
            );
        })
    ));
    constructor(
        private actions$: Actions,
        private customFieldsService: CustomFieldsService
    ) { }
}
