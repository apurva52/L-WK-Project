import { Action, createReducer, on } from '@ngrx/store';

import { widgetActions } from './widget.actions';
import { initialWidgetState, WidgetState } from './widget.state';

const reducer = createReducer(
    initialWidgetState,
    on(widgetActions.loadCustomFieldsSummary, (state) => ({
        ...state,
        loading: true,
        error: null
    })),
    on(widgetActions.loadCustomFieldsSummarySuccess, (state, { summary }) => ({
        ...state,
        loading: false,
        customFieldsSummary: summary,
        error: null
    })),
    on(widgetActions.loadCustomFieldsSummaryFailure, (state, { error }) => ({
        ...state,
        loading: false,
        customFieldsSummary: null,
        error: error
    }))
    );
export function widgetReducer(state: WidgetState | undefined, action: Action): WidgetState {
        return reducer(state, action);
    }