import { createAction, props } from '@ngrx/store';

import { customFieldsSummary } from '../interfaces/customFieldsSummary.model';

export enum AppActionTypes {
    LoadCustomFieldsSummary = '[CT CustomFields] Load Custom Fields Summary',
    LoadCustomFieldsSummarySuccess = '[CT CustomFields] Load Custom Fields Summary success',
    LoadCustomFieldsSummaryFailure = '[CT CustomFields] Load Custom Fields Summary failure'
}

export const loadCustomFieldsSummary = createAction(
    AppActionTypes.LoadCustomFieldsSummary
);
export const loadCustomFieldsSummarySuccess = createAction(
    AppActionTypes.LoadCustomFieldsSummarySuccess,
    props<{ summary: customFieldsSummary }>()
);
export const loadCustomFieldsSummaryFailure = createAction(
    AppActionTypes.LoadCustomFieldsSummaryFailure,
    props<{ error: any }>()
);

export const widgetActions = {
    loadCustomFieldsSummary,
    loadCustomFieldsSummarySuccess,
    loadCustomFieldsSummaryFailure
};