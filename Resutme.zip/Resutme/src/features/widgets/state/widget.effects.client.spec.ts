import { TestBed } from '@angular/core/testing';
import { ExperienceConfigurationServiceNg } from '@ct/core-ui-ng';
import { EffectsModule } from '@ngrx/effects';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { Observable } from 'rxjs';
import { TestScheduler } from 'rxjs/testing';

import { CustomFieldsService } from '../../../shared/services/custom-fields/customFields.service';
import { CustomFieldsSummarySuccessStub } from '../test-values/customFieldsSummar.stub';

import { widgetActions } from './widget.actions';
import { WidgetEffects } from './widget.effects';
import { initialWidgetState, WIDGETS_FEATURE_KEY } from './widget.state';

describe('details side effects', () => {
    let action$: Observable<any>;
    let effects: WidgetEffects;
    let testScheduler: TestScheduler;
    const customFieldsService = jasmine.createSpyObj<any>('CustomFieldsService', ['getSummary']);

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                EffectsModule.forRoot([WidgetEffects])
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [WIDGETS_FEATURE_KEY]: initialWidgetState
                    }
                }),
                provideMockActions(() => action$),
                CustomFieldsService,
                {
                    provide: CustomFieldsService,
                    useValue: customFieldsService
                },
                ExperienceConfigurationServiceNg
            ]
        });
        effects = TestBed.inject(WidgetEffects);
        testScheduler = new TestScheduler((actual, expected) => {
            expect(actual).toEqual(expected);
        });
    });

    it('should load Summary and update store', () => {
        const action = widgetActions.loadCustomFieldsSummary();
        const outcome = widgetActions.loadCustomFieldsSummarySuccess({ summary: CustomFieldsSummarySuccessStub.result });
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-b|', { b: CustomFieldsSummarySuccessStub.result });
            customFieldsService.getSummary.and.returnValue(result$);
            expectObservable(effects.loadCustomFieldsSummary$).toBe('--b', {
                b: outcome
            });
        });
    });

});
