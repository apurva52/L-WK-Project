import { CustomFieldsSummaryStub, CustomFieldsSummarySuccessStub } from '../test-values/customFieldsSummar.stub';

import * as widgetActions from './widget.actions';
import { widgetReducer } from './widget.reducer';
import { initialWidgetState } from './widget.state';

describe('widget CustomField reducer', () => {

    it('should process load CustomFieldsSummary', () => {
        const currentState = { ...initialWidgetState };
        expect(widgetReducer(currentState, widgetActions.loadCustomFieldsSummary())).toEqual({
            ...currentState,
            customFieldsSummary: CustomFieldsSummaryStub.result,
            loading: true
        });
    });

    it('should process load CustomFieldsSummarySuccess', () => {
        const currentState = { ...initialWidgetState };
        expect(widgetReducer(currentState,
            widgetActions.loadCustomFieldsSummarySuccess(
                { summary: CustomFieldsSummarySuccessStub.result }
                ))).toEqual({
            ...currentState,
            customFieldsSummary: CustomFieldsSummarySuccessStub.result,
            loading: false,
            error: null
        });
    });

    it('should process load CustomFieldsSummaryFailure', () => {
        const currentState = { ...initialWidgetState };
        expect(widgetReducer(currentState, widgetActions.loadCustomFieldsSummaryFailure({error: 'error'}))).toEqual({
            ...currentState,
            customFieldsSummary: null,
            loading: false,
            error: 'error'
        });
    });

});
