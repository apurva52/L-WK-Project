import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
    selector: 'ct-tally-card',
    templateUrl: './tally-card.component.html',
    styleUrls: ['./tally-card.component.scss']
})
export class TallyCardComponent {
    @Input() title: string;
    @Input() link: string;
    @Input() primaryCount?: string;
    @Input() primaryLabel?: string;
    @Input() secondaryCount?: string;
    @Input() secondaryLabel?: string;

    @Output() seeAllEvent: EventEmitter<string> = new EventEmitter();

    onSeeAllClicked(): void {
        this.seeAllEvent.emit(this.link);
    }
}
