import {
    CellClickedEvent,
    GridApi,
    GridOptions,
    GridReadyEvent,
    IGetRowsParams,
    SideBarDef
} from '@ag-grid-community/core';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CTGridColumnDefinition } from '@ct/platform-primitives-uicomponents/grid';
import { Store } from '@ngrx/store';
import { fromEvent, Observable, Subscription } from 'rxjs';

import { selectedUserManagementState } from '../../../pages/users-and-roles/users-management/state/user-management.selectors';
import { PaginatedUsers } from '../../../pages/users-and-roles/users-management/state/user-management.state';

import { PaginatedRoles } from './../../../pages/users-and-roles/roles-management/state/role-management.state';
import { SelectionChangeEvent } from './interfaces/selection-change-event.interface';

@Component({
    selector: 'ct-authorization-management-grid',
    templateUrl: './management-grid.component.html',
    styleUrls: ['./management-grid.component.scss']
})
export class ManagementGridComponent {
    get isInfiniteGrid(): boolean {
        return this.gridOptions?.rowModelType === 'infinite';
    }

    get selectedNodesLength(): number {
        return this.gridApi?.getSelectedNodes().length;
    }
    readonly INFINITE_GRID_MIN_ELEMENTS = 200;

    @Input() widgetTitle: string = '';
    @Input() gridData: Observable<PaginatedUsers | PaginatedRoles>;
    @Input() gridDefinition: Array<CTGridColumnDefinition>;
    @Input() gridOptions: GridOptions;
    @Input() selectedIds: Array<string>;
    @Input() customCellRendererComponents?: { [key: string]: any };
    @Input() totalRecordCount: number;
    @Input() displayBulkOptions: boolean = true;
    @Input() rowHeight: number = 60;
    @Input() gridStyle: string = 'grey';

    @Output() selectionChange: EventEmitter<SelectionChangeEvent> =
        new EventEmitter();
    @Output() clear: EventEmitter<void> = new EventEmitter();
    @Output() onGetRows: EventEmitter<IGetRowsParams> = new EventEmitter();
    @Output() cellClicked = new EventEmitter<CellClickedEvent>();
    @Output() gridReady = new EventEmitter<GridReadyEvent>();

    gridApi: GridApi;
    selectedRows: Set<string>;

    sidebarConfig: SideBarDef | boolean = false;
    selectedUserManagementState$ = this.store$
        .select(selectedUserManagementState)
        .subscribe((selected) => {
            if (!this.gridApi) return;
            this.gridApi.forEachNode((node) => {
                const doesNodeExist = selected?.some(
                    (sele) => node.id === sele.sf_contact_id
                );
                node.setSelected(doesNodeExist);
            });
        });

    private readonly FIT_COLUMNS_DELAY = 500;
    private gridDataSubscription: Subscription;

    private resizeSubscription: Subscription;
    constructor(private store$: Store) {}

    ngOnInit(): void {
        if (this.gridData) {
            this.gridDataSubscription = this.gridData.subscribe(
                (paginatedData) => {
                    if (paginatedData.data && this.gridApi) {
                        setTimeout(() => {
                            this.gridApi.sizeColumnsToFit();
                            this.gridApi.forEachNode((node) => {
                                const doesNodeExist = this.selectedIds?.some(
                                    (id) => node.id === id
                                );
                                node.setSelected(doesNodeExist);
                            });
                        }, this.FIT_COLUMNS_DELAY);
                    }
                }
            );
        }
    }

    ngOnDestroy(): void {
        this.gridDataSubscription && this.gridDataSubscription.unsubscribe();
        !!this.resizeSubscription && this.resizeSubscription.unsubscribe();
    }

    onGridReady(event: GridReadyEvent): void {
        this.gridReady.emit(event);
        this.gridApi = event.api;
        this.gridApi.showLoadingOverlay();
        this.resizeSubscription = fromEvent(window, 'resize').subscribe(() => {
            this.gridApi.sizeColumnsToFit();
        });
    }

    onSelectionChange(event: any): void {
        if (!!event.selected.length) {
            this.selectionChange.emit({
                total: event.total,
                selected: event.selected
            });
        } else {
            this.clear.emit();
        }
    }

    onCellClicked(event: CellClickedEvent): void {
        this.cellClicked.emit(event);
    }

    clearSelection(): void {
        this.gridApi.deselectAll();
    }
}
