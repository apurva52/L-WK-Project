import { AgGridModule } from '@ag-grid-community/angular';
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {
    async,
    ComponentFixture,
    fakeAsync,
    TestBed,
    tick
} from '@angular/core/testing';
import { Router, RouterEvent } from '@angular/router';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { ReplaySubject } from 'rxjs';
import { of } from 'rxjs';

import { initialState } from '../../../pages/users-and-roles/users-management/state/user-management.reducers';
import { selectedUserManagementState } from '../../../pages/users-and-roles/users-management/state/user-management.selectors';
import { PaginatedUsers, USER_MANAGEMENT_FEATURE_KEY } from '../../../pages/users-and-roles/users-management/state/user-management.state';
import { AuthService } from '../../../shared/services/auth/auth.service';

import mockUserManagement from './../../../pages/users-and-roles/users-management/state/test-values/mock-users.json';
import { ManagementGridComponent } from './management-grid.component';

const eventSubject = new ReplaySubject<RouterEvent>(1);
class Mockrouter {
    navigate = jasmine.createSpy('navigate');
    events = eventSubject.asObservable();
}
describe('Management Grid', () => {
    let component: ManagementGridComponent;
    let fixture: ComponentFixture<ManagementGridComponent>;
    let mockRouter: Mockrouter;

    beforeEach(async(() => {
        mockRouter = new Mockrouter();
        TestBed.configureTestingModule({
            declarations: [ManagementGridComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [USER_MANAGEMENT_FEATURE_KEY]: initialState
                    },
                    selectors: [
                        { selector: selectedUserManagementState, value: [] }
                    ]
                }),
                {
                    provide: Router,
                    useValue: mockRouter
                },
                AuthService,
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ManagementGridComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    xit('gridReady', fakeAsync(() => {
        const TEST_TIMEOUT = 1001;
        component.selectedIds = ['test'];
        const mockEvent = {
            api: {
                showLoadingOverlay: jasmine.createSpy(),
                sizeColumnsToFit: jasmine.createSpy(),
                forEachNode: (callback: Function) => {
                    callback({ id: 'test', setSelected: jasmine.createSpy() });
                }
            }
        };
        component.onGridReady(mockEvent as any);
        tick(TEST_TIMEOUT);
        expect(component.gridApi).toBeDefined();
    }));

    it('should clear selection from grid', () => {
        component.gridApi = {
            deselectAll: jasmine.createSpy(),
            forEachLeafNode: jasmine.createSpy().and.returnValue([])
        } as any;
        component.clearSelection();
        expect(component.gridApi.deselectAll).toHaveBeenCalled();
    });

    it('should emit selection', () => {
        spyOn(component.selectionChange, 'emit');
        const event = { total: 1, selected: ['Unit Test'] };
        component.onSelectionChange(event);
        expect(component.selectionChange.emit).toHaveBeenCalled();
    });

    it('should change selection of clear from grid', () => {
        spyOn(component.clear, 'emit');
        const event = { total: 0, selected: [] };
        component.onSelectionChange(event);
        expect(component.clear.emit).toHaveBeenCalled();
    });

    xit('should emit a selection from store', fakeAsync(() => {
        component.gridData = of(mockUserManagement as PaginatedUsers);
        component.selectedIds = ['test'];
        const TEST_TIMEOUT = 1001;
        component.gridApi = {
            sizeColumnsToFit: jasmine.createSpy(),
            forEachNode: jasmine.createSpy().and.callThrough()
        } as any;
        component.ngOnInit();
        tick(TEST_TIMEOUT);
        component.ngOnDestroy();
        expect(component.gridApi.forEachNode).toHaveBeenCalled();
    }));

    it('should emit a cell clicked', () => {
        spyOn(component.cellClicked, 'emit');
        const event = {} as any;
        component.onCellClicked(event);
        expect(component.cellClicked.emit).toHaveBeenCalled();
    });
});
