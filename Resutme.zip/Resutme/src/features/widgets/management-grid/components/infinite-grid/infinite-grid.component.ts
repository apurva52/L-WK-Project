import {
    GridOptions,
    GridReadyEvent,
    IDatasource,
    IGetRowsParams,
    SideBarDef
} from '@ag-grid-community/core';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CTGridColumnDefinition } from '@ct/platform-primitives-uicomponents/grid';
import { Observable } from 'rxjs';

import { PaginatedRoles } from './../../../../../pages/users-and-roles/roles-management/state/role-management.state';
import { PaginatedUsers } from './../../../../../pages/users-and-roles/users-management/state/user-management.state';
import { SelectionChangeEvent } from './../../interfaces/selection-change-event.interface';

@Component({
    selector: 'ct-infinite-grid',
    templateUrl: './infinite-grid.component.html',
    styleUrls: ['./infinite-grid.component.scss']
})
export class InfiniteGridComponent implements OnInit {
    initConfigurations: { gridId: string, enableStateCapture: boolean };
    @Input() widgetTitle: string = '';
    @Input() gridData: Observable<PaginatedUsers | PaginatedRoles>;
    @Input() gridDefinition: Array<CTGridColumnDefinition>;
    @Input() gridOptions: GridOptions;
    @Input() customCellRendererComponents?: { [key: string]: any };
    @Input() rowHeight: number;
    @Input() sidebarConfig: SideBarDef;
    @Input() gridStyle: string;
    @Input() gridId: string;

    @Output() selectionChange: EventEmitter<SelectionChangeEvent> =
        new EventEmitter();
    @Output() gridReady: EventEmitter<GridReadyEvent> = new EventEmitter();
    @Output() onGetRows: EventEmitter<IGetRowsParams> = new EventEmitter();

    dataSource: IDatasource = {
        rowCount: undefined,
        getRows: (params: IGetRowsParams) => {
            this.onGetRows.emit(params);
        }
    };

    onGridReady(event: GridReadyEvent): void {
        this.gridReady.emit(event);
    }

    onSelectionChange(event: SelectionChangeEvent): void {
        this.selectionChange.emit(event);
    }

    ngOnInit(): void {
        this.initConfigurations = { gridId: this.gridId, enableStateCapture: true };
    }
}
