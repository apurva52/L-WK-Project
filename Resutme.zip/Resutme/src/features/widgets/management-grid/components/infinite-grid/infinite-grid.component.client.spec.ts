import { LazyElementsModule } from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { TranslateModule } from '@ngx-translate/core';

import { InfiniteGridComponent } from './infinite-grid.component';

describe('InfiniteGridComponent', () => {
    let component: InfiniteGridComponent;
    let fixture: ComponentFixture<InfiniteGridComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [InfiniteGridComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(InfiniteGridComponent);
        component = fixture.componentInstance;
    });

    it('should create', () => {
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });

    it('gridReady', () => {
        fixture.detectChanges();
        const mockEvent = {
            api: {}
        };
        spyOn(component.gridReady, 'emit');
        component.onGridReady(mockEvent as any);
        expect(component.gridReady.emit).toHaveBeenCalled();
    });

    it('should emit a change selection', () => {
        fixture.detectChanges();
        spyOn(component.selectionChange, 'emit');
        const event = { total: 1, selected: ['Unit Test'] };
        component.onSelectionChange(event);
        expect(component.selectionChange.emit).toHaveBeenCalled();
    });

    it('should emit get rows from datasource', () => {
        spyOn(component.onGetRows, 'emit');
        const event = {} as any;
        component.dataSource.getRows(event);
        expect(component.onGetRows.emit).toHaveBeenCalled();
    });
});
