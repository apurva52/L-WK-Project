import { AgGridModule } from '@ag-grid-community/angular';
import { LazyElementsModule } from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { TranslateModule } from '@ngx-translate/core';

import { NormalGridComponent } from './normal-grid.component';

describe('NormalGridComponent', () => {
    let component: NormalGridComponent;
    let fixture: ComponentFixture<NormalGridComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [NormalGridComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(NormalGridComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('gridReady', () => {
        const mockEvent = {
            api: {}
        };
        spyOn(component.gridReady, 'emit');
        component.onGridReady(mockEvent as any);
        expect(component.gridReady.emit).toHaveBeenCalled();
    });

    it('should emit a change selection', () => {
        spyOn(component.selectionChange, 'emit');
        const event = { total: 1, selected: ['Unit Test'] };
        component.onSelectionChange(event);
        expect(component.selectionChange.emit).toHaveBeenCalled();
    });

    it('should emit a cell clicked', () => {
        spyOn(component.cellClicked, 'emit');
        const event = {} as any;
        component.onCellClicked(event);
        expect(component.cellClicked.emit).toHaveBeenCalled();
    });
});
