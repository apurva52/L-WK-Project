import {
    CellClickedEvent,
    GridOptions,
    GridReadyEvent,
    SideBarDef
} from '@ag-grid-community/core';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CTGridColumnDefinition } from '@ct/platform-primitives-uicomponents/grid';
import { Observable } from 'rxjs/internal/Observable';

import { SelectionChangeEvent } from '../../interfaces/selection-change-event.interface';

import { Role } from './../../../../../pages/users-and-roles/roles-management/interfaces/role.model';
import { PaginatedRoles } from './../../../../../pages/users-and-roles/roles-management/state/role-management.state';
import { User } from './../../../../../pages/users-and-roles/users-management/interfaces/user.model';
import { PaginatedUsers } from './../../../../../pages/users-and-roles/users-management/state/user-management.state';

@Component({
    selector: 'ct-normal-grid',
    templateUrl: './normal-grid.component.html',
    styleUrls: ['./normal-grid.component.scss']
})
export class NormalGridComponent {
    @Input() widgetTitle: string = '';
    @Input() gridData: Observable<PaginatedUsers | PaginatedRoles>;
    @Input() syncGridData: Array<User> | Array<Role>;
    @Input() gridDefinition: Array<CTGridColumnDefinition>;
    @Input() gridOptions: GridOptions;
    @Input() customCellRendererComponents?: { [key: string]: any };
    @Input() rowHeight: number;
    @Input() sidebarConfig: SideBarDef;
    @Input() gridStyle: string;

    @Output() selectionChange: EventEmitter<SelectionChangeEvent> =
        new EventEmitter();
    @Output() gridReady: EventEmitter<GridReadyEvent> = new EventEmitter();
    @Output() cellClicked = new EventEmitter<CellClickedEvent>();

    onGridReady(event: GridReadyEvent): void {
        this.gridReady.emit(event);
    }

    onSelectionChange(event: SelectionChangeEvent): void {
        this.selectionChange.emit(event);
    }

    onCellClicked(event: CellClickedEvent): void {
        this.cellClicked.emit(event);
    }
}
