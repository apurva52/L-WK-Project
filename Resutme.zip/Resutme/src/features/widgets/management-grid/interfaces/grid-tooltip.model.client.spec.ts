import mockUserManagement from './../../../../pages/users-and-roles/users-management/state/test-values/mock-users.json';
import { GridTooltip } from './grid-tooltip.model';
describe('GridTooltip', () => {
    const MAX_ROLES_SIZE = 3;
    const gridTooltip = new GridTooltip();
    it('Should render the content with more than 3 pills', () => {
        const mockRoles = [
            {
                role_id: 1,
                role_name: 'Super User'
            },
            {
                role_id: 3,
                role_name: 'Admin'
            },
            {
                role_id: 4,
                role_name: 'View Only'
            },
            {
                role_id: 5,
                role_name: 'Guest'
            }
        ];
        const mockParams = { value: mockRoles, MAX_ROLES_SIZE };
        gridTooltip.init(mockParams);
        expect(gridTooltip.eGui.innerHTML).toContain('Guest');
    });
    it('Should render the content with less than 3 pills', () => {
        const userWithLessThanThreeRoles = mockUserManagement.data.find(
            (user) => user.roles.length < MAX_ROLES_SIZE
        );
        const mockParams = {
            value: userWithLessThanThreeRoles.roles,
            MAX_ROLES_SIZE
        };
        gridTooltip.init(mockParams);
        expect(gridTooltip.eGui.innerHTML).toEqual('');
    });
    it('Should render the content', () => {
        expect(gridTooltip.getGui()).toBeDefined();
    });
});
