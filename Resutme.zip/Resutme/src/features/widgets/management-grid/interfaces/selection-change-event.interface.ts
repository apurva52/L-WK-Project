export interface SelectionChangeEvent {
    total: number;
    selected: Array<any>;
}
