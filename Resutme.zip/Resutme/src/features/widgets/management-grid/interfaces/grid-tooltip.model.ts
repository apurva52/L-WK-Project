export class GridTooltip {
    eGui: HTMLDivElement;
    init(params): void {
        const missingPills = this.getMissingPils(params);
        this.eGui = document.createElement('div');
        if (!!missingPills) {
            this.eGui.classList.add('custom-tooltip');
            this.eGui.innerHTML = missingPills;
        }
    }

    getGui(): HTMLDivElement {
        return this.eGui;
    }

    private getMissingPils(params: any): string | undefined {
        if (params.value.length > params.MAX_ROLES_SIZE) {
            const pills = params.value.map((role) => `<span class="pill ${role.role_name.replace(' ', '_')}">${role.role_name}</span>`);
            const stringPills = pills.slice(params.MAX_ROLES_SIZE).join('');
            return stringPills;
        }
    }
}
