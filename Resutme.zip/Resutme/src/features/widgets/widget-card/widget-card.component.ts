import { Component, Input } from '@angular/core';

@Component({
  selector: 'ct-widget-card',
  templateUrl: './widget-card.component.html',
  styleUrls: ['./widget-card.component.scss']
})
export class WidgetCardComponent {
  @Input() widgetTitle: string = '';

}
