import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CtGridModule } from '@ct/platform-primitives-uicomponents/grid';
import { CtPrimitivesModule } from '@ct/platform-primitives-uicomponents/primitives';
import { JumpstartComponentsModule } from '@wk/components-angular11';
import { ClickOutsideDirective } from 'src/shared/directives/click-outside.directive';

import { AuthorizationPillComponent } from './authorization-pill/authorization-pill.component';
import { LazyMultiselectComponent } from './lazy-multiselect/lazy-multiselect.component';
import { InfiniteGridComponent } from './management-grid/components/infinite-grid/infinite-grid.component';
import { NormalGridComponent } from './management-grid/components/normal-grid/normal-grid.component';
import { ManagementGridComponent } from './management-grid/management-grid.component';
import { TallyCardComponent } from './tally-card/tally-card.component';
import { WidgetCardComponent } from './widget-card/widget-card.component';

@NgModule({
    declarations: [
        WidgetCardComponent,
        ManagementGridComponent,
        TallyCardComponent,
        NormalGridComponent,
        InfiniteGridComponent,
        AuthorizationPillComponent,
        LazyMultiselectComponent,
        ClickOutsideDirective
    ],
    imports: [
        CommonModule,
        CtPrimitivesModule,
        CtGridModule,
        JumpstartComponentsModule
    ],
    exports: [WidgetCardComponent, ManagementGridComponent, TallyCardComponent, AuthorizationPillComponent, LazyMultiselectComponent]
})
export class WidgetsModule {}
