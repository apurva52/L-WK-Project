export const CustomFieldsSummaryStub: any = {
    "result": {
        totalNumber: '0',
        requiredFields: '0'
    }
}

export const CustomFieldsSummarySuccessStub: any = {
    "result": {
        totalNumber: 5,
        requiredFields: 10
    }
}