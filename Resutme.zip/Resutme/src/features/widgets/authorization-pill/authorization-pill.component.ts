import { Component, Input } from '@angular/core';

type Theme = 'dark' | 'light';

@Component({
    selector: 'ct-authorization-pill',
    templateUrl: './authorization-pill.component.html',
    styleUrls: ['./authorization-pill.component.scss']
})
export class AuthorizationPillComponent {
    @Input() bgColor: string = 'gray';
    @Input() theme: Theme = 'dark';

    private readonly themeParams = {
        dark: {
            color: '#FFF',
            backgroundColor: {
                '#007AC3': '#007AC3',
                '#005B92': '#005B92',
                '#85BC20': '#85BC20',
                '#E5202E': '#E5202E',
                '#EA8F00': '#EA8F00',
                '#241866': '#241866',
                '#940C72': '#940C72',
                '#009881': '#009881',
                '#000000': '#000000'
            }
        },
        light: {
            color: '#000',
            backgroundColor: {
                '#007AC3': '#A6D1EA',
                '#005B92': '#A6D1EA',
                '#85BC20': '#D4E8B1',
                '#E5202E': '#F6B1B6',
                '#EA8F00': '#A6D1EA',
                '#241866': '#A6D1EA',
                '#940C72': '#F8ADE5',
                '#009881': '#D4E8B1',
                '#000000': '#474747'
            }
        }
    };

    get pillStyle(): string {
        const bgColor = this.themeParams[this.theme].backgroundColor[this.bgColor] || this.bgColor;
        const textColor = this.themeParams[this.theme].color;
        return `background-color: ${bgColor}; color: ${textColor}`;
    }

}
