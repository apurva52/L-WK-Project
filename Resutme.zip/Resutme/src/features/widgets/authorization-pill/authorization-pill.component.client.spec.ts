import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthorizationPillComponent } from './authorization-pill.component';

describe('AuthorizationPillComponent', () => {
  let component: AuthorizationPillComponent;
  let fixture: ComponentFixture<AuthorizationPillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuthorizationPillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthorizationPillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get a Pill style form the directory', () => {
    component.bgColor = '#007AC3';
    component.theme = 'light';
    expect(component.pillStyle).toEqual(`background-color: #A6D1EA; color: #000`);
  });

});
