export interface ReferenceType {
    referenceId: number;
    referenceDesc: string;
    isClientManaged: string;
    category: string;
    isDisplayForIgnite: string;
    referenceRoute: string;
    lastModifiedBy: string;
    lastModifiedDate: string;
}