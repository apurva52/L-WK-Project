import { ReferenceType } from './reference-types.model';

export interface ReferenceTypesResponse {
    totalRecordCount: number;
    page: number;
    pageSize: number;
    data: Array<ReferenceType>;
}