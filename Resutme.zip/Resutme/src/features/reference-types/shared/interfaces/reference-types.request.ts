export interface ReferenceTypesRequest {
    /** specifies page number, default api value is used if not specified */
    pageSize?: number;
    /** sets page size, default api value is used if not specified */
    page?: number;
    /** specifies column name to sort by, referenceId used by default on api */
    sortBy?: string;
    /** specifies sort direction, ascending by default */
    sortOrder?: string;
    /** sets left margin for last modification date, format YYYY-MM-ddTHH:mm:ss */
    lastModifiedDateFrom?: string;
    /** sets right margin for last modification date, format YYYY-MM-ddTHH:mm:ss */
    lastModifiedDateTo?: string;
}