import { LocaleServiceNg } from '@ct/core-ui-ng';
import { Observable } from 'rxjs';

export function dynamicFormsLocaleFactory(localeService: LocaleServiceNg): Observable<string> {
    return localeService.locale$;
}
