import wkVars from '@wk/vars';
import { Observable, of } from 'rxjs';

export function dynamicFormsWebComponentUrlsFactory(): Observable<any> {
    return of({
        'ct-entitytype-selector': wkVars('ct-entitytype-selector').url,
        'ct-typeahead': wkVars('ct-typeahead').url
    });
}
