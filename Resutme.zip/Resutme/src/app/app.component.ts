import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { I18nServiceNg, LocaleServiceNg } from '@ct/core-ui-ng';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { BreadcrumbItem } from '@wk/components';
import wkVars from '@wk/vars/src/client';

import { WEB_COMPONENT_NAME } from '../app/app.name';
import { userManagementInitiateAction } from '../pages/users-and-roles/users-management/state/user-management.actions';
import { NavigationsService } from '../shared/services/navigation/navigations.service';
import { makeWhiteBackground } from '../shared/util';

import { appActions } from './state/app.actions';
import {
    selectBreadcrumbsItems,
    selectForceRedirectTo
} from './state/app.selectors';
import { AppState } from './state/app.state';

@Component({
    templateUrl: 'app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent {
    _userTokenPayload: object;
    @Output() forceRedirectTo: EventEmitter<string> =
        new EventEmitter<string>();

    @Output() updateBreadcrumbs: EventEmitter<Array<BreadcrumbItem>> =
        new EventEmitter<Array<BreadcrumbItem>>();

    @Input() set isInternal(value: boolean) {
        if (value) {
            this._isInternal = value;
            this.store$.dispatch(
                appActions.setIsInternal({ value: this._isInternal })
            );
            this.store$.dispatch(
                userManagementInitiateAction({
                    controlId: '',
                    isInternal: this._isInternal,
                    pageSize: this.MAX_USERS_LENGTH
                })
            );
        }
    }
    @Input() set urlPathPrefix(value: string) {
        if (value) {
            this._urlPathPrefix = value;
        }
    }

    @Input() set userTokenPayload(value: object) {
        this._userTokenPayload = value;
        if (value) {
            this.store$.dispatch(
                appActions.setUserTokenPayload({ payload: value })
            );
        }
    }

    @Input() set locale(value: string) {
        if (value) {
            this._locale = value;
            this.updateLocale(value);
        }
    }

    @Input() set updateUsersPanelRoute(value: BreadcrumbItem) {
        if (value) {
            this.router.navigate([value.link]).catch((e) => {
                throw new Error(
                    this.translate.instant('DefaultErrorMessages.routerError')
                );
            });
        }
    }

    selectBreadcrumbsItems$ = this.store$
        .select(selectBreadcrumbsItems)
        .subscribe((breadcrumbsItems) => {
            if (breadcrumbsItems?.length > 0) {
                this.updateBreadcrumbs.emit(breadcrumbsItems);
            }
        });

    get locale(): string {
        return this._locale;
    }
    @Input() defaultTabSelected: string = '0';
    @Output() hideBreadcrumbs: EventEmitter<boolean> =
        new EventEmitter<boolean>(false);

    _isInternal = false;
    _urlPathPrefix = '';
    private _locale: string;
    private readonly MAX_USERS_LENGTH: number = 100000;
    constructor(
        private localeService: LocaleServiceNg,
        private i18nService: I18nServiceNg,
        private store$: Store<AppState>,
        private router: Router,
        private translate: TranslateService,
        private navigationsService: NavigationsService
    ) {}
    ngOnInit(): void {
        makeWhiteBackground();
        this.navigationsService.subscribeRouteEvents(
            this.router,
            this.translate
        );
        this.router.navigate(['/account-tools/users-and-roles']).catch((e) => {
            throw new Error(
                this.translate.instant('DefaultErrorMessages.routerError')
            );
        });

        this.store$.select(selectForceRedirectTo).subscribe((route) => {
            if (!this.forceRedirectTo) {
                this.forceRedirectTo = new EventEmitter<string>();
            }
            if (route) this.forceRedirectTo.emit(route);
        });
        this.navigationsService.isHidden().subscribe((isHidden) => {
            this.hideBreadcrumbs.emit(isHidden);
        });
    }
    updateLocale(locale: string): void {
        this.localeService.setLocale(locale);
        this.i18nService
            .loadResources(locale, {
                baseUrl: wkVars(WEB_COMPONENT_NAME)?.url
            })
            .catch((err) => {
                throw new Error(
                    this.translate.instant(
                        'DefaultErrorMessages.i18ServiceError'
                    )
                );
            });
    }
}
