import { NgModule } from '@angular/core';
import {
    ApplicationConfigurationServiceNg,
    AppSettingsModule,
    AuthorizationService,
    UserServiceNg
} from '@ct/core-ui-ng';
import { EntitiesGridService } from '@ct/platform-common-uicomponents/entities-grids';
import {
    EntitySearchService,
    EntitySelectorService
} from '@ct/platform-common-uicomponents/entity-reference';
import { QuickSwitcherApiService } from '@ct/platform-common-uicomponents/quick-switcher';
import { ReferenceService } from '@ct/platform-common-uicomponents/reference-controls';
import { createInstance } from '@wk/edge-services';
import wkVars from '@wk/vars';

import { environment } from '../environments/environment';
import { ReferenceTablesService } from '../pages/reference-tables/services/reference-tables.service';
import { AuthorizationManagementService } from '../shared/services/authorization-management/authorization-management.service';
import { CustomFieldsService } from '../shared/services/custom-fields/customFields.service';
import { EntitiesService } from '../shared/services/entities/entities.service';
import { GroupsService } from '../shared/services/groups/groups.service';
import { ReferenceTypesService } from '../shared/services/reference-types/reference-types.service';

import { AuthService } from './../shared/services/auth/auth.service';
import { WEB_COMPONENT_NAME } from './app.name';
export function getBaseUrl(): string {
    const options = wkVars(WEB_COMPONENT_NAME);
    const host = (options && options.url) || '';

    return `${host}/__remoteService`;
}

@NgModule({
    imports: [
        AppSettingsModule.forRoot(environment.applicationName)
    ],
    providers: [
        {
            provide: ApplicationConfigurationServiceNg,
            useFactory: () =>
                createInstance(ApplicationConfigurationServiceNg, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: UserServiceNg,
            useFactory: () =>
                createInstance(UserServiceNg, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: AuthService,
            useFactory: () =>
                createInstance(AuthService, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: CustomFieldsService,
            useFactory: () =>
                createInstance(CustomFieldsService, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: ReferenceTypesService,
            useFactory: () =>
                createInstance(ReferenceTypesService, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: ReferenceTablesService,
            useFactory: () =>
                createInstance(ReferenceTablesService, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: QuickSwitcherApiService,
            useFactory: () =>
                createInstance(QuickSwitcherApiService, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: EntitiesService,
            useFactory: () =>
                createInstance(EntitiesService, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: EntitySearchService,
            useFactory: () =>
                createInstance(EntitySearchService, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: ReferenceService,
            useFactory: () =>
                createInstance(ReferenceService, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: EntitiesGridService,
            useFactory: () =>
                createInstance(EntitiesGridService, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: GroupsService,
            useFactory: () =>
                createInstance(GroupsService, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: AuthorizationService,
            useFactory: () =>
                createInstance(AuthorizationService, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: EntitySelectorService,
            useFactory: () =>
                createInstance(EntitySelectorService, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: AuthorizationManagementService,
            useFactory: () =>
                createInstance(AuthorizationManagementService, {
                    baseUrl: getBaseUrl()
                })
        },
        {
            provide: CustomFieldsService,
            useFactory: () =>
                createInstance(CustomFieldsService, {
                    baseUrl: getBaseUrl()
                })
        }
    ]
})
export class ProvideServicesModule {}
