import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
    {
        path: 'account-tools/users-and-roles',
        loadChildren: () =>
            import('../pages/users-and-roles/users-and-roles-page.module').then(
                (m) => m.UsersAndRolesPageModule
            )
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
