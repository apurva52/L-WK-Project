import { createAction, props } from '@ngrx/store';
import { BreadcrumbItem } from '@wk/components';

export enum AppActionTypes {
    SetIsInternal = '[users-panel-app] Set Selected Opportunity Id',
    SetUserTokenPayload = '[CT Layout Root] Set User Token Payload',
    ForcedNavigation = '[users-panel-app] Forcing navigation to...',
    UpdateBreadcrumbsItems = '[users-panel-app] updating breadcrumbs items list'
}

const setIsInternal = createAction(
    AppActionTypes.SetIsInternal,
    props<{ value: boolean }>()
);

const setUserTokenPayload = createAction(
    AppActionTypes.SetUserTokenPayload,
    props<{ payload: object }>()
);

const forcedNavigation = createAction(
    AppActionTypes.ForcedNavigation,
    props<{ route: string }>()
);
const updateBreadcrumbsItems = createAction(
    AppActionTypes.UpdateBreadcrumbsItems,
    props<{ breadcrumbsItems: Array<BreadcrumbItem> }>()
);

export const appActions = {
    setIsInternal,
    setUserTokenPayload,
    forcedNavigation,
    updateBreadcrumbsItems
};
