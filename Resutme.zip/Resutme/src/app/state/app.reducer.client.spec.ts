import { appActions } from './app.actions';
import { appReducer, initialAppState } from './app.reducer';

describe('users management reducer', () => {
    it('should process users load', () => {
        const currentState = { ...initialAppState };
        const actionParams = { value: true };
        expect(
            appReducer(currentState, appActions.setIsInternal(actionParams))
        ).toEqual({
            ...currentState,
            isInternal: true,
            userTokenPayload: null
        });
    });

    it('should process users token payload', () => {
        const currentState = { ...initialAppState };
        const actionParams = { payload: { name: 'Omar Del Toro' } };
        expect(
            appReducer(
                currentState,
                appActions.setUserTokenPayload(actionParams)
            )
        ).toEqual({
            ...currentState,
            isInternal: false,
            userTokenPayload: { name: 'Omar Del Toro' }
        });
    });

    it('should process new route', () => {
        const currentState = { ...initialAppState };
        const actionParams = '/account-tools';
        expect(
            appReducer(
                currentState,
                appActions.forcedNavigation({ route: actionParams })
            )
        ).toEqual({
            ...currentState,
            isInternal: false,
            userTokenPayload: null,
            routeRedirectTo: '/account-tools'
        });
    });

    it('should process update breabcrumbs', () => {
        const currentState = { ...initialAppState };
        const actionParams = [];
        expect(
            appReducer(
                currentState,
                appActions.updateBreadcrumbsItems({
                    breadcrumbsItems: actionParams
                })
            )
        ).toEqual({
            ...currentState,
            isInternal: false,
            userTokenPayload: null,
            routeRedirectTo: '',
            breadcrumbsItems: []
        });
    });
});
