import { Action, createReducer, on } from '@ngrx/store';

import { appActions } from './app.actions';
import { AppState } from './app.state';
export const initialAppState: AppState = {
    isInternal: false,
    userTokenPayload: null,
    routeRedirectTo: '',
    breadcrumbsItems: []
};

const reducer = createReducer<AppState>(
    initialAppState,
    on(appActions.setIsInternal, (state, { value }) => ({
        ...state,
        isInternal: value
    })),
    on(appActions.setUserTokenPayload, (state, { payload }) => ({
        ...state,
        userTokenPayload: payload
    })),
    on(appActions.forcedNavigation, (state, { route }) => ({
        ...state,
        routeRedirectTo: route
    })),
    on(appActions.updateBreadcrumbsItems, (state, { breadcrumbsItems }) => ({
        ...state,
        breadcrumbsItems
    }))
);

export function appReducer(
    state: AppState | undefined,
    action: Action
): AppState {
    return reducer(state, action);
}
