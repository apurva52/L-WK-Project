import { BreadcrumbItem } from '@wk/components';

export const USERS_PANEL_APP_FEATURE_KEY = 'users-panel-app';

export interface AppState {
    isInternal: boolean;
    userTokenPayload: object;
    routeRedirectTo: string;
    breadcrumbsItems: Array<BreadcrumbItem>;
}

export interface ContactUser {
    sf_contact_name: string;
    sf_contact_id: string;
    sf_account_id?: string;
}
