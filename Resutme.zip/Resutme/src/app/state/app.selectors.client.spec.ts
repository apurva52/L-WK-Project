import { initialAppState } from './app.reducer';
import * as appSelectors from './app.selectors';
import { AppState } from './app.state';

describe('associations details selectors', () => {
    it('should select isInternal', () => {
        const currentState: AppState = {
            ...initialAppState,
            isInternal: true
        };
        const currentLoadingStatus =
            appSelectors.selectIsInternal.projector(currentState);
        expect(currentLoadingStatus).toEqual(true);
    });

    it('should select User token payload', () => {
        const currentState: AppState = {
            ...initialAppState,
            isInternal: true,
            userTokenPayload: {
                name: 'Omar Del Toro'
            }
        };
        const currentUserTokenPayload =
            appSelectors.selectUserTokenPayload.projector(currentState);
        expect(currentUserTokenPayload).toEqual({ name: 'Omar Del Toro' });
    });

    it('should select new route to redirect', () => {
        const currentState: AppState = {
            ...initialAppState,
            isInternal: true,
            userTokenPayload: {
                name: 'Omar Del Toro'
            },
            routeRedirectTo: '/account-tools'
        };
        const currentRoute =
            appSelectors.selectForceRedirectTo.projector(currentState);
        expect(currentRoute).toEqual('/account-tools');
    });

    it('should select breadcrumbs Items', () => {
        const currentState: AppState = {
            ...initialAppState,
            isInternal: true,
            userTokenPayload: {
                name: 'Omar Del Toro'
            },
            routeRedirectTo: '/account-tools',
            breadcrumbsItems: []
        };
        const currentRoute =
            appSelectors.selectBreadcrumbsItems.projector(currentState);
        expect(currentRoute).toEqual([]);
    });
});
