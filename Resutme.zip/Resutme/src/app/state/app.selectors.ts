import { createFeatureSelector, createSelector } from '@ngrx/store';

import { AppState, USERS_PANEL_APP_FEATURE_KEY } from './app.state';

export const selectRootFeature = createFeatureSelector<AppState>(
    USERS_PANEL_APP_FEATURE_KEY
);
export const selectIsInternal = createSelector(
    selectRootFeature,
    (state: AppState) => state.isInternal
);
export const selectUserTokenPayload = createSelector(
    selectRootFeature,
    (state: AppState) => state.userTokenPayload
);

export const selectForceRedirectTo = createSelector(
    selectRootFeature,
    (state: AppState) => state.routeRedirectTo
);

export const selectBreadcrumbsItems = createSelector(
    selectRootFeature,
    (state: AppState) => state.breadcrumbsItems
);
