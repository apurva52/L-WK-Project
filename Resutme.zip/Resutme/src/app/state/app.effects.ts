import { Injectable } from '@angular/core';
import { Actions } from '@ngrx/effects';

import { AuthService } from '../../shared/services/auth/auth.service';

@Injectable()
export class AppEffects {
    constructor(
        protected actions$: Actions,
        protected authService: AuthService
    ) {}
}
