export const WEB_COMPONENT_NAME = 'ct-engage-users-panel-uiwc';
