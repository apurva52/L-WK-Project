import { AgGridModule } from '@ag-grid-community/angular';
import { LazyElementsModule } from '@angular-extensions/elements';
import { CommonModule } from '@angular/common';
import {
    APP_INITIALIZER,
    CUSTOM_ELEMENTS_SCHEMA,
    DoBootstrap,
    Injector,
    NgModule
} from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
    AclClaimsBasedDefinitionService,
    AclDefinitionService,
    AuthorizationModule,
    GlobalErrorHandlerModule,
    RequestPatchingModule,
    translateLoaderFactory,
    UserModule,
    WEB_COMPONENTS_INITIALIZERS
} from '@ct/core-ui-ng';
import {
    EntitiesGridService,
    EntitiesGridsModule
} from '@ct/platform-common-uicomponents/entities-grids';
import { QuickSwitcherControlsModule } from '@ct/platform-common-uicomponents/quick-switcher';
import {
    CtGridModule,
    initializeAgGridLicence
} from '@ct/platform-primitives-uicomponents/grid';
import { CtModalsModule } from '@ct/platform-primitives-uicomponents/modals';
import { CtPrimitivesModule } from '@ct/platform-primitives-uicomponents/primitives';
import { EffectsModule } from '@ngrx/effects';
import {
    DefaultRouterStateSerializer,
    StoreRouterConnectingModule
} from '@ngrx/router-store';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { JumpstartComponentsModule } from '@wk/components-angular11';
import wkVars from '@wk/vars';

import { environment } from '../environments/environment';
import { EntitySelectorEffects } from '../features/entity-selector/state/entity-selector.effects';
import { entitySelectorReducer } from '../features/entity-selector/state/entity-selector.reducers';
import { ENTITY_SELECTOR_FEATURE_KEY } from '../features/entity-selector/state/entity-selector.state';
import { DigitalExperienceEffects } from '../features/modules-and-permissions-grid/state/digital-experience/digital-experience.effects';
import { digitalExperienceReducer } from '../features/modules-and-permissions-grid/state/digital-experience/digital-experience.reducers';
import { DIGITAL_EXPERIENCE_FEATURE_KEY } from '../features/modules-and-permissions-grid/state/digital-experience/digital-experience.state';
import { ModulesAndPermissionsEffects } from '../features/modules-and-permissions-grid/state/modules-and-permissions/modules-and-permissions.effects';
import { modulesAndPermissionsReducer } from '../features/modules-and-permissions-grid/state/modules-and-permissions/modules-and-permissions.reducers';
import { MODULES_AND_PERMISSIONS_FEATURE_KEY } from '../features/modules-and-permissions-grid/state/modules-and-permissions/modules-and-permissions.state';
import { WidgetEffects } from '../features/widgets/state/widget.effects';
import { widgetReducer } from '../features/widgets/state/widget.reducer';
import { WIDGETS_FEATURE_KEY } from '../features/widgets/state/widget.state';
import { WidgetsModule } from '../features/widgets/widgets.module';
import { CustomFieldsEffects } from '../pages/custom-fields/state/custom-fields.effects';
import { customFieldsReducer } from '../pages/custom-fields/state/custom-fields.reducers';
import { CUSTOM_FIELDSS_FEATURE_KEY } from '../pages/custom-fields/state/custom-fields.state';
import { AddGroupModalEffects } from '../pages/groups/state/add-group-modal/add-group-modal.effects';
import { addGroupModalReducer } from '../pages/groups/state/add-group-modal/add-group-modal.reducer';
import { ADD_GROUP_MODAL_FEATURE_KEY } from '../pages/groups/state/add-group-modal/add-group-modal.state';
import { groupDetailsReducer } from '../pages/groups/state/group-details/group-details.reducers';
import { GROUP_DETAILS_FEATURE_KEY } from '../pages/groups/state/group-details/group-details.state';
import { groupsReducer } from '../pages/groups/state/groups.reducer';
import { GROUPS_FEATURE_KEY } from '../pages/groups/state/groups.state';
import { UsersForRoleEffects } from '../pages/users-and-roles/roles-management/details/components/users-list-from-role/state/users-from-role.effects';
import { usersForRoleReducer } from '../pages/users-and-roles/roles-management/details/components/users-list-from-role/state/users-from-role.reducers';
import { USERS_FOR_ROLE_FEATURE_KEY } from '../pages/users-and-roles/roles-management/details/components/users-list-from-role/state/users-from-role.state';
import { RoleManagementEffects } from '../pages/users-and-roles/roles-management/state/role-management.effects';
import { roleManagementReducer } from '../pages/users-and-roles/roles-management/state/role-management.reducers';
import { ROLE_MANAGEMENT_FEATURE_KEY } from '../pages/users-and-roles/roles-management/state/role-management.state';
import { UsersAndRolesPageModule } from '../pages/users-and-roles/users-and-roles-page.module';
import { UserManagementEffects } from '../pages/users-and-roles/users-management/state/user-management.effects';
import { userManagementReducer } from '../pages/users-and-roles/users-management/state/user-management.reducers';
import { USER_MANAGEMENT_FEATURE_KEY } from '../pages/users-and-roles/users-management/state/user-management.state';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WEB_COMPONENT_NAME } from './app.name';
import { ProvideServicesModule } from './provide-services.module';
import { AppEffects } from './state/app.effects';
import { appReducer } from './state/app.reducer';
import { USERS_PANEL_APP_FEATURE_KEY } from './state/app.state';

@NgModule({
    declarations: [AppComponent],
    imports: [
        BrowserModule,
        CommonModule,
        WidgetsModule,
        CtPrimitivesModule,
        FormsModule,
        ReactiveFormsModule,
        CtModalsModule,
        CtGridModule,
        AgGridModule,
        EntitiesGridsModule,
        QuickSwitcherControlsModule,
        JumpstartComponentsModule,
        TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: () =>
                    translateLoaderFactory(wkVars(WEB_COMPONENT_NAME).url)
            }
        }),
        StoreDevtoolsModule.instrument(),
        environment.production
            ? []
            : StoreRouterConnectingModule.forRoot({
                  serializer: DefaultRouterStateSerializer
              }),
        StoreModule.forRoot(
            {
                [USERS_PANEL_APP_FEATURE_KEY]: appReducer,
                [WIDGETS_FEATURE_KEY]: widgetReducer,
                [CUSTOM_FIELDSS_FEATURE_KEY]: customFieldsReducer,
                [GROUPS_FEATURE_KEY]: groupsReducer,
                [ADD_GROUP_MODAL_FEATURE_KEY]: addGroupModalReducer,
                [USER_MANAGEMENT_FEATURE_KEY]: userManagementReducer,
                [ROLE_MANAGEMENT_FEATURE_KEY]: roleManagementReducer,
                [USERS_FOR_ROLE_FEATURE_KEY]: usersForRoleReducer,
                [ENTITY_SELECTOR_FEATURE_KEY]: entitySelectorReducer,
                [GROUP_DETAILS_FEATURE_KEY]: groupDetailsReducer,
                [DIGITAL_EXPERIENCE_FEATURE_KEY]: digitalExperienceReducer,
                [MODULES_AND_PERMISSIONS_FEATURE_KEY]:
                    modulesAndPermissionsReducer
            },
            {
                runtimeChecks: {
                    strictStateImmutability: false,
                    strictActionImmutability: false
                }
            }
        ),
        EffectsModule.forRoot([
            AppEffects,
            WidgetEffects,
            CustomFieldsEffects,
            UserManagementEffects,
            RoleManagementEffects,
            UsersForRoleEffects,
            EntitySelectorEffects,
            DigitalExperienceEffects,
            AddGroupModalEffects,
            ModulesAndPermissionsEffects
        ]),
        LazyElementsModule.forRoot({}),
        ProvideServicesModule,
        AppRoutingModule,
        UserModule,
        BrowserAnimationsModule,
        AuthorizationModule,
        UsersAndRolesPageModule,
        RequestPatchingModule,
        GlobalErrorHandlerModule.forRoot({
            applicationName: environment.applicationName
        })
    ],
    providers: [
        ...WEB_COMPONENTS_INITIALIZERS,
        {
            provide: APP_INITIALIZER,
            useFactory: initializeAgGridLicence,
            multi: true
        },
        EntitiesGridService,
        {
            provide: AclDefinitionService,
            useClass: AclClaimsBasedDefinitionService
        }
    ],
    entryComponents: [AppComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule implements DoBootstrap {
    constructor(protected injector: Injector) {}

    ngDoBootstrap(): void {
        if (!customElements.get(WEB_COMPONENT_NAME)) {
            customElements.define(
                WEB_COMPONENT_NAME,
                createCustomElement(AppComponent, {
                    injector: this.injector
                })
            );
        }
    }
}
