//Sonar-cube Test
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import {
    AclClaimsBasedDefinitionService,
    AclDefinitionService,
    AuthorizationModule,
    AuthorizationService,
    LocaleServiceNg
} from '@ct/core-ui-ng';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { of } from 'rxjs';

import { UsersManagementComponent } from '../pages/users-and-roles/users-management/users-management.component';
import { NavigationsService } from '../shared/services/navigation/navigations.service';

import { AppComponent } from './app.component';
import {
    selectBreadcrumbsItems,
    selectForceRedirectTo,
    selectUserTokenPayload
} from './state/app.selectors';
const mockNavigationsService = jasmine.createSpyObj('NavigationsService', [
    'subscribeRouteEvents',
    'getBreadcrumbs',
    'isHidden'
]);
describe('AppComponent', () => {
    let fixture: ComponentFixture<AppComponent>;
    let component: AppComponent;
    let localeService: LocaleServiceNg;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                CommonModule,
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule,
                RouterModule.forRoot([]),
                AuthorizationModule,
                RouterTestingModule.withRoutes([
                    {
                        path: 'account-tools/users-and-roles',
                        component: UsersManagementComponent
                    },
                    {
                        path: 'user-management',
                        component: UsersManagementComponent
                    }
                ])
            ],
            declarations: [AppComponent, UsersManagementComponent],
            providers: [
                provideMockStore({
                    initialState: {},
                    selectors: [
                        {
                            selector: selectUserTokenPayload,
                            value: {
                                name: 'Omar Del Toro'
                            }
                        },
                        {
                            selector: selectForceRedirectTo,
                            value: ''
                        },
                        {
                            selector: selectBreadcrumbsItems,
                            value: [
                                {
                                    name: 'Users And Roles'
                                }
                            ]
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                },
                {
                    provide: AclDefinitionService,
                    useClass: AclClaimsBasedDefinitionService
                },
                {
                    provide: AuthorizationService,
                    useValue: jasmine.createSpy()
                },
                {
                    provide: NavigationsService,
                    useValue: mockNavigationsService
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        });

        fixture = TestBed.createComponent(AppComponent);
        component = fixture.componentInstance;
        localeService = fixture.debugElement.injector.get(LocaleServiceNg);
        mockNavigationsService.isHidden.and.returnValue(of(false));
    });

    it('should create AppComponent', () => {
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });

    it('should set locale', () => {
        const lang = 'en';
        component.locale = lang;
        component.locale = null;
        expect(component.locale).toBe(lang);
    });

    it('should set isInternal', () => {
        const userIsInternal = true;
        component.isInternal = userIsInternal;
        fixture.detectChanges();
        expect(component._isInternal).toBe(true);
    });

    it('should set urlPathPrefix', () => {
        const urlPathPrefixExpected = 'internal-tools';
        component.urlPathPrefix = urlPathPrefixExpected;
        fixture.detectChanges();
        expect(component._urlPathPrefix).toBe(urlPathPrefixExpected);
    });

    it('should set User token payload', () => {
        const userLogged = { name: 'Omar Del Toro' };
        component.userTokenPayload = userLogged;
        fixture.detectChanges();
        expect(component._userTokenPayload).toBe(userLogged);
    });
});
