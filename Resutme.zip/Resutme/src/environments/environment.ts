export const environment = {
    production: false,
    baseUrl: '',
    applicationName: 'ct-engage-users-panel-uiwc'
};
