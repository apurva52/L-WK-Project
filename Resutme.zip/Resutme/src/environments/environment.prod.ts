export const environment = {
    production: true,
    baseUrl: '/engage-admin',
    applicationName: 'ct-engage-users-panel-uiwc'
};
