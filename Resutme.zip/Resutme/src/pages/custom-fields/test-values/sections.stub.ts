export const SectionsStub: any = {
    result: {
        id: 1111,
        name: "EventsSection",
        objectTypeId: 111,
        objectType: "event"
    }
};
