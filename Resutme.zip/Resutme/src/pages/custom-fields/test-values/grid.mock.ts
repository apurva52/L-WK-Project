import { CellClickedEvent } from '@ag-grid-community/core';
import { GridComponent } from '@ct/platform-primitives-uicomponents/grid';

import { CUSTOMFIELD_CLICKABLE_COLUMNS } from '../state/custom-fields.grid.constants';

export function getMockGrid(): GridComponent {
    return {
        ...{
            colDef: [
                {
                    minWidth: 0
                },
                {
                    minWidth: 0
                },
                {
                    minWidth: 0
                },
                {
                    minWidth: 0
                }
            ],
            gridOptions: {
                columnApi: {
                    autoSizeAllColumns: () => {}
                },
                rowClassRules: {},
                onFirstDataRendered: () => {},
                onCellClicked: () =>
                    ({
                        colDef: { field: CUSTOMFIELD_CLICKABLE_COLUMNS[0] },
                        data: { customFieldId: 123 }
                    } as CellClickedEvent)
            },
            clearSelection: () => {}
        }
    } as unknown as GridComponent;
}
