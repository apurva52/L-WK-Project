export interface CustomFieldsModel {
    customFieldId: number;
    accountId: string;
    customFieldName: string;
    type: number;
    description: string;
    sectionId: number;
    isRequired: string;
    fieldUIMetaJson: string;
    typeName: string;
    tiedTo: string;
    appliedTo: string;
    isRequiredLabel: string;
    createdBy: string;
}
