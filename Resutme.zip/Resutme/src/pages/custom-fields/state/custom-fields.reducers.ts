import { createReducer, on } from '@ngrx/store';

import {
    customFieldsFailureAction,
    customFieldsFilterAction,
    customFieldsFilterFailureAction,
    customFieldsFilterSuccessAction,
    customFieldsInitiateAction,
    customFieldsSelectAction,
    customFieldsSelectClearAllAction,
    customFieldsSuccessAction,
    getSectionsFailureAction,
    getSectionsInitiateAction,
    getSectionsSuccessAction
} from './custom-fields.actions';
import { CustomFields } from './custom-fields.state';

export const initialState: CustomFields = {
    loading: false,
    customFieldsFilterParams: [],
    customFieldsData: [],
    customFieldSearchData: [],
    error: {
        active: false,
        message: ''
    },
    total: 0,
    selected: [],
    customFieldsSelectClearAllAction: false,
    sectionsData: []
};

export const customFieldsReducer = createReducer(
    initialState,
    on(customFieldsInitiateAction, (state) => ({
        ...state,
        loading: true
    })),
    on(customFieldsSelectAction, (state, action) => ({
        ...state,
        total: action.customFieldsSelectParams ? action.customFieldsSelectParams.total : 0,
        selected: action.customFieldsSelectParams.selected
    })),
    on(customFieldsSuccessAction, (state, action) => ({
        ...state,
        loading: false,
        customFieldsData: action.response.result.items,
        customFieldSearchData: action.response.result.items
            .map(({ customFieldName }) => customFieldName)
            .map((s) => {
                return {
                    value: s,
                    label: s
                };
            })
    })),
    on(customFieldsFailureAction, (state, action) => ({
        ...state,
        loading: false,
        error: {
            active: true,
            message: action.errorMessage
        }
    })),
    on(customFieldsSelectClearAllAction, (state, action) => ({
        ...state,
        customFieldsSelectClearAllAction: action.value
    })),
    on(getSectionsInitiateAction, (state) => ({
        ...state,
        loading: true
    })),
    on(getSectionsSuccessAction, (state, action) => ({
        ...state,
        loading: false,
        sectionsData: action.sectionsResponse
    })),
    on(getSectionsFailureAction, (state, action) => ({
        ...state,
        loading: false,
        error: {
            active: true,
            message: action.errorMessage
        }
    })),
    on(customFieldsFilterAction, (state, action) => ({
        ...state,
        loading: true,
        customFieldsFilterParams: [action.customFieldsFilterParams]
    })),
    on(customFieldsFilterSuccessAction, (state, action) => ({
        ...state,
        loading: false,
        customFieldsData: action.response?.result?.items ? action.response?.result?.items : [],
        customFieldSearchData: action.response?.result?.items ? action.response?.result?.items : []
            .map(({ customFieldName }) => customFieldName)
            .map((s) => {
                return {
                    value: s,
                    label: s
                };
            })
    })),
    on(customFieldsFilterFailureAction, (state, action) => ({
        ...state,
        loading: false,
        error: {
            active: true,
            message: action.errorMessage
        }
    }))
);