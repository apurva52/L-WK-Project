export interface CustomFieldsFilterParams {
    section : Array<number>;
    isRequired: Array<string>;
    createdby: Array<string>;
}