import { createAction, props } from '@ngrx/store';

import { CustomFieldsFilterParams } from './custom-fields-filter.params';
import { CustomFieldsParams } from './custom-fields.params';
import { CustomFieldsSelectParams } from './custom-fields.selectParams';
import { CustomSectionsModel } from './custom-sections.model';

export enum CustomFieldsActionTypes {
    CustomFieldsSelectClearAll = `[custom-fields][CustomFields] ClearAll`,
    CustomFieldsSelect = `[custom-fields][CustomFields] Select`,
    CustomFieldsInitiate = `[custom-fields][CustomFields] Initiate`,
    CustomFieldsCancel = `[custom-fields][CustomFields] Cancel`,
    CustomFieldsSuccess = `[custom-fields][CustomFields] Success`,
    CustomFieldsFailure = `[custom-fields][CustomFields] Failure`,
    GetSectionsInitiate =  `[custom-fields][CustomFields] Get Sections`,
    GetSectionsFailed = `[custom-fields][CustomFields] Get Sections Failure`,
    GetSectionsSuccess = `[custom-fields][CustomFields] Get Sections Success`,
    CustomFieldsFilter =  `[custom-fields][CustomFields] Filter Custom Fields`,
    CustomFieldsFilterFailure = `[custom-fields][CustomFields] Filter Custom Fields Failure`,
    CustomFieldsFilterSuccess = `[custom-fields][CustomFields] Filter Custom Fields Success`
}

export const customFieldsSelectClearAllAction = createAction(
    CustomFieldsActionTypes.CustomFieldsSelectClearAll,
    props<{
        value: boolean;
    }>()
);

export const customFieldsSelectAction = createAction(
    CustomFieldsActionTypes.CustomFieldsSelect,
    props<{
        customFieldsSelectParams: CustomFieldsSelectParams;
    }>()
);

export const customFieldsInitiateAction = createAction(
    CustomFieldsActionTypes.CustomFieldsInitiate,
    props<{
        customFieldsParams: CustomFieldsParams;
    }>()
);

export const customFieldsSuccessAction = createAction(
    CustomFieldsActionTypes.CustomFieldsSuccess,
    props<{ response: any; params: CustomFieldsParams }>()
);

export const customFieldsFailureAction = createAction(
    CustomFieldsActionTypes.CustomFieldsFailure,
    props<{
        errorMessage: string;
    }>()
);

export const customFieldsFilterAction = createAction(
    CustomFieldsActionTypes.CustomFieldsFilter,
    props<{
        customFieldsParams: CustomFieldsParams,
        customFieldsFilterParams: CustomFieldsFilterParams }>()
);

export const customFieldsFilterFailureAction = createAction(
    CustomFieldsActionTypes.CustomFieldsFilterFailure,
    props<{
        errorMessage: string
    }>()
);

export const customFieldsFilterSuccessAction = createAction(
    CustomFieldsActionTypes.CustomFieldsFilterSuccess,
    props<{ response: any; }>()
);

export const getSectionsInitiateAction = createAction(
    CustomFieldsActionTypes.GetSectionsInitiate
);

export const getSectionsFailureAction = createAction(
    CustomFieldsActionTypes.GetSectionsFailed,
    props<{
        errorMessage: string
    }>()
);

export const getSectionsSuccessAction = createAction(
    CustomFieldsActionTypes.GetSectionsSuccess,
    props<{ sectionsResponse: Array<CustomSectionsModel> }>()
);