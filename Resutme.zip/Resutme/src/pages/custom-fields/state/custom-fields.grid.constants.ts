import { GridOptions } from '@ag-grid-community/core';

import { CustomFieldsParams } from '../state/custom-fields.params';

export const GRID_PARAMS = {
    PAGE_SIZE: 20
};

export const ROW_SCROLL_HEIGHT = 50;
export const SCROLL_CACHE_MULTIPLIER = 2;
export const SCROLL_PAGE_MULTIPLIER = 3;
export const PAGE_NUMBER = 1;
export const PAGE_SIZE = 100;

export const customFieldsParams:  CustomFieldsParams = {
    pageNumber: PAGE_NUMBER,
    pageSize: PAGE_SIZE,
    sortKey: 'asc',
    sortBy: 'customFieldName'
};

export const CUSTOMFIELD_CLICKABLE_COLUMNS = ['customFieldName'];
export const CUSTOMFIELD_TEXT_FIELDS = ['customFieldName', 'tiedTo', 'typeName', 'isRequired', 'createdBy'];
//formationDate

export const GRID_OPTIONS_BASE: GridOptions = {
    debounceVerticalScrollbar: true,
    rowModelType: 'infinite',
    rowData: [],
    suppressHorizontalScroll: false,
    infiniteInitialRowCount: 1,
    components: {
        loadingCellRenderer: (params) => {
            if (params.value !== undefined) {
                return params.value;
            } else {
                return 'x';
            }
        }
    },
    defaultColDef: {
        sortable: true,
        resizable: true,
        enablePivot: false
    },
    sortingOrder: ['desc', 'asc'],
    suppressRowClickSelection: true,
    rowSelection: 'multiple'
};
