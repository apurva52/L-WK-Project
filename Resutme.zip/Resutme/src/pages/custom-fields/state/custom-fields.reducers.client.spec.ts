import { CustomFieldsStub } from '../test-values/custom-fields.stub';
import { SectionsStub } from '../test-values/sections.stub';

import { CustomFieldsFilterParams } from './custom-fields-filter.params';
import * as customfieldActions from './custom-fields.actions';
import { CustomFieldsParams } from './custom-fields.params';
import { customFieldsReducer, initialState } from './custom-fields.reducers';
import { CustomFieldsSelectParams } from './custom-fields.selectParams';

describe('custom fields reducer', () => {
    const customFieldsParams: CustomFieldsParams = { pageNumber: 1, pageSize: 20, sortBy: 'asc', sortKey: 'customFieldName' };
    const customFieldsSelectParams: CustomFieldsSelectParams = { selected: [], total: 10 };
    it('should process custom Fields load', () => {
        const currentState = { ...initialState };
        expect(
            customFieldsReducer(
                currentState,
                customfieldActions.customFieldsInitiateAction({
                    customFieldsParams: customFieldsParams
                })
            )
        ).toEqual({
            ...currentState,
            loading: true
        });
    });

    it('should process custom Fields select action', () => {
        const currentState = { ...initialState };
        expect(
            customFieldsReducer(
                currentState,
                customfieldActions.customFieldsSelectAction({
                    customFieldsSelectParams: customFieldsSelectParams
                })
            )
        ).toEqual({
            ...currentState,
            total: 10,
            selected: []
        });
    });

    it('should process custom Fields success', () => {
        const currentState = { ...initialState };
        expect(
            customFieldsReducer(
                currentState,
                customfieldActions.customFieldsSuccessAction({
                    response: CustomFieldsStub,
                    params: customFieldsParams
                })
            )
        ).toEqual({
            ...currentState,
            loading: false,
            customFieldsData: CustomFieldsStub.result.items,
            customFieldSearchData: CustomFieldsStub.result.items
                .map(({ customFieldName }) => customFieldName)
                .map((s) => {
                    return {
                        value: s,
                        label: s
                    };
                })
        });
    });

    it('should process custom Fields failure', () => {
        const currentState = { ...initialState };
        expect(
            customFieldsReducer(
                currentState,
                customfieldActions.customFieldsFailureAction({
                    errorMessage: 'error'
                })
            )
        ).toEqual({
            ...currentState,
            loading: false,
            error: {
                active: true,
                message: 'error'
            }
        });
    });

    it('should process sections data load', () => {
        const currentState = { ...initialState };
        expect(customFieldsReducer(currentState, customfieldActions.getSectionsInitiateAction())).toEqual({
            ...currentState,
            loading: true
        });
    });

    it('should process sections load failure', () => {
        const currentState = { ...initialState };
        expect(
            customFieldsReducer(
                currentState,
                customfieldActions.getSectionsFailureAction({
                    errorMessage: 'error'
                })
            )
        ).toEqual({
            ...currentState,
            loading: false,
            error: {
                active: true,
                message: 'error'
            }
        });
    });

    it('should process custom Filter Fields load', () => {
        const section501: number = 501;
        const section502: number = 502;
        const customFieldsFilterParams: CustomFieldsFilterParams = {
            section: [section501, section502],
            isRequired: ['Optional', 'Required'],
            createdby: ['testName']
        };

        const customFieldsParams: CustomFieldsParams = {
            pageNumber: 1,
            pageSize: 100,
            sortKey: 'asc',
            sortBy: 'customFieldName'
        };
        const currentState = { ...initialState };
        expect(
            customFieldsReducer(
                currentState,
                customfieldActions.customFieldsFilterAction({
                    customFieldsParams: customFieldsParams,
                    customFieldsFilterParams: customFieldsFilterParams
                })
            )
        ).toEqual({
            ...currentState,
            loading: true,
            customFieldsFilterParams: [customFieldsFilterParams]
        });
    });

    it('should process custom Fields Filter failure', () => {
        const currentState = { ...initialState };
        expect(
            customFieldsReducer(
                currentState,
                customfieldActions.customFieldsFilterFailureAction({
                    errorMessage: 'error'
                })
            )
        ).toEqual({
            ...currentState,
            loading: false,
            error: {
                active: true,
                message: 'error'
            }
        });
    });

    it('should process custom customFieldsFilterSuccessAction', () => {
        const currentState = { ...initialState };

        expect(
            customFieldsReducer(
                currentState,
                customfieldActions.customFieldsFilterSuccessAction({
                    response: CustomFieldsStub
                })
            )
        ).toEqual({
            ...currentState,
            loading: false,
            customFieldsData: CustomFieldsStub.result.items,
            customFieldSearchData: CustomFieldsStub.result.items
        });
    });

    it('should process getSectionsSuccessAction', () => {
        const currentState = { ...initialState };
        expect(
            customFieldsReducer(
                currentState,
                customfieldActions.getSectionsSuccessAction({
                    sectionsResponse: SectionsStub
                })
            )
        ).toEqual({
            ...currentState,
            loading: false,
            sectionsData: SectionsStub
        });
    });

    it('should process customFieldsSelectClearAllAction', () => {
        const currentState = { ...initialState };
        expect(
            customFieldsReducer(
                currentState,
                customfieldActions.customFieldsSelectClearAllAction({
                    value: true
                })
            )
        ).toEqual({
            ...currentState,
            customFieldsSelectClearAllAction: true
        });
    });
});
