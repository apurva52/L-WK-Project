export interface CustomFieldsParams {
    pageNumber: number;
    pageSize: number;
    sortKey: string;
    sortBy: string;
}
