import { createFeatureSelector, createSelector } from '@ngrx/store';

import { CUSTOM_FIELDSS_FEATURE_KEY, CustomFields } from './custom-fields.state';

export const selectRootFeature = createFeatureSelector<CustomFields>(CUSTOM_FIELDSS_FEATURE_KEY);

export const selectCustomFieldsLoadingStatus = createSelector(selectRootFeature, (state: CustomFields) => state.loading);

export const selectCustomFieldsData = createSelector(selectRootFeature, (state: CustomFields) => state.customFieldsData);

export const selectCustomFieldSearchData = createSelector(selectRootFeature, (state: CustomFields) => state.customFieldSearchData);

export const selectedCustomFieldsTotal = createSelector(selectRootFeature, (state: CustomFields) => state.total);

export const selectedCustomFields = createSelector(selectRootFeature, (state: CustomFields) => state.selected);

export const selectedCustomFieldsFilterParams = createSelector(selectRootFeature, (state: CustomFields) => state.customFieldsFilterParams);

export const selectCustomFieldsSelectClearAllAction = createSelector(
    selectRootFeature,
    (state: CustomFields) => state.customFieldsSelectClearAllAction
);

export const selectSectionsData = createSelector(selectRootFeature, (state: CustomFields) => state.sectionsData);
