export const CUSTOM_FIELDSS_FEATURE_KEY = 'customFieldsFeatureKey';
import { CustomFieldsFilterParams } from './custom-fields-filter.params';
import { CustomFieldsModel } from './custom-fields.model';
import { CustomSectionsModel } from './custom-sections.model';

export interface CustomFields {
    loading: boolean;
    customFieldsData: Array<CustomFieldsModel>;
    customFieldSearchData: Array<{ value: string; label: string }>;
    customFieldsFilterParams: Array<CustomFieldsFilterParams>;
    error: {
        active: boolean;
        message: string;
    };
    total: number;
    selected: Array<any>;
    customFieldsSelectClearAllAction: boolean;
    sectionsData: Array<CustomSectionsModel>;
}
