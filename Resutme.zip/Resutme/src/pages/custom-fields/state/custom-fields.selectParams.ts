export interface CustomFieldsSelectParams {
    total : number;
    selected : Array<any>;
}