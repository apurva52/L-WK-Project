import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { from, of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';

import { CustomFieldsService } from '../../../shared/services/custom-fields/customFields.service';

import {
    customFieldsFailureAction,
    customFieldsFilterAction,
    customFieldsFilterFailureAction,
    customFieldsFilterSuccessAction,
    customFieldsInitiateAction,
    customFieldsSuccessAction,
    getSectionsFailureAction,
    getSectionsInitiateAction,
    getSectionsSuccessAction
} from './custom-fields.actions';

@Injectable()
export class CustomFieldsEffects {
    entitiesInitiate$ = createEffect(() =>
        this.actions$.pipe(
            ofType(customFieldsInitiateAction),
            switchMap((params) => {
                return from(this.customFieldsService.initiateRequest(params.customFieldsParams)).pipe(
                    map((response) =>
                        customFieldsSuccessAction({
                            response: response,
                            params: params.customFieldsParams
                        })
                    ),
                    catchError((err) => of(customFieldsFailureAction({ errorMessage: err })))
                );
            })
        )
    );

    getSectionsInitiate$ = createEffect(() =>
        this.actions$.pipe(
            ofType(getSectionsInitiateAction),
            switchMap((params) => {
                return from(this.customFieldsService.getSectionRequest()).pipe(
                    map((response) =>
                        getSectionsSuccessAction({
                            sectionsResponse: response.result
                        })
                    ),
                    catchError((err) => of(getSectionsFailureAction({ errorMessage: err })))
                );
            })
        )
    );

    filterCustomFileds$ = createEffect(() =>
        this.actions$.pipe(
            ofType(customFieldsFilterAction),
            switchMap((params) => {
                return from(this.customFieldsService.filterCustomFields(params.customFieldsParams, params.customFieldsFilterParams)).pipe(
                    map((response) =>
                        customFieldsFilterSuccessAction({
                            response: response
                        })
                    ),
                    catchError((err) => of(customFieldsFilterFailureAction({ errorMessage: err })))
                );
            })
        )
    );

    constructor(private actions$: Actions, private customFieldsService: CustomFieldsService) {}
}
