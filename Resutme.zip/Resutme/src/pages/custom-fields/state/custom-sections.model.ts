export interface CustomSectionsModel {
    id: number;
    name: string;
    objectTypeId: number;
    objectType: string;
}