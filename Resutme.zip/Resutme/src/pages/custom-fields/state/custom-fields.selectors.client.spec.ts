
import { CustomFieldsStub } from '../test-values/custom-fields.stub';

import { initialState } from './custom-fields.reducers';
import * as customFieldsSelectors from './custom-fields.selectors';
import { CustomFields } from './custom-fields.state';

describe('former names selectors', () => {
    it('should return current custom fields data', () => {
        const mockData = CustomFieldsStub.result;
        const currentState: CustomFields = {
            ...initialState,
            loading: false,
            customFieldsData: CustomFieldsStub.result,
            customFieldSearchData: [],
            error: {
                active: false,
                message: ''
            },
            total: 0,
            selected: []
        };

        const currentData =
        customFieldsSelectors.selectCustomFieldsData.projector(currentState);
        expect(currentData).toEqual(mockData);
    });

    it('should return current loading status', () => {
        const mockLoading = true;
        const currentState: CustomFields = {
            ...initialState,
            loading: true
        };

        const currentData =
        customFieldsSelectors.selectCustomFieldsLoadingStatus.projector(currentState);
        expect(currentData).toEqual(mockLoading);
    });


});