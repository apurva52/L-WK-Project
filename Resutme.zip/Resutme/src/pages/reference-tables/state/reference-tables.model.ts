export interface ReferenceTablesModel {
    referenceId: number;
    referenceDesc: string;
    isClientManaged: string;
    category: string;
    isDisplayForIgnite: string;
    referenceRoute: string;
    lastModifiedBy: string;
    lastModifiedDate: string;
}


export interface DeleteReferenceValuePostModel {
    referenceRoute: string;
    referenceDataGuid: string;
}


export interface CheckReferenceValuePostModelSuccess {
    result: boolean;
}

export interface DeleteReferenceValueSuccess {
    result: boolean;
}