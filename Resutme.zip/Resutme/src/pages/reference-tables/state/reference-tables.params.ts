export interface ReferenceTablesParams {
    pageNumber: number;
    pageSize: number;
    sortKey: string;
    sortBy: string;
}

export interface ReferenceTypeParams extends ReferenceTablesParams {
    referenceRoute: string;
}