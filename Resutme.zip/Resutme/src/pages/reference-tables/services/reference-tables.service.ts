import { Post, Route } from '@wk/edge-services';

import { DeleteReferenceValuePostModel } from '../state/reference-tables.model';
import { ReferenceTablesParams } from '../state/reference-tables.params';

@Route('reference-tables')
export class ReferenceTablesService {
    @Post()
    async getReferenceTypes(_params : ReferenceTablesParams): Promise<any> {
        throw new Error('Not implemented');
    }

    @Post()
    async getReferenceValueStatus(_params : DeleteReferenceValuePostModel): Promise<any> {
        throw new Error('Not implemented');
    }

    @Post()
    async deleteReferenceValue(_params : DeleteReferenceValuePostModel): Promise<any> {
        throw new Error('Not implemented');
    }
}
