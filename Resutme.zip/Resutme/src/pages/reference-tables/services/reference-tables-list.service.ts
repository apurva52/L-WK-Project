import {
  GridOptions,
  IGetRowsParams
} from '@ag-grid-community/core';
import { Injectable } from '@angular/core';
import moment from 'moment';

import { ENTITY_TEXT_FIELDS, GRID_OPTIONS_BASE, SCROLL_CACHE_MULTIPLIER, SCROLL_PAGE_MULTIPLIER } from '../state/reference-tables.grid.constant';
import { ReferenceTablesModel } from '../state/reference-tables.model';
import { ReferenceTablesParams } from '../state/reference-tables.params';

import { ReferenceTablesService } from './reference-tables.service';

@Injectable({
  providedIn: 'root'
})
export class ReferenceTablesListService {

  constructor(private referenceTablesService: ReferenceTablesService) { }

  getGridOptions(): GridOptions {
    const maxRows = 250;
    const baseRowNum = maxRows;

    return {
      ...GRID_OPTIONS_BASE,
      rowBuffer: Math.ceil(baseRowNum * SCROLL_CACHE_MULTIPLIER),
      cacheBlockSize: Math.ceil(baseRowNum * SCROLL_CACHE_MULTIPLIER),
      paginationPageSize: Math.ceil(baseRowNum * SCROLL_PAGE_MULTIPLIER)
    };
  }

  async getRows(params: IGetRowsParams): Promise<void> {
    const request: ReferenceTablesParams = {} as ReferenceTablesParams;
    request.pageSize = params.endRow - params.startRow;
    request.pageNumber = (params.startRow / request.pageSize) + 1;

    if (params.sortModel.length) {
      request.sortKey = params.sortModel[0].sort;
      request.sortBy = params.sortModel[0].colId;
    } else {
      request.sortKey = 'asc';
      request.sortBy = 'referenceDesc';
    }

    const data = await this.referenceTablesService.getReferenceTypes(request);
    const lastRow = this.getLastRow(data.result.data.length, request.pageNumber, request.pageSize);
    data.result.data = data.result.data.map(item => this.formatCellValues(item));
    params.successCallback(data.result.data, lastRow);
  }

  private getLastRow(rows: number, pageNum: number, pageSize: number): number {
    return rows < pageSize
      ? (pageNum - 1) * pageSize + rows
      : (pageNum + 1) * pageSize;
  }

  private formatCellValues(referenceTablesModel: ReferenceTablesModel): ReferenceTablesModel {
    ENTITY_TEXT_FIELDS.forEach(prop => {
      referenceTablesModel[prop] = !!referenceTablesModel[prop] ? referenceTablesModel[prop] : '-';
    });

    if (referenceTablesModel.lastModifiedDate && referenceTablesModel.lastModifiedDate !== '-') {
      referenceTablesModel.lastModifiedDate = moment(referenceTablesModel.lastModifiedDate).format('MMMM D, YYYY');
    }

    return referenceTablesModel;
  }

  private getAppHeight(): number {
    return window.innerHeight;
  }
}
