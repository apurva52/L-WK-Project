import { appSettingsSection, edgeFetch } from '@ct/core-ui/server';
import { getRequest } from '@wk/edge-services';

import { logger } from '../../../server/logger';
import { DeleteReferenceValuePostModel } from '../state/reference-tables.model';
import { ReferenceTablesParams } from '../state/reference-tables.params';

import { ReferenceTablesService } from './reference-tables.service';

const LOG_CLASS_NAME = 'ReferenceTablesServiceImpl';

export class ReferenceTablesServiceImpl implements ReferenceTablesService {
    @appSettingsSection('apiUrls')
    apiUrls: Promise<{ [key: string]: string }>;

    async getReferenceTypes(rtParams : ReferenceTablesParams): Promise<any> {
        const LOG_METHOD_NAME = 'ReferenceTablesServiceImpl';
        logger.info(`${LOG_CLASS_NAME}.${LOG_METHOD_NAME} enter`);
        let queryString = '';
        let sortingQueryString = '';

        if (rtParams.pageSize && rtParams.pageNumber) {
            queryString = '?page=' + rtParams.pageNumber + '&pageSize=' + rtParams.pageSize;
        }

        if (rtParams.sortKey && rtParams.sortBy) {
            sortingQueryString = queryString === '' ? '?' : '&';
            sortingQueryString = sortingQueryString + 'sortOrder=' + rtParams.sortKey + '&sortBy=' + rtParams.sortBy;
        }

        const request = getRequest();
        logger.info(`${LOG_CLASS_NAME}.${LOG_METHOD_NAME} before appSettings requested`);
        const apiUrls = await this.apiUrls;
        logger.info(`${LOG_CLASS_NAME}.${LOG_METHOD_NAME} appSettings received`);
        logger.info(`${LOG_CLASS_NAME}.${LOG_METHOD_NAME} before data requested`);

        return edgeFetch(`${apiUrls.EMAccountServiceUrl}/reference-types${queryString}${sortingQueryString}`, {
            headers: {},
            appendAuthorization: true,
            method: 'GET'
        }, request).then(data => {
            logger.info(`${LOG_CLASS_NAME}.${LOG_METHOD_NAME} data received`);
            return data;
        });
    }

    async getReferenceValueStatus(referencePostModel: DeleteReferenceValuePostModel): Promise<any> {
        const request = getRequest();
        const apiUrls = await this.apiUrls;
        return edgeFetch(
            `${apiUrls.EMAccountServiceUrl}/reference-types/${referencePostModel.referenceRoute}/reference-data/${referencePostModel.referenceDataGuid}/check-if-used`,
            {
                headers: {},
                appendAuthorization: true,
                method: 'GET'
            },
            request
        ).then((data) => {
            return data;
        });
    }

    async deleteReferenceValue(referencePostModel: DeleteReferenceValuePostModel): Promise<any> {
        const request = getRequest();
        const apiUrls = await this.apiUrls;
        return edgeFetch(
            `${apiUrls.EMAccountServiceUrl}/reference-types/${referencePostModel.referenceRoute}/reference-data/${referencePostModel.referenceDataGuid}`,
            {
                headers: {},
                appendAuthorization: true,
                method: 'DELETE'
            },
            request
        ).then((data) => {
            return data;
        });
    }
}
