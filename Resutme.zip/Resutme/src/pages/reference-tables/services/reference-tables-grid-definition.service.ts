import { Injectable } from '@angular/core';
import { CTGridColumnDefinition } from '@ct/platform-primitives-uicomponents/grid';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
    providedIn: 'root'
})
export class ReferenceTablesGridDefinitionService {
    constructor(
        private translate: TranslateService) {
    }

    getGridDefinition(): Array<CTGridColumnDefinition> {
        return [
            {
                dataType: 'STRING',
                colDef: {
                    resizable: true,
                    pinned: 'left',
                    headerName: this.translate.instant(`ReferenceTableModule.referenceTablesListComponent.gridLabel.fieldName`),
                    field: 'referenceDesc',
                    minWidth: 380
                },
                cellRendererOptions: {
                    useCellRenderer: 'clickCellRenderer'
                }
            },
            {
                dataType: 'STRING',
                colDef: {
                    resizable: true,
                    headerName: this.translate.instant(`ReferenceTableModule.referenceTablesListComponent.gridLabel.category`),
                    field: 'category',
                    minWidth: 150
                }
            },
            {
                dataType: 'STRING',
                colDef: {
                    resizable: true,
                    headerName: this.translate.instant(`ReferenceTableModule.referenceTablesListComponent.gridLabel.lastUpdated`),
                    field: 'lastModifiedDate',
                    minWidth: 150
                }
            },
            {
                dataType: 'STRING',
                colDef: {
                    resizable: true,
                    headerName: this.translate.instant(`ReferenceTableModule.referenceTablesListComponent.gridLabel.updatedBy`),
                    field: 'lastModifiedBy',
                    minWidth: 150
                }
            }
        ];
    }
}