import { IGetRowsParams } from '@ag-grid-community/core';
import { TestBed } from '@angular/core/testing';

import { ReferenceTablesMappedResponseData, ReferenceTablesResponseData } from '../shared/mock/referenceTablesStub-data.mock';
import { GRID_OPTIONS_BASE, ROW_SCROLL_HEIGHT, SCROLL_CACHE_MULTIPLIER, SCROLL_PAGE_MULTIPLIER } from '../state/reference-tables.grid.constant';

import { ReferenceTablesListService } from './reference-tables-list.service';
import { ReferenceTablesService } from './reference-tables.service';

describe('ReferenceTablesListService', () => {
    let service: ReferenceTablesListService;

    beforeEach(() => {
      TestBed.configureTestingModule({
        providers: [
            ReferenceTablesService
        ]
      });
      service = TestBed.inject(ReferenceTablesListService);
    });

    it('should be created', () => {
      expect(service).toBeTruthy();
    });

    it('should get grid options with calculated variables', () => {
        const mockBrowserHeight = 12500;
        const mockRowNum = Math.ceil(mockBrowserHeight / ROW_SCROLL_HEIGHT);
        const cacheSize = Math.ceil(mockRowNum * SCROLL_CACHE_MULTIPLIER);
        const pageSize = Math.ceil(mockRowNum * SCROLL_PAGE_MULTIPLIER);
        spyOn<any>(service, 'getAppHeight').and.returnValue(mockBrowserHeight);

        const options = service.getGridOptions();

        expect(options).not.toBeNull();
        expect(options).toEqual({
          ...GRID_OPTIONS_BASE,
          cacheBlockSize: cacheSize,
          rowBuffer: cacheSize,
          paginationPageSize: pageSize
        });
    });

    it('should map entities to fill empty ticks and format dates', () => {
        const responseData = ReferenceTablesResponseData.data[0];
        const formattedData = ReferenceTablesMappedResponseData.data[0];
        expect((<any>service).formatCellValues(responseData)).toEqual(formattedData);
    });

    it('should set max rows correctly', () => {
        const maxRowSize = 20;
        const minRowSize = 10;
        const equalDataSize = 60;
        const lessEqualDataSize = 30;
        expect((<any>service).getLastRow(maxRowSize, 2, maxRowSize)).withContext('data size equal to full page').toBe(equalDataSize);
        expect((<any>service).getLastRow(minRowSize, 2, maxRowSize)).withContext('data size less than full page').toBe(lessEqualDataSize);
        expect((<any>service).getLastRow(0, 2, maxRowSize)).withContext('data is empty').toBe(maxRowSize);
    });

    it('should call a service with correct request and a callback after response', async () => {
        const referenceTablesService = TestBed.inject(ReferenceTablesService);
        const serviceSpy = spyOn(referenceTablesService, 'getReferenceTypes').and.returnValue(
            new Promise((resolve) => {
                resolve({ result: ReferenceTablesResponseData });
            }
        ));
        const params = {
          successCallback(rowsThisBlock: Array<any>, lastRow?: number): void { },
          startRow: 20,
          endRow: 40,
          sortModel: [{
            sort: 'asc',
            colId: 'referenceDesc'
          }]
        } as IGetRowsParams;
        const callbackSpy = spyOn(params, 'successCallback');
        const expectedRequest = {
          pageSize: 20,
          pageNumber: 2,
          sortKey: 'asc',
          sortBy: 'referenceDesc'
        };

        await service.getRows(params);

        const mappedEntityStub = 21;
        expect(serviceSpy).toHaveBeenCalledWith(expectedRequest);
        expect(callbackSpy).toHaveBeenCalledWith(ReferenceTablesMappedResponseData.data, mappedEntityStub);

        const initialParams = {
          successCallback(rowsThisBlock: Array<any>, lastRow?: number): void { },
          startRow: 0,
          endRow: 20
        } as IGetRowsParams;
        const initialCallbackSpy = spyOn(initialParams, 'successCallback');
        const initialExpectedRequest = {
          pageSize: 20,
          pageNumber: 1,
          sortKey: 'asc',
          sortBy: 'referenceDesc'
        };

        await service.getRows(params);

        const initialmappedEntityStub = 21;
        expect(callbackSpy).toHaveBeenCalledWith(ReferenceTablesMappedResponseData.data, initialmappedEntityStub);
    });

});
