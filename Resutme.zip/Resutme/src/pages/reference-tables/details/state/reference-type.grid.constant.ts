import { GridOptions } from '@ag-grid-community/core';

import { ReferenceTypeParams } from '../../state/reference-tables.params';

export const ROW_SCROLL_HEIGHT = 50;
export const SCROLL_CACHE_MULTIPLIER = 2;
export const SCROLL_PAGE_MULTIPLIER = 3;
export const ROW_HEIGHT = 72;
export const GRID_CLICKABLE_COLUMNS = ['referenceDesc'];
export const GRID_TEXT_FIELDS = ['referenceDesc', 'category', 'lastModifiedDate', 'lastModifiedBy'];
export const SYSTEM_DEF = 'System Defined';
export const CUSTOM_DEF = 'Custom Defined';
export const NAME_FIELD_LINK = 'name';
export const NOT_SYSTEM_DEFINED = 'N';
export const SYSTEM_DEFINED = 'Y';
export const DELETE_FIELD = 'guid';
export const TYPE_FIELD = 'sysDefinedInd';
export const TIMEOUT_DURATION = 1000;

export const GRID_OPTIONS: GridOptions = {
    debounceVerticalScrollbar: true,
    suppressHorizontalScroll: true,
    infiniteInitialRowCount: 1,
    defaultColDef: {
        sortable: true,
        resizable: true,
        enablePivot: false,
        filter: true
    },
    sortingOrder: ['desc', 'asc'],
    suppressRowClickSelection: true,
    rowSelection: 'single'
};

export function getReferenceTypeParams(dataRoute: string): ReferenceTypeParams {
    return {
        referenceRoute: dataRoute,
        pageNumber: 1,
        pageSize: 100,
        sortKey: 'asc',
        sortBy: 'referenceTypeName'
    };
}

