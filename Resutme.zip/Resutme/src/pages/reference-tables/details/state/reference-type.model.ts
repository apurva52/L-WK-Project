export interface ReferenceTypeModel {
    id: number;
    referenceGuid: string;
    displayOrderNo: number;
    referenceTypeName: string;
    sysDefinedInd: string;
}

export interface ReferenceTypeResponseModel {
    data: Array<ReferenceTypeModel>;
    totalRecordCount : number;
}