jest.mock('@wk/edge-services', () => {
    const module = jest.requireActual('@wk/edge-services');

    return {
        __esModule: true,
        ...module,
        getRequest: () => undefined
    };
});

import { EdgeFetchOptions } from '@ct/core-ui/server';
import * as serverCore from '@ct/core-ui/server';

import { ReferenceTypeDataServiceImpl } from './reference-type-data.service.impl';

describe('ReferenceTypeData Service Impl', () => {
    let service: ReferenceTypeDataServiceImpl;
    const testApiUrls = {
        EMAccountServiceUrl: 'https://example.com'
    };
    const testSubscriptionKey = 'test';

    beforeEach(() => {
        jest.restoreAllMocks();
        service = new ReferenceTypeDataServiceImpl();
        Reflect.defineProperty(service, 'apiUrls', {
            value: Promise.resolve(testApiUrls)
        });
        Reflect.defineProperty(service, 'subscriptionKey', {
            value: Promise.resolve(testSubscriptionKey)
        });
    });

    describe('ReferenceType Data Service Imple WithRequest', () => {
        beforeEach(() => {
            jest.spyOn(serverCore, 'edgeFetch').mockImplementation(
                (url: any, options: EdgeFetchOptions<object>) => {
                    return Promise.resolve({
                        url: url.toString(),
                        options
                    });
                }
            );
        });

        xit('should construct url for getReferenceTypeDetails', (done) => {
            const referenceRoute = 'testRoute';
            service
                .getReferenceTypeDetails(referenceRoute)
                .then((response: any) => {
                    expect(response.url).toBe(
                        'https://example.com/reference-types/testRoute'
                    );
                    done();
                });
        });
    });
});
