import { Injectable } from '@angular/core';
import { CTGridColumnDefinition } from '@ct/platform-primitives-uicomponents/grid';
import { TranslateService } from '@ngx-translate/core';

import { DELETE_FIELD, NAME_FIELD_LINK, TYPE_FIELD } from '../state/reference-type.grid.constant';

@Injectable({
    providedIn: 'root'
})
export class ReferenceTypeDataGridDefinitionService {

    constructor(
        private translate: TranslateService) {
    }

    getGridDefinition(): Array<CTGridColumnDefinition> {
        const STRINGTYPE = 'STRING';
        const CUSTOM_FUNCTION = 'customFunction';
        return [
            {
                dataType: STRINGTYPE,
                colDef: {
                    resizable: true,
                    headerName: this.translate.instant(`ReferenceTableModule.referenceTablesValuesData.gridLabel.tableValue`),
                    field: NAME_FIELD_LINK,
                    minWidth: 350
                },
                cellRendererOptions: {
                    useCellRenderer: CUSTOM_FUNCTION
                }
            },
            {
                dataType: STRINGTYPE,
                colDef: {
                    resizable: true,
                    headerName: this.translate.instant(`ReferenceTableModule.referenceTablesValuesData.gridLabel.printOrder`),
                    field: 'displayOrderNo',
                    minWidth: 300
                },
                cellRendererOptions: {
                    useCellRenderer: CUSTOM_FUNCTION
                }
            },
            {
                dataType: STRINGTYPE,
                colDef: {
                    resizable: true,
                    headerName: this.translate.instant(`ReferenceTableModule.referenceTablesValuesData.gridLabel.type`),
                    field: TYPE_FIELD,
                    minWidth: 180,
                    pinned: 'right'
                },
                cellRendererOptions: {
                    useCellRenderer: CUSTOM_FUNCTION
                }
            },
            {
                dataType: STRINGTYPE,
                colDef: {
                    resizable: true,
                    headerName: '',
                    field: DELETE_FIELD,
                    minWidth: 60,
                    pinned: 'right'
                },
                cellRendererOptions: {
                    useCellRenderer: CUSTOM_FUNCTION
                }
            }
        ];
    }
}