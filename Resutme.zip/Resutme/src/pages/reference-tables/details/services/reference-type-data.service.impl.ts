////import { appSettingsSection, edgeFetch } from '@ct/core-ui/server';
import { getRequest } from '@wk/edge-services';

import { logger } from '../../../../server/logger';
import { ApiResponse } from '../../../../shared/interfaces/api-response.model';
import { ReferenceTypeResponseModel } from '../state/reference-type.model';

import { ReferenceTypeDataService } from './reference-type-data.service';

const LOG_CLASS_NAME = 'ReferenceTypeDataServiceImpl';

export class ReferenceTypeDataServiceImpl implements ReferenceTypeDataService {
    // @appSettingsSection('apiUrls')
    // apiUrls: Promise<{ [key: string]: string }>;

    async getReferenceTypeDetails(
        referenceRoute: string
    ): Promise<ApiResponse<ReferenceTypeResponseModel>> {
        // const LOG_METHOD_NAME = 'getReferenceTypeDetails';
        // logger.info(`${LOG_CLASS_NAME}.${LOG_METHOD_NAME} enter`);

        // const request = getRequest();
        // logger.info(
        //     `${LOG_CLASS_NAME}.${LOG_METHOD_NAME} before appSettings requested`
        // );
        // const apiUrls = '';
        // logger.info(
        //     `${LOG_CLASS_NAME}.${LOG_METHOD_NAME} appSettings received`
        // );
        // logger.info(
        //     `${LOG_CLASS_NAME}.${LOG_METHOD_NAME} before data requested`
        // );

        // return edgeFetch(`${apiUrls.EMAccountServiceUrl}/reference-types/${referenceRoute}`, {
        //     headers: {},
        //     appendAuthorization: true,
        //     method: 'GET'
        // }, request).then(data => {
        //     logger.info(`${LOG_CLASS_NAME}.${LOG_METHOD_NAME} data received`);
        //     return data;
        // });
        return null;
    }
}
