import { Get, Route } from '@wk/edge-services';

import { ApiResponse } from '../../../../shared/interfaces/api-response.model';
import { ReferenceTypeResponseModel } from '../state/reference-type.model';

@Route('reference-type-data')
export class ReferenceTypeDataService {
    @Get()
    async getReferenceTypeDetails(
        _referenceRoute: string
    ): Promise<ApiResponse<ReferenceTypeResponseModel>> {
        throw new Error('Not implemented');
    }
}
