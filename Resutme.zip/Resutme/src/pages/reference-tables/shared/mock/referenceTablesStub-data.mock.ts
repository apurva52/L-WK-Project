export const ReferenceTablesResponseData = {
    'totalRecordCount': 110,
    'page': 1,
    'pageSize': 100,
    'data': [{
        'referenceId': 1,
        'referenceDesc': 'Address Type - Entity',
        'isClientManaged': 'Y',
        'category': 'Addresses',
        'isDisplayForIgnite': 'Y',
        'referenceRoute': 'address-type-entity',
        'lastModifiedBy': '',
        'lastModifiedDate': '2022-01-01'
    }]
};

export const ReferenceTablesMappedResponseData = {
    'totalRecordCount': 110,
    'page': 1,
    'pageSize': 100,
    'data': [{
        'referenceId': 1,
        'referenceDesc': 'Address Type - Entity',
        'isClientManaged': 'Y',
        'category': 'Addresses',
        'isDisplayForIgnite': 'Y',
        'referenceRoute': 'address-type-entity',
        'lastModifiedBy': '-',
        'lastModifiedDate': 'January 1, 2022'
    }]
};