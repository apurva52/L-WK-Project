export enum NextMode {
    save = 'save',
    next = 'next'
}
