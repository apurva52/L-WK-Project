import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { of } from 'rxjs';

import { selectedRolesForMultiSelect } from '../../../../../../../../pages/users-and-roles/roles-management/state/role-management.selectors';
import { AccordionTypes } from '../../../../../../../../shared/interfaces/accordion-types-enum';
import { roleManagementReducer } from '../../../../../../roles-management/state/role-management.reducers';
import {
    ROLE_MANAGEMENT_FEATURE_KEY,
    RoleManagementState
} from '../../../../../../roles-management/state/role-management.state';

import { entitySelectorReducer } from './../../../../../../../../features/entity-selector/state/entity-selector.reducers';
import { getSelectedEntities } from './../../../../../../../../features/entity-selector/state/entity-selector.selectors';
import { ENTITY_SELECTOR_FEATURE_KEY } from './../../../../../../../../features/entity-selector/state/entity-selector.state';
import { mockSelectedEntities } from './../../../../../../../../features/entity-selector/stubs/selected-entities';
import { Step3AssociateEntitiesComponent } from './step-3-associate-entities.component';
describe('Step3AssociateEntitiesComponent', () => {
    let component: Step3AssociateEntitiesComponent;
    let fixture: ComponentFixture<Step3AssociateEntitiesComponent>;
    let store$: MockStore<RoleManagementState>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [Step3AssociateEntitiesComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [ROLE_MANAGEMENT_FEATURE_KEY]: roleManagementReducer,
                        [ENTITY_SELECTOR_FEATURE_KEY]: entitySelectorReducer
                    },
                    selectors: [
                        {
                            selector: getSelectedEntities,
                            value: mockSelectedEntities
                        },
                        {
                            selector: selectedRolesForMultiSelect([
                                { id: '1', label: 'Test', isSelected: true }
                            ]),
                            value: []
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store$ = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(Step3AssociateEntitiesComponent);
        component = fixture.componentInstance;
        component.userFullname = 'Unit Test';
        component.selectedRolesForm = new FormGroup({
            roles: new FormControl({ value: [], disabled: false }, [
                Validators.required
            ])
        });
        component.stepForm = new FormGroup({
            entityGroupsOfRoles: new FormGroup({}, [Validators.required])
        });
        spyOn(component['store$'], 'dispatch');
    });

    it('should create and load empty roles for multiselect', () => {
        spyOn(component['store$'], 'select').and.returnValue(of([]));
        fixture.detectChanges();
        expect(component).toBeTruthy();
        expect(component['store$'].dispatch).toHaveBeenCalled();
    });

    it('should create and load roles for multiselect', () => {
        spyOn(component['store$'], 'select').and.returnValue(
            of([{ id: '9', label: 'Affiliate', isSelected: true }])
        );
        fixture.detectChanges();
        expect(component).toBeTruthy();
        expect(component['store$'].dispatch).toHaveBeenCalled();
        expect(component.selectedRolesForm.value.roles).toBeDefined();
    });

    it('Should Deselect Roles based on the Cancel Action', () => {
        spyOn(component['store$'], 'select');
        component.selectedRolesForm.setValue({
            roles: [{ id: '9', label: 'Affiliate', isSelected: true }]
        });
        component.removeRoles('9');
        expect(component.selectedRolesForm.value.roles).toEqual([]);
        expect(component['store$'].select).toHaveBeenCalled();
    });

    it('Should change header type', () => {
        expect(component.getHeaderType(false)).toEqual(
            AccordionTypes.Collapsed
        );
        expect(component.getHeaderType(true)).toEqual(AccordionTypes.Expanded);
    });

    it('should map role', () => {
        const selectedItem = {
            id: '123',
            label: 'Item 1',
            isSelected: true
        };
        const testMapRole = component.mapRole(selectedItem);
        expect(testMapRole.role_name).toEqual(selectedItem.label);
    });

    it('Should emit toogle accordion action', () => {
        spyOn(component.changeSelectRole, 'emit');
        component.currentRole = {
            isCurrent: true,
            isSelected: true,
            id: '133',
            label: 'Role 1'
        };
        component.onToggleAccordion('133');
        component.onToggleAccordion('134');
        expect(component.changeSelectRole.emit).toHaveBeenCalled();
    });
    it('Should dispatch on clear all', () => {
        component.onClear();
        expect(component['store$'].dispatch).toHaveBeenCalled();
    });

    it('should get group of roles controls', () => {
        expect(component.entityGroupsOfRolesControls).toBeDefined();
    });
});
