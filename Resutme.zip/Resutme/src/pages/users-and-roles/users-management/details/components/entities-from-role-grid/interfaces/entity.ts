export interface Entity {
    entity_id?: number;
    entity_guid?: string;
    entity_name: string;
    entity_type?: string;
    entity_country: string;
    domestic_jurisdiction: string;
    foreign_jurisdiction?: string;
    domestic_jurisdiction_abbr?: string;
    active_foreign_jurisdictions_count?: number;
    total_foreign_jurisdictions_count?: number;
}
