import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ModalModel } from '@ct/platform-primitives-uicomponents/modals';
import { NotificationModel, NotificationType } from '@ct/platform-primitives-uicomponents/primitives';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';


import { AppState } from '../../../../../../app/state/app.state';
import { entitySelectBy } from '../../../../../../features/entity-selector/state/entity-selector.actions';
import { AddEntityModalModel } from '../../../interfaces/add-entity-modal.consts';
import { GridEntityGroup } from '../entities-from-role-grid/interfaces/entity-group';

@Component({
    selector: 'ct-add-entity-to-role-user-modal',
    templateUrl: './add-entity-to-role-user-modal.component.html',
    styleUrls: ['./add-entity-to-role-user-modal.component.scss']
})
export class AddEntityToRoleUserModalComponent implements OnInit {
    readonly NotificationType = NotificationType;
    @Input() isOpen: boolean = false;
    @Input() hasAllEntitiesGroup: boolean = false;
    @Output() onAddEntities: EventEmitter<Array<GridEntityGroup>> =
        new EventEmitter();
    @Output() closed: EventEmitter<void> = new EventEmitter();

    modalModel: ModalModel;
    addAllEntitiesControl: boolean = false;
    formGroup: FormGroup = new FormGroup({
        jurisdiction: new FormControl(null, {
            validators: [Validators.required]
        }),
        entityType: new FormControl(),
        entity: new FormControl(null, { validators: [Validators.required] }),
        entityGroup: new FormControl(null, {
            validators: [Validators.required]
        })
    });

    warningNotification: NotificationModel = {
        title: 'entitySelectorModule.addEntityFormComponent.warningNotification.title',
        content: 'entitySelectorModule.addEntityFormComponent.warningNotification.content',
        confirmationText: 'entitySelectorModule.addEntityFormComponent.warningNotification.confirmationText'
    };

    isNotificationVisible = false;

    constructor(
        private translate: TranslateService,
        private store$: Store<AppState>
    ) { }

    ngOnInit(): void {
        this.modalModel = AddEntityModalModel(this.translate);
        this.addAllEntitiesControl = this.hasAllEntitiesGroup;
        this.isNotificationVisible = this.hasAllEntitiesGroup;
    }

    addEntities($event: Array<GridEntityGroup>): void {
        this.onAddEntities.emit($event);
    }

    onCloseAddEntityModal(): void {
        this.closed.emit();
        this.store$.dispatch(entitySelectBy({ select: null }));
    }
    onAddAllEntitiesChanged(event): void {
        this.addAllEntitiesControl = event?.target?.checked;
    }
    closeNotification(): void {
        this.isNotificationVisible = false;
    }
}
