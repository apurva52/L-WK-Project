import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { getSelectedEntities } from 'src/features/entity-selector/state/entity-selector.selectors';
import {
    selectedRolesForMultiSelect,
    selectIsAddUserRoleModalVisible
} from 'src/pages/users-and-roles/roles-management/state/role-management.selectors';

import { Step2AssignRolesToUserComponent } from './step-2-assign-roles-to-user.component';
describe('Step2AssignRolesToUserComponent', () => {
    let component: Step2AssignRolesToUserComponent;
    let fixture: ComponentFixture<Step2AssignRolesToUserComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [Step2AssignRolesToUserComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    },
                    selectors: [
                        {
                            selector: selectIsAddUserRoleModalVisible,
                            value: true
                        },
                        {
                            selector: getSelectedEntities,
                            value: true
                        },
                        {
                            selector: selectedRolesForMultiSelect([
                                { id: '1', label: 'Test', isSelected: true }
                            ]),
                            value: []
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(Step2AssignRolesToUserComponent);
        component = fixture.componentInstance;
        component.userFullname = 'Unit Test';
        component.stepForm = new FormGroup({
            roles: new FormControl({ value: null, disabled: false }, [
                Validators.required
            ])
        });
        spyOn(component['store$'], 'dispatch');
    });

    it('should create and load empty roles for multiselect', () => {
        fixture.detectChanges();
        expect(component).toBeTruthy();
        expect(component['store$'].dispatch).toHaveBeenCalled();
    });

    xit('should create and load roles for multiselect', () => {
        component.stepForm.setValue({
            roles: [{ id: '9', label: 'Affiliate', isSelected: true }]
        });
        fixture.detectChanges();
        expect(component).toBeTruthy();
        expect(component['store$'].dispatch).toHaveBeenCalled();
        expect(component.stepForm.value.roles).toBeDefined();
    });

    xit('Should Deselect Roles based on the Cancel Action', () => {
        spyOn(component['store$'], 'select');
        component.stepForm.setValue({
            roles: [{ id: '9', label: 'Affiliate', isSelected: true }]
        });
        component.removeRoles('9');
        expect(component.stepForm.value.roles).toEqual([]);
        expect(component['store$'].select).toHaveBeenCalled();
    });
});
