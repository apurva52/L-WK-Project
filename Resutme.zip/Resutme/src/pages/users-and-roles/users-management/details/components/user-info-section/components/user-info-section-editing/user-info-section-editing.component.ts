import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ButtonType } from '@ct/platform-primitives-uicomponents/primitives';
import { RadioComboboxOption } from '@ct/platform-primitives-uicomponents/primitives/radio-combobox/interfaces/radio-combobox-options.interface';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';

import { UpdateUserRequest, UserStatus } from '../../../../../../../../pages/users-and-roles/users-management/state/user-management.state';
import { User } from '../../../../../interfaces/user.model';
import { userDetailsSection } from '../../../../details-user.config';

@Component({
    selector: 'ct-user-info-section-editing',
    templateUrl: './user-info-section-editing.component.html',
    styleUrls: ['./user-info-section-editing.component.scss']
})
export class UserInfoSectionEditingComponent implements OnInit, OnDestroy {

    readonly ButtonType = ButtonType;

    @Input() user: User;
    @Output() save: EventEmitter<UpdateUserRequest> = new EventEmitter();
    @Output() cancel: EventEmitter<void> = new EventEmitter();

    hasChangeInitialValues = false;
    initialUserInfo: any;

    selectedOption: RadioComboboxOption;
    userDetailsSection = userDetailsSection;
    form: FormGroup = new FormGroup({
        first_name: new FormControl('', [Validators.required]),
        last_name: new FormControl('', [Validators.required]),
        email_address: new FormControl('', [Validators.required, Validators.email]),
        job_title: new FormControl(''),
        company: new FormControl(''),
        status: new FormControl('')
    });

    controlOptions: Array<RadioComboboxOption> = [
        {
            label: this.translate.instant('userRolesModule.detailsComponent.active'),
            value: UserStatus.ACTIVE,
            checked: false,
            disabled: false
        },
        {
            label: this.translate.instant('userRolesModule.detailsComponent.inActive'),
            value: UserStatus.INACTIVE,
            checked: false,
            disabled: false
        }
    ];
    private destroyed$ = new Subject<boolean>();
    private readonly DEBOUNCE_TIME = 300;

    constructor(private translate: TranslateService) { }

    ngOnInit(): void {
        this.patchForm();
        this.subscribeToFormChanges();
        this.initialUserInfo = this.form.getRawValue();
    }

    getControl(controlName: string): FormControl {
        return this.form.get(controlName) as FormControl;
    }

    onChange(option: RadioComboboxOption): void {
        this.selectedOption = option;
        this.form.get('status').patchValue(option.value);
    }

    onSubmit(): void {
        this.save.emit(this.form.value);
    }

    ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private patchForm(): void {
        this.controlOptions.forEach( option => option.checked = option.value === this.user.status );
        this.form.patchValue({ ...this.user, status: this.user.status });
        if (this.controlOptions.find(option => option.checked)?.value === UserStatus.INACTIVE) {
            Object.keys(this.form.controls)
                .filter(key => key !== 'status')
                .forEach(key => this.form.get(key).disable());
        }
    }

    private subscribeToFormChanges(): void {
        this.form.valueChanges
            .pipe(debounceTime(this.DEBOUNCE_TIME), distinctUntilChanged(), takeUntil(this.destroyed$))
            .subscribe(formValues => {
                this.hasChangeInitialValues = Object.entries(this.initialUserInfo)
                    .some(([key, value]) => this.form.getRawValue()[key] !== value);
            });
    }
}
