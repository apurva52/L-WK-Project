// tslint:disable:max-file-line-count
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import {
    async,
    ComponentFixture,
    fakeAsync,
    TestBed,
    tick
} from '@angular/core/testing';
import { FormControl, Validators } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { AppState } from '../../../../../../app/state/app.state';
import { initialState } from '../../../state/user-management.reducers';
import { selectIsAddUserModalVisible } from '../../../state/user-management.selectors';
import { USER_MANAGEMENT_FEATURE_KEY } from '../../../state/user-management.state';

import { AddUserComponent } from './add-user.component';
import { Step1UserDetailsComponent } from './components/step-1-user-details/step-1-user-details.component';
import { NextMode } from './interfaces/next-mode.enum';

describe('AddUserComponent', () => {
    let component: AddUserComponent;
    let fixture: ComponentFixture<AddUserComponent>;
    let store$: MockStore<AppState>;
    let debugElement: DebugElement;

    const ADITIONAL_STEPS = 3;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [AddUserComponent, Step1UserDetailsComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [USER_MANAGEMENT_FEATURE_KEY]: initialState
                    },
                    selectors: [
                        { selector: selectIsAddUserModalVisible, value: true }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store$ = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AddUserComponent);
        debugElement = fixture.debugElement;
        component = fixture.componentInstance;

        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should navigate to previous step', () => {
        component.onNext();
        component.onPrevious();
        fixture.detectChanges();
        expect(component.activeStep).toEqual(0);
    });

    it('should navigate to next step', () => {
        component.onNext();
        fixture.detectChanges();
        expect(component.activeStep).toEqual(1);
    });

    it('should navigate to last step', () => {
        component.newUserStepsPayload = [
            {
                isActive: true,
                isFailed: false,
                isVisited: true,
                stepId: 1,
                description: 'test'
            }
        ];
        component.rolesInView = [
            {
                id: '132',
                isCurrent: true,
                isSelected: true,
                label: 'Role 1'
            },
            {
                id: '133',
                isCurrent: false,
                isSelected: true,
                label: 'Role 2'
            }
        ];

        component.onNext();
        fixture.detectChanges();
        expect(component.isInlastStep).toEqual(true);
    });

    it('should get child form from state', () => {
        expect(component.getStepForm(0)).toBeDefined();
    });

    it('should get User fullname', () => {
        component.getStepForm(0).patchValue({
            first_name: 'Unit',
            last_name: 'Test'
        });
        expect(component.userFullname).toEqual('Unit Test');
    });

    it('should validate if current form is valid', () => {
        component.setStep(0);
        component.getStepForm(0).patchValue({
            first_name: 'Unit',
            last_name: 'Test',
            email_address: 'unit@test.com'
        });
        expect(component.isCurrentFormValid).toBeTruthy();
    });

    it('should close wizard modal', () => {
        spyOn(component['store$'], 'dispatch');
        component.closeWizardModal();
        expect(component['store$'].dispatch).toHaveBeenCalled();
    });

    xit('should launch modal confirmation for cancel action', fakeAsync(() => {
        const cancelBtn: HTMLElement = debugElement.nativeElement.querySelector(
            'button#cancel-wizard'
        );
        const closeBtn: HTMLElement = debugElement.nativeElement.querySelector(
            'span.wk-icon-filled-close'
        );

        cancelBtn.click();
        tick();

        fixture.whenStable().then(() => {
            expect(component.isCancelNotificationVisible).toEqual(true);
        });

        component.isCancelNotificationVisible = false;
        closeBtn.click();
        tick();

        fixture.whenStable().then(() => {
            expect(component.isCancelNotificationVisible).toEqual(true);
        });
    }));

    it('should navigate switch to Save mode', () => {
        const mockRole = {
            id: '132',
            isCurrent: true,
            isSelected: true,
            label: 'Role 1'
        };
        component.newUserStepsPayload = [
            {
                isActive: true,
                isFailed: false,
                isVisited: true,
                stepId: 2,
                description: 'test'
            }
        ];

        component.getStepForm(1).get('roles').patchValue([mockRole]);

        fixture.detectChanges();
        expect(component.mode).toEqual('save');
    });

    it('should change current role', () => {
        const mockRoles = [
            {
                id: '132',
                isCurrent: true,
                isSelected: true,
                label: 'Role 1'
            },
            {
                id: '133',
                isCurrent: false,
                isSelected: true,
                label: 'Role 2'
            },
            {
                id: '134',
                isCurrent: false,
                isSelected: true,
                label: 'Role 3'
            }
        ];
        component.newUserStepsPayload = [
            {
                isActive: true,
                isFailed: false,
                isVisited: true,
                stepId: 2,
                description: 'test'
            }
        ];

        component
            .getStepForm(1)
            .get('roles')
            .patchValue([mockRoles], { emitEvent: true });
        component.rolesInView = mockRoles;
        fixture.detectChanges();
        component.onChangeSelectedRole('133');
        expect(component.currentSelectedRole).toEqual(mockRoles[1]);
    });

    it('should move backward', () => {
        const mockRoles = [
            {
                id: '132',
                isCurrent: false,
                isSelected: true,
                label: 'Role 1'
            },
            {
                id: '133',
                isCurrent: false,
                isSelected: true,
                label: 'Role 2'
            },
            {
                id: '134',
                isCurrent: true,
                isSelected: true,
                label: 'Role 3'
            }
        ];
        component.newUserStepsPayload = [
            {
                isActive: true,
                isFailed: false,
                isVisited: true,
                stepId: 2,
                description: 'test'
            }
        ];

        component.rolesInView = mockRoles;
        component.aditionalStep = ADITIONAL_STEPS;

        fixture.detectChanges();
        component['moveBackward']();
        expect(component.currentSelectedRole).toEqual(mockRoles[1]);
    });

    it('navigate previous', () => {
        const mockRoles = [
            {
                id: '132',
                isCurrent: false,
                isSelected: true,
                label: 'Role 1'
            },
            {
                id: '133',
                isCurrent: false,
                isSelected: true,
                label: 'Role 2'
            },
            {
                id: '134',
                isCurrent: true,
                isSelected: true,
                label: 'Role 3'
            }
        ];
        component.newUserStepsPayload = [
            {
                isActive: true,
                isFailed: false,
                isVisited: true,
                stepId: 2,
                description: 'test'
            }
        ];

        component.rolesInView = mockRoles;
        component.aditionalStep = ADITIONAL_STEPS;

        component.newUserStepsPayload = [
            {
                isActive: false,
                isFailed: false,
                isVisited: true,
                stepId: 1,
                description: 'test'
            },
            {
                isActive: true,
                isFailed: false,
                isVisited: true,
                stepId: 2,
                description: 'test 2'
            }
        ];

        fixture.detectChanges();
        component.onPrevious();
        expect(component.activeStep).toBe(1);
    });

    it('should change configuration', () => {
        component.totalAditionalSteps = ADITIONAL_STEPS;
        component.mode = NextMode.save;
        component.entityGroupsOfRoles.addControl(
            '123',
            new FormControl('', [Validators.required])
        );
        fixture.detectChanges();

        component['updateConfiguration']();
        expect(component.mode).toBe(NextMode.next);
    });
    it('should save', () => {
        const spy = spyOn(store$, 'dispatch').and.callThrough();
        component['save']();
        expect(spy).toHaveBeenCalled();
    });
    it('should dismiss confirmation message', () => {
        component.isCancelNotificationVisible = true;
        component.cancelConfirmation();
        expect(component.isCancelNotificationVisible).toBeFalsy();
    });

});
