import { Component, Input } from '@angular/core';
import { RoleAssignedToUser } from 'src/shared/interfaces/roles-assigned-to-user.response';

import { userRolesModuleSection } from '../../../../details-user.config';

@Component({
    selector: 'ct-internal-customer-role-info',
    templateUrl: './internal-customer-role-info.component.html',
    styleUrls: ['./internal-customer-role-info.component.scss']
})
export class InternalCustomerRoleInfoComponent {
    @Input() role: RoleAssignedToUser;
    userRolesModule = userRolesModuleSection;
}
