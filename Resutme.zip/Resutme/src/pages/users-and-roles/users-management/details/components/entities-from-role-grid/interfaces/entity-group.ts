import { Entity } from './entity';

export interface EntityGroup {
    entity_group_id?: number;
    edh_entity_group_id: number;
    edh_entity_group_guid: string;
    edh_entity_group_name: string;
    edh_entity_group_type: 'I' | 'C';
    entity_type?: string;
    entity_status?: string;
    jurisdiction?: string;
    entities?: Array<Entity>;
}

export interface GridEntityGroup extends EntityGroup {
    isAllEntitiesGroup?: boolean;
}

export interface NestedEntityGroup {
    roleId: number;
    entityGroup: EntityGroup;
}
