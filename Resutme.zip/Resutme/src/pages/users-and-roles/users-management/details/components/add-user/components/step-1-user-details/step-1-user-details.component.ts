import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';

import { StepComponent } from '../../interfaces/step-component.model';

@Component({
    selector: 'ct-step-1-user-details',
    templateUrl: './step-1-user-details.component.html',
    styleUrls: ['./step-1-user-details.component.scss']
})
export class Step1UserDetailsComponent extends StepComponent {
    @Input() stepForm: FormGroup;

    constructor(public store$: Store) {
        super();
    }
}
