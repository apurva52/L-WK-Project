// tslint:disable max-file-line-count
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import {
    ModalModel,
    ScreenSizeEnum,
    WizardConfiguration
} from '@ct/platform-primitives-uicomponents/modals';
import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { Observable, of, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { clearSelectedEntities } from '../../../../../../features/entity-selector/state/entity-selector.actions';
import { userAddUserModalAction } from '../../../state/user-management.actions';
import {
    savingUserState,
    selectIsAddUserModalVisible
} from '../../../state/user-management.selectors';

import {
    userManagementSaveAction,
    userManagementSaveSuccessAction
} from './../../../state/user-management.actions';
import * as configComponent from './add-user.config';
import { InputMultiSelectRole } from './interfaces/input-multiselect-role.interface';
import { NextMode } from './interfaces/next-mode.enum';

@Component({
    selector: 'ct-add-user',
    templateUrl: './add-user.component.html',
    styleUrls: ['./add-user.component.scss']
})
export class AddUserComponent implements OnInit {
    get activeStep(): number {
        return this.newUserStepsPayload.findIndex((step) => step.isActive) || 0;
    }

    get activeStepId(): number {
        return (
            this.newUserStepsPayload.find((step) => step.isActive)?.stepId || 0
        );
    }

    get isInlastStep(): boolean {
        return this.activeStep === this.newUserStepsPayload.length - 1;
    }

    get userFullname(): string {
        const { first_name, last_name } = this.getStepForm(0).value;
        return `${first_name} ${last_name}`.trim();
    }

    get isCurrentFormValid(): boolean {
        return this.getStepForm(this.activeStep)?.valid;
    }

    get entityGroupsOfRoles(): FormGroup {
        return this.getStepForm(2).get('entityGroupsOfRoles') as FormGroup;
    }

    get isReadyToSave(): boolean {
        return this.form.valid;
    }

    get isAllowedMoveForward(): boolean {
        return (
            this.isReadyToSave ||
            this.entityGroupsOfRoles.get(this.currentSelectedRole.id)?.valid
        );
    }

    get currentSelectedRole(): InputMultiSelectRole {
        return this.rolesInView.find((role) => role.isCurrent);
    }

    get isNotActiveStepScrollable(): boolean {
        return this.notScrollableStepIds.includes(this.activeStepId);
    }

    readonly ScreenSizeEnum = ScreenSizeEnum;

    @Output() userCreated = new EventEmitter<void>();

    _moveForward = false;
    isAddUserModalVisible$ = this.store$.select(selectIsAddUserModalVisible);
    wizardConfig$: Observable<WizardConfiguration>;
    isFormValid: boolean = false;
    isCancelNotificationVisible: boolean = false;
    mode: NextMode = NextMode.next;
    headerText: string = '';
    newUserStepsPayload = configComponent.getNewUserStepsPayload();
    hasOverlayClickClose: boolean = false;
    btnsVisible: boolean = true;
    totalAditionalSteps: number = 0;
    aditionalStep: number = 1;
    currentRoleId: string = '';
    rolesInView: Array<InputMultiSelectRole> = [];

    notScrollableStepIds: Array<number> = [2];

    confirmModalModel: ModalModel = {
        title: 'userRolesModule.newUserComponent.cancelConfirmModal.title',
        cancelText:
            'userRolesModule.newUserComponent.cancelConfirmModal.cancelBtn',
        confirmText:
            'userRolesModule.newUserComponent.cancelConfirmModal.confirmBtn',
        modalType: ScreenSizeEnum.large
    };

    form: FormArray = new FormArray([
        new FormGroup({
            first_name: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            last_name: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            email_address: new FormControl({ value: '', disabled: false }, [
                Validators.required,
                Validators.email
            ]),
            job_title: new FormControl({ value: '', disabled: false }),
            department: new FormControl({ value: '', disabled: false }),
            company: new FormControl({ value: '', disabled: false }),
            account_id: new FormControl({ value: '', disabled: false })
        }),
        new FormGroup({
            roles: new FormControl({ value: [], disabled: false }, [
                Validators.required
            ])
        }),
        new FormGroup({
            entityGroupsOfRoles: new FormGroup({}, [Validators.required])
        })
    ]);

    savingUser$: Observable<boolean> = this.store$.select(savingUserState);

    private _destroyed$ = new Subject<boolean>();

    constructor(
        private store$: Store,
        private translate: TranslateService,
        private actionsListener$: ActionsSubject
    ) {}

    ngOnInit(): void {
        this.wizardConfig$ = of(
            configComponent.setWizardConfig(this.translate)
        );
        this.actionsListener$
            .pipe(
                ofType(userManagementSaveSuccessAction),
                takeUntil(this._destroyed$)
            )
            .subscribe(() => {
                this.userCreated.emit();
                this.store$.dispatch(userAddUserModalAction({ value: false }));
            });
        this.getStepForm(0)
            .valueChanges.pipe(takeUntil(this._destroyed$))
            .subscribe((data) => {
                if (
                    Object.keys(data)
                        .filter((key) => key !== 'account_id')
                        .every((key) => !data[key])
                ) {
                    this.getStepForm(0).markAsPristine();
                }
            });
        this.subscribeRoleChanges();
        this.subscribeAssignEntitiesChanges();
    }

    ngOnDestroy(): void {
        this._destroyed$.next();
        this._destroyed$.complete();
    }

    getStepForm(index: number): FormGroup {
        return this.form.at(index) as FormGroup;
    }

    setStep(index: number): void {
        this.newUserStepsPayload.forEach((step, i) => {
            step.isActive = i === index;
            step.isVisited = i < index;
        });
    }

    onPrevious(): void {
        if (!this.isInlastStep) {
            this.setStep(this.activeStep - 1);
        } else {
            this.aditionalStep === 1
                ? this.setStep(this.activeStep - 1)
                : this.moveBackward();
        }
    }

    onNext(): void {
        if (!this.isInlastStep) {
            this.setStep(this.activeStep + 1);
        } else {
            this.mode === NextMode.save ? this.save() : this.moveForward();
        }
    }

    closeWizardModal(): void {
        this.setStep(0);
        this.store$.dispatch(clearSelectedEntities());
        this.store$.dispatch(userAddUserModalAction({ value: false }));
    }

    onChangeSelectedRole($event: string): void {
        this.rolesInView.forEach((role, index) => {
            const isCurrent = role.id === $event;
            role.isCurrent = isCurrent;
            this.aditionalStep = isCurrent ? index + 1 : this.aditionalStep;
        });
    }

    cancelConfirmation(): void {
        this.isCancelNotificationVisible = false;
    }

    private subscribeRoleChanges(): void {
        this.getStepForm(1)
            .get('roles')
            .valueChanges.pipe(takeUntil(this._destroyed$))
            .subscribe((roles) => {
                if (roles) {
                    roles.forEach((role) => {
                        if (!this.entityGroupsOfRoles.contains(role.id)) {
                            this.entityGroupsOfRoles.addControl(
                                role.id,
                                new FormControl('', {
                                    validators: Validators.required
                                })
                            );
                        }
                    });

                    Object.keys(this.entityGroupsOfRoles.controls).forEach(
                        (key) => {
                            if (!roles.some((role) => role.id === key)) {
                                this.entityGroupsOfRoles.removeControl(key);
                            }
                        }
                    );
                }
                this.totalAditionalSteps = roles ? roles.length : 0;
                this.rolesInView = this.mapRoles(roles);
                this.updateConfiguration();
            });
    }

    private subscribeAssignEntitiesChanges(): void {
        this.entityGroupsOfRoles.valueChanges
            .pipe(takeUntil(this._destroyed$))
            .subscribe((entityGroups) => {
                this.isInlastStep && this.updateConfiguration();
            });
    }

    private mapRoles(
        roles: Array<InputMultiselectItem>
    ): Array<InputMultiSelectRole> {
        return roles.map((role, index) => ({
            ...role,
            isCurrent: index === 0
        }));
    }

    private updateConfiguration(): void {
        if (
            (this.mode === NextMode.next && this.totalAditionalSteps === 1) ||
            (this.mode === NextMode.next && this.entityGroupsOfRoles.valid)
        ) {
            this.wizardConfig$ = of(
                configComponent.setWizardConfig(this.translate, true)
            );
            this.mode = NextMode.save;
        }
        if (
            this.mode === NextMode.save &&
            this.totalAditionalSteps > 1 &&
            this.entityGroupsOfRoles.invalid
        ) {
            this.wizardConfig$ = of(
                configComponent.setWizardConfig(this.translate, false)
            );
            this.mode = NextMode.next;
        }
    }

    private save(): void {
        const { value: user } = this.getStepForm(0);
        const { entityGroupsOfRoles } = this.getStepForm(2).value;
        this.store$.dispatch(
            userManagementSaveAction({
                user,
                entityGroupsOfRoles
            })
        );
    }

    private moveForward(): void {
        if (this.aditionalStep === this.totalAditionalSteps) {
            return;
        }
        this.rolesInView.forEach(
            (role, index) => (role.isCurrent = index === this.aditionalStep)
        );
        ++this.aditionalStep;
    }

    private moveBackward(): void {
        if (this.aditionalStep === 1) {
            return;
        }
        this.rolesInView.forEach(
            (role, index) =>
                (role.isCurrent = index + 1 === this.aditionalStep - 1)
        );
        --this.aditionalStep;
    }
}
