export interface Step2AssignRolesToUser {
    roles: Array<string>;
}
