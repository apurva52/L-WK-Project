import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { initialState } from '../../../../../../features/entity-selector/state/entity-selector.reducers';
import { ENTITY_SELECTOR_FEATURE_KEY } from '../../../../../../features/entity-selector/state/entity-selector.state';

import { AddEntityToRoleUserModalComponent } from './add-entity-to-role-user-modal.component';

describe('AddEntityToRoleUserModalComponent', () => {
    let component: AddEntityToRoleUserModalComponent;
    let fixture: ComponentFixture<AddEntityToRoleUserModalComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [AddEntityToRoleUserModalComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [ENTITY_SELECTOR_FEATURE_KEY]: initialState
                    }
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AddEntityToRoleUserModalComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should add Entities', () => {
        spyOn(component.onAddEntities, 'emit');
        component.addEntities([]);
        expect(component.onAddEntities.emit).toHaveBeenCalled();
    });

    it('should call onAddAllEntitiesChanged', () => {
        const allEntityBoolean = true;
        component.onAddAllEntitiesChanged({ target: { checked: allEntityBoolean } });
        expect(component.addAllEntitiesControl).toEqual(allEntityBoolean);
    });

    it('should close add Entity modal', () => {
        spyOn(component.closed, 'emit');
        spyOn(component['store$'], 'dispatch');
        component.onCloseAddEntityModal();
        expect(component.closed.emit).toHaveBeenCalled();
        expect(component['store$'].dispatch).toHaveBeenCalled();
    });
    it('should show notification', () => {
        component.hasAllEntitiesGroup = true;
        component.ngOnInit();
        expect(component.isNotificationVisible).toBeTruthy();
    });
    it('should hide notification', () => {
        component.isNotificationVisible = true;
        component.closeNotification();
        expect(component.isNotificationVisible).toBeFalsy();
    });
});
