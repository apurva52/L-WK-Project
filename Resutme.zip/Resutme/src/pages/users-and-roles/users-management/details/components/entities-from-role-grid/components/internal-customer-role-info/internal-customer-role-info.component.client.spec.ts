import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { TranslateModule } from '@ngx-translate/core';

import { RoleAssignedToUser } from '../../../../../../../../shared/interfaces/roles-assigned-to-user.response';
import { DefaultTextPipe } from '../../../../../../../../shared/pipes/default-text.pipe';

import { InternalCustomerRoleInfoComponent } from './internal-customer-role-info.component';

describe('InternalCustomerRoleInfoComponent', () => {
    let component: InternalCustomerRoleInfoComponent;
    let fixture: ComponentFixture<InternalCustomerRoleInfoComponent>;

    const mockedRole: RoleAssignedToUser = {
        created_by: '',
        created_by_name: '',
        created_date: '',
        last_modified_by: '',
        last_modified_by_name: '',
        last_modified_date: '',
        role_color: '',
        role_id: 1,
        role_name: '',
        role_property: '',
        role_type: '',
        sf_account_id: '123',
        sf_account_name: '',
        sf_assigned_by_account_id: '123',
        sf_assigned_by_account_name: ''
    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [InternalCustomerRoleInfoComponent, DefaultTextPipe],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(InternalCustomerRoleInfoComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        component.role = mockedRole;
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });
});
