import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';

export interface InputMultiselectItemExtended extends InputMultiselectItem {
    role_name: string;
}
