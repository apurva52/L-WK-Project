import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { Step1UserDetailsComponent } from './step-1-user-details.component';

describe('Step1UserDetailsComponent', () => {
    let component: Step1UserDetailsComponent;
    let fixture: ComponentFixture<Step1UserDetailsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [Step1UserDetailsComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    }
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(Step1UserDetailsComponent);
        component = fixture.componentInstance;
        component.stepForm = new FormGroup({
            firstName: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            lastName: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            email: new FormControl({ value: '', disabled: false }, [
                Validators.required,
                Validators.email
            ]),
            jobTitle: new FormControl({ value: '', disabled: false }),
            department: new FormControl({ value: '', disabled: false }),
            company: new FormControl({ value: '', disabled: false })
        });
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('form should be reset', () => {
        spyOn(component.stepForm, 'reset');
        component['resetForm']();
        expect(component.stepForm.reset).toHaveBeenCalled();
    });
});
