import { Component, ElementRef, Input, ViewChild } from '@angular/core';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { ContactUser } from 'src/app/state/app.state';
import { selectAccountMembers } from 'src/pages/users-and-roles/users-management/state/user-management.selectors';
import { AccountMembersResponse } from 'src/pages/users-and-roles/users-management/state/user-management.state';
import { SortPipe } from 'src/shared/pipes/sort/sort.pipe';
import { generateUUID } from 'src/shared/util';

@Component({
    selector: 'ct-internal-customer-role-info-account-members',
    templateUrl: './internal-customer-role-info-am.component.html',
    styleUrls: ['./internal-customer-role-info-am.component.scss']
})
export class InternalCustomerRoleInfoAccountMembersComponent {
    get buttonId(): string {
        return `buttonDropdown${this.id}`;
    }
    @Input() set sf_account_id(value: string) {
        this._sf_account_id = value;
        this.store$.select(selectAccountMembers).subscribe((accountMembers) => {
            if (accountMembers) this.getCustomerAccountDetails(accountMembers);
        });
    }
    id = generateUUID();
    isOpen: boolean = false;
    isDisabled: boolean = false;
    isContactsEmpty = false;
    filterQuery: string = '';
    selectedContact: ContactUser;
    firstMember: ContactUser;
    secondMember: ContactUser;
    contacts: Array<ContactUser>;
    loadingMembers = true;

    plusMoreText: string = '';
    labelContactsText: string = '';
    contactDropdownWidth: number;
    @ViewChild('contactDropdown', { static: true }) contactDropdown: ElementRef;
    _sf_account_id: string = '';
    constructor(
        private sortPipe: SortPipe,
        private store$: Store,
        private translate: TranslateService
    ) {}
    sortContacts(contacts: Array<ContactUser>): Array<ContactUser> {
        if (contacts) {
            const [...contactUsers] = contacts;
            const sortedContactUsers = this.sortPipe.transform(
                contactUsers,
                'sf_contact_name',
                'asc'
            );
            return [...sortedContactUsers];
        }
        return [];
    }

    toggle(isOpen: boolean): void {
        if (isOpen) {
            this.contactDropdownWidth =
                this.contactDropdown.nativeElement.clientWidth;
        }
        if (this.isOpen !== isOpen) {
            this.isOpen = isOpen;
        }
    }
    getCustomerAccountDetails(
        accountMembers: Record<string, AccountMembersResponse>
    ): void {
        if (accountMembers) {
            this.loadingMembers =
                accountMembers[this._sf_account_id]?.isLoading;
            const contacts = this.sortContacts(
                accountMembers[this._sf_account_id]?.contacts
            );
            this.isContactsEmpty = !contacts.length;
            this.firstMember = contacts.shift() ?? null;
            this.secondMember = contacts.shift() ?? null;
            this.labelContactsText = [
                this.firstMember?.sf_contact_name ?? '--',
                this.secondMember?.sf_contact_name ?? '--'
            ].join(', ');
            this.contacts = contacts;
            this.plusMoreText = `+${contacts.length} ${this.translate.instant(
                'userRolesModule.detailsComponent.moreText'
            )}`;
        }
    }
}
