import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';
import { Store } from '@ngrx/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { clearRoleSelectedEntities } from '../../../../../../../../features/entity-selector/state/entity-selector.actions';
import { AccordionTypes } from '../../../../../../../../shared/interfaces/accordion-types-enum';
import { roleManagementInitiateAction } from '../../../../../../roles-management/state/role-management.actions';
import { selectedRolesForMultiSelect } from '../../../../../../roles-management/state/role-management.selectors';
import { ROLES_PAGE_SIZE } from '../../../../../../roles-management/state/role-management.state';
import { InputMultiSelectRole } from '../../interfaces/input-multiselect-role.interface';
import { StepComponent } from '../../interfaces/step-component.model';

import { SelectedEntities } from './../../../../../../../../features/entity-selector/interfaces/selected-entities';
import { clearSelectedEntities } from './../../../../../../../../features/entity-selector/state/entity-selector.actions';
import { getSelectedEntities } from './../../../../../../../../features/entity-selector/state/entity-selector.selectors';
import { InputMultiselectItemExtended } from './step-3-associate-entities.config';

@Component({
    selector: 'ct-step-3-associate-entities',
    templateUrl: './step-3-associate-entities.component.html',
    styleUrls: ['./step-3-associate-entities.component.scss']
})
export class Step3AssociateEntitiesComponent
    extends StepComponent
    implements OnInit
{
    @Input() stepForm: FormGroup;
    @Input() selectedRolesForm: FormGroup;
    @Input() userFullname: string;

    @Output() changeSelectRole: EventEmitter<string> = new EventEmitter();

    rolesForMultiSelect$: Observable<Array<InputMultiselectItem>>;
    selectedEntities$: Observable<SelectedEntities> =
        this.store$.select(getSelectedEntities);

    private _currentRole: InputMultiSelectRole;
    private _destroyed$ = new Subject<boolean>();

    constructor(private store$: Store) {
        super();
    }

    get rolesControl(): FormControl {
        return this.selectedRolesForm.get('roles') as FormControl;
    }

    get rolesDataForMultiselect(): Array<InputMultiselectItem> {
        return this.rolesControl?.value;
    }

    get entityGroupsOfRolesControls(): FormGroup {
        return this.stepForm.get('entityGroupsOfRoles') as FormGroup;
    }

    @Input()
    set currentRole(role: InputMultiSelectRole) {
        this._currentRole = role;
    }
    get currentRole(): InputMultiSelectRole {
        return this._currentRole;
    }

    ngOnInit(): void {
        this.updateRolesSelector();
        this.loadRoles();
        this.selectedEntities$
            .pipe(takeUntil(this._destroyed$))
            .subscribe((entityGroupsOfRoles) => {
                this.stepForm.patchValue({ entityGroupsOfRoles });
            });
    }

    ngOnDestroy(): void {
        this._destroyed$.next();
        this._destroyed$.complete();
    }

    loadRoles(pageNumber: number = 1): void {
        this.store$.dispatch(
            roleManagementInitiateAction({
                pageNumber,
                controlId: '',
                pageSize: ROLES_PAGE_SIZE
            })
        );
    }

    removeRoles(id: string): void {
        const roles = this.selectedRolesForm.value.roles.filter(
            (roles) => roles.id != id
        );
        this.selectedRolesForm.patchValue({ roles });
        this.store$.dispatch(clearRoleSelectedEntities({ role: id }));
        this.updateRolesSelector();
    }

    mapRole(role: InputMultiselectItem): InputMultiselectItemExtended {
        return { ...role, role_name: role.label };
    }

    getHeaderType(isFirst: boolean): string {
        return isFirst ? AccordionTypes.Expanded : AccordionTypes.Collapsed;
    }

    onClear(): void {
        this.store$.dispatch(clearSelectedEntities());
    }

    onToggleAccordion(id: string): void {
        if (this.currentRole.id === id) {
            return;
        }
        this.changeSelectRole.emit(id);
    }

    private updateRolesSelector(): void {
        this.rolesForMultiSelect$ = this.store$.select(
            selectedRolesForMultiSelect(this.rolesDataForMultiselect || [])
        );
    }
}
