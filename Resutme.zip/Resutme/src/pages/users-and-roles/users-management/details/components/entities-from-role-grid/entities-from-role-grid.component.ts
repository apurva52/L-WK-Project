/* tslint:disable max-file-line-count */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SelectedEvent } from '@ct/platform-common-uicomponents/entities-grids/shared/interfaces/selected-event.interface';
import { ModalModel } from '@ct/platform-primitives-uicomponents/modals';
import { NotificationType } from '@ct/platform-primitives-uicomponents/primitives';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { filter, take } from 'rxjs/operators';

import { AppState } from '../../../../../../app/state/app.state';
import { AccordionTypes } from '../../../../../../shared/interfaces/accordion-types-enum';
import { RoleAssignedToUser } from '../../../../../../shared/interfaces/roles-assigned-to-user.response';
import {
    roleManagementUsersRoleEntitiesAssignAction,
    roleManagementUsersRoleEntitiesAssignFailureAction,
    roleManagementUsersRoleEntitiesAssignSuccessAction
} from '../../../../roles-management/state/role-management.actions';
import {
    removeUserRoleAssignmentEntitiesAction,
    removeUserRoleAssignmentEntitiesFailureAction,
    removeUserRoleAssignmentEntitiesSuccessAction,
    UnAssignRoleFromUser,
    UnAssignRoleFromUserSuccessAction,
    userGetRolesAssignedToUser,
    userManagementLoadRoleEntitiesAction,
    userManagementLoadRoleEntitiesFailureAction,
    userManagementLoadRoleEntitiesSuccessAction
} from '../../../state/user-management.actions';
import * as selectors from '../../../state/user-management.selectors';

import { EntityGroup } from './interfaces/entity-group';


@Component({
    selector: 'ct-entities-from-role-grid',
    templateUrl: './entities-from-role-grid.component.html',
    styleUrls: ['./entities-from-role-grid.component.scss']
})
export class EntitiesFromRoleGridComponent implements OnInit {
    readonly NotificationType = NotificationType;

    @Input() editDisabled: boolean;
    @Input() deleteDisabled: boolean;
    @Input() editVisible: boolean = true;
    @Input() deleteVisible: boolean = true;
    @Input() sfUserId: string;
    @Input() role: RoleAssignedToUser;
    @Input() isViewOnly: boolean = false;
    @Input()
    set isAccordionOpened(value: boolean) {
        this._isAccordionOpened = value;
        this.updateHeaderType();
        if (value) {
            setTimeout(() => this.loadEntitiesGridData());
        }
    }
    get isAccordionOpened(): boolean {
        return this._isAccordionOpened;
    }
    @Input() displayEntities: boolean = true;
    @Input() displayModulesGrid: boolean = false;
    @Input() displayExport: boolean = true;
    @Input() isInternalCustomerRole: boolean;
    @Input()
    set isUserInactive(value: boolean) {
        this._isUserInactive = value;
        this.onCancelRemoveEntityItemsNotification();
    }
    get isUserInactive(): boolean {
        return this._isUserInactive;
    }

    get accordionType(): AccordionTypes {
        return this.isAccordionOpened ? AccordionTypes.Expanded : AccordionTypes.Disabled;
    }

    @Output() export: EventEmitter<MouseEvent> = new EventEmitter();
    @Output() accordionToggle: EventEmitter<boolean> = new EventEmitter<boolean>();
    headerType: string = AccordionTypes.Collapsed;
    isAddEntityModalOpen: boolean;
    role_length: number;
    isRemoveWarningVisible: boolean;
    entitiesGridData: Array<EntityGroup> = [];
    entitiesGridLoading = false;
    checkedEntityItems = [];
    isRemoveEntityItemsNotificationVisible = false;
    hasAllEntities = false;
    selectUserRolesLoaded$ = this.store$.select(
        selectors.selectUserRolesLoaded
    );
    modalModel: ModalModel = {
        title: 'userRolesModule.DeleteRoleComponent.title',
        cancelText: 'userRolesModule.DeleteRoleComponent.cancelButton',
        confirmText: 'userRolesModule.DeleteRoleComponent.confirmButton'
    };
    removeEntityItemsNotificationModel = {
        title: this.translate.instant('entitiesGrid.unassignEntityWarning.title'),
        content: this.translate.instant('entitiesGrid.unassignEntityWarning.content'),
        confirmationText: this.translate.instant('entitiesGrid.unassignEntityWarning.confirmationText'),
        cancelationText: this.translate.instant('entitiesGrid.unassignEntityWarning.cancelationText')
    };
    bulkOptions = [
        {
            name: this.translate.instant('entitiesGrid.unassignActionButtonLabel'),
            icon: 'wk-icon-trash',
            handler: () => this.isRemoveEntityItemsNotificationVisible = true,
            action: () => this.isRemoveEntityItemsNotificationVisible = true
        }
    ];

    private _entitiesDataLoaded = false;
    private _isAccordionOpened = false;
    private _isUserInactive = false;

    constructor(
        private store$: Store<AppState>,
        private actionsListener$: ActionsSubject,
        private route: ActivatedRoute,
        public router: Router,
        private translate: TranslateService
    ) { }

    ngOnInit(): any {
        this.selectUserRolesLoaded$.subscribe((res: any) => {
            this.role_length = res.length;
            if (res.length > 1) {
                this.modalModel.title = 'userRolesModule.DeleteRoleComponent.title';
                this.modalModel.cancelText = 'userRolesModule.DeleteRoleComponent.cancelButton';
                this.modalModel.confirmText = 'userRolesModule.DeleteRoleComponent.confirmButton';
            }
            if (res.length == 1) {
                if (this.modalModel.hasOwnProperty('cancelText')) {
                    delete this.modalModel.cancelText;
                }
                this.modalModel.title = 'entitiesGrid.WarningTitle';
                this.modalModel.confirmText = 'entitiesGrid.OkButton';
            }
        });
    }

    onToggleAccordion(): void {
        this.isAccordionOpened = !this.isAccordionOpened;
        this.accordionToggle.emit(this.isAccordionOpened);
    }

    onAddEntityToRoleUserModalToggle(value: boolean): void {
        this.hasAllEntities = this.entitiesGridData.some(group => group.edh_entity_group_id === -1 && group.edh_entity_group_type === 'I');
        this.isAddEntityModalOpen = value;
    }

    onAddEntities(data: Array<EntityGroup>): void {
        const implicitGroup = data.find(group => group.edh_entity_group_type === 'I' && group.edh_entity_group_id < 0);
        const existedImplicitGroup = this.entitiesGridData.find(group => group.edh_entity_group_type === 'I');
        const uniqueNewGroups = data.filter(group =>
            !this.entitiesGridData.find(entityGroup => group.edh_entity_group_guid === entityGroup.edh_entity_group_guid)
        );
        if (implicitGroup) {
            if (existedImplicitGroup) {
                implicitGroup.edh_entity_group_guid = existedImplicitGroup.edh_entity_group_guid;
                implicitGroup.edh_entity_group_id = existedImplicitGroup.edh_entity_group_id;
                implicitGroup.edh_entity_group_name = existedImplicitGroup.edh_entity_group_name;
                implicitGroup.entities = implicitGroup.entities?.filter(entity =>
                    !existedImplicitGroup.entities?.find( existedEntity => existedEntity.entity_id === entity.entity_id)
                );
            }
            this.addUserRoleEntityGroupAssignment([implicitGroup]);
        } else if (uniqueNewGroups.length) {
            this.addUserRoleEntityGroupAssignment(uniqueNewGroups);
        }
        this.onAddEntityToRoleUserModalToggle(false);
    }

    async edit(): Promise<void> {
        await this.router.navigate([`account-tools/users-and-roles/role-management/details/${this.role.role_id}`], {
            relativeTo: this.route?.parent?.parent
        });
    }

    onConfirmRemoveEntityItemsNotification(): void {
        this.onCancelRemoveEntityItemsNotification();
        this.removeCheckedEntityItems();
    }

    onCancelRemoveEntityItemsNotification(): void {
        this.isRemoveEntityItemsNotificationVisible = false;
    }

    onCheckedEntityItemsChange(event: SelectedEvent): void {
        this.checkedEntityItems = event.selected;
    }

    onCheckedEntityItemsCleared(): void {
        this.checkedEntityItems = [];
        this.onCancelRemoveEntityItemsNotification();
    }

    delete(): void {
        this.isRemoveWarningVisible = true;
    }

    onConfirmClick(): void {
        if (this.role_length == 1) {
            this.isRemoveWarningVisible = false;
            return;
        }
        this.actionsListener$
            .pipe(
                ofType(UnAssignRoleFromUserSuccessAction),
                take(1)
            )
            .subscribe((data) => {
                this.isRemoveWarningVisible = false;
                this.store$.dispatch(userGetRolesAssignedToUser({ userId: this.sfUserId }));
            });
        this.store$.dispatch(UnAssignRoleFromUser({ roleId: this.role.role_id, sfContactId: [this.sfUserId] }));
    }

    onRemoveWarningVisibleCancel(): void {
        this.isRemoveWarningVisible = false;
    }

    private loadEntitiesGridData(): void {
        if (!this.displayEntities || this._entitiesDataLoaded) {
            return;
        }
        this.entitiesGridLoading = true;
        this.subscribeRoleEntitiesLoadedState();
        this.store$.dispatch(
            userManagementLoadRoleEntitiesAction({
                userId: this.sfUserId,
                roleId: this.role.role_id
            })
        );
    }

    private subscribeRoleEntitiesLoadedState(): void {
        this.actionsListener$
            .pipe(
                ofType(userManagementLoadRoleEntitiesSuccessAction, userManagementLoadRoleEntitiesFailureAction),
                filter((data) => data.roleId === this.role.role_id),
                take(1)
            )
            .subscribe((data) => {
                this.entitiesGridData = data['result']?.data || [];
                this.entitiesGridLoading = false;
                this._entitiesDataLoaded = true;
            });
    }

    private updateHeaderType(): void {
        this.headerType = this.isAccordionOpened ? AccordionTypes.Expanded : AccordionTypes.Collapsed;
    }

    private addUserRoleEntityGroupAssignment(groupsArray: Array<EntityGroup>): void {
        this.entitiesGridLoading = true;
        this.subscribeUsersRoleEntityGroupAssignedState();
        this.store$.dispatch(roleManagementUsersRoleEntitiesAssignAction({
            roleId: this.role.role_id,
            userIdToEntityGroups: { [this.sfUserId]: groupsArray },
            isExistedRole: true
        }));
    }

    private subscribeUsersRoleEntityGroupAssignedState(): void {
        this.actionsListener$
            .pipe(
                ofType(
                    roleManagementUsersRoleEntitiesAssignSuccessAction,
                    roleManagementUsersRoleEntitiesAssignFailureAction
                ),
                take(1)
            )
            .subscribe((response) => {
                if (!(response as any).errorMessage) {
                    this._entitiesDataLoaded = false;
                    this.loadEntitiesGridData();
                } else {
                    this.entitiesGridLoading = false;
                }
            });
    }

    private removeCheckedEntityItems(): void {
        if (this.checkedEntityItems.length) {
            this.entitiesGridLoading = true;
            const groups = [];
            this.checkedEntityItems.forEach((item) => {
                const existedGroup = groups.find(group => group.edh_entity_group_id === item.entity_group?.edh_entity_group_id);
                if (!item.is_group) {
                    existedGroup ? existedGroup.entities.push(item) : groups.push({ ...item.entity_group, entities: [item] });
                } else if (!existedGroup) {
                    groups.push({
                        ...item.entity_group,
                        entities: []
                    });
                }
            });
            this.actionsListener$
                .pipe(
                    ofType(removeUserRoleAssignmentEntitiesSuccessAction, removeUserRoleAssignmentEntitiesFailureAction),
                    filter((data) => data.roleId === this.role.role_id && data.sfContactId === this.sfUserId),
                    take(1)
                )
                .subscribe((data) => {
                    if (!!(data as any).error) {
                        this.entitiesGridLoading = false;
                    } else {
                        this._entitiesDataLoaded = false;
                        this.loadEntitiesGridData();
                    }
                });
            this.store$.dispatch(removeUserRoleAssignmentEntitiesAction({
                roleId: this.role.role_id,
                sfContactId: this.sfUserId,
                entityGroups: groups
            }));
        }
    }
}
