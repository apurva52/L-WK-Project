import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { UserStatus } from 'src/pages/users-and-roles/users-management/state/user-management.state';

import { User } from './../../../../../interfaces/user.model';
import { UserInfoSectionEditingComponent } from './user-info-section-editing.component';

describe('UserInfoSectionEditingComponent', () => {
    let component: UserInfoSectionEditingComponent;
    let fixture: ComponentFixture<UserInfoSectionEditingComponent>;
    const mockUser: User = {
        contact_id: '4',
        sf_contact_id: '14000000401',
        contact_name: 'Smith John',
        email: 'SmithJohnn@outlook.com',
        roles: [
            {
                role_id: 3,
                role_name: 'Guest',
                role_color: 'white'
            }
        ],
        status: UserStatus.ACTIVE
    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [UserInfoSectionEditingComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    }
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(UserInfoSectionEditingComponent);
        component = fixture.componentInstance;
        component.user = mockUser;
        fixture.detectChanges();

    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });


    it('should change Selected OUser status', () => {
        expect(component.selectedOption).toBeUndefined();
        component.onChange(component.controlOptions[0]);
        expect(component.selectedOption).toBeDefined();
    });

    it('should emit save event', () => {
        spyOn(component.save, 'emit');
        component.onSubmit();
        expect(component.save.emit).toHaveBeenCalled();
    });
    it('should detect initial user has changed', () => {
        const clock = jasmine.clock();
        const DEBOUNCE_TIME = 600;
        clock.install();
        component.form.patchValue({
            first_name: 'Test',
            last_name: 'User',
            email_address: 'test.user@mail.com',
            job_title: 'Test user',
            company: 'Test Co.',
            status: UserStatus.ACTIVE
        });
        clock.tick(DEBOUNCE_TIME);
        fixture.detectChanges();

        clock.uninstall();
        expect(component.hasChangeInitialValues).toBeTruthy();

    });

    it('should disable form when user status inactive', () => {
        component.user = {
            ...mockUser
        };
        component['patchForm']();
        expect(Object.keys(component.form.value).length).toBeGreaterThan(1);

        component.user = {
            ...mockUser,
            status: UserStatus.INACTIVE
        };
        component['patchForm']();
        expect(Object.keys(component.form.value).length).toBe(1);
        expect(component.form.value).toEqual({
            status: UserStatus.INACTIVE
        });
    });
});
