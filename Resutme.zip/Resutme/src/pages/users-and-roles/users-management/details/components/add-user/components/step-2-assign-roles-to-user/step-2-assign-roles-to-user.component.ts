import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import { clearRoleSelectedEntities, clearSelectedEntities } from '../../../../../../../../features/entity-selector/state/entity-selector.actions';
import { roleManagementInitiateAction } from '../../../../../../roles-management/state/role-management.actions';
import { selectedRolesForMultiSelect } from '../../../../../../roles-management/state/role-management.selectors';
import { ROLES_PAGE_SIZE } from '../../../../../../roles-management/state/role-management.state';
import { StepComponent } from '../../interfaces/step-component.model';

@Component({
    selector: 'ct-step-2-assign-roles-to-user',
    templateUrl: './step-2-assign-roles-to-user.component.html',
    styleUrls: ['./step-2-assign-roles-to-user.component.scss']
})
export class Step2AssignRolesToUserComponent extends StepComponent implements OnInit {
    @Input() stepForm: FormGroup;
    @Input() userFullname: string;

    rolesForMultiSelect$: Observable<Array<InputMultiselectItem>>;
    rolesData = [];

    constructor(private store$: Store) {
        super();
    }

    ngOnInit(): void {
        this.updateRolesSelector();
        this.loadRoles();
    }

    loadRoles(pageNumber: number = 1): void {
        this.store$.dispatch(roleManagementInitiateAction({ pageNumber, controlId: '', pageSize: ROLES_PAGE_SIZE }));
    }

    removeRoles(id: string): void {
        const roles = this.stepForm.value.roles.filter(roles => (roles.id != id));
        this.stepForm.patchValue({ roles });
        this.store$.dispatch(clearRoleSelectedEntities({role: id}));
        this.updateRolesSelector();
    }
    onClear(): void {
        this.store$.dispatch(clearSelectedEntities());
    }

    private updateRolesSelector(): void {
        this.rolesForMultiSelect$ = this.store$.select(selectedRolesForMultiSelect(this.rolesDataForMultiselect || []));
    }

    get rolesDataForMultiselect(): Array<InputMultiselectItem> {
        return this.stepForm?.value?.roles;
    }
}
