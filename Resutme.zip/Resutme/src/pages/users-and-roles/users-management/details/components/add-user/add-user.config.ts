import { WizardConfiguration } from '@ct/platform-primitives-uicomponents/modals';
import { Step } from '@ct/platform-primitives-uicomponents/primitives';
import { TranslateService } from '@ngx-translate/core';

export function getNewUserStepsPayload(): Array<Step> {
    return [
        {
            isActive: true,
            isFailed: false,
            isVisited: false,
            stepId: 1,
            description: ''
        },
        {
            isActive: false,
            isFailed: false,
            isVisited: false,
            stepId: 2,
            description: ''
        },
        {
            isActive: false,
            isFailed: false,
            isVisited: false,
            stepId: 3,
            description: ''
        }
    ];
}

export function setWizardConfig(
    translate: TranslateService,
    isReadyToSave: boolean = false
): WizardConfiguration {
    return {
        label: translate.instant('userRolesModule.newUserComponent.title'),
        cancelText: translate.instant(
            'userRolesModule.newUserComponent.cancelLbl'
        ),
        cancelToRight: true,

        steps: [
            {
                nextLabel: translate.instant(
                    'userRolesModule.newUserComponent.nextLbl'
                ),
                title: translate.instant(
                    'userRolesModule.newUserComponent.stepTitle'
                ),
                validation: false,
                previousLabel: translate.instant(
                    'userRolesModule.newUserComponent.previousLbl'
                )
            },
            {
                nextLabel: translate.instant(
                    'userRolesModule.assingRolesComponent.nextLbl'
                ),
                title: translate.instant(
                    'userRolesModule.assingRolesComponent.stepTitle'
                ),
                validation: false,
                previousLabel: translate.instant(
                    'userRolesModule.newUserComponent.previousLbl'
                )
            },
            {
                nextLabel: isReadyToSave
                    ? translate.instant(
                        'userRolesModule.associateEntitiesToRoleComponent.saveLbl'
                    )
                    : translate.instant(
                        'userRolesModule.associateEntitiesToRoleComponent.nextLbl'
                    ),
                title: translate.instant(
                    'userRolesModule.associateEntitiesToRoleComponent.stepTitle'
                ),
                validation: false,
                previousLabel: translate.instant(
                    'userRolesModule.newUserComponent.previousLbl'
                )
            }
        ]
    };
}
