export interface Step1UserDetailsInterface {
    firstName: string;
    lastName: string;
    email: string;
    jobTitle: string;
    department: string;
    company: string;
}
