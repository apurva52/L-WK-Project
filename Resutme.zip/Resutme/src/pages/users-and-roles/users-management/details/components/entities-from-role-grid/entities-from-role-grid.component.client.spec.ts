/* tslint:disable max-file-line-count */
/* tslint:disable:no-unused-variable */
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, Router, RouterEvent } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { EntitiesGridComponent } from '@ct/platform-common-uicomponents/entities-grids';
import { ActionsSubject, StoreModule } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { ReplaySubject } from 'rxjs/internal/ReplaySubject';
import { RoleAssignedToUser } from 'src/shared/interfaces/roles-assigned-to-user.response';

import {
    roleManagementUsersRoleEntitiesAssignSuccessAction
} from '../../../../roles-management/state/role-management.actions';
import {
    removeUserRoleAssignmentEntitiesSuccessAction,
    UnAssignRoleFromUserSuccessAction,
    userManagementLoadRoleEntitiesSuccessAction
} from '../../../state/user-management.actions';
import { initialState } from '../../../state/user-management.reducers';
import {
    getUnassignRoleStatus,
    selectUserRolesLoaded
} from '../../../state/user-management.selectors';
import {
    USER_MANAGEMENT_FEATURE_KEY,
    UserManagementState
} from '../../../state/user-management.state';

import { EntitiesFromRoleGridComponent } from './entities-from-role-grid.component';
import { EntityGroup } from './interfaces/entity-group';

const eventSubject = new ReplaySubject<RouterEvent>(1);
class Mockrouter {
    navigate = jasmine.createSpy('navigate');
    events = eventSubject.asObservable();
    getCurrentNavigation = jasmine.createSpy('getCurrentNavigation');
}

describe('EntitiesFromRoleGridComponent', () => {
    let component: EntitiesFromRoleGridComponent;
    let fixture: ComponentFixture<EntitiesFromRoleGridComponent>;
    let store: MockStore<UserManagementState>;
    let mockRouter: Mockrouter;
    const sfUserId = '1';
    const role = {
        created_by: '0030400000UQzDuAAL',
        created_by_name: 'John Doe',
        created_date: '01-20-2022',
        last_modified_by: '0030400000UQzDuAAL',
        last_modified_by_name: 'John Doe',
        last_modified_date: '01-20-2022',
        role_color: '#FF0000',
        role_id: 2,
        role_name: 'Test role',
        role_property: 'C',
        role_type: 'C',
        sf_account_id: '1',
        sf_account_name: 'John Doe',
        sf_assigned_by_account_id: '1',
        sf_assigned_by_account_name: 'John Doe'
    };
    const paramsSubject = new BehaviorSubject({
        id: 1
    });
    const actionSub: ActionsSubject = new ActionsSubject();
    const unassignresp = { result: true };
    beforeEach(async(() => {
        mockRouter = new Mockrouter();
        mockRouter.getCurrentNavigation.and.returnValue({
            extras: {}
        });
        TestBed.configureTestingModule({
            declarations: [
                EntitiesFromRoleGridComponent,
                EntitiesGridComponent
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            imports: [
                TranslateModule.forRoot(),
                RouterTestingModule,
                StoreModule.forRoot({})
            ],
            providers: [
                { provide: ActionsSubject, useValue: actionSub },
                provideMockStore({
                    initialState: {
                        [USER_MANAGEMENT_FEATURE_KEY]: initialState
                    },
                    selectors: [
                        {
                            selector: getUnassignRoleStatus,
                            value: unassignresp
                        },
                        { selector: selectUserRolesLoaded, value: [] }
                    ]
                }),
                {
                    provide: ActivatedRoute,
                    useValue: {
                        params: paramsSubject
                    }
                }
            ]
        }).compileComponents();
        store = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(EntitiesFromRoleGridComponent);
        component = fixture.componentInstance;
        component.sfUserId = sfUserId;
        component.role = role;
    });

    it('should create', () => {
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });

    it('should component init', () => {
        component.ngOnInit();
        component.role_length = 1;
        component.modalModel.cancelText = 'cancel';
        delete component.modalModel.cancelText;
        expect(component.modalModel.cancelText).toBe(undefined);
        expect(component.modalModel.title).toBeDefined();
        expect(component.modalModel.confirmText).toBeDefined();
    });

    it('should component init with data > 1', () => {
        const user1: RoleAssignedToUser = {
            created_by: '',
            created_by_name: '',
            created_date: '',
            last_modified_by: '',
            last_modified_by_name: '',
            last_modified_date: '',
            role_color: '',
            role_id: 1,
            role_name: '',
            role_property: '',
            role_type: '',
            sf_account_id: '',
            sf_account_name: '',
            sf_assigned_by_account_id: '',
            sf_assigned_by_account_name: ''
        };
        const user2: RoleAssignedToUser = {
            created_by: '',
            created_by_name: '',
            created_date: '',
            last_modified_by: '',
            last_modified_by_name: '',
            last_modified_date: '',
            role_color: '',
            role_id: 2,
            role_name: '',
            role_property: '',
            role_type: '',
            sf_account_id: '',
            sf_account_name: '',
            sf_assigned_by_account_id: '',
            sf_assigned_by_account_name: ''
        };
        (component as any).store$.overrideSelector(selectUserRolesLoaded, [
            user1,
            user2
        ]);
        fixture.detectChanges();
        component.ngOnInit();
        component.role_length = 1;
        expect(component.modalModel.cancelText).toBeDefined();
        expect(component.modalModel.title).toBeDefined();
        expect(component.modalModel.confirmText).toBeDefined();
    });

    it('should component init with data === 1', () => {
        const user1: RoleAssignedToUser = {
            created_by: '',
            created_by_name: '',
            created_date: '',
            last_modified_by: '',
            last_modified_by_name: '',
            last_modified_date: '',
            role_color: '',
            role_id: 1,
            role_name: '',
            role_property: '',
            role_type: '',
            sf_account_id: '',
            sf_account_name: '',
            sf_assigned_by_account_id: '',
            sf_assigned_by_account_name: ''
        };
        (component as any).store$.overrideSelector(selectUserRolesLoaded, [
            user1
        ]);
        fixture.detectChanges();
        component.ngOnInit();
        component.modalModel.cancelText = 'cancel';
        delete component.modalModel.cancelText;
        expect(component.modalModel.cancelText).toBe(undefined);
        expect(component.modalModel.title).toBeDefined();
        expect(component.modalModel.confirmText).toBeDefined();
    });

    it('should redirect to role edit page', () => {
        const router = TestBed.inject(Router);
        const routerSpy = spyOn(router, 'navigate');
        component.edit();
        fixture.detectChanges();
        expect(component.router.navigate).toHaveBeenCalled();
        expect(routerSpy).toHaveBeenCalledWith(
            [`account-tools/users-and-roles/role-management/details/2`],
            {
                relativeTo: undefined
            }
        );
    });

    it('should toogle accordion open and call entities', () => {
        const clock = jasmine.clock();
        clock.install();
        const accordionToggleSpy = spyOn(component.accordionToggle, 'emit');
        const storeDispatchSpy = spyOn(store, 'dispatch').and.callThrough();
        const accordionToggleCallsCount = 2;
        const storeDispatchCallsCount = 1;
        component.isAccordionOpened = false;

        component.onToggleAccordion();
        clock.tick(1);
        fixture.detectChanges();
        expect(component.isAccordionOpened).toEqual(true);

        component.onToggleAccordion();
        clock.tick(1);
        fixture.detectChanges();
        expect(component.isAccordionOpened).toEqual(false);

        clock.uninstall();
        expect(accordionToggleSpy).toHaveBeenCalledTimes(accordionToggleCallsCount);
        expect(storeDispatchSpy).toHaveBeenCalledTimes(storeDispatchCallsCount);
    });

    it('should open and close add entity modal', () => {
        component.onAddEntityToRoleUserModalToggle(true);
        expect(component.isAddEntityModalOpen).toBeTruthy();

        component.onAddEntityToRoleUserModalToggle(false);
        expect(component.isAddEntityModalOpen).toBeFalsy();
    });

    it('should dispatch associate entities action', () => {
        const testEntities = [
            {
                entity_id: 1,
                entity_guid: '1',
                entity_name: 'Test entity 1',
                entity_country: '',
                domestic_jurisdiction: ''
            },
            {
                entity_id: 2,
                entity_guid: '2',
                entity_name: 'Test entity 2',
                entity_country: '',
                domestic_jurisdiction: ''
            }
        ];
        const testImplicitGroup: EntityGroup = {
            entity_group_id: -1,
            edh_entity_group_id: -1,
            edh_entity_group_guid: '-1',
            edh_entity_group_name: '',
            edh_entity_group_type: 'I',
            entities: testEntities
        };
        const testExistingImplicitGroup: EntityGroup = {
            entity_group_id: 1,
            edh_entity_group_id: 1,
            edh_entity_group_guid: '1',
            edh_entity_group_name: 'Test implicit group 1',
            edh_entity_group_type: 'I',
            entities: []
        };
        const testCustomGroup: EntityGroup = {
            entity_group_id: 1,
            edh_entity_group_id: 1,
            edh_entity_group_guid: '1',
            edh_entity_group_name: 'Test custom group 1',
            edh_entity_group_type: 'C',
            entities: testEntities
        };
        const dispatchSpy = spyOn((component as any).store$, 'dispatch');
        const dispatchCallCount = 3;

        component.entitiesGridData = [];
        component.onAddEntities([testImplicitGroup]);

        component.entitiesGridData = [
            { ...testExistingImplicitGroup, entities: [testEntities[0]] }
        ];
        component.onAddEntities([
            { ...testImplicitGroup, entities: testEntities }
        ]);

        component.entitiesGridData = [];
        component.onAddEntities([testCustomGroup]);

        component.entitiesGridData = [testCustomGroup];
        component.onAddEntities([testCustomGroup]);

        expect(dispatchSpy).toHaveBeenCalledTimes(dispatchCallCount);
        expect(component.isAddEntityModalOpen).toEqual(false);
    });

    it('should change entitiesGridData on subscribeRoleEntitiesLoadedState to empty data', () => {
        component['_entitiesDataLoaded'] = false;
        component['subscribeRoleEntitiesLoadedState']();
        component['actionsListener$'].next(
            userManagementLoadRoleEntitiesSuccessAction({
                roleId: role.role_id,
                userId: sfUserId,
                result: null
            })
        );
        fixture.detectChanges();
        expect(component.entitiesGridData).toEqual([]);
        expect(component['_entitiesDataLoaded']).toBeTruthy();
    });

    it('should change entitiesGridData on subscribeRoleEntitiesLoadedState to test data', () => {
        const testGroups: Array<EntityGroup> = [
            {
                entity_group_id: -1,
                edh_entity_group_id: -1,
                edh_entity_group_guid: '-1',
                edh_entity_group_name: '',
                edh_entity_group_type: 'C',
                entities: [
                    {
                        entity_id: 1,
                        entity_guid: '1',
                        entity_name: 'Test entity 1',
                        entity_country: '',
                        domestic_jurisdiction: ''
                    }
                ]
            }
        ];
        component['_entitiesDataLoaded'] = false;
        component['subscribeRoleEntitiesLoadedState']();
        component['actionsListener$'].next(
            userManagementLoadRoleEntitiesSuccessAction({
                roleId: role.role_id,
                userId: sfUserId,
                result: { data: testGroups } as any
            })
        );
        fixture.detectChanges();
        expect(component.entitiesGridData).toEqual(testGroups);
        expect(component['_entitiesDataLoaded']).toBeTruthy();
    });

    it('should dispatch action to call load entities after asigning new users role entities', () => {
        const dispatchSpy = spyOn((component as any).store$, 'dispatch');
        component['subscribeUsersRoleEntityGroupAssignedState']();
        component['actionsListener$'].next(
            roleManagementUsersRoleEntitiesAssignSuccessAction()
        );
        fixture.detectChanges();
        expect(dispatchSpy).toHaveBeenCalled();
    });

    it('should set and clear checked items', () => {
        const data = [
            {
                entity_id: '1',
                entity_guid: '1',
                entity_type: '',
                entity_country: '',
                domestic_jurisdiction: '',
                foreign_jurisdiction: [],
                entity_name: ['1'],
                entity_group: {
                    edh_entity_group_id: 3,
                    edh_entity_group_guid:
                        '23f77391-b001-41a8-a528-ec3c3dc3c5a0',
                    edh_entity_group_name: 'Entity Group 3',
                    edh_entity_group_type: 'C',
                    entity_type: 'LLC',
                    entity_status: 'Active',
                    jurisdiction: 'FL, GA, AL, SC, NC, MI, LA',
                    entities: []
                },
                is_group: false
            }
        ] as any;

        component.onCheckedEntityItemsChange({ total: 1, selected: data });
        expect(component['checkedEntityItems'].length).toBeTruthy();

        component.onCheckedEntityItemsCleared();
        expect(component['checkedEntityItems'].length).toBeFalsy();
    });

    it('should show and close warning notification', () => {
        component.bulkOptions[0].handler();
        expect(component.isRemoveEntityItemsNotificationVisible).toBeTruthy();
        component.onCancelRemoveEntityItemsNotification();
        expect(component.isRemoveEntityItemsNotificationVisible).toBeFalsy();
    });

    it('should remove checked entity items', () => {
        const entityGroups = [
            {
                edh_entity_group_id: 1,
                edh_entity_group_guid: '3fd77391-b001-41a8-a528-ec3c3dc3c5a6',
                edh_entity_group_name: 'Entity Group 1',
                edh_entity_group_type: 'C',
                entity_type: 'LLC',
                entity_status: 'Active',
                jurisdiction: 'FL, GA, AL, SC, NC, MI, LA',
                entities: [
                    {
                        entity_id: 96000005937,
                        entity_guid: '11f28063-f227-41a2-b1fd-cc75b2586172',
                        entity_name: 'Entity Name 1',
                        entity_type: 'Corp',
                        entity_country: 'US',
                        domestic_jurisdiction: 'Delaware',
                        foreign_jurisdiction: 'Delaware'
                    }
                ]
            },
            {
                edh_entity_group_id: 2,
                edh_entity_group_guid: '3fd77391-b001-41a8-a528-ec3c3dc3c5a7',
                edh_entity_group_name: 'Entity Group 2',
                edh_entity_group_type: 'C',
                entity_type: 'LLC',
                entity_status: 'Active',
                jurisdiction: 'FL, GA, AL, SC, NC, MI, LA',
                entities: [
                    {
                        entity_id: 96000005938,
                        entity_guid: '11f28063-f227-41a2-b1fd-cc75b2586173',
                        entity_name: 'Entity Name 2',
                        entity_type: 'Corp',
                        entity_country: 'US',
                        domestic_jurisdiction: 'Delaware',
                        foreign_jurisdiction: 'Delaware'
                    }
                ]
            }
        ] as any;
        const data = [
            {
                entity_id: 96000005937,
                entity_guid: '11f28063-f227-41a2-b1fd-cc75b2586172',
                entity_type: 'Corp',
                entity_country: 'US',
                domestic_jurisdiction: 'Delaware',
                foreign_jurisdiction: [],
                entity_name: [
                    entityGroups[0].edh_entity_group_name,
                    'Entity Name 1'
                ],
                entity_group: entityGroups[0],
                is_group: false
            },
            {
                entity_id: 2,
                entity_guid: '3fd77391-b001-41a8-a528-ec3c3dc3c5a7',
                entity_type: '',
                entity_country: '',
                domestic_jurisdiction: '',
                foreign_jurisdiction: [],
                entity_name: ['Entity Group 2'],
                entity_group: entityGroups[1],
                is_group: true
            }
        ] as any;
        const dispatchSpy = spyOn((component as any).store$, 'dispatch');
        component.onConfirmRemoveEntityItemsNotification();
        expect(dispatchSpy).not.toHaveBeenCalled();

        component['checkedEntityItems'] = data;
        component.onConfirmRemoveEntityItemsNotification();
        expect(dispatchSpy).toHaveBeenCalled();

        const loadEntitiesGridDataSpy = spyOn(
            component as any,
            'loadEntitiesGridData'
        );
        component['actionsListener$'].next(
            removeUserRoleAssignmentEntitiesSuccessAction({
                roleId: role.role_id,
                sfContactId: sfUserId
            })
        );
        fixture.detectChanges();
        expect(loadEntitiesGridDataSpy).toHaveBeenCalled();
    });

    it(`should open modal when click on delete`, () => {
        component.delete();
        expect(component.isRemoveWarningVisible).toBe(true);
    });

    it(`should close modal`, () => {
        component.onRemoveWarningVisibleCancel();
        expect(component.isRemoveWarningVisible).toBe(false);
    });

    it(`should dispatch unassign role and close modal`, () => {
        component.role_length = 2;
        const rp_num = 2;
        spyOn(store, 'dispatch').and.callThrough();
        component.onConfirmClick();
        component.role_length = 2;
        component['actionsListener$'].next(
            UnAssignRoleFromUserSuccessAction({
                result: true
            })
        );
        expect(component.isRemoveWarningVisible).toBe(false);
        expect(store.dispatch).toHaveBeenCalledTimes(rp_num);
    });

    it(`should return unassign role and close modal`, () => {
        component.role_length = 1;
        component.onConfirmClick();
        expect(component.isRemoveWarningVisible).toBe(false);
    });

    it(`should load entities grid data if display entities allowed and data not loaded`, () => {
        spyOn(store, 'dispatch').and.callThrough();

        component.displayEntities = false;
        component['_entitiesDataLoaded'] = false;
        component['loadEntitiesGridData']();
        expect(store.dispatch).not.toHaveBeenCalled();

        component.displayEntities = true;
        component['loadEntitiesGridData']();
        expect(store.dispatch).toHaveBeenCalledTimes(1);

        component['_entitiesDataLoaded'] = true;
        component['loadEntitiesGridData']();
        expect(store.dispatch).toHaveBeenCalledTimes(1);
    });
});
