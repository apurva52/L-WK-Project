import { FormControl, FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';

export class StepComponent {
    stepForm: FormGroup;
    protected subscriptions: Array<Subscription> = [];

    getFormControl(key: string): FormControl {
        return this.stepForm.get(key) as FormControl;
    }

    protected addSubscription(subscription: Subscription): void {
        this.subscriptions.push(subscription);
    }
    protected removeAllSubscriptions(): void {
        this.subscriptions.forEach((sub) => sub.unsubscribe());
    }
    protected resetForm(): void {
        this.stepForm.reset();
    }
}
