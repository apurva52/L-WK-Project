import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { UserHeaderTagsComponent } from './user-header-tags.component';

describe('UserHeaderTagsComponent', () => {
    let component: UserHeaderTagsComponent;
    let fixture: ComponentFixture<UserHeaderTagsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [UserHeaderTagsComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    }
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(UserHeaderTagsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should return value for black color', () => {
        const expected = 'background-color: #000000; color: white';
        const color = component.getPillBackgroundColor('#000000');
        expect(expected).toEqual(color);
    });

    it('should return default gray color', () => {
        const expected = 'background-color: gray; color: white';
        const color = component.getPillBackgroundColor();
        expect(expected).toEqual(color);
    });
});
