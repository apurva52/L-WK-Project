import { Component, Input } from '@angular/core';
import { RoleAssignedToUser } from 'src/shared/interfaces/roles-assigned-to-user.response';

@Component({
    selector: 'ct-user-header-tags',
    templateUrl: './user-header-tags.component.html',
    styleUrls: ['./user-header-tags.component.scss']
})
export class UserHeaderTagsComponent {
    @Input() roles: Array<RoleAssignedToUser>;
    getPillBackgroundColor(rolePillColorValue: string = 'gray'): string {
        return `background-color: ${rolePillColorValue}; color: white`;
    }
}
