import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { ContactUser } from 'src/app/state/app.state';
import { selectAccountMembers } from 'src/pages/users-and-roles/users-management/state/user-management.selectors';
import { UserManagementState } from 'src/pages/users-and-roles/users-management/state/user-management.state';

import { PipesModule } from '../../../../../../../../shared/pipes/pipes.module';

import { InternalCustomerRoleInfoAccountMembersComponent } from './internal-customer-role-info-am.component';

describe('InternalCustomerRoleInfoAccountMembersComponent', () => {
    let component: InternalCustomerRoleInfoAccountMembersComponent;
    let fixture: ComponentFixture<InternalCustomerRoleInfoAccountMembersComponent>;
    let store$: MockStore<UserManagementState>;
    const contact1 = {
        sf_account_id: '123',
        sf_contact_id: '1c',
        sf_contact_name: 'account 1'
    };
    const contact2 = {
        sf_account_id: '123',
        sf_contact_id: '2c',
        sf_contact_name: 'account 2'
    };
    const contact3 = {
        sf_account_id: '123',
        sf_contact_id: '3c',
        sf_contact_name: 'account 3'
    };
    const contact4 = {
        sf_account_id: '123',
        sf_contact_id: '4c',
        sf_contact_name: 'account 4'
    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [InternalCustomerRoleInfoAccountMembersComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule,
                PipesModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    },
                    selectors: [
                        {
                            selector: selectAccountMembers,
                            value: {
                                '123': {
                                    currentSFAccountId: '123',
                                    contacts: [
                                        {
                                            sf_contact_name: 'name1',
                                            sf_contact_id: 'contact1',
                                            sf_account_id: 'account1'
                                        },
                                        {
                                            sf_contact_name: 'name2',
                                            sf_contact_id: 'contact2',
                                            sf_account_id: 'account2'
                                        },
                                        {
                                            sf_contact_name: 'name3',
                                            sf_contact_id: 'contact3',
                                            sf_account_id: 'account3'
                                        }
                                    ],
                                    isLoading: false
                                }
                            }
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store$ = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(
            InternalCustomerRoleInfoAccountMembersComponent
        );
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should toggle', () => {
        component.toggle(true);
        fixture.detectChanges();
        expect(component.isOpen).toBeTruthy();
    });

    it('should toggle false', () => {
        component.toggle(false);
        fixture.detectChanges();
        expect(component.isOpen).toBeFalsy();
    });

    it('should sortContacts', () => {
        const contacts: Array<ContactUser> = [contact2, contact1];
        const expected: Array<ContactUser> = [contact1, contact2];
        const actual = component.sortContacts(contacts);
        fixture.detectChanges();
        expect(expected).toEqual(actual);
    });

    it('should check empty selectAccountMembers', () => {
        (component as any).store$.overrideSelector(selectAccountMembers, [{}]);
        fixture.detectChanges();
        expect(component).toBeDefined();
    });

    it('should check firstMember and secondMember from selectAccountMembers', () => {
        component.sf_account_id = '123';
        component._sf_account_id = '123';
        component.getCustomerAccountDetails({
            '123': {
                currentSFAccountId: '123',
                contacts: [contact1, contact2, contact3, contact4],
                isLoading: false
            }
        });
        fixture.detectChanges();
        expect(component).toBeDefined();
        expect(component.isContactsEmpty).toBeFalsy();
        expect(component.firstMember).toEqual(contact1);
        expect(component.secondMember).toEqual(contact2);
        expect(component.labelContactsText).toEqual('account 1, account 2');
        expect(component.contacts).toEqual([contact3, contact4]);
        expect(component.plusMoreText).toEqual(
            '+2 userRolesModule.detailsComponent.moreText'
        );
        expect(component.loadingMembers).toBeFalse;
        expect(component._sf_account_id).toEqual('123');
    });
});
