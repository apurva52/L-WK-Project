import { ColumnApi, GridApi, RowNode } from '@ag-grid-community/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvatarRendererComponent } from './avatar-renderer';

describe('AvatarRendererComponent', () => {
    let fixture: ComponentFixture<AvatarRendererComponent>;
    let component: AvatarRendererComponent;
    const mockedParams = {
        value: undefined,
        valueFormatted: undefined,
        data: undefined,
        node: null,
        rowIndex: 0,
        $scope: undefined,
        api: new GridApi(),
        columnApi: new ColumnApi(),
        context: undefined,
        eGridCell: undefined,
        eParentOfValue: undefined,
        registerRowDragger: null,
        click: (event: any) => {
            return false;
        }
    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [AvatarRendererComponent]
        }).compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(AvatarRendererComponent);
        component = fixture.componentInstance;
    });

    it('should be defined', () => {
        expect(component).toBeDefined();
    });

    it('should init component', () => {
        mockedParams.value = 'John Smith';
        component.agInit(mockedParams);
        expect(component.params).toBeDefined();
        expect(component.cellValue).toBe('John Smith');
    });

    it('run refresh', () => {
        expect(component['refresh'](null)).toEqual(false);
    });

    it('should perform click action', () => {
        mockedParams.data = {
            contact_id: 1,
            contact_name: 'John Smith'
        };
        component.agInit(mockedParams);
        component.onClick();
        expect(component.clickEvent).toBeDefined();
    });
});
