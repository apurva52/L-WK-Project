import { ICellRendererParams } from '@ag-grid-community/core';

export interface AvatarRendererParams extends ICellRendererParams {
    click?: (event: any) => {};
    showAvatar?: (boolean) => false;
}
