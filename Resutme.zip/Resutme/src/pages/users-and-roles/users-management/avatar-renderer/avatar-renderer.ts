import { ICellRendererAngularComp } from '@ag-grid-community/angular';
import { ICellRendererParams } from '@ag-grid-community/core';
import { Component } from '@angular/core';

import { AvatarRendererParams } from './avatar-renderer-params';

@Component({
    selector: 'ct-avatar-renderer',
    templateUrl: './avatar-renderer.html',
    styleUrls: ['./avatar-renderer.scss']
})
export class AvatarRendererComponent implements ICellRendererAngularComp {
    params: ICellRendererParams;
    cellValue: string;
    avatarattr: string = '';
    clickEvent: (event) => {};
    shouldShowAvatar: (boolean: any) => false;

    refresh(params: ICellRendererParams): boolean {
        return false;
    }

    agInit(params: AvatarRendererParams): void {
        this.params = params;
        this.cellValue = params.value;
        if (this.cellValue != undefined) {
            this.avatarattr = this.cellValue.split(' ').reduce((current: string, next: string) => current + next.charAt(0), '');
        }
        this.clickEvent = params.click;
        this.shouldShowAvatar = params.showAvatar;
    }

    onClick(): void {
        this.clickEvent(this.params?.data);
    }
}
