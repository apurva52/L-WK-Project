import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { initialState } from '../../state/user-management.reducers';
import {
    assignRolesToUsersBulkModalState,
    selectedUsersManagement
} from '../../state/user-management.selectors';
import {
    USER_MANAGEMENT_FEATURE_KEY,
    UserManagementState,
    UserStatus
} from '../../state/user-management.state';

import { AssignRolesToUsersBulkComponent } from './assign-roles-to-users-bulk.component';

describe('AssignRolesToUsersBulkComponent', () => {
    let component: AssignRolesToUsersBulkComponent;
    let fixture: ComponentFixture<AssignRolesToUsersBulkComponent>;
    let store: MockStore<UserManagementState>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [AssignRolesToUsersBulkComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [USER_MANAGEMENT_FEATURE_KEY]: initialState
                    },
                    selectors: [
                        { selector: assignRolesToUsersBulkModalState, value: true },
                        { selector: selectedUsersManagement, value: [{}] }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AssignRolesToUsersBulkComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it(`should initialize`, () => {
        const selectedUsersMock = [{
            contact_id: '1',
            sf_contact_id: '1',
            contact_name: 'Test User1',
            email: '1',
            roles: [],
            status: 'active'
        }];
        store.overrideSelector(selectedUsersManagement, selectedUsersMock);
        fixture.detectChanges();
        component.ngOnInit();
        expect(component.selectedUsers).toEqual(selectedUsersMock);
    });

    it(`should destroy`, () => {
        spyOn(component['_destroyed$'], 'complete').and.callThrough();
        component.ngOnDestroy();
        expect(component['_destroyed$'].complete).toHaveBeenCalled();
    });

    it(`should dispatch close modal`, () => {
        const expectedCallsCount = 2;
        spyOn(store, 'dispatch').and.callThrough();
        component['close']();
        component.onCancelClick();
        expect(store.dispatch).toHaveBeenCalledTimes(expectedCallsCount);
    });

    it(`should dispatch wisard open and close modal`, () => {
        const expectedCallsCount = 3;
        spyOn(store, 'dispatch').and.callThrough();
        component.onConfirmClick();
        expect(store.dispatch).toHaveBeenCalledTimes(expectedCallsCount);
    });

    it(`should return active users as message params`, () => {
        component.selectedUsers = [
            { contact_name: '0' },
            { contact_name: '1', status: UserStatus.INACTIVE },
            { contact_name: '2', status: UserStatus.ACTIVE },
            { contact_name: '3', status: UserStatus.ACTIVE }
        ] as Array<any>;
        expect(component.activeSelectedUsersAsMessageParams).toEqual({ '0': '"2", "3"' });
    });
});
