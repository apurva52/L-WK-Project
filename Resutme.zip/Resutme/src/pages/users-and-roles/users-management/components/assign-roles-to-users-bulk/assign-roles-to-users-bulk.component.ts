import { Component, OnDestroy, OnInit } from '@angular/core';
import { ModalModel } from '@ct/platform-primitives-uicomponents/modals';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { User } from '../../interfaces/user.model';
import {
    userAddRolesToUsersModalAction,
    userManagementAssignRolesToUsersBulkModalAction,
    userManagementSelectAction
} from '../../state/user-management.actions';
import { assignRolesToUsersBulkModalState, selectedUsersManagement } from '../../state/user-management.selectors';
import { UserStatus } from '../../state/user-management.state';

@Component({
    selector: 'ct-assign-roles-to-users-bulk',
    templateUrl: './assign-roles-to-users-bulk.component.html',
    styleUrls: ['./assign-roles-to-users-bulk.component.scss']
})
export class AssignRolesToUsersBulkComponent implements OnInit, OnDestroy {

    assignRolesToUserBulkModalState$ = this.store$.select(assignRolesToUsersBulkModalState);
    selectedUsers: Array<User> = [];
    modalModel: ModalModel = {
        title: 'userRolesModule.assingRolesComponent.assingRolesToUsersBulkComponent.title',
        cancelText: 'userRolesModule.assingRolesComponent.assingRolesToUsersBulkComponent.stayOnPage',
        confirmText: 'userRolesModule.assingRolesComponent.assingRolesToUsersBulkComponent.confirmButton'
    };

    get activeSelectedUsers(): Array<User> {
        return this.selectedUsers.filter(user => user.status?.toLowerCase() === UserStatus.ACTIVE);
    }

    get activeSelectedUsersAsMessageParams(): any {
        return { '0': this.activeSelectedUsers.map(u => `"${u.contact_name}"`).join(', ') };
    }

    get allSelectedUsersAreActive(): boolean {
        return this.selectedUsers.every((temp => temp.status?.toLowerCase() === UserStatus.ACTIVE));
    }

    private _destroyed$ = new Subject<boolean>();

    constructor(private store$: Store) { }

    ngOnInit(): void {
        this.store$.select(selectedUsersManagement)
            .pipe(takeUntil(this._destroyed$))
            .subscribe(data => this.selectedUsers = data);
    }

    ngOnDestroy(): void {
        this._destroyed$.next();
        this._destroyed$.complete();
    }

    onCancelClick(): void {
        this.close();
    }

    onConfirmClick(): void {
        this.store$.dispatch(userManagementSelectAction({
            total: this.activeSelectedUsers.length,
            selected: this.activeSelectedUsers
        }));
        this.store$.dispatch(userAddRolesToUsersModalAction({ value: true }));
        this.close();
    }

    private close(): void {
        this.store$.dispatch(userManagementAssignRolesToUsersBulkModalAction({ isOpen: false }));
    }
}
