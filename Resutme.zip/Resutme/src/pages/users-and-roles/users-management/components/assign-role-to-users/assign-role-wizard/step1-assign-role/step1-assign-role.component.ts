import { GridApi, IGetRowsParams } from '@ag-grid-community/core';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import {
    NotificationModel,
    NotificationType
} from '@ct/platform-primitives-uicomponents/primitives';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { delay, take } from 'rxjs/operators';
import { StepComponent } from 'src/pages/users-and-roles/roles-management/components/add/interfaces/step-component.model';
import { Role } from 'src/pages/users-and-roles/roles-management/interfaces/role.model';
import { ROLES_COLUMNS_ROLE_NAME } from 'src/pages/users-and-roles/roles-management/roles-management.config';
import { createLevel } from 'src/shared/config/claims.config';
import { paramsSwitcherRequest } from 'src/shared/interfaces/paramsSwitcherRequest';
import { AuthorizationManagementService } from 'src/shared/services/authorization-management/authorization-management.service';
import { ModulePermissionsService } from 'src/shared/services/module-permissions/module-permissions.service';

import { RolesAssignedForUserSelected } from '../../../../../../users-and-roles/users-management/interfaces/assign-roles-to-users-selected.model';
import { User } from '../../../../../../users-and-roles/users-management/interfaces/user.model';
import {
    userDeselectUser,
    userRolesAssignedForUserSelected
} from '../../../../../../users-and-roles/users-management/state/user-management.actions';
import { roleManagementSuccessAction } from '../../../../../roles-management/state/role-management.actions';

@Component({
    selector: 'ct-step1-assign-role',
    templateUrl: './step1-assign-role.component.html',
    styleUrls: ['./step1-assign-role.component.scss']
})
export class Step1AssignRoleComponent extends StepComponent implements OnInit {
    get selectedUsers(): Array<User> {
        return this.stepForm.get('users')?.value || [];
    }
    @Input()
    set isNotificationVisible(value: boolean) {
        this._showNotification = value;
    }
    get isNotificationVisible(): boolean {
        return this._showNotification;
    }
    @Input()
    set warningNotification(value: NotificationModel) {
        this._notification = value;
    }
    get warningNotification(): NotificationModel {
        return this._notification;
    }
    readonly NotificationType = NotificationType;
    userHasCreatePermission =
        this.modulePermissionsService.doesUserHasPermission(createLevel);
    @Output() warningClosed: EventEmitter<void> = new EventEmitter();
    @Input() stepForm: FormGroup;
    @Output() addNewRole: EventEmitter<void> = new EventEmitter();
    GRID_MAX_ELEMENTS: number = 200;
    private _showNotification = false;
    private _notification: NotificationModel;
    private gridApi: GridApi;
    private DELAY_GRID_UPDATE: number = 300;
    constructor(
        private store$: Store,
        private actionsListener$: ActionsSubject,
        private modulePermissionsService: ModulePermissionsService,
        private authorizationManagementService: AuthorizationManagementService
    ) {
        super();
    }

    ngOnInit(): void {
        this.selectPreloadedRoles();
    }

    onGridReady($event): void {
        this.gridApi = $event.api;
        this.gridApi.showLoadingOverlay();
    }

    onPillClicked(user: User): void {
        this.store$.dispatch(userDeselectUser({ user }));
    }
    onSelectionChange(selected: RolesAssignedForUserSelected): void {
        this.store$.dispatch(userRolesAssignedForUserSelected({ selected }));
        this.stepForm.get('roles').patchValue(selected.selected);
    }
    onConfirmNotification(): void {
        this.warningClosed.emit();
    }

    async onLoadRoles(params: IGetRowsParams): Promise<void> {
        const request: paramsSwitcherRequest = {} as paramsSwitcherRequest;
        request.pageSize = params.endRow - params.startRow;
        request.pageNumber = params.startRow / request.pageSize + 1;
        if (params.sortModel.length) {
            request.sortKey = params.sortModel[0].sort;
            request.sortBy =
                params.sortModel[0]?.colId.toLowerCase() ===
                ROLES_COLUMNS_ROLE_NAME
                    ? 'RoleName'
                    : params.sortModel[0].colId;
        }
        const response = await this.authorizationManagementService.getRolesList(
            request
        );
        this.store$.dispatch(roleManagementSuccessAction({ response }));

        const lastRow = this.getLastRow(
            response.data.length,
            request.pageNumber,
            request.pageSize
        );
        params.successCallback(response.data, lastRow);
    }
    private getLastRow(
        rows: number,
        pageNum: number,
        pageSize: number
    ): number {
        return rows < pageSize
            ? (pageNum - 1) * pageSize + rows
            : (pageNum + 1) * pageSize;
    }
    private selectPreloadedRoles(): void {
        const { roles }: { roles: Array<Role> } = this.stepForm.value;
        if (!!roles.length) {
            this.actionsListener$
                .pipe(
                    ofType(roleManagementSuccessAction),
                    take(1),
                    delay(this.DELAY_GRID_UPDATE)
                )
                .subscribe(() => {
                    roles.forEach((role) => {
                        const rowNode = this.gridApi.getRowNode(
                            role.role_id.toString()
                        );
                        rowNode.setSelected(true);
                    });
                });
        }
    }
}
