/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserDetailsDisplayComponent } from './user-details-display.component';

describe('UserDetailsDisplayComponent', () => {
    let component: UserDetailsDisplayComponent;
    let fixture: ComponentFixture<UserDetailsDisplayComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [UserDetailsDisplayComponent]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(UserDetailsDisplayComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should create', () => {
        const user = {
            contact_id: '',
            sf_contact_id: '',
            contact_name: '',
            email: '',
            roles: []
        };
        component.user = user;
        fixture.detectChanges();
        expect(component).toBeTruthy();
        expect(component._user).toEqual(user);
    });
});
