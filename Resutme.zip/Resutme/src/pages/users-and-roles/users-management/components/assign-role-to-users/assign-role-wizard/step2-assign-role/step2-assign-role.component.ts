import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import {
    clearRoleSelectedEntities,
    entitySelectBy,
    entitySelectorChangeStatus
} from 'src/features/entity-selector/state/entity-selector.actions';
import { StepComponent } from 'src/pages/users-and-roles/roles-management/components/add/interfaces/step-component.model';
import { roleManagementGetRoleDetailsAction } from 'src/pages/users-and-roles/roles-management/state/role-management.actions';
import { User } from 'src/pages/users-and-roles/users-management/interfaces/user.model';
import { userGetRoleIdFromAccordianAction } from 'src/pages/users-and-roles/users-management/state/user-management.actions';

import { selectAssignRolesToUsersSelected, selectedUserManagementState } from '../../../../state/user-management.selectors';
import * as configComponent from '../assign-role-wizard.config';

@Component({
    selector: 'ct-step2-assign-role',
    templateUrl: './step2-assign-role.component.html',
    styleUrls: ['./step2-assign-role.component.scss']
})
export class Step2AssignRoleComponent extends StepComponent implements OnInit, OnDestroy {
    get selectedUsers(): Array<User> {
        return this.getFormControl('users')?.value || [];
    }

    get activeUsersAccordion(): number {
        return this.getFormControl('activeAccordion')?.value;
    }

    set activeUsersAccordion(value: number) {
        this.getFormControl('activeAccordion')?.setValue(value);
    }

    get userEntitiesFormGroup(): FormGroup {
        return this.stepForm?.controls?.userEntities as FormGroup;
    }

    get userToApplySameCheckboxFormGroup(): FormGroup {
        return this.stepForm?.controls?.userToApplySameCheckbox as FormGroup;
    }

    get activeTabId(): number {
        return this.getFormControl('activeTabId')?.value;
    }

    set activeTabId(value: number) {
        this.getFormControl('activeTabId')?.setValue(value);
    }
    @Input() stepForm: FormGroup;

    selectedUsers$ = this.store$.select(selectedUserManagementState);
    selectedRoles: Array<InputMultiselectItem> = [];

    tabId = 0;

    generateUserRoleControlKey = configComponent.generateUserRoleControlKey;

    private destroyed$: Subject<boolean> = new Subject<boolean>();

    constructor(private store$: Store) {
        super();
    }
    ngOnInit(): void {
        this.store$
            .select(selectAssignRolesToUsersSelected)
            .pipe(takeUntil(this.destroyed$))
            .subscribe((roles) => {
                const selectedRoles = roles.selected || [];
                this.selectedRoles = selectedRoles.map((role) => {
                    return {
                        id: role.role_id.toString(),
                        label: role.role,
                        isSelected: false
                    };
                });
                this.recreateControls();
                this.getFormControl('roles')?.setValue(selectedRoles);
            })
            .unsubscribe();
        this.store$.dispatch(userGetRoleIdFromAccordianAction({
            accordianRoleId: this.selectedRoles[0]?.id
        }));
        this.store$.dispatch(roleManagementGetRoleDetailsAction({
            roleId: parseInt(this.selectedRoles[0]?.id)
        }));
    }

    ngOnDestroy(): void {
        this.clearEntitiesSelectorState();
    }

    onToggleEvent(roleId, index: number): void {
        this.activeUsersAccordion = index;
        this.store$.dispatch(userGetRoleIdFromAccordianAction({
            accordianRoleId: roleId
         }));
        this.store$.dispatch(roleManagementGetRoleDetailsAction({
            roleId: parseInt(roleId)
        }));
        this.clearEntitiesSelectorState();
    }

    onSelectedTab(index: number): void {
        this.activeTabId = index;
    }

    convertUserToInputMultiselectItem(user: User): InputMultiselectItem {
        return {
            id: user.sf_contact_id,
            label: user.contact_name,
            isSelected: true
        };
    }

    private recreateControls(): void {
        const removedControlsKeys = configComponent.recreateEntitiesControls(
            this.selectedUsers,
            this.selectedRoles,
            this.userEntitiesFormGroup,
            this.userToApplySameCheckboxFormGroup
        );
        removedControlsKeys.forEach(key => this.store$.dispatch(clearRoleSelectedEntities({ role: key })));
    }

    private clearEntitiesSelectorState(): void {
        this.store$.dispatch(entitySelectBy({ select: undefined }));
        this.store$.dispatch(entitySelectorChangeStatus({ open: false }));
    }

}
