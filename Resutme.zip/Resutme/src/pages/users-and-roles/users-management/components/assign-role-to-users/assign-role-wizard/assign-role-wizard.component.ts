//tslint:disable:max-file-line-count
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormArray, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { ModalModel, ScreenSizeEnum, WizardConfiguration } from '@ct/platform-primitives-uicomponents/modals';
import { NotificationModel } from '@ct/platform-primitives-uicomponents/primitives/notifications';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { clearAllData, selectEntities } from 'src/features/entity-selector/state/entity-selector.actions';
import { USER_TO_ROLE_SEPARATOR } from 'src/pages/users-and-roles/roles-management/interfaces/role-management.params';
import { Role } from 'src/pages/users-and-roles/roles-management/interfaces/role.model';
import {
    roleManagementAddNewRoleModalAction,
    roleManagementUsersRoleEntitiesAssignAction,
    roleManagementUsersRoleEntitiesAssignFailureAction,
    roleManagementUsersRoleEntitiesAssignSuccessAction
} from 'src/pages/users-and-roles/roles-management/state/role-management.actions';

import { User } from '../../../interfaces/user.model';
import { userAddRolesToUsersModalAction, userRemoveUsersWarningModalAction } from '../../../state/user-management.actions';
import { selectAssignRolesWizardNextDisabled, selectedUserManagementState, selectShouldShowRemoveUserWarning } from '../../../state/user-management.selectors';

import { isAssigningRoleToUser } from './../../../../roles-management/state/role-management.selectors';
import * as configComponent from './assign-role-wizard.config';

@Component({
    selector: 'ct-assign-role-wizard',
    templateUrl: './assign-role-wizard.component.html',
    styleUrls: ['./assign-role-wizard.component.scss']
})
export class AssignRoleWizardComponent implements OnInit, OnDestroy {

    get isInlastStep(): boolean {
        return this.activeStep === this.assignRoleToUsersStepsPayload.length - 1;
    }

    get activeTab(): FormControl {
        return this.getStepForm(1).get('activeTabId') as FormControl;
    }

    get activeAccordion(): FormControl {
        return this.getStepForm(1).get('activeAccordion') as FormControl;
    }

    get selectedUsers(): FormControl {
        return this.getStepForm(1).get('users') as FormControl;
    }

    get selectedRoles(): FormControl {
        return this.getStepForm(1).get('roles') as FormControl;
    }
    get userEntities(): FormGroup {
        return this.getStepForm(1).get('userEntities') as FormGroup;
    }
    get userToApplySameCheckbox(): FormGroup {
        return this.getStepForm(1).get('userToApplySameCheckbox') as FormGroup;
    }
    get hasDuplicates(): boolean {
        return this.duplicatedWarningMessages.length > 0;
    }
    set isDuplicatesWarningVisible(value: boolean) {
        this._showWarning = value;
    }
    get isDuplicatesWarningVisible(): boolean {
        return this._showWarning;
    }

    readonly ScreenSizeEnum = ScreenSizeEnum;

    wizardConfig: WizardConfiguration;
    activeStep = 0;
    activetabindex = 0;
    selectAssignRolesWizardNextDisabled$ = this.store$.select(selectAssignRolesWizardNextDisabled);
    selectedUsers$ = this.store$.select(selectedUserManagementState);
    isRemoveWarningVisible: boolean = false;
    isCancelNotificationVisible: boolean = false;
    isRemoveWarningVisible$ = this.store$.select(selectShouldShowRemoveUserWarning).subscribe((value) => {
        this.isRemoveWarningVisible = value;
    });
    isAssigningRoleToUser$ = this.store$.select(isAssigningRoleToUser);

    assignRoleToUsersStepsPayload = [];
    hasOverlayClickClose = false;
    btnsVisible = true;
    associationInProgress = false;
    nextLabel = this.translate.instant('userRolesModule.newRoleWizardComponent.nextLabel');
    applyLabelText = this.translate.instant('userRolesModule.newRoleWizardComponent.applyLabel');

    removeWarningModalModel: ModalModel = {
        title: 'userRolesModule.assingRolesComponent.removeWarningModal.title',
        cancelText: 'userRolesModule.assingRolesComponent.removeWarningModal.cancelBtn',
        confirmText: 'userRolesModule.assingRolesComponent.removeWarningModal.confirmBtn',
        cancelToLeft: true
    };

    confirmModalModel: ModalModel = {
        title: 'userRolesModule.assingRolesComponent.cancelConfirmModal.title',
        cancelText: 'userRolesModule.assingRolesComponent.cancelConfirmModal.cancelBtn',
        confirmText: 'userRolesModule.assingRolesComponent.cancelConfirmModal.confirmBtn',
        cancelToLeft: false
    };

    form: FormArray = new FormArray([
        new FormGroup({
            role_id: new FormControl({ value: '', disabled: false }, [Validators.required])
        }),
        new FormGroup({
            users: new FormControl({ value: [], disabled: false }, [Validators.required]),
            roles: new FormControl({ value: [], disabled: false }),
            activeAccordion: new FormControl({ value: 0, disabled: false }),
            activeTabId: new FormControl({ value: 0, disabled: false }),
            userEntities: new FormGroup({}),
            userToApplySameCheckbox: new FormGroup({})
        }, this.lastStepFormValidation())
    ]);


    hasCompletedWithoutErrors = false;
    warningNotification$: Subject<NotificationModel> = new Subject();
    duplicatedWarningMessages: Array<NotificationModel> = [];

    @Input() isInternal: boolean;
    @Output() completed: EventEmitter<boolean> = new EventEmitter();
    private _showWarning = false;

    private _destroyed$ = new Subject<boolean>();

    constructor(private store$: Store, private translate: TranslateService, private actionsListener$: ActionsSubject) { }

    ngOnInit(): void {
        this.assignRoleToUsersStepsPayload = configComponent.getAssignRolesToUsersStepsPayload(this.isInternal);
        this.wizardConfig = configComponent.setWizardConfig(this.translate, this.isInternal);
        this.subscribeSelectedUsers();
    }

    ngOnDestroy(): void {
        if (this.isRemoveWarningVisible$) this.isRemoveWarningVisible$.unsubscribe();
        this._destroyed$.next();
        this._destroyed$.complete();
    }
    getStepForm(index: number): FormGroup {
        return this.form.at(index) as FormGroup;
    }

    onPrevious(): void {
        if (this.isInlastStep && this.activeTab.value === 0 && this.activeAccordion.value === 0) {
            this.goPrevious();
        } else {
            this.navigateBack();
        }
    }

    onNext(): void {
        if (this.isInternal) {
            if (this.checkDuplicatedRolesAndShowWarning()) {
                return;
            }
            configComponent.recreateEntitiesControls(
                this.selectedUsers.value,
                this.selectedRoles.value.map(role => ({
                    id: role.role_id.toString(),
                    label: role.role,
                    isSelected: false
                })),
                this.userEntities,
                this.userToApplySameCheckbox
            );
            this.addUserRoleAssignmentWithEntityGroup();
        } else {
            this.isInlastStep ? this.step2Submit() : this.goToNext();
        }
    }

    showDuplicatesWarning(): void {
        const message = this.duplicatedWarningMessages.pop();
        this.warningNotification$.next(message);
        this.isDuplicatesWarningVisible = true;
    }
    onWarningClosed(): void {
        this.isDuplicatesWarningVisible = false;
        this.duplicatedWarningMessages.length > 0 && this.showDuplicatesWarning();
    }

    closeWizardModal(): void {
        this.onRemoveWarningVisibleCancel();
        this.store$.dispatch(userAddRolesToUsersModalAction({ value: false }));
        this.store$.dispatch(clearAllData());
        this.completed.emit(this.hasCompletedWithoutErrors);
    }

    onRemoveWarningVisibleCancel(): void {
        this.isRemoveWarningVisible = false;
        this.store$.dispatch(userRemoveUsersWarningModalAction({ value: false }));
    }

    openAddNewRoleModal(): void {
        this.closeWizardModal();
        this.store$.dispatch(roleManagementAddNewRoleModalAction({ isOpen: true }));
    }

    validateCancelModal(): void {
        if (!!this.getStepForm(1).value.roles.length || this.activeStep > 0) {
            this.isCancelNotificationVisible = true;
            return;
        }
        this.closeWizardModal();
    }

    private navigateBack(): void {
        const active = this.activeAccordion.value;
        const selectedRolesCount = this.selectedRoles.value.length - 1;
        if (active === 0) {
            this.activeTab.setValue(this.activeTab.value - 1);
            this.activeAccordion.setValue(selectedRolesCount);
        } else {
            this.activeAccordion.setValue(active > 0 ? active - 1 : selectedRolesCount);
        }
    }

    private goPrevious(): void {
        this.wizardConfig.steps[this.activeStep].nextLabel = this.nextLabel;
        this.assignRoleToUsersStepsPayload[this.activeStep].isActive = false;
        this.activetabindex--;
        this.activeStep--;
        this.assignRoleToUsersStepsPayload[this.activeStep].isActive = true;
        this.assignRoleToUsersStepsPayload[this.activeStep].isVisited = false;
    }

    private checkDuplicatedRolesAndShowWarning(): boolean {
        this.findUsersWithDuplicatedRoles();
        if (this.hasDuplicates) {
            this.showDuplicatesWarning();
            return true;
        }
        return false;
    }

    private goToNext(): void {
        if (this.checkDuplicatedRolesAndShowWarning()) {
            return;
        }
        this.assignRoleToUsersStepsPayload[this.activeStep].isActive = false;
        this.assignRoleToUsersStepsPayload[this.activeStep].isVisited = true;
        this.activeStep++;
        this.assignRoleToUsersStepsPayload[this.activeStep].isActive = true;
    }
    private findUsersWithDuplicatedRoles(): void {
        this.resetWarningMessages();
        this.selectedRoles.value.forEach(({ role_id, role }) => {
            const duplicates = this.findDuplicatedUsersByRole(role_id);
            duplicates.length > 0 && this.buildWarningMessages(role, duplicates);
        });
    }
    private buildWarningMessages(roleName: string, duplicatedUsers: Array<User>): void {
        const names = duplicatedUsers.map(user => user.contact_name).join(', ');
        const singularContent = this.translate.instant('userRolesModule.assignRolesToUsersWizardComponent.warningMessages.warningDuplicatedUser', { roleName, userName: names });
        const pluralContent = this.translate.instant('userRolesModule.assignRolesToUsersWizardComponent.warningMessages.warningDuplicatedUsers', { roleName, userNames: names });
        this.duplicatedWarningMessages.push({
            title: this.translate.instant('userRolesModule.assignRolesToUsersWizardComponent.warningMessages.title'),
            content: duplicatedUsers.length > 1 ? pluralContent : singularContent,
            confirmationText: this.translate.instant('userRolesModule.assignRolesToUsersWizardComponent.warningMessages.confirmationText')
        });
    }
    private resetWarningMessages(): void {
        this.isDuplicatesWarningVisible = false;
        this.duplicatedWarningMessages = [];
    }
    private findDuplicatedUsersByRole(roleId: string): Array<User> {
        return this.selectedUsers.value.filter(user => user.roles.some(({ role_id }) => roleId === role_id));
    }
    private step2Submit(): void {
        this.assignSameEntitiesToSelectedUsers();
        this.doAllUserHaveEntitiesAssociation() ? this.submit() : this.navigateForward();
    }
    private navigateForward(): void {
        const selectedUsersCount = this.selectedUsers.value.length - 1;
        const selectedRolesCount = this.selectedRoles.value.length - 1;
        if (this.activeAccordion.value === selectedRolesCount && this.activeTab.value < selectedUsersCount) {
            this.activeTab.setValue(this.activeTab.value + 1);
            this.activeAccordion.setValue(0);
        } else if (this.activeAccordion.value < selectedRolesCount) {
            this.activeAccordion.setValue(this.activeAccordion.value + 1);
        }
    }

    private submit(): void {
        if (this.wizardConfig.steps[this.activeStep].nextLabel === this.applyLabelText) {
            this.addUserRoleAssignmentWithEntityGroup();
        } else {
            this.activeAccordion.setValue(-1);
            this.wizardConfig.steps[this.activeStep].nextLabel = this.applyLabelText;
            this.subscribeApplyLabel();
        }
    }

    private assignSameEntitiesToSelectedUsers(): void {
        const lastStepFormGroup = this.getStepForm(this.activeStep);
        const lastStepFormGroupValue = lastStepFormGroup.value;
        const activeAccordion = lastStepFormGroupValue.activeAccordion;
        const activeTab = lastStepFormGroupValue.activeTabId;
        if (activeAccordion < 0 || activeTab < 0) {
            return;
        }
        const users = lastStepFormGroupValue.users;
        const roles = lastStepFormGroupValue.roles;
        const activeUser = users[activeTab];
        const activeRole = roles[activeAccordion];
        if (activeRole === undefined) {
            lastStepFormGroup.controls['activeTabId'].setValue(this.activetabindex++);
            return;
        }
        const userRoleKey = this.getUserRoleKey(activeUser, activeRole);
        const checkboxControl = lastStepFormGroup.controls.userToApplySameCheckbox.get(userRoleKey);
        if (checkboxControl?.value) {
            const userEntities = lastStepFormGroup.controls.userEntities as FormGroup;
            const activeUserRoleEntities = userEntities.get(userRoleKey)?.value;
            Object.keys(userEntities.controls).forEach((key) => {
                if (key.endsWith(activeRole.role_id)) {
                    userEntities.controls[key].setValue(activeUserRoleEntities);
                }
            });
            const userEntitiesValue = lastStepFormGroup.controls.userEntities.value;
            this.store$.dispatch(selectEntities({ payload: userEntitiesValue }));
        }
    }

    private getUserRoleKey(user: User, role: Role): string {
        const roleInputMultiselect = {
            id: role.role_id.toString(),
            label: role.role,
            isSelected: false
        };
        return configComponent.generateUserRoleControlKey(user, roleInputMultiselect);
    }

    private addUserRoleAssignmentWithEntityGroup(): void {
        this.associationInProgress = true;
        const lastStepFormValue = this.getStepForm(1).value;
        this.subscribeUsersRoleEntitiesAssignedState();
        const userIdToEntityGroups = lastStepFormValue.userEntities;
        this.store$.dispatch(roleManagementUsersRoleEntitiesAssignAction({ userIdToEntityGroups }));
    }

    private doAllUserHaveEntitiesAssociation(): boolean {
        const lastStepNumber = this.wizardConfig.steps.length - 1;
        const userEntitiesFormGroup = this.getStepForm(lastStepNumber).controls.userEntities as FormGroup;
        const controlKeys = Object.keys(userEntitiesFormGroup.controls);
        return controlKeys.length && controlKeys.every((key) => !!userEntitiesFormGroup.controls[key].value?.length);
    }

    private subscribeUsersRoleEntitiesAssignedState(): void {
        this.actionsListener$
            .pipe(ofType(roleManagementUsersRoleEntitiesAssignSuccessAction, roleManagementUsersRoleEntitiesAssignFailureAction), take(1))
            .subscribe((result) => {
                this.associationInProgress = false;
                if (!(result as any).errorMessage) {
                    this.hasCompletedWithoutErrors = true;
                    this.closeWizardModal();
                }
            });
    }

    private subscribeSelectedUsers(): void {
        this.selectedUsers$
            .pipe(takeUntil(this._destroyed$))
            .subscribe(users => {
                this.selectedUsers.setValue(users);
                this.hydrateUserEntities();
            });
    }

    private subscribeApplyLabel(): void {
        this.isAssigningRoleToUser$
            .pipe(takeUntil(this._destroyed$))
            .subscribe(loading => {
                this.applyLabelText = this.translate.instant(`userRolesModule.newRoleWizardComponent.apply${loading ? 'ing' : ''}Label`);
                this.wizardConfig.steps[this.activeStep].nextLabel = this.applyLabelText;
            });
    }

    private hydrateUserEntities(): void {
        const selectedEntities = this.userEntities.value;
        Object.keys(selectedEntities).forEach(key => {
            const userId = key.split(USER_TO_ROLE_SEPARATOR)[0];
            if (!this.selectedUsers?.value.some(user => user.sf_contact_id === userId)) {
                this.userEntities.removeControl(key);
            }
        });
    }

    private lastStepFormValidation(): ValidatorFn {
        const component = this;
        return (form: FormGroup): ValidationErrors | null => {
            if (!component.isInlastStep) {
                return null;
            }
            const activeTabId = form.get('activeTabId').value;
            const activeAccordion = form.get('activeAccordion').value;
            const userEntities = form.get('userEntities').value || {};
            if (activeTabId < 0 || activeAccordion < 0) {
                return Object.keys(userEntities).some((key) => !userEntities[key].length) ? { invalid: true } : null;
            }
            const users = form.get('users').value || [];
            const roles = form.get('roles').value || [];
            const activeUser = users[activeTabId];
            const activeRole = roles[activeAccordion];
            return activeUser && activeRole && userEntities[this.getUserRoleKey(activeUser, activeRole)]?.length ?
                null : { invalid: true };
        };
    }
}
