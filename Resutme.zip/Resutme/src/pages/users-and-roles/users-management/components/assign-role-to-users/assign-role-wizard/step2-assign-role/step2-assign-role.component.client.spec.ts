/* tslint:disable:no-unused-variable */
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { USER_TO_ROLE_SEPARATOR } from 'src/pages/users-and-roles/roles-management/interfaces/role-management.params';

import { RoleEntitiesAccordion } from '../../../../../../../features/entity-selector/role-entities-accordion/role-entities-accordion.component';
import { User } from '../../../../../users-management/interfaces/user.model';
import { initialState } from '../../../../../users-management/state/user-management.reducers';
import {
    selectAssignRolesToUsersSelected,
    selectedUserManagementState
} from '../../../../../users-management/state/user-management.selectors';
import { UserDetailsDisplayComponent } from '../../user-details-display/user-details-display.component';

import { Step2AssignRoleComponent } from './step2-assign-role.component';

describe('Step2AssignRoleComponent', () => {
    let component: Step2AssignRoleComponent;
    let fixture: ComponentFixture<Step2AssignRoleComponent>;
    let store$: MockStore;

    const mockedUser: User = {
        contact_id: '1',
        contact_name: 'one',
        email: '',
        roles: [],
        sf_contact_id: '1'
    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                Step2AssignRoleComponent,
                UserDetailsDisplayComponent,
                RoleEntitiesAccordion
            ],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState,
                    selectors: [
                        {
                            selector: selectAssignRolesToUsersSelected,
                            value: { total: 0, selected: [] }
                        },
                        {
                            selector: selectedUserManagementState,
                            value: [
                                {
                                    contact_id: '1',
                                    sf_contact_id: 'sf1',
                                    contact_name: 'contact name',
                                    email: 'contact@name.com',
                                    roles: [
                                        {
                                            role_color: '#005B92',
                                            role_id: 344,
                                            role_name: '110wow'
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store$ = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(Step2AssignRoleComponent);
        component = fixture.componentInstance;

        component.stepForm = new FormGroup({
            users: new FormControl({ value: [], disabled: false }, [Validators.required]),
            activeAccordion: new FormControl({ value: 0, disabled: false }),
            userEntities: new FormGroup({}),
            activeTabId: new FormControl({ value: 0, disabled: false })
        });

        component.activeTabId = 0;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should change active accordion value', () => {
        const actionSpy = spyOn(store$, 'dispatch');
        const index = 1;
        const roleId = '344';
        component.onToggleEvent(roleId, index);
        expect(component.activeUsersAccordion).toBe(index);
        expect(actionSpy).toHaveBeenCalled();
    });

    it('should call onSelectedTab', () => {
        component.onSelectedTab(1);
        fixture.detectChanges();
        expect(component.activeTabId).toEqual(1);
    });

    it('should call convertUserToInputMultiselectItem', () => {
        const newUser = component.convertUserToInputMultiselectItem(mockedUser);
        fixture.detectChanges();
        expect(newUser).toEqual({
            id: '1',
            label: 'one',
            isSelected: true
        });
    });

    it('should call generateUserRoleControlKey', () => {
        const userKey = component.generateUserRoleControlKey(mockedUser, {
            id: '1',
            isSelected: false,
            label: 'R1'
        });
        expect(userKey).toEqual(`1${USER_TO_ROLE_SEPARATOR}1`);
    });

    it('should change active accordion value on Next', () => {
        fixture.detectChanges();
        expect(component.activeUsersAccordion).toBe(0);
    });

    it('should recreate controls', () => {
        const users = [
            {
                contact_id: '1',
                sf_contact_id: 'user1',
                contact_name: 'User 1',
                email: '',
                roles: []
            },
            {
                contact_id: '2',
                sf_contact_id: 'user2',
                contact_name: 'User 2',
                email: '',
                roles: []
            }
        ];
        const roles = [
            {
                role_id: 1,
                role: 'Test role 1',
                type: 'S',
                created_date: '',
                created_by: ''
            },
            {
                role_id: 2,
                role: 'Test role 2',
                type: 'S',
                created_date: '',
                created_by: ''
            }
        ];
        const selectedRoles = roles.map((role) => {
            return {
                id: role.role_id.toString(),
                label: role.role,
                isSelected: false
            };
        });

        component.stepForm = new FormGroup({
            users: new FormControl(users),
            roles: new FormControl(roles),
            activeAccordion: new FormControl(0),
            activeTabId: new FormControl(0),
            userEntities: new FormGroup({}),
            userToApplySameCheckbox: new FormGroup({
                [component.generateUserRoleControlKey(users[1], selectedRoles[1])]: new FormControl(true)
            })
        });
        component.selectedRoles = selectedRoles;

        component['recreateControls']();
        fixture.detectChanges();

        const expectedUserEntitiesControls = users.length * roles.length;
        const expectedCheckboxControls = roles.length;
        expect(Object.keys(component.userEntitiesFormGroup.controls).length).toBe(expectedUserEntitiesControls);
        expect(Object.keys(component.userToApplySameCheckboxFormGroup.controls).length).toBe(expectedCheckboxControls);
    });
});
