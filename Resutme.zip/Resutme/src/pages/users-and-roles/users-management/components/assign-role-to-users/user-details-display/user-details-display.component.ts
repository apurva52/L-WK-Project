import { GridOptions } from '@ag-grid-community/core';
import { Component, Input } from '@angular/core';
import { CTGridColumnDefinition } from '@ct/platform-primitives-uicomponents/grid';

import { AvatarRendererComponent } from '../../../avatar-renderer/avatar-renderer';
import { User } from '../../../interfaces/user.model';
import { RolesPillsRendererComponent } from '../../../roles-pills-renderer/roles-pills-renderer.component';

@Component({
    selector: 'ct-user-details-display',
    templateUrl: './user-details-display.component.html',
    styleUrls: ['./user-details-display.component.scss']
})
export class UserDetailsDisplayComponent {
    _user: User;
    @Input()
    set user(value: User) {
        this._user = value;
    }

    get user(): User {
        return this._user;
    }

    customCellRendererComponents = {
        rolesPillsRenderer: RolesPillsRendererComponent,
        avatarRenderer: AvatarRendererComponent
    };

    gridDefinition: Array<CTGridColumnDefinition> = [
        {
            colDef: {
                headerName: 'Name',
                field: 'contact_name'
            },
            cellRendererOptions: {
                useCellRenderer: 'avatarRenderer'
            },
            cellRenderedParams: {
                showAvatar: true
            },
            dataType: 'CUSTOM'
        },
        {
            colDef: {
                headerName: 'Job Title',
                field: 'job_title'
            },
            dataType: 'CUSTOM'
        },
        {
            colDef: {
                headerName: 'Roles',
                field: 'roles',
                cellStyle: {
                    overflow: 'visible',
                    'z-index': 2
                },
                keyCreator: (params) =>
                    params.data.roles.map((role) => role.role_name)
            },
            cellRendererOptions: {
                useCellRenderer: 'rolesPillsRenderer'
            },
            dataType: 'CUSTOM'
        }
    ];

    gridOptions: GridOptions = {
        suppressCellSelection: true,
        suppressMenuHide: true,
        suppressDragLeaveHidesColumns: true,
        suppressMultiRangeSelection: true,
        suppressRowClickSelection: true,
        suppressRowHoverHighlight: true,
        suppressContextMenu: true,
        defaultColDef: {
            headerCheckboxSelection: false,
            suppressMenu: true,
            resizable: false,
            sortable: false,
            filter: false
        }
    };
}
