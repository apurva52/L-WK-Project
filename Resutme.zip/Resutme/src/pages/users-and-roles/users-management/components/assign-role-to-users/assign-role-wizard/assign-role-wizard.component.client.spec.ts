// tslint:disable max-file-line-count
// tslint:disable:max-line-length
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormArray, FormControl, FormGroup } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { USER_TO_ROLE_SEPARATOR } from 'src/pages/users-and-roles/roles-management/interfaces/role-management.params';

import { initialState } from '../../../state/user-management.reducers';
import {
    selectAssignRolesWizardNextDisabled,
    selectedUserManagementState,
    selectShouldShowRemoveUserWarning
} from '../../../state/user-management.selectors';
import { UserManagementState } from '../../../state/user-management.state';

import { isAssigningRoleToUser } from './../../../../roles-management/state/role-management.selectors';
import { AssignRoleWizardComponent } from './assign-role-wizard.component';

describe('AssignRoleWizardComponent', () => {
    let component: AssignRoleWizardComponent;
    let fixture: ComponentFixture<AssignRoleWizardComponent>;
    let store$: MockStore<UserManagementState>;
    const mockedRoles = [
        {
            role_id: 1,
            role: 'Testing',
            type: 'I'
        },
        {
            role_id: 2,
            role: 'Testing 2',
            type: 'I'
        }
    ];

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [AssignRoleWizardComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState,
                    selectors: [
                        {
                            selector: selectAssignRolesWizardNextDisabled,
                            value: false
                        },
                        {
                            selector: selectShouldShowRemoveUserWarning,
                            value: false
                        },
                        { selector: selectedUserManagementState, value: [
                            {
                                contact_id: '123',
                                sf_contact_id: 'sf123',
                                contact_name: 'user1',
                                email: 'mail@mail.com',
                                roles: []
                            }
                        ]}, {
                            selector: isAssigningRoleToUser, value: false
                        }
                    ]
                }),
                TranslateService,
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store$ = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AssignRoleWizardComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should increase step by 1 onNext', () => {
        component.activeStep = 0;
        component.onNext();
        fixture.detectChanges();
        expect(component.activeStep).toEqual(1);
    });

    it('should submit step 2', () => {
        component.activeStep = 1;
        component.getStepForm(1).controls.activeAccordion.setValue(-1);
        component.onNext();
        fixture.detectChanges();
        expect(component.activeStep).toEqual(1);
    });

    it('should submit step 2', () => {
        component.activeStep = 1;
        component.getStepForm(component.activeStep).controls.activeAccordion?.setValue(-1);
        component.wizardConfig.steps[component.activeStep].nextLabel = 'userRolesModule.newRoleWizardComponent.applyLabel';

        const handleSpy = spyOn(component as any, 'doAllUserHaveEntitiesAssociation');
        handleSpy.and.callFake(() => {
            return new Promise((resolve) => {
                resolve(true);
            });
        });

        component.onNext();
        fixture.detectChanges();
        expect(component.activeStep).toEqual(1);
    });

    it('should decrease step by 1 onPrevious', () => {
        component.activeStep = 1;
        component.activetabindex = 1;
        component.onPrevious();
        fixture.detectChanges();
        expect(component.activeStep).toEqual(0);
    });

    it('should dispatch action when closing modal', () => {
        const actionSpy = spyOn(store$, 'dispatch');
        component.closeWizardModal();
        fixture.detectChanges();
        expect(actionSpy).toHaveBeenCalled();
    });

    it('should dispatch action when remove warning visible cancel modal', () => {
        const actionSpy = spyOn(store$, 'dispatch');
        component.onRemoveWarningVisibleCancel();
        fixture.detectChanges();
        expect(actionSpy).toHaveBeenCalled();
    });

    it('ngOnDestroy', () => {
        component.isRemoveWarningVisible$ = new Subscription();
        spyOn(component.isRemoveWarningVisible$, 'unsubscribe');
        component.ngOnDestroy();
        expect(component.isRemoveWarningVisible$.unsubscribe).toHaveBeenCalled();
    });

    it('should apply same entities for all selected users', () => {
        const secondStepNumber = 1;
        const users = [
            {
                contact_id: '1',
                sf_contact_id: 'user1',
                contact_name: 'User 1',
                email: '',
                roles: []
            },
            {
                contact_id: '2',
                sf_contact_id: 'user2',
                contact_name: 'User 2',
                email: '',
                roles: []
            }
        ];
        const roles = [
            {
                role_id: 1,
                role: 'Test role 1',
                type: 'S',
                created_date: '',
                created_by: ''
            }
        ];
        const entities = [
            {
                edh_entity_group_id: 1,
                edh_entity_group_guid: '1',
                edh_entity_group_name: 'Group 1',
                edh_entity_group_type: 'I',
                entities: [
                    {
                        entity_id: 1,
                        entity_guid: '1',
                        entity_name: 'Entity 1',
                        entity_country: 'Test',
                        domestic_jurisdiction: 'Test'
                    }
                ]
            }
        ];

        component.activeStep = secondStepNumber;
        component.getStepForm(secondStepNumber).controls.activeAccordion.setValue(0);
        component.getStepForm(secondStepNumber).controls.activeTabId.setValue(0);
        component.getStepForm(secondStepNumber).controls.users.setValue(users);
        component.getStepForm(secondStepNumber).controls.roles.setValue(roles);

        const userEntitiesFormGroup = component.getStepForm(secondStepNumber).controls.userEntities as FormGroup;
        const userToApplySameCheckboxFromGroup = component.getStepForm(secondStepNumber).controls.userToApplySameCheckbox as FormGroup;
        users.forEach((user, userIndex) => {
            roles.forEach((role) => {
                userEntitiesFormGroup.addControl((component as any).getUserRoleKey(user, role), new FormControl(userIndex === 0 ? entities : []));
            });
        });
        userToApplySameCheckboxFromGroup.addControl((component as any).getUserRoleKey(users[0], roles[0]), new FormControl(true));
        component.onNext();

        Object.keys(userEntitiesFormGroup.controls).forEach((key) => {
            expect(userEntitiesFormGroup.controls[key].value).toEqual(entities);
        });
    });

    it('should submit step 2 when all accordions are collapsed', () => {
        component.activeStep = 1;
        component.getStepForm(1).controls.activeAccordion.setValue(2);
        component.onNext();
        fixture.detectChanges();
        expect(component.activeStep).toEqual(1);
    });

    it('should dispatch actions to close modal and open add new role modal', () => {
        const dispatchSpy = spyOn(store$, 'dispatch');
        component.openAddNewRoleModal();
        fixture.detectChanges();
        expect(dispatchSpy).toHaveBeenCalled();
    });

    it('should addUserRoleAssignmentWithEntityGroup', () => {
        const spy = spyOn(store$, 'dispatch');
        component.activeStep = 1;
        component.form = new FormArray([
            new FormGroup({}),
            new FormGroup({
                userEntities: new FormGroup({
                    [`user1${USER_TO_ROLE_SEPARATOR}223`]: new FormControl()
                })
            })
        ]);
        component['addUserRoleAssignmentWithEntityGroup']();

        expect(spy).toHaveBeenCalled();
    });

    describe('should navigate accordions and tabs', () => {
        beforeEach(() => {
            component.assignRoleToUsersStepsPayload = [
                { isActive: true, isVisited: true, stepId: 1, description: 'Step 1', isFailed: false},
                { isActive: true, isVisited: true, stepId: 2, description: 'Step 2', isFailed: false}
            ];

            component.form = new FormArray([
                new FormGroup({}),
                new FormGroup({
                    userEntities: new FormGroup({
                        [`user1${USER_TO_ROLE_SEPARATOR}223`]: new FormControl()
                    }),
                    activeTabId: new FormControl(2),
                    activeAccordion: new FormControl(2),
                    users: new FormControl({value: [
                        {
                            contact_id: '1',
                            sf_contact_id: 'user1',
                            contact_name: 'User 1',
                            email: '',
                            roles: []
                        },
                        {
                            contact_id: '2',
                            sf_contact_id: 'user2',
                            contact_name: 'User 2',
                            email: '',
                            roles: []
                        }
                    ]}),
                    roles: new FormControl([
                        {
                            role_id: 1,
                            role: 'Testing',
                            type: 'I'
                        },
                        {
                            role_id: 2,
                            role: 'Testing 2',
                            type: 'I'
                        },
                        {
                            role_id: 3,
                            role: 'Testing 3',
                            type: 'I'
                        },
                        {
                            role_id: 4,
                            role: 'Testing 4',
                            type: 'I'
                        }
                        ])
                })
            ]);
            component.activeStep = 1;
            fixture.detectChanges();
        });

        it('should navigate back', () => {
            component.onPrevious();
            expect(component.activeAccordion.value).toBe(1);
            component.onPrevious();
            expect(component.activeAccordion.value).toBe(0);
            component.onPrevious();
            expect(component.activeTab.value).toBe(1);
        });

        it('should navigate forward', () => {
            const NEXT_ACTIVE_ACCORDION = 3;
            component['navigateForward']();
            expect(component.activeAccordion.value).toBe(NEXT_ACTIVE_ACCORDION);
        });

        it('should navigate forward to next tab', () => {
            component.form = new FormArray([
                new FormGroup({}),
                new FormGroup({
                    userEntities: new FormGroup({
                        [`user1${USER_TO_ROLE_SEPARATOR}223`]: new FormControl()
                    }),
                    activeTabId: new FormControl(0),
                    activeAccordion: new FormControl(1),
                    users: new FormControl([
                        {
                            contact_id: '1',
                            sf_contact_id: 'user1',
                            contact_name: 'User 1',
                            email: '',
                            roles: []
                        },
                        {
                            contact_id: '2',
                            sf_contact_id: 'user2',
                            contact_name: 'User 2',
                            email: '',
                            roles: []
                        }
                    ]),
                    roles: new FormControl([
                            {
                                role_id: 1,
                                role: 'Testing',
                                type: 'I'
                            },
                            {
                                role_id: 2,
                                role: 'Testing 2',
                                type: 'I'
                            }
                        ])
                })
            ]);

            component['navigateForward']();
            expect(component.activeAccordion.value).toBe(0);
            expect(component.activeTab.value).toBe(1);
         });

        it(' should hydrate selected users', () => {
            const TOTAL_LENGTH = 4;
            component.form = new FormArray([
                new FormGroup({}),
                new FormGroup({
                    userEntities: new FormGroup({
                        [`user1${USER_TO_ROLE_SEPARATOR}1`]: new FormControl(),
                        [`user1${USER_TO_ROLE_SEPARATOR}2`]: new FormControl(),
                        [`user2${USER_TO_ROLE_SEPARATOR}1`]: new FormControl(),
                        [`user2${USER_TO_ROLE_SEPARATOR}2`]: new FormControl(),
                        [`user3${USER_TO_ROLE_SEPARATOR}1`]: new FormControl(),
                        [`user3${USER_TO_ROLE_SEPARATOR}2`]: new FormControl(),
                        [`user3${USER_TO_ROLE_SEPARATOR}3`]: new FormControl()
                    }),
                    activeTabId: new FormControl(0),
                    activeAccordion: new FormControl(1),
                    users: new FormControl([
                        {
                            contact_id: '1',
                            sf_contact_id: 'user1',
                            contact_name: 'User 1',
                            email: '',
                            roles: []
                        },
                        {
                            contact_id: '2',
                            sf_contact_id: 'user2',
                            contact_name: 'User 2',
                            email: '',
                            roles: []
                        }
                    ]),
                    roles: new FormControl([
                            {
                                role_id: 1,
                                role: 'Testing',
                                type: 'I'
                            },
                            {
                                role_id: 2,
                                role: 'Testing 2',
                                type: 'I'
                            }
                        ])

                })
            ]);
            fixture.detectChanges();
            component['hydrateUserEntities']();
            expect(Object.entries(component.userEntities.value).length).toBe(TOTAL_LENGTH);
         });
    });
    describe('warning messages', () => {
        beforeEach(() => {
            component.activeStep = 0;
            component.form = new FormArray([
                new FormGroup({}),
                new FormGroup({
                    userEntities: new FormGroup({
                        [`user1${USER_TO_ROLE_SEPARATOR}1`]: new FormControl(),
                        [`user1${USER_TO_ROLE_SEPARATOR}2`]: new FormControl(),
                        [`user2${USER_TO_ROLE_SEPARATOR}1`]: new FormControl(),
                        [`user2${USER_TO_ROLE_SEPARATOR}2`]: new FormControl(),
                        [`user3${USER_TO_ROLE_SEPARATOR}1`]: new FormControl(),
                        [`user3${USER_TO_ROLE_SEPARATOR}2`]: new FormControl(),
                        [`user3${USER_TO_ROLE_SEPARATOR}3`]: new FormControl()
                    }),
                    activeTabId: new FormControl(0),
                    activeAccordion: new FormControl(1),
                    users: new FormControl([
                        {
                            contact_id: '1',
                            sf_contact_id: 'user1',
                            contact_name: 'User 1',
                            email: '',
                            roles: mockedRoles
                        },
                        {
                            contact_id: '2',
                            sf_contact_id: 'user2',
                            contact_name: 'User 2',
                            email: '',
                            roles: []
                        }
                    ]),
                    roles: new FormControl(mockedRoles)
                })
            ]);
        });
        it('should prompt duplicates warning', () => {
            component.onNext();
            expect(component.isInlastStep).toBeFalsy();
        });
        it('should prompt duplicates warning multiple users', () => {
            component.form.at(1).get('users').patchValue([
                {
                    contact_id: '1',
                    sf_contact_id: 'user1',
                    contact_name: 'User 1',
                    email: '',
                    roles: mockedRoles
                },
                {
                    contact_id: '2',
                    sf_contact_id: 'user2',
                    contact_name: 'User 2',
                    email: '',
                    roles: mockedRoles
                }
            ]);
            component.onNext();
            expect(component.isInlastStep).toBeFalsy();
        });
    });

    it('should construct user-role key', () => {
        const user = {
            contact_id: '1',
            sf_contact_id: 'user1',
            contact_name: 'User 1',
            email: '',
            roles: []
        };
        const role = {
            role_id: 1,
            role: 'Test role 1',
            type: 'S',
            created_date: '',
            created_by: ''
        } as any;
        const value = component['getUserRoleKey'](user, role);
        expect(value).toBe(`${user.sf_contact_id}${USER_TO_ROLE_SEPARATOR}${role.role_id}`);
    });

    it('should validate last step form', () => {
        const users = [{
            contact_id: '1',
            sf_contact_id: 'user1',
            contact_name: 'User 1',
            email: '',
            roles: []
        }];
        const roles: Array<any> = [
            {
                role_id: 1,
                role: 'Test role 1',
                type: 'S',
                created_date: '',
                created_by: ''
            },
            {
                role_id: 2,
                role: 'Test role 2',
                type: 'S',
                created_date: '',
                created_by: ''
            }
        ];
        const entities = [{
            edh_entity_group_id: 1,
            edh_entity_group_guid: '1',
            edh_entity_group_name: 'Group 1',
            edh_entity_group_type: 'I',
            entities: [{
                entity_id: 1,
                entity_guid: '1',
                entity_name: 'Entity 1',
                entity_country: 'Test',
                domestic_jurisdiction: 'Test'
            }]
        }];
        users.forEach((user) => {
            roles.forEach((role) => {
                component.userEntities.addControl(component['getUserRoleKey'](user, role), new FormControl([]));
            });
        });
        component.selectedUsers.setValue(users);
        component.selectedRoles.setValue(roles);
        const lastStepForm = component.getStepForm(1);
        component.activeStep = 0;
        fixture.detectChanges();
        expect(lastStepForm.valid).toBe(true);
        component.activeStep = 1;
        component.activeAccordion.setValue(-1);
        fixture.detectChanges();
        expect(lastStepForm.valid).toBe(false);
        component.activeAccordion.setValue(0);
        fixture.detectChanges();
        expect(lastStepForm.valid).toBe(false);
        component.userEntities.get(component['getUserRoleKey'](users[0], roles[0])).setValue(entities);
        fixture.detectChanges();
        expect(lastStepForm.valid).toBe(true);
        Object.keys(component.userEntities.controls).forEach(key => component.userEntities.get(key).setValue(entities));
        component.activeAccordion.setValue(-1);
        fixture.detectChanges();
        expect(lastStepForm.valid).toBe(true);
    });

    it('should show cancel confirmation modal', () => {
        spyOn(component, 'getStepForm').and.returnValue({
            value: {
                roles: ['TEST']
            }
        } as any);
        spyOn(component, 'closeWizardModal');
        component.activeStep = 1;
        component.validateCancelModal();
        expect(component.isCancelNotificationVisible).toBeTruthy();
    });

    it('should close modoal due to be in step 1', () => {
        spyOn(component, 'closeWizardModal');
        spyOn(component, 'getStepForm').and.returnValue({
            value: {
                roles: []
            }
        } as any);
        component.activeStep = 0;
        component.validateCancelModal();
        expect(component.isCancelNotificationVisible).toBeFalsy();
        expect(component.closeWizardModal).toHaveBeenCalled();
    });

    it('should not assign roles for internal', () => {
        component.isInternal = true;
        const users = [{
            contact_id: '1',
            sf_contact_id: 'user1',
            contact_name: 'User 1',
            email: '',
            roles: mockedRoles
        }];
        component.selectedUsers.setValue(users);
        component.selectedRoles.setValue(mockedRoles);
        fixture.detectChanges();
        const actionSpy = spyOn(store$, 'dispatch');
        component.onNext();
        expect(component.isDuplicatesWarningVisible).toBeTruthy();
        expect(actionSpy).not.toHaveBeenCalled();
    });

    it('should assign roles for internal', () => {
        component.isInternal = true;
        const users = [{
            contact_id: '1',
            sf_contact_id: 'user1',
            contact_name: 'User 1',
            email: '',
            roles: []
        }];
        component.ngOnInit();
        component.selectedUsers.setValue(users);
        component.selectedRoles.setValue(mockedRoles);
        fixture.detectChanges();
        expect(component.assignRoleToUsersStepsPayload).toEqual([]);
        const actionSpy = spyOn(store$, 'dispatch');
        component.onNext();
        fixture.detectChanges();
        expect(Object.keys(component.userEntities.controls).length).toBe(
            component.selectedUsers.value.length * component.selectedRoles.value.length
        );
        expect(actionSpy).toHaveBeenCalled();
    });
});
