import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { NotificationModel } from '@ct/platform-primitives-uicomponents/primitives';
import { ActionsSubject } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { roleManagementSuccessAction } from 'src/pages/users-and-roles/roles-management/state/role-management.actions';
import { ModulePermissionsService } from 'src/shared/services/module-permissions/module-permissions.service';

import { selectRoleManagementStateData } from '../../../../../roles-management/state/role-management.selectors';
import { initialState } from '../../../../state/user-management.reducers';
import { selectedUsersManagement } from '../../../../state/user-management.selectors';
import { UserManagementState } from '../../../../state/user-management.state';

import { Step1AssignRoleComponent } from './step1-assign-role.component';

describe('Step1AssignRoleComponent', () => {
    let component: Step1AssignRoleComponent;
    let fixture: ComponentFixture<Step1AssignRoleComponent>;
    let store$: MockStore<UserManagementState>;
    const actionSub: ActionsSubject = new ActionsSubject();
    const mockWarningMessage: NotificationModel = {
        title: 'Warning',
        content: 'Warning message',
        confirmationText: 'Ok'
    };
    const modulePermissionsServiceMock = jasmine.createSpyObj<any>([
        'doesUserHasPermission',
        'doesNotUserHasPermission'
    ]);

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [Step1AssignRoleComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                { provide: ActionsSubject, useValue: actionSub },
                provideMockStore({
                    initialState,
                    selectors: [
                        {
                            selector: selectRoleManagementStateData,
                            value: { total: 0, selected: [] }
                        },
                        { selector: selectedUsersManagement, value: [] }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                },
                {
                    provide: ModulePermissionsService,
                    useValue: modulePermissionsServiceMock
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store$ = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(Step1AssignRoleComponent);
        component = fixture.componentInstance;
        modulePermissionsServiceMock.doesUserHasPermission.and.returnValue(
            true
        );

        component.stepForm = new FormGroup({
            users: new FormControl({ value: [], disabled: false }, [
                Validators.required
            ]),
            roles: new FormControl({ value: [], disabled: false }, [
                Validators.required
            ]),
            activeAccordion: new FormControl({ value: 0, disabled: false }),
            userEntities: new FormGroup({})
        });

        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should dispatch action when pill clicked', () => {
        const actionSpy = spyOn(store$, 'dispatch');
        component.onPillClicked(null);
        fixture.detectChanges();
        expect(actionSpy).toHaveBeenCalled();
    });

    it('should dispatch action when onSelectionChange', () => {
        const actionSpy = spyOn(store$, 'dispatch');
        component.onSelectionChange({ total: 0, selected: [] });
        fixture.detectChanges();
        expect(actionSpy).toHaveBeenCalled();
    });

    it('should fire grid ready', () => {
        const gridApiEvent = {
            api: {
                showLoadingOverlay: jasmine.createSpy()
            }
        };
        component.onGridReady(gridApiEvent);
        expect(component['gridApi']).toBeDefined();
    });
    it('should select elements of current form value', () => {
        component.stepForm.get('roles').setValue([
            {
                role_id: 2761,
                role: 'aaa1',
                type: 'I',
                created_date: '2022-12-12T11:26:28',
                created_by: '0032f00000exrMWAAY',
                created_by_name: 'Reema Sahoo',
                last_modified_date: '2022-12-12T11:26:28',
                last_modified_by: '0032f00000exrMWAAY',
                last_modified_by_name: 'Reema Sahoo'
            },
            {
                role_id: 7466,
                role: 'AAATest2',
                type: 'C',
                created_date: '2023-02-01T12:46:37',
                created_by: '0032f00000eMqW9AAK',
                created_by_name: 'shalini testenv',
                last_modified_date: '2023-02-01T12:46:37',
                last_modified_by: '0032f00000eMqW9AAK',
                last_modified_by_name: 'shalini testenv'
            }
        ]);
        component['gridApi'] = {
            getRowNode: jasmine
                .createSpy()
                .and.returnValue({ setSelected: jasmine.createSpy() })
        } as any;
        component.ngOnInit();
        const actionSubject = TestBed.inject(ActionsSubject) as ActionsSubject;
        actionSubject.next(roleManagementSuccessAction({ response: null }));
        expect(component).toBeTruthy();
    });
    it('should emit close Warning message', () => {
        spyOn(component.warningClosed, 'emit');
        component.warningNotification = mockWarningMessage;
        component.isNotificationVisible = true;
        component.onConfirmNotification();
        expect(component.warningClosed.emit).toHaveBeenCalled();
    });

    it('should load the data', async () => {
        const params: any = {
            successCallback: (
                rowsThisBlock: Array<any>,
                lastRow?: number
            ): void => {},
            startRow: 0,
            endRow: component.GRID_MAX_ELEMENTS,
            sortModel: [{ sort: 'asc', sortBy: 'name', colId: 'role' }]
        };
        const serviceEmptyResultMock: any = {
            data: [],
            totalRecordCount: 0,
            page: 1,
            pageSize: component.GRID_MAX_ELEMENTS,
            totalPages: 1
        };
        const totalPages = 2;
        const serviceResultMock: any = {
            data: Array.from(Array(component.GRID_MAX_ELEMENTS), (_, i) => ({
                role_id: i,
                role: `${i}`
            })),
            totalRecordCount: component.GRID_MAX_ELEMENTS * totalPages,
            page: 1,
            pageSize: component.GRID_MAX_ELEMENTS,
            totalPages: totalPages
        };
        const dispatchSpy = spyOn(store$, 'dispatch').and.callThrough();
        const successCallbackSpy = spyOn(
            params,
            'successCallback'
        ).and.callThrough();
        const getRolesListSpy = spyOn(
            component['authorizationManagementService'],
            'getRolesList'
        );
        const expectedCallsCount = 2;

        getRolesListSpy.and.callFake((...params) =>
            Promise.resolve(serviceResultMock)
        );
        await component.onLoadRoles(params);
        expect(successCallbackSpy).toHaveBeenCalledWith(
            serviceResultMock.data,
            jasmine.any(Number)
        );
        expect(params.sortModel[0].colId).toEqual('role');
        getRolesListSpy.and.callFake((...params) =>
            Promise.resolve(serviceEmptyResultMock)
        );
        await component.onLoadRoles(params);
        expect(successCallbackSpy).toHaveBeenCalledWith(
            serviceEmptyResultMock.data,
            jasmine.any(Number)
        );
        expect(dispatchSpy).toHaveBeenCalledTimes(expectedCallsCount);
        expect(successCallbackSpy).toHaveBeenCalledTimes(expectedCallsCount);

        const updatedParams = {
            ...params,
            sortModel: [{ sort: 'asc', sortBy: 'name', colId: 'created_by' }]
        };
        await component.onLoadRoles(updatedParams);
        expect(updatedParams.sortModel[0].colId).toEqual('created_by');
    });
});
