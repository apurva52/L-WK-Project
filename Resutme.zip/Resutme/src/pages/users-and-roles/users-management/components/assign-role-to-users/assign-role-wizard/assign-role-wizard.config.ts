import { FormControl, FormGroup } from '@angular/forms';
import { WizardConfiguration } from '@ct/platform-primitives-uicomponents/modals';
import { Step } from '@ct/platform-primitives-uicomponents/primitives';
import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';
import { TranslateService } from '@ngx-translate/core';
import { USER_TO_ROLE_SEPARATOR } from 'src/pages/users-and-roles/roles-management/interfaces/role-management.params';

import { User } from '../../../interfaces/user.model';

export const step2Index = 1;

export function getAssignRolesToUsersStepsPayload(isInternal: boolean = false): Array<Step> {
    if (isInternal) {
        return [];
    }
    return [
        {
            isActive: true,
            isFailed: false,
            isVisited: false,
            stepId: 1,
            description: ''
        },
        {
            isActive: true,
            isFailed: false,
            isVisited: false,
            stepId: 2,
            description: ''
        }
    ];
}

export function setWizardConfig(translate: TranslateService, isInternal: boolean = false): WizardConfiguration {
    const config = {
        label: translate.instant('userRolesModule.assignRolesToUsersWizardComponent.title'),
        headerDivider: false,
        cancelToRight: true,
        cancelText: translate.instant('userRolesModule.assignRolesToUsersWizardComponent.cancelLabel'),
        steps: [
            {
                nextLabel: translate.instant('userRolesModule.newRoleWizardComponent.assignLabel'),
                title: translate.instant('userRolesModule.assignRolesToUsersWizardComponent.stepTitle'),
                validation: false,
                previousLabel: translate.instant('userRolesModule.assignRolesToUsersWizardComponent.previousLabel')
            }
        ]
    };
    if (!isInternal) {
        config.steps[0].nextLabel = translate.instant('userRolesModule.assignRolesToUsersWizardComponent.nextLabel');
        config.steps.push({
            nextLabel: translate.instant('userRolesModule.assignRolesToUsersWizardComponent.nextLabel'),
            title: translate.instant('userRolesModule.assignRolesToUsersWizardComponent.step2Title'),
            validation: false,
            previousLabel: translate.instant('userRolesModule.assignRolesToUsersWizardComponent.previousLabel')
        });
    }
    return config;
}

export function generateUserRoleControlKey(user: User, role: InputMultiselectItem): string {
    return `${user.sf_contact_id}${USER_TO_ROLE_SEPARATOR}${role.id}`;
}

export function generateAllUserRoleControlsKeys(users: Array<User>, roles: Array<InputMultiselectItem>): Array<string> {
    const keys = [];
    users.forEach((user) => {
        roles.forEach((role) => {
            keys.push(generateUserRoleControlKey(user, role));
        });
    });
    return keys;
}

export function recreateEntitiesControls(
    users: Array<User>,
    roles: Array<InputMultiselectItem>,
    userEntitiesFormGroup: FormGroup,
    userToApplySameCheckboxFormGroup: FormGroup
): Array<string> {
    const controlKeys = generateAllUserRoleControlsKeys(users, roles);
    const removedControlKeys = [];
    Object.keys(userEntitiesFormGroup).forEach((key) => {
        if (!controlKeys.find((existedKey) => existedKey === key)) {
            userEntitiesFormGroup.removeControl(key);
            userToApplySameCheckboxFormGroup.removeControl(key);
            removedControlKeys.push(key);
        }
    });
    users.forEach((user, index) => {
        roles.forEach((role) => {
            const key = generateUserRoleControlKey(user, role);
            if (!userEntitiesFormGroup.get(key)) {
                userEntitiesFormGroup.addControl(key, new FormControl([]));
            }
            if (users.length > 1 && index === 0) {
                userToApplySameCheckboxFormGroup.addControl(key, new FormControl(false));
            } else {
                userToApplySameCheckboxFormGroup.removeControl(key);
            }
        });
    });
    return removedControlKeys;
}
