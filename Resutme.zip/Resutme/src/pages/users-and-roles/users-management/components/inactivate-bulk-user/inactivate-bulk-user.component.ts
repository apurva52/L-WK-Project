import { Component, OnDestroy, OnInit } from '@angular/core';
import { ModalModel } from '@ct/platform-primitives-uicomponents/modals';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { User } from '../../interfaces/user.model';
import {
    userManagementClearSelectAction,
    userManagementDeleteUserAction,
    userManagementDeleteUserSuccessAction,
    userManagementInactivateBulkUserModalAction
} from '../../state/user-management.actions';
import { bulkUserDeleteModalState, inactivatingUserState, selectedUsersManagement } from '../../state/user-management.selectors';
import { UserStatus } from '../../state/user-management.state';

@Component({
    selector: 'ct-inactivate-bulk-user',
    templateUrl: './inactivate-bulk-user.component.html',
    styleUrls: ['./inactivate-bulk-user.component.scss']
})
export class InactivateBulkUserComponent implements OnInit, OnDestroy {

    inactivatingUser$ = this.store$.select(inactivatingUserState);
    deleteBulkUserModalState$ = this.store$.select(bulkUserDeleteModalState);
    selectedUserManagementIdsState$ = this.store$.select(selectedUsersManagement).subscribe(data => {
        this.selectedUsers = data;
    });

    selectedUsers: any;
    modalModel: ModalModel = {
        title: 'userRolesModule.InactivateUserComponent.InactivateBulkUserComponent.title',
        cancelText: 'userRolesModule.InactivateUserComponent.InactivateBulkUserComponent.stayOnPage',
        confirmText: 'userRolesModule.InactivateUserComponent.InactivateBulkUserComponent.confirmButton'
    };

    get activeSelectedUsers(): Array<User> {
        return this.selectedUsers.filter(user => user.status?.toLowerCase() === UserStatus.ACTIVE);
    }

    get activeSelectedUsersAsMessageParams(): any {
        return { '0': this.activeSelectedUsers.map(u => `"${u.contact_name}"`).join(', ') };
    }

    get allSelectedUsersAreActive(): boolean {
        return this.selectedUsers.every((temp => temp.status?.toLowerCase() === UserStatus.ACTIVE));
    }

    private _destroyed$ = new Subject<boolean>();
    constructor(private store$: Store, private actionsListener$: ActionsSubject) { }

    ngOnInit(): void {
        this.inactivatingUser$.pipe(takeUntil(this._destroyed$)).subscribe((inactivating) => {
            this.modalModel.confirmText = `userRolesModule.InactivateUserComponent.InactivateBulkUserComponent.${ inactivating ? 'inactivating' : 'confirmButton' }`;
        });
    }

    ngOnDestroy(): void {
        this._destroyed$.next();
        this._destroyed$.complete();
    }

    onCancelClick(): void {
        this.close();
    }

    onConfirmClick(): void {
        this.activeSelectedUsers.forEach(selectedUser => {
            this.store$.dispatch(userManagementDeleteUserAction({
                user: selectedUser,
                inactivate: true
            }));
        });

        this.actionsListener$.pipe(
            ofType(userManagementDeleteUserSuccessAction),
            takeUntil(this._destroyed$)).subscribe(() => {
                this.close(true);
            });
    }

    private close(clearSelection: boolean = false): void {
        this.store$.dispatch(userManagementInactivateBulkUserModalAction({ isBulkUserModalVisible: false }));
        clearSelection && this.store$.dispatch(userManagementClearSelectAction());
    }
}
