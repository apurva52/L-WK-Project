import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { of } from 'rxjs';

import { initialState } from '../../state/user-management.reducers';
import {
    bulkUserDeleteModalState,
    inactivatingUserState,
    selectedUsersManagement
} from '../../state/user-management.selectors';
import {
    USER_MANAGEMENT_FEATURE_KEY,
    UserManagementState,
    UserStatus
} from '../../state/user-management.state';

import { InactivateBulkUserComponent } from './inactivate-bulk-user.component';

describe('InactivateBulkUserComponent', () => {
    let component: InactivateBulkUserComponent;
    let fixture: ComponentFixture<InactivateBulkUserComponent>;
    let store: MockStore<UserManagementState>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [InactivateBulkUserComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [USER_MANAGEMENT_FEATURE_KEY]: initialState
                    },
                    selectors: [
                        { selector: bulkUserDeleteModalState, value: true },
                        { selector: inactivatingUserState, value: false },
                        { selector: selectedUsersManagement, value: [{}] }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(InactivateBulkUserComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it(`should dispatch close modal`, () => {
        const expectedCallsCount = 2;
        spyOn(store, 'dispatch').and.callThrough();
        component['close']();
        component.onCancelClick();
        expect(store.dispatch).toHaveBeenCalledTimes(expectedCallsCount);
    });

    it(`should dispatch close modal and clear selection`, () => {
        const expectedCallsCount = 2;
        spyOn(store, 'dispatch').and.callThrough();
        component['close'](true);
        expect(store.dispatch).toHaveBeenCalledTimes(expectedCallsCount);
    });

    it(`should dispatch remove role and close modal`, () => {
        spyOn(store, 'dispatch').and.callThrough();
        component.selectedUsers = [{
            sf_contact_id: '1',
            contact_name: '1',
            status: UserStatus.ACTIVE
        }];
        component.onConfirmClick();
        expect(store.dispatch).toHaveBeenCalled();
    });

    it(`should change confirm button to loading`, () => {
        component.inactivatingUser$ = of(true);
        component.ngOnInit();
        component.inactivatingUser$.subscribe((inactivating) => {
            expect(inactivating).toBeTruthy();
            expect(component.modalModel.confirmText).toContain('inactivating');
        });
    });

    it(`should return active users as message params`, () => {
        component.selectedUsers = [
            { contact_name: '0' },
            { contact_name: '1', status: UserStatus.INACTIVE },
            { contact_name: '2', status: UserStatus.ACTIVE },
            { contact_name: '3', status: UserStatus.ACTIVE }
        ];
        expect(component.activeSelectedUsersAsMessageParams).toEqual({ '0': '"2", "3"' });
    });

    it(`should destroy`, () => {
        spyOn(component['_destroyed$'], 'complete').and.callThrough();
        component.ngOnDestroy();
        expect(component['_destroyed$'].complete).toHaveBeenCalled();
    });
});
