import { DocumentsStateForRole } from './../../../../../features/modules-and-permissions-grid/state/modules-and-permissions/modules-and-permissions.state';
interface AssociationGroup {
    type: string;
    group_id: number;
}

export interface PermissionModules {
    [key: string]: number;
}

export interface PermissionSubModules {
    [key: string]: {
        [key: string]: number;
    };
}

export interface PermissionModuleSections {
    [key: string]: {
        [key: string]: {
            [key: string]: number;
        };
    };
}
export interface PermissionNestedContent {
    [key: string]: {
        [key: string]: {
            [key: string]: {
                [key: string]: number;
            };
        };
    };
}

export interface RolePermissions {
    modules?: PermissionModules;
    sub_modules?: PermissionSubModules;
    module_sections?: PermissionModuleSections;
    nested_content?: PermissionNestedContent;
    restricted_documents_metadata?: DocumentsStateForRole;
}

export interface RoleDetails extends RolePermissions {
    role: string;
    type: string;
    color: string;
    created_date: string;
    created_by: string;
    created_by_name: string;
    last_modified_date: string;
    last_modified_by: string;
    last_modified_by_name: string;
    restricted_association_groups_ids: Array<AssociationGroup>;
}

export type UpdateRoleRequest = Omit<RoleDetails, 'created_date' | 'created_by' | 'created_by_name' | 'last_modified_date' | 'last_modified_by' | 'last_modified_by_name' | 'restricted_association_groups_ids'>;

export const rolePermissionsInitialState: RolePermissions = {
    modules: {
        place_new_order: 0,
        activities: 0,
        compliance_events: 0,
        orders: 0,
        invoice_and_payments: 0,
        entities: 0,
        documents: 0,
        account_tools: 0,

        sop: 0,

        business_licenses: 0,
        sec: 0,
        reports: 0
    },
    sub_modules: {
        activities: {
            to_dos_all_account: 0,
            ct_activities_all_account: 0,
            ct_updates: 0,
            hcue_pending_updates: 0
        },
        compliance_events: {
            system_created: 0,
            custom_events: 0
        },
        orders: {
            all_account_orders: 0
        },
        invoice_and_payments: {
            all_account_invoices: 0
        },
        entities: {
            org_charts: 0,
            access_to_entities: 0,
            basic_info: 0,
            summary: 0,
            jurisdictions: 0,
            associations: 0,
            related_assumed_names: 0,
            governance: 0,
            historical_info: 0,
            company_officials: 0,
            cap_structure_and_ownership: 0,
            entity_bank: 0
        },
        documents: {
            documents: 0
        },
        account_tools: {
            users_roles: 0,
            preferences_invoices_and_payments: 0,
            account_settings: 0,
            associations: 0,
            custom_fields: 0,
            groups: 0,
            reference_tables: 0
        },
        sec: {
            issuer_edgar_information: 0,
            insider_information: 0
        },
        reports: {
            reports: 0,
            audit_logs: 0
        }
    },
    module_sections: {
        entities: {
            summary: {
                summary_vitals: 0,
                summary_details: 0
            },
            jurisdictions: {
                jurisdiction_vitals: 0,
                jurisdiction_details: 0
            },
            associations: {
                people: 0,
                businesses: 0,
                addresses: 0,
                locations: 0,
                properties: 0
            },
            historical_info: {
                former_names: 0,
                notes_history_entity_organizational_history: 0
            },
            cap_structure_and_ownership: {
                general_info_cap_structure_stock_split: 0,
                owners_ownership_holdings: 0,
                pending_activities: 0
            }
        },
        account_tools: {
            account_settings: {
                billing: 0
            },
            associations: {
                people: 0,
                businesses: 0,
                addresses: 0,
                locations: 0,
                properties: 0,
                registered_agent: 0,
                sop_di: 0
            }
        }
    },
    nested_content: {
        account_tools: {
            associations: {
                people: {
                    list_view: 0
                }
            }
        }
    }
};

export const roleDetailsInitialState: RoleDetails = {
    ...rolePermissionsInitialState,
    role: '',
    type: '',
    color: '',
    created_date: '',
    created_by: '',
    created_by_name: '',
    last_modified_date: '',
    last_modified_by: '',
    last_modified_by_name: '',
    restricted_association_groups_ids: []
};
