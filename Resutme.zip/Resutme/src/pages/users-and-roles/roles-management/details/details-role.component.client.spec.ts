/* tslint:disable:max-file-line-count */
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, Router, RouterEvent } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Ability, defineAbility } from '@casl/ability';
import { AbilityModule } from '@casl/angular';
import {
    AclDefinitionService,
    AuthorizationModule,
    AuthorizationService,
    CtAuthorizationEnums
} from '@ct/core-ui-ng';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { DefaultTextPipe } from '@ct/platform-common-uicomponents/custom-fields-renderer';
import { GroupLettersFilter } from '@ct/platform-primitives-uicomponents/grid';
import { ActionsSubject } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import {
    TranslateLoader,
    TranslateModule,
    TranslateStore
} from '@ngx-translate/core';
import {
    BehaviorSubject,
    Observable,
    of,
    ReplaySubject,
    Subscription
} from 'rxjs';
import { initialAppState } from 'src/app/state/app.reducer';
import { selectIsInternal } from 'src/app/state/app.selectors';
import { USERS_PANEL_APP_FEATURE_KEY } from 'src/app/state/app.state';
import { userRolesClaimsPath } from 'src/shared/config/claims.config';
import { ModulePermissionsService } from 'src/shared/services/module-permissions/module-permissions.service';

import { GroupsService } from '../../../../shared/services/groups/groups.service';
import { NavigationsService } from '../../../../shared/services/navigation/navigations.service';
import { DetailsUserComponent } from '../../users-management/details/details-user.component';
import { RolesPillsRendererComponent } from '../../users-management/roles-pills-renderer/roles-pills-renderer.component';
import { initialState } from '../../users-management/state/user-management.reducers';
import { selectIsAddUserModalVisible } from '../../users-management/state/user-management.selectors';
import { USER_MANAGEMENT_FEATURE_KEY } from '../../users-management/state/user-management.state';
import { UsersManagementComponent } from '../../users-management/users-management.component';
import { NameWithInitialsAvatarComponent } from '../components/name-with-initials-avatar/name-with-initials-avatar.component';
import { RoleType } from '../interfaces/role-type.enum';
import { Role } from '../interfaces/role.model';
import { RolesManagementComponent } from '../roles-management.component';
import { initialRoleManagementState } from '../state/role-management.reducers';
import {
    roleDetailsState,
    roleNameCreatedState,
    selectedRoleManagementDeleteRoleModalState,
    selectRoleManagementStateData
} from '../state/role-management.selectors';
import { ROLE_MANAGEMENT_FEATURE_KEY } from '../state/role-management.state';
import { rolesResponseData } from '../state/test-values/roles-mock.stub';

import {
    roleManagementSaveNewRoleSuccessAction,
    roleManagementUpdateRoleSuccessAction
} from './../state/role-management.actions';
import { DetailsTextLabelComponent } from './components/details-text-label/details-text-label.component';
import { DetailsRoleComponent } from './details-role.component';
import { dotMenuOptions } from './details-role.constants';
import mockRoleDetails from './state/test-values/role-details-mock.json';

const errorTranslationsStub = {
    'userRolesModule.QuickSwitcherComponent.expandTooltip':
        'Quick Role Switcher',
    'userRolesModule.detailsComponent.createdBy': 'Created By',
    'userRolesModule.detailsComponent.createdOn': 'Created On',
    'userRolesModule.detailsComponent.pillColor': 'Pill Color'
};

const mockNavigationsService = jasmine.createSpyObj('NavigationsService', [
    'hideBreadcrumbs',
    'getPreviousState',
    'goBack',
    'getBreadcrumbs',
    'updateBreadcrumbs'
]);

const mockGroupsService = jasmine.createSpyObj<any>('GroupsService', [
    'createGroup'
]);

class FakeLoader implements TranslateLoader {
    getTranslation(_lang: string): Observable<any> {
        return of(errorTranslationsStub);
    }
}
const eventSubject = new ReplaySubject<RouterEvent>(1);

class Mockrouter {
    navigate = jasmine.createSpy('navigate');
    events = eventSubject.asObservable();
    getCurrentNavigation = jasmine.createSpy('getCurrentNavigation');
}

describe('DetailsRoleComponent', () => {
    const actionSub: ActionsSubject = new ActionsSubject();
    let component: DetailsRoleComponent;
    let fixture: ComponentFixture<DetailsRoleComponent>;
    let store: MockStore;
    let mockRouter: Mockrouter;
    let ability: Ability;
    const modulePermissionsServiceMock = jasmine.createSpyObj<any>([
        'doesUserHasPermission',
        'doesNotUserHasPermission'
    ]);
    const aclDefinitionService = jasmine.createSpyObj<any>([
        'updateEntityAbility',
        'updateModuleAbility',
        'updateFieldsAbility'
    ]);
    const PathForUserRoles =
        CtAuthorizationEnums.CtModulesEnum.ACCOUNT_TOOLS +
        CtAuthorizationEnums.CtAccountToolsFieldsEnum.USER_ROLES;
    const paramsSubject = new BehaviorSubject({
        id: 1
    });

    beforeEach(async(() => {
        mockRouter = new Mockrouter();
        mockRouter.getCurrentNavigation.and.returnValue({
            extras: {}
        });
        TestBed.configureTestingModule({
            declarations: [
                UsersManagementComponent,
                RolesManagementComponent,
                RolesPillsRendererComponent,
                DetailsRoleComponent,
                GroupLettersFilter,
                DetailsTextLabelComponent,
                NameWithInitialsAvatarComponent,
                DefaultTextPipe,
                DetailsUserComponent
            ],
            imports: [
                AuthorizationModule,
                AbilityModule,
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule,
                RouterTestingModule.withRoutes([
                    {
                        path: 'account-tools/users-and-roles/role-management/details/1',
                        component: DetailsRoleComponent
                    }
                ])
            ],
            providers: [
                AuthorizationService,
                {
                    provide: AclDefinitionService,
                    useValue: aclDefinitionService
                },
                {
                    provide: GroupsService,
                    useValue: mockGroupsService
                },
                {
                    provide: Ability,
                    useValue: {
                        can: () => true,
                        cannot: () => true
                    }
                },
                provideMockStore({
                    initialState: {
                        [ROLE_MANAGEMENT_FEATURE_KEY]: initialRoleManagementState,
                        [USER_MANAGEMENT_FEATURE_KEY]: initialState,
                        [USERS_PANEL_APP_FEATURE_KEY]: initialAppState
                    },
                    selectors: [
                        {
                            selector: selectRoleManagementStateData,
                            value: rolesResponseData
                        },
                        {
                            selector: roleDetailsState,
                            value: mockRoleDetails.data
                        },
                        {
                            selector: roleNameCreatedState,
                            value: 'role saved'
                        },
                        {
                            selector:
                                selectedRoleManagementDeleteRoleModalState,
                            value: { isOpen: false }
                        },
                        {
                            selector: selectIsInternal,
                            value: false
                        },
                        {
                            selector: selectIsAddUserModalVisible,
                            value: false
                        }
                    ]
                }),
                TranslateStore,
                {
                    provide: NavigationsService,
                    useValue: mockNavigationsService
                },
                {
                    provide: ActivatedRoute,
                    useValue: {
                        params: paramsSubject
                    }
                },
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                },
                { provide: ActionsSubject, useValue: actionSub },
                {
                    provide: ModulePermissionsService,
                    useValue: modulePermissionsServiceMock
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store = TestBed.inject(MockStore);
        ability = TestBed.inject(Ability);
        mockNavigationsService.getBreadcrumbs.and.returnValue(
            of([{ name: 'details' }])
        );
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DetailsRoleComponent);
        component = fixture.componentInstance;
        modulePermissionsServiceMock.doesUserHasPermission.and.returnValue(
            true
        );
        const role: Role = component.getStoreData(rolesResponseData.data[0]);
        const historyState = {
            name: role.role,
            link: `/role-management/details/${role.role_id}`,
            disabled: true,
            rel: JSON.stringify(role)
        };
        mockNavigationsService.getPreviousState.and.returnValue(historyState);
        fixture.detectChanges();
        component.defaultRoleId = '1';
    });

    it('should create', () => {
        const spyAction = spyOn(component.store$, 'dispatch');
        component.ngOnInit();
        fixture.detectChanges();
        expect(component).toBeTruthy();
        expect(spyAction).toHaveBeenCalled();
        expect(Object.keys(component.switcherConfig)).toBeTruthy();
    });

    it('ngOnDestroy', () => {
        component.breadcrumbsSubcription$ = new Subscription();
        spyOn(component.breadcrumbsSubcription$, 'unsubscribe');
        component.ngOnDestroy();
        expect(
            component.breadcrumbsSubcription$.unsubscribe
        ).toHaveBeenCalled();
    });

    it('it should navigate to new role page', () => {
        const role: Role = rolesResponseData.data[1];
        component.selectedRoleData = role;
        const router = TestBed.inject(Router);
        const routerSpy = spyOn(router, 'navigate');
        component.roleChange(role, true);
        fixture.detectChanges();
        expect(routerSpy).toHaveBeenCalled();
    });

    it('it should navigate to role list', () => {
        const router = TestBed.inject(Router);
        const routerSpy = spyOn(router, 'navigate').and.callThrough();
        component.navigateFullList();
        expect(routerSpy).toHaveBeenCalled();
    });

    it('it should get the selected role', () => {
        const adminRole4Index = 3;
        const mockRole: Role = rolesResponseData.data[adminRole4Index];
        component.roleChange(mockRole, true);
        const role: Role = component.getSelectedRole();
        expect(role).toEqual(mockRole);
    });

    it('it should get correct 3dots options for system role', (done: DoneFn) => {
        const expectedOptionsCount: number = 2;
        const systemRole: Role = rolesResponseData.data.find(
            (role) => role.type === RoleType.SYSTEM
        );
        component.selectedRoleData = systemRole;
        component['updateDropdownOptions']();
        component.dropdownOptions$.subscribe((options) => {
            expect(options.length).toEqual(expectedOptionsCount);
            done();
        });
    });

    it('it should get correct 3dots options for system role userHasCreatePermission', (done: DoneFn) => {
        const expectedOptionsCount: number = 1;
        const systemRole: Role = rolesResponseData.data.find(
            (role) => role.type === RoleType.SYSTEM
        );
        component.userHasCreatePermission = true;
        component.selectedRoleData = systemRole;
        component['updateDropdownOptions']();
        component.dropdownOptions$.subscribe((options) => {
            expect(options.length).toEqual(expectedOptionsCount);
            done();
        });
    });

    it('it should get correct 3dots options for customer role userHasCreatePermission', (done: DoneFn) => {
        const expectedOptionsCount: number = 1;
        component.userHasCreatePermission = true;
        const customerRole: Role = rolesResponseData.data.find(
            (role) => role.type === RoleType.CUSTOMER
        );
        component.selectedRoleData = customerRole;
        component['updateDropdownOptions']();
        component.dropdownOptions$.subscribe((options) => {
            expect(options.length).toEqual(expectedOptionsCount);
            done();
        });
    });

    it('it should get correct 3dots options for customer role', (done: DoneFn) => {
        const expectedOptionsCount: number = 3;
        const customerRole: Role = rolesResponseData.data.find(
            (role) => role.type === RoleType.CUSTOMER
        );
        component.selectedRoleData = customerRole;
        component['updateDropdownOptions']();
        component.dropdownOptions$.subscribe((options) => {
            expect(options.length).toEqual(expectedOptionsCount);
            done();
        });
    });

    it('set edit only if next level ability CREATE is false', () => {
        component['ability'] = defineAbility((can) => {
            can(CtAuthorizationEnums.AclLevelsEnum.EDIT, PathForUserRoles);
        });
        fixture.detectChanges();
        expect(
            ability.cannot(
                CtAuthorizationEnums.AclLevelsEnum.CREATE,
                userRolesClaimsPath
            )
        ).toBe(true);
    });

    it('set edit only if next ability is false i.e CREATE', () => {
        component['ability'] = defineAbility((can) => {
            can(CtAuthorizationEnums.AclLevelsEnum.EDIT, PathForUserRoles);
        });
        fixture.detectChanges();
        expect(component.userHasCreatePermission).toBeFalse;
    });

    it('it should call copy and create role from dots', () => {
        spyOn(store, 'dispatch').and.callThrough();
        component.on3DotsOptionSelect([...dotMenuOptions][0]);
        expect(store.dispatch).toHaveBeenCalled();
    });

    it('it should call assign user(s) from dots', () => {
        spyOn(store, 'dispatch').and.callThrough();
        component.on3DotsOptionSelect([...dotMenuOptions][1]);
        expect(store.dispatch).toHaveBeenCalled();
    });

    it('it should call delete role from dots', () => {
        spyOn(store, 'dispatch').and.callThrough();
        component.on3DotsOptionSelect([...dotMenuOptions].pop());
        expect(store.dispatch).toHaveBeenCalled();
    });

    it('it should update or not values on M&P table changes', () => {
        const updatedPermissionsValue = {
            modules: {
                test_module: 13
            }
        };
        component.roleDetails = {
            ...mockRoleDetails.data,
            type: RoleType.SYSTEM
        };
        component.updatedPermissionsInitializationCompleted = false;
        component.updatedPermissions = null;
        component.onPermissionsChanged(updatedPermissionsValue);
        expect(component.updatedPermissionsInitializationCompleted).toEqual(
            true
        );
        component.onPermissionsChanged(updatedPermissionsValue);
        expect(component.isRoleUpdateNotificationVisible).toEqual(true);
        expect(component.updatedPermissions).toBeFalsy();
        component.isRoleUpdateNotificationVisible = false;
        component.roleDetails = mockRoleDetails.data;
        component.onPermissionsChanged(updatedPermissionsValue);
        expect(component.updatedPermissions).toEqual(updatedPermissionsValue);
    });

    it('it should dispatch during onCancelChanges', () => {
        spyOn(store, 'dispatch').and.callThrough();
        component.onCancelChanges();
        expect(store.dispatch).toHaveBeenCalled();
    });

    it('it discard values during call onDiscardModulesAndPermissionsChanges', () => {
        component.updatedPermissions = {
            modules: {
                test_module: 13
            }
        };
        spyOn(store, 'dispatch').and.callThrough();
        spyOn(
            component.discardModulesAndPermissionsChangesEvent,
            'next'
        ).and.callThrough();
        component.onDiscardModulesAndPermissionsChanges();
        expect(component.updatedPermissions).toBeNull();
        expect(store.dispatch).toHaveBeenCalled();
        expect(
            component.discardModulesAndPermissionsChangesEvent.next
        ).toHaveBeenCalled();
    });

    it('should dispatch action to open copy and create new role modal', () => {
        spyOn(store, 'dispatch').and.callThrough();
        component.isRoleUpdateNotificationVisible = true;

        component.showRoleCreatedNotification = true;
        component.openCopyAndCreateNewRole();
        expect(component.isRoleUpdateNotificationVisible).toEqual(false);
        expect(store.dispatch).toHaveBeenCalled();
        expect(component.showRoleCreatedNotification).toBeFalsy();
    });

    it('should update role', () => {
        spyOn(store, 'dispatch').and.callThrough();
        component.onUpdateRole();
        expect(store.dispatch).toHaveBeenCalled();
        expect(component.updateRoleModalModel.confirmText).toContain(
            'confirmInProgressText'
        );
    });

    it('should invoke success role update', () => {
        const actionSubject = TestBed.inject(ActionsSubject) as ActionsSubject;
        actionSubject.next(
            roleManagementUpdateRoleSuccessAction({ result: true })
        );
        expect(component.updatedPermissions).toBeFalsy();
        expect(component.updateRoleModalModel.confirmText).toContain(
            'confirmText'
        );
    });

    it('should invoke show notification when role saved success', () => {
        const actionSubject = TestBed.inject(ActionsSubject) as ActionsSubject;
        actionSubject.next(
            roleManagementSaveNewRoleSuccessAction({ role_id: 1 })
        );
        expect(component.showRoleCreatedNotification).toBeTruthy();
    });

    it('should return switcher config correctly', () => {
        store.overrideSelector(selectIsInternal, false);
        component.ngOnInit();
        expect(component.switcherConfig.queryParams).toBeFalsy();

        store.overrideSelector(selectIsInternal, true);
        component.ngOnInit();
        expect(component.switcherConfig.queryParams).toBeTruthy();
    });
    it('should navigate back', () => {
        const router = TestBed.inject(Router);
        const spy = spyOn(router, 'navigate').and.callThrough();
        component.navigateBack();
        expect(spy).toHaveBeenCalled();
    });
    it('should prevent role update with add user modal opened' , () => {

        store.overrideSelector(selectIsAddUserModalVisible, true);
        component.selectedRoleData = undefined;
        component.subscribeToRoleTableData();
        expect(component.selectedRoleData).toBeUndefined();
    });
    it('should handle role update with null data' , () => {
        store.overrideSelector(selectRoleManagementStateData, null);
        component.subscribeToRoleTableData();
        const selected = component.getSelectedRole();
        expect(component.selectedRoleData).toEqual(selected);
    });
});
