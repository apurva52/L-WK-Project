export interface GetRowsParams {
    startRow: number;
    endRow: number;
    successCallback: Function;
}
