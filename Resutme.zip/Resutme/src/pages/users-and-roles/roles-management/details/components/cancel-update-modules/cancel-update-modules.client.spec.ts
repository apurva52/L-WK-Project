import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';

import { initialRoleManagementState } from '../../../state/role-management.reducers';
import { cancelRoleModulesAndPermissionsUpdateState } from '../../../state/role-management.selectors';
import {
    ROLE_MANAGEMENT_FEATURE_KEY,
    RoleManagementState
} from '../../../state/role-management.state';

import { CancelUpdateRoleModulesAndPermissionsComponent } from './cancel-update-modules.component';

class FakeLoader implements TranslateLoader {
    getTranslation(_lang: string): Observable<any> {
        return of({});
    }
}

describe('CancelUpdateModulesComponent', () => {
    let component: CancelUpdateRoleModulesAndPermissionsComponent;
    let fixture: ComponentFixture<CancelUpdateRoleModulesAndPermissionsComponent>;
    let store: MockStore<RoleManagementState>;
    const mockState = {
        isOpen: true
    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CancelUpdateRoleModulesAndPermissionsComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [ROLE_MANAGEMENT_FEATURE_KEY]:
                            initialRoleManagementState
                    },
                    selectors: [
                        {
                            selector:
                                cancelRoleModulesAndPermissionsUpdateState,
                            value: mockState
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(
            CancelUpdateRoleModulesAndPermissionsComponent
        );
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it(`should dispatch close modal`, () => {
        const expectedCallsCount = 1;
        spyOn(store, 'dispatch').and.callThrough();
        component.onCancelClick();
        expect(store.dispatch).toHaveBeenCalledTimes(expectedCallsCount);
    });

    it(`should dispatch discard changes event`, () => {
        const expectedCallsCount = 1;
        spyOn(component.discardChanges, 'emit').and.callThrough();
        component.onConfirmClick();
        expect(component.discardChanges.emit).toHaveBeenCalledTimes(
            expectedCallsCount
        );
    });
});
