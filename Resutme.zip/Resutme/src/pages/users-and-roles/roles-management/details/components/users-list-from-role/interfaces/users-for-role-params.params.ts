export interface UsersForRoleParams {
    roleId: string;
    pageNumber: number;
    pageSize: number;
    sortKey?: string;
    sortBy?: string;
}
