import { createFeatureSelector, createSelector } from '@ngrx/store';

import { USERS_FOR_ROLE_FEATURE_KEY, UsersForRoleState } from './users-from-role.state';

export const selectRootFeature = createFeatureSelector<UsersForRoleState>(USERS_FOR_ROLE_FEATURE_KEY);

export const selectUsersForRoleStateLoadingStatus = createSelector(selectRootFeature, (state: UsersForRoleState) => state.loading);

export const selectUsersForRoleStateData = createSelector(selectRootFeature, (state: UsersForRoleState) => state.usersData);

export const selectedRoleForUserState = createSelector(
    selectRootFeature,
    (state: UsersForRoleState) => state.selected
);