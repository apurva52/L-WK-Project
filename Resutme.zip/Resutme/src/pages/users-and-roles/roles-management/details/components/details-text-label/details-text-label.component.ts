import { AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'ct-details-text-label',
    templateUrl: './details-text-label.component.html',
    styleUrls: ['./details-text-label.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class DetailsTextLabelComponent implements AfterViewInit {
    @Input() i18nSection: string;
    @Input() i18nKey: string;
    @Input() required = false;
    header = '';

    constructor(private cdRef: ChangeDetectorRef, translate: TranslateService) {}

    ngAfterViewInit(): void {
        this.header = `${this.i18nSection}.${this.i18nKey}`;
        this.cdRef.detectChanges();
    }
}
