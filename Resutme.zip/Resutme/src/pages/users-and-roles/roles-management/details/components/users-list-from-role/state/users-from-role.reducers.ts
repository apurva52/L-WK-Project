import { createReducer, on } from '@ngrx/store';
import { UserStatus } from 'src/pages/users-and-roles/users-management/state/user-management.state';

import { clearUsersForRole, getUsersForRoleAction, getUsersForRoleFailureAction, getUsersForRoleSuccessAction, userFromRoleSelectAction } from './users-from-role.actions';
import { UsersForRoleState } from './users-from-role.state';

export const initialState: UsersForRoleState = {
    loading: false,
    usersData: {
        role_id: null,
        role_name: null,
        data: []
    },
    searchData: [],
    error: {
        active: false,
        message: ''
    },
    selected: [],
    isAddUserModalVisible: false
};

export const usersForRoleReducer = createReducer(
    initialState,
    on(getUsersForRoleAction, (state) => ({
        ...state,
        loading: true
    })),
    on(getUsersForRoleSuccessAction, (state, action) => ({
        ...state,
        loading: false,
        usersData: {
            data: action.response.data.users.filter(res => res.status.toLowerCase() === UserStatus.ACTIVE)
        },
        error: {
            active: false,
            message: ''
        }
    })),
    on(getUsersForRoleFailureAction, (state, action) => ({
        ...state,
        loading: false,
        error: {
            active: true,
            message: action.errorMessage
        }
    })),
    on(clearUsersForRole, (state, action) => ({
        ...state,
        usersData: {
            ...initialState.usersData
        }
    })),
    on(userFromRoleSelectAction, (state, action) => ({
           ...state,
           selected: action.selected
       }))
);
