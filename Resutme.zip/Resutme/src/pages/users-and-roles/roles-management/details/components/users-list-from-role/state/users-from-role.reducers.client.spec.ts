// tslint:disable-next-line:max-line-length
import mockUsersFromRole from './test-values/mock-users-from-role.json';
import * as usersForRoleActions from './users-from-role.actions';
import { initialState, usersForRoleReducer } from './users-from-role.reducers';
import { UsersForRoleResponse } from './users-from-role.state';

describe('users from role reducer', () => {
    it('should process users load', () => {
        const currentState = { ...initialState };
        const actionParams = { pageNumber: 1, pageSize: 10, roleId: '1' };
        expect(
            usersForRoleReducer(
                currentState,
                usersForRoleActions.getUsersForRoleAction(actionParams)
            )
        ).toEqual({
            ...currentState,
            loading: true
        });
    });
    it('should process users load success', () => {
        const currentState = { ...initialState };
        const response: UsersForRoleResponse = { data: mockUsersFromRole as any };
        expect(
            usersForRoleReducer(
                currentState,
                usersForRoleActions.getUsersForRoleSuccessAction({
                    response
                })
            )
        ).toEqual({
            ...currentState,
            loading: false,
            usersData: {
                data: mockUsersFromRole.users as any
            }
        });
    });
    it('should process users load failure', () => {
        const currentState = { ...initialState };
        expect(
            usersForRoleReducer(
                currentState,
                usersForRoleActions.getUsersForRoleFailureAction({
                    errorMessage: 'Unit Test error'
                })
            )
        ).toEqual({
            ...currentState,
            error: {
                active: true,
                message: 'Unit Test error'
            }
        });
    });
    it('should clear users', () => {
        const currentState = { ...initialState, usersData: { data: mockUsersFromRole.users } as any };
        expect(
            usersForRoleReducer(currentState, usersForRoleActions.clearUsersForRole())
        ).toEqual({
            ...currentState,
            loading: false,
            usersData: initialState.usersData
        });
    });

    it('should select users', () => {
        const newState = {
            total: mockUsersFromRole.users.length,
            selected: mockUsersFromRole.users
        };
        const currentState = { ...initialState };
        expect(
            usersForRoleReducer(
                currentState,
                usersForRoleActions.userFromRoleSelectAction(newState)
            )
        ).toEqual({
            ...currentState,
            selected: mockUsersFromRole.users
        });
    });
});
