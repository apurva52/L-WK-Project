import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { from, of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';

import { AuthorizationManagementService } from '../../../../../../../shared/services/authorization-management/authorization-management.service';

import { getUsersForRoleAction, getUsersForRoleFailureAction, getUsersForRoleSuccessAction } from './users-from-role.actions';

@Injectable()
export class UsersForRoleEffects {
    getUsersForRole$ = createEffect(() =>
        this.actions$.pipe(
            ofType(getUsersForRoleAction),
            switchMap((params) => {
                return from(this.authorizationManagementService.getUsersAssignedToARole(params)).pipe(
                    map((response) =>
                        getUsersForRoleSuccessAction({
                            response
                        })
                    ),
                    catchError((err) => of(getUsersForRoleFailureAction({ errorMessage: err })))
                );
            })
        )
    );

    constructor(private actions$: Actions, private authorizationManagementService: AuthorizationManagementService) {}
}
