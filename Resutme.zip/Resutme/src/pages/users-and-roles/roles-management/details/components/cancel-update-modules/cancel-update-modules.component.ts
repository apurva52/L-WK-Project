import { Component, EventEmitter, Output } from '@angular/core';
import { ModalModel } from '@ct/platform-primitives-uicomponents/modals';
import { Store } from '@ngrx/store';

import { roleManagementToggleUpdateRoleMPModalAction } from '../../../state/role-management.actions';
import { cancelRoleModulesAndPermissionsUpdateState } from '../../../state/role-management.selectors';

@Component({
    selector: 'ct-cancel-update-modules',
    templateUrl: './cancel-update-modules.component.html',
    styleUrls: ['./cancel-update-modules.component.scss']
})
export class CancelUpdateRoleModulesAndPermissionsComponent {
    @Output() discardChanges = new EventEmitter<void>();

    state$ = this.store$.select(cancelRoleModulesAndPermissionsUpdateState);

    modalModel: ModalModel = {
        title: 'userRolesModule.detailsComponent.updateRoleModulesAndPermissionsCancelModal.title',
        cancelText:
            'userRolesModule.detailsComponent.updateRoleModulesAndPermissionsCancelModal.cancelText',
        confirmText:
            'userRolesModule.detailsComponent.updateRoleModulesAndPermissionsCancelModal.confirmText'
    };

    constructor(private store$: Store) {}

    onCancelClick(): void {
        this.store$.dispatch(
            roleManagementToggleUpdateRoleMPModalAction({ isOpen: false })
        );
    }

    onConfirmClick(): void {
        this.discardChanges.emit();
    }
}
