// tslint:disable max-file-line-count
import { GridOptions } from '@ag-grid-community/core';
import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Ability } from '@casl/ability';
import {
    CTGridColumnDefinition,
    GroupLettersFilter
} from '@ct/platform-primitives-uicomponents/grid';
import { ModalModel } from '@ct/platform-primitives-uicomponents/modals';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SelectionChangeEvent } from 'src/features/widgets/management-grid/interfaces/selection-change-event.interface';
import { UnAssignRoleFromUser, UnAssignRoleFromUserSuccessAction, userManagementSaveSuccessAction } from 'src/pages/users-and-roles/users-management/state/user-management.actions';
import { selectIsAddUserModalVisible, userSavedState } from 'src/pages/users-and-roles/users-management/state/user-management.selectors';
import { isFirstColumn } from 'src/pages/users-and-roles/users-management/users-management.config';
import { editLevel } from 'src/shared/config/claims.config';
import { ModulePermissionsService } from 'src/shared/services/module-permissions/module-permissions.service';

import { AvatarRendererComponent } from '../../../../users-management/avatar-renderer/avatar-renderer';
import { User, UserFromRole } from '../../../../users-management/interfaces/user.model';
import { RolesPillsRendererComponent } from '../../../../users-management/roles-pills-renderer/roles-pills-renderer.component';
import { AddUserRoleModalAction } from '../../../state/role-management.actions';
import { selectIsAddUserRoleModalVisible } from '../../../state/role-management.selectors';

import { GetRowsParams } from './interfaces/get-rows-params.params';
import {
    clearUsersForRole,
    getUsersForRoleAction,
    userFromRoleSelectAction
} from './state/users-from-role.actions';
import { selectUsersForRoleStateData } from './state/users-from-role.selectors';
import { USERS_FOR_ROLE_PAGE_SIZE } from './state/users-from-role.state';

@Component({
    selector: 'ct-users-from-role-accordion',
    templateUrl: './users-from-role-accordion.component.html',
    styleUrls: ['./users-from-role-accordion.component.scss']
})
export class UsersFromRoleAccordionComponent implements OnInit {
    @Input() roleId: string;
    @Input() roleName: string;
    gridStyle: string = 'zebra-mini';
    isModalOpen = false;
    isRemoveWarningVisible = false;
    isAddUserRoleModalVisible$ = this.store$.select(
        selectIsAddUserRoleModalVisible
    );
    isInitialized = false;
    existUsername = '';
    assignedRoleData: Array<UserFromRole> = [];
    currentRolePosition = 0;
    customCellRendererComponents = {
        rolesPillsRenderer: RolesPillsRendererComponent,
        avatarRenderer: AvatarRendererComponent
    };

    gridDefinition: Array<CTGridColumnDefinition> = [
        {
            colDef: {
                headerName: 'User Name',
                checkboxSelection: isFirstColumn,
                headerCheckboxSelection: isFirstColumn,
                field: 'contact_name',
                sortable: true,
                suppressMenu: false,
                filter: true,
                filterFramework: GroupLettersFilter,
                menuTabs: ['filterMenuTab', 'generalMenuTab']
            },
            cellRendererOptions: {
                useCellRenderer: 'avatarRenderer'
            },
            cellRenderedParams: {
                click: async (event: User) => {
                    await this.router.navigate([
                        `account-tools/users-and-roles/user-management/details/${event.sf_contact_id}`
                    ]);
                },
                showAvatar: true
            },
            dataType: 'CUSTOM'
        },
        {
            colDef: {
                headerName: 'Roles',
                checkboxSelection: isFirstColumn,
                headerCheckboxSelection: isFirstColumn,
                field: 'roles',
                sortable: true,
                suppressMenu: false,
                filter: true,
                cellStyle: {
                    overflow: 'visible',
                    'z-index': 2
                },
                keyCreator: (params) =>
                    params.data.user_roles.map((role) => role.role_name),
                menuTabs: ['filterMenuTab', 'generalMenuTab']
            },
            cellRendererOptions: {
                useCellRenderer: 'rolesPillsRenderer'
            },
            dataType: 'CUSTOM'
        },
        {
            colDef: {
                headerName: 'Email',
                checkboxSelection: isFirstColumn,
                headerCheckboxSelection: isFirstColumn,
                field: 'email',
                sortable: true
            },
            dataType: 'STRING'
        }
    ];

    gridOptions: GridOptions = {
        rowModelType: 'clientSide',
        rowSelection: 'multiple',
        suppressDragLeaveHidesColumns: true,
        suppressCellSelection: true,
        suppressMultiRangeSelection: false,
        suppressRowClickSelection: true,
        defaultColDef: {
            headerCheckboxSelection: false,
            sortable: false,
            resizable: true,
            suppressMenu: true,
            filter: true,
            filterParams: {
                caseSensitive: false
            }
        },
        suppressMenuHide: true,
        getRowNodeId: this.getRowId
    };

    usersForRoleData$ = this.store$.select(selectUsersForRoleStateData);
    isAccordionOpened: boolean = false;
    isAccordionOpenedAtleastOnce: boolean = false;
    currentGetRowsParams: GetRowsParams;
    userHasEditPermission =
        this.modulePermissionsService.doesUserHasPermission(editLevel);
    showUsersAsignedToRoleNotification = false;
    modalModel: ModalModel = {
        title: 'userRolesModule.DeleteRoleComponent.title',
        cancelText: 'userRolesModule.DeleteRoleComponent.cancelButton',
        confirmText: 'userRolesModule.DeleteRoleComponent.confirmButton'
    };
    currentRoleExist: boolean;
    existUserRolesFlag = false;

    isAddUserModalVisible$ = this.store$.select(selectIsAddUserModalVisible);
    userSavedFullname$: Observable<string> = this.store$.select(userSavedState);
    showUserCreatedNotification = false;

    private _destroyed$ = new Subject();

    constructor(
        private actionsListener$: ActionsSubject,
        private store$: Store,
        private ability: Ability,
        private route: ActivatedRoute,
        private router: Router,
        private modulePermissionsService: ModulePermissionsService
    ) {}

    ngOnInit(): void {
        this.roleId = this.route.snapshot.paramMap.get('id');
        this.loadUsers();
        this.actionsListener$
            .pipe(
                ofType(userManagementSaveSuccessAction),
                takeUntil(this._destroyed$)
            )
            .subscribe(() => (this.showUserCreatedNotification = true));
    }

    loadUsers(pageNumber: number = 1): void {
        if (this.isAccordionOpenedAtleastOnce) {
            this.store$.dispatch(
                getUsersForRoleAction({
                    pageNumber,
                    pageSize: USERS_FOR_ROLE_PAGE_SIZE,
                    roleId: this.roleId
                })
            );
        }
    }

    onToggleAccordion(isOpened: boolean): void {
        if (isOpened && !this.isAccordionOpenedAtleastOnce) {
            this.isAccordionOpenedAtleastOnce = true;
            this.loadUsers();
        }
        this.isAccordionOpened = isOpened;
    }

    openModal(val: boolean): void {
        this.store$.dispatch(AddUserRoleModalAction({ value: val }));
    }
    ngOnDestroy(): void {
        this.store$.dispatch(clearUsersForRole());
        this._destroyed$.next();
        this._destroyed$.complete();
    }

    onUsersAddedToRole(usersAdded: boolean): void {
        if (usersAdded) {
            this.showUsersAsignedToRoleNotification = true;
            this.loadUsers();
        }
    }

    onSelectionChange(event: SelectionChangeEvent): void {
        this.store$.dispatch(userFromRoleSelectAction(event));
        this.assignedRoleData = event.selected;
    }

    onRemoveWarningVisibleCancel(): void {
        if (this.existUserRolesFlag) {
            this.currentRolePosition = 0;
            this.isRemoveWarningVisible = false;
            return;
        }
        if (this.assignedRoleData.length == this.currentRolePosition) {
            this.currentRolePosition = 0;
            this.isRemoveWarningVisible = false;
            return;
        }
        this.UnassignRole();
    }
    UnassignRole(): void {
        this.isRemoveWarningVisible = true;
        this.existUserRolesFlag = this.assignedRoleData.every(
            (dt) => dt.roles.length > 0
        );
        const dt = this.assignedRoleData[this.currentRolePosition];
        if (dt.roles.length === 0) {
            this.currentRoleExist = true;
            this.currentRolePosition++;
            this.existUsername = dt.contact_name;
            if (this.modalModel.hasOwnProperty('cancelText')) {
                delete this.modalModel.cancelText;
            }
            this.modalModel.title = 'entitiesGrid.WarningTitle';
            this.modalModel.confirmText = 'entitiesGrid.OkButton';
        } else {
            this.currentRoleExist = false;
            this.currentRolePosition++;
            this.modalModel.title =
                'userRolesModule.detailsComponent.UnassignRoleTitle';
            this.modalModel.cancelText =
                'userRolesModule.DeleteRoleComponent.cancelButton';
            this.modalModel.confirmText =
                'userRolesModule.DeleteRoleComponent.confirmButton';
        }
    }

    onConfirmClick(): void {
        if (!this.currentRoleExist) {
            if (this.existUserRolesFlag) {
                const sfids = this.assignedRoleData.map(
                    (del) => del.sf_contact_id
                );
                this.store$.dispatch(
                    UnAssignRoleFromUser({
                        roleId: Number(this.roleId),
                        sfContactId: sfids
                    })
                );
            } else {
                this.store$.dispatch(
                    UnAssignRoleFromUser({
                        roleId: Number(this.roleId),
                        sfContactId: [
                            this.assignedRoleData[this.currentRolePosition - 1]
                                .sf_contact_id
                        ]
                    })
                );
            }
            this.actionsListener$
                .pipe(ofType(UnAssignRoleFromUserSuccessAction))
                .subscribe((data) => {
                    this.isRemoveWarningVisible = false;
                    this.loadUsers();
                });
            if (this.assignedRoleData.length == this.currentRolePosition) {
                this.currentRolePosition = 0;
                this.isRemoveWarningVisible = false;
                return;
            }
        } else {
            if (this.assignedRoleData.length == this.currentRolePosition) {
                this.currentRolePosition = 0;
                this.isRemoveWarningVisible = false;
                return;
            }
        }
        this.UnassignRole();
    }

    private getRowId(user: User): string {
        return user.sf_contact_id;
    }
}