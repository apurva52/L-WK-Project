import { UserFromRole } from '../../../../../users-management/interfaces/user.model';
export const USERS_FOR_ROLE_FEATURE_KEY = 'usersForRoleFeatureKey';
export const USERS_FOR_ROLE_PAGE_SIZE = 200;

export interface UsersForRole {
    role_id: number;
    role_name: string;
    data: Array<UserFromRole>;
}

export interface UsersForRoleResponse {
    data: {
        role_id: number,
        role_name: string,
        users: Array<UserFromRole>;
    };
}

export interface UsersForRoleState {
    loading: boolean;
    usersData: UsersForRole;
    searchData: Array<{ value: string; label: string }>;
    error: {
        active: boolean;
        message: string;
    };
    selected: Array<UserFromRole>;
    isAddUserModalVisible: false;
}
