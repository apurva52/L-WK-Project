import { createAction, props } from '@ngrx/store';
import { SelectionChangeEvent } from 'src/features/widgets/management-grid/interfaces/selection-change-event.interface';

import { UsersForRoleParams } from '../interfaces/users-for-role-params.params';

import { UsersForRoleResponse } from './users-from-role.state';

export enum UsersForRoleActionTypes {
    GetInitiate = `[User Users for Role] Get`,
    GetFailed = `[User Users for Role] Get Failure`,
    GetSuccess = `[User Users for Role] Get Success`,
    ClearUsers = `[User Users for Role] Clear Users`,
    SelectUsersFromRole = `[User Management] Select Users`
}

export const getUsersForRoleAction = createAction(UsersForRoleActionTypes.GetInitiate, props<UsersForRoleParams>());

export const getUsersForRoleSuccessAction = createAction(UsersForRoleActionTypes.GetSuccess, props<{ response: UsersForRoleResponse }>());

export const getUsersForRoleFailureAction = createAction(
    UsersForRoleActionTypes.GetFailed,
    props<{
        errorMessage: string;
    }>()
);
export const userFromRoleSelectAction = createAction(
    UsersForRoleActionTypes.SelectUsersFromRole,
    props<SelectionChangeEvent>()
);
export const clearUsersForRole = createAction(UsersForRoleActionTypes.ClearUsers);
