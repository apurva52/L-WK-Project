import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { I18nTestingModule, LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

import { DetailsTextLabelComponent } from './details-text-label.component';

describe('DetailsTextLabelComponent', () => {
  let component: DetailsTextLabelComponent;
  let fixture: ComponentFixture<DetailsTextLabelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DetailsTextLabelComponent],
      imports: [
        I18nTestingModule,
        LocaleTestingModule,
        TranslateModule.forRoot()
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsTextLabelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create translate string from input', async () => {
    component.i18nSection = 'module.details';
    component.i18nKey = 'fieldName';

    component.ngAfterViewInit();
    fixture.detectChanges();

    expect(component.header).toBe('module.details.fieldName');
  });
});
