/* tslint:disable:no-unused-variable */
// tslint:disable max-file-line-count
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { Router, RouterEvent } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Ability } from '@casl/ability';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { StoreModule } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { ReplaySubject } from 'rxjs/internal/ReplaySubject';
import { initialAppState } from 'src/app/state/app.reducer';
import { USERS_PANEL_APP_FEATURE_KEY } from 'src/app/state/app.state';
import { User } from 'src/pages/users-and-roles/users-management/interfaces/user.model';
import { UnAssignRoleFromUserSuccessAction, userManagementSaveSuccessAction } from 'src/pages/users-and-roles/users-management/state/user-management.actions';

import { AvatarRendererComponent } from '../../../../../../pages/users-and-roles/users-management/avatar-renderer/avatar-renderer';
import { RolesPillsRendererComponent } from '../../../../../../pages/users-and-roles/users-management/roles-pills-renderer/roles-pills-renderer.component';
import { usersResponseData } from '../../../../../../pages/users-and-roles/users-management/state/test-values/users-mock.stub';
import { initialState } from '../../../../../../pages/users-and-roles/users-management/state/user-management.reducers';
import { USER_MANAGEMENT_FEATURE_KEY } from '../../../../../../pages/users-and-roles/users-management/state/user-management.state';
import { AuthorizationManagementService } from '../../../../../../shared/services/authorization-management/authorization-management.service';

import { GetRowsParams } from './interfaces/get-rows-params.params';
import mockUsersFromRole from './state/test-values/mock-users-from-role.json';
import { selectUsersForRoleStateData } from './state/users-from-role.selectors';
import { UsersFromRoleAccordionComponent } from './users-from-role-accordion.component';

const eventSubject = new ReplaySubject<RouterEvent>(1);
class Mockrouter {
    navigate = jasmine.createSpy('navigate');
    events = eventSubject.asObservable();
    getCurrentNavigation = jasmine.createSpy('getCurrentNavigation');
}

describe('UsersFromRoleAccordionComponent', () => {
    let component: UsersFromRoleAccordionComponent;
    let fixture: ComponentFixture<UsersFromRoleAccordionComponent>;
    let store: MockStore<UsersFromRoleAccordionComponent>;

    let mockRouter: Mockrouter;
    const authorizationManagementServiceMock = jasmine.createSpyObj(
        'AuthorizationManagementService',
        ['getUsersAssignedToARole']
    );
    authorizationManagementServiceMock.getUsersAssignedToARole.and.returnValue(
        mockUsersFromRole
    );
    const mockParams: GetRowsParams = {
        startRow: 1,
        endRow: 10,
        successCallback: jasmine.createSpy()
    };

    beforeEach(async(() => {
        mockRouter = new Mockrouter();
        mockRouter.getCurrentNavigation.and.returnValue({
            extras: {}
        });
        TestBed.configureTestingModule({
            declarations: [
                UsersFromRoleAccordionComponent,
                AvatarRendererComponent,
                RolesPillsRendererComponent
            ],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                StoreModule.forRoot({}),
                LocaleTestingModule,
                RouterTestingModule
            ],

            providers: [
                {
                    provide: AuthorizationManagementService,
                    useValue: authorizationManagementServiceMock
                },
                {
                    provide: Ability,
                    useValue: {
                        can: () => true,
                        cannot: () => true
                    }
                },
                provideMockStore({
                    initialState: {
                        [USER_MANAGEMENT_FEATURE_KEY]: initialState,
                        [USERS_PANEL_APP_FEATURE_KEY]: initialAppState
                    },
                    selectors: [
                        {
                            selector: selectUsersForRoleStateData,
                            value: usersResponseData
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
        })
            .overrideModule(BrowserDynamicTestingModule, {
                set: {
                    entryComponents: [
                        RolesPillsRendererComponent,
                        AvatarRendererComponent
                    ]
                }
            })
            .compileComponents();
        store = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(UsersFromRoleAccordionComponent);
        component = fixture.componentInstance;
        component.isAccordionOpenedAtleastOnce = true;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should load users', async () => {
        spyOn(component['store$'], 'dispatch');
        await component.loadUsers();
        expect(component['store$'].dispatch).toHaveBeenCalled();
    });
    it('should toggle accordion', async () => {
        component.isAccordionOpenedAtleastOnce = false;
        component.onToggleAccordion(true);
        expect(component.isAccordionOpened).toBeTruthy();
        expect(component.isAccordionOpenedAtleastOnce).toBeTruthy();
    });

    it('should toggle accordion -ve case', async () => {
        component.isAccordionOpenedAtleastOnce = false;
        component.onToggleAccordion(false);
        expect(component.isAccordionOpened).toBeFalsy();
        expect(component.isAccordionOpenedAtleastOnce).toBeFalsy();
    });
    it('should open modal', () => {
        spyOn(component['store$'], 'dispatch');
        component.openModal(true);
        expect(component['store$'].dispatch).toHaveBeenCalled();
    });

    it('Navigation click test', async () => {
        const router = TestBed.inject(Router);
        const routerSpy = spyOn(router, 'navigate');
        fixture.detectChanges();
        component.gridDefinition[0].cellRenderedParams.click({
            sf_contact_id: 87
        });
        expect((<any>component).router.navigate).toHaveBeenCalled();
        expect(routerSpy).toHaveBeenCalledWith([`account-tools/users-and-roles/user-management/details/87`]);
    });

    it(`should show users asigned to role notification correctly`, () => {
        spyOn(component['store$'], 'dispatch');
        component.showUsersAsignedToRoleNotification = false;

        component.onUsersAddedToRole(false);
        expect(component.showUsersAsignedToRoleNotification).toBeFalsy();
        expect(component['store$'].dispatch).not.toHaveBeenCalled();

        component.onUsersAddedToRole(true);
        expect(component.showUsersAsignedToRoleNotification).toBeTruthy();
        expect(component['store$'].dispatch).toHaveBeenCalled();
    });


    it(`should close modal`, () => {
        component.assignedRoleData.length = 2;
        component.currentRolePosition = 2;
        component.onRemoveWarningVisibleCancel();
        expect(component.currentRolePosition).toEqual(0);
        expect(component.isRemoveWarningVisible).toBe(false);
    });
    it(`should not close modal`, () => {
        spyOn(component, 'UnassignRole').and.callThrough();
        component.assignedRoleData.length = 2;
        component.currentRolePosition = 2;
        component.assignedRoleData[component.currentRolePosition] = {
            contact_id: 1,
            sf_contact_id: '1',
            contact_name: 'superuser',
            email: 'superuser@gmail.com',
            status: 'false',
            roles: [{
                'role_id': 4,
                'role_color': 'red',
                'role_name': 'Guest'
            }]
        };
        component.onRemoveWarningVisibleCancel();
        expect(component.UnassignRole).toHaveBeenCalled();
    });

    it(`should dispatch unassign role and close modal for multiple roles`, () => {
        spyOn(store, 'dispatch').and.callThrough();
        spyOn(component, 'loadUsers').and.callThrough();
        const rp_num = 1;
        component.currentRoleExist = false;
        component.existUserRolesFlag = true;
        component.assignedRoleData.length = 1;
        component.currentRolePosition = 1;
        component.assignedRoleData = [
            {
                contact_id: 1,
                sf_contact_id: '1',
                contact_name: 'superuser',
                email: 'superuser@gmail.com',
                status: 'false',
                roles: []
            }];

        component.onConfirmClick();
        expect(store.dispatch).toHaveBeenCalledTimes(rp_num);
        component['actionsListener$'].next(
            UnAssignRoleFromUserSuccessAction({
                result: true
            })
        );
        expect(component.currentRolePosition).toEqual(0);
        expect(component.isRemoveWarningVisible).toBe(false);
        expect(component.loadUsers).toHaveBeenCalled();
    });
    it(`should dispatch unassign role and close modal for single roles `, () => {
        spyOn(store, 'dispatch').and.callThrough();
        spyOn(component, 'loadUsers').and.callThrough();
        const rp_num = 1;
        component.currentRoleExist = false;
        component.existUserRolesFlag = false;
        component.assignedRoleData.length = 1;
        component.currentRolePosition = 1;
        component.assignedRoleData = [
            {
                contact_id: 1,
                sf_contact_id: '1',
                contact_name: 'superuser',
                email: 'superuser@gmail.com',
                status: 'false',
                roles: []
            }];

        component.onConfirmClick();
        expect(store.dispatch).toHaveBeenCalledTimes(rp_num);
        component['actionsListener$'].next(
            UnAssignRoleFromUserSuccessAction({
                result: true
            })
        );
        expect(component.currentRolePosition).toEqual(0);
        expect(component.isRemoveWarningVisible).toBe(false);
        expect(component.loadUsers).toHaveBeenCalled();
    });

    it(`should return unassign role and close modal`, () => {
        component.assignedRoleData.length = 2;
        component.currentRolePosition = 2;
        component.currentRoleExist = true;
        component.onConfirmClick();
        expect(component.currentRolePosition).toEqual(0);
        expect(component.isRemoveWarningVisible).toBe(false);
    });

    it('should get Row Id from User', () => {
        const user: User = { sf_contact_id: '0030400000VoiKbAAJ', contact_id: '0', contact_name: null, email: null, roles: [] };
        const userId = component['getRowId'](user);
        expect(userId).toEqual('0030400000VoiKbAAJ');
    });

    it(`should open modal when click on unassign with some role`, () => {
        component.currentRolePosition = 1;
        component.assignedRoleData[component.currentRolePosition] = {
            contact_id: 1,
            sf_contact_id: '1',
            contact_name: 'superuser',
            email: 'superuser@gmail.com',
            status: 'false',
            roles: [{
                'role_id': 4,
                'role_color': 'red',
                'role_name': 'Guest'
            }]
};
        component.UnassignRole();
        expect(component.currentRoleExist).toEqual(false);
        component.modalModel.cancelText = 'cancel';
        expect(component.modalModel.cancelText).toBeDefined();
        expect(component.modalModel.title).toBeDefined();
        expect(component.modalModel.confirmText).toBeDefined();
    });
    it(`should open modal when click on unassign with no role`, () => {
        component.assignedRoleData[component.currentRolePosition] = {
            contact_id: 1,
            sf_contact_id: '1',
            contact_name: 'superuser',
            email: 'superuser@gmail.com',
            status: 'false',
            roles: []
        };
        component.UnassignRole();
        expect(component.currentRoleExist).toEqual(true);
        component.modalModel.cancelText = 'cancel';
        delete component.modalModel.cancelText;
        expect(component.modalModel.cancelText).toBe(undefined);
        expect(component.modalModel.title).toBeDefined();
        expect(component.modalModel.confirmText).toBeDefined();
    });

    it(`should select some Users with no roles`, () => {
        spyOn(store, 'dispatch').and.callThrough();
        component.onSelectionChange({
            total: 1,
            selected: mockUsersFromRole.NouserRoles
        });
        expect(store.dispatch).toHaveBeenCalled();
    });

    it(`should show user created notification`, () => {
        component.showUserCreatedNotification = false;
        component['actionsListener$'].next(userManagementSaveSuccessAction({ result: true }));
        fixture.detectChanges();
        expect(component.showUserCreatedNotification).toBeTruthy();
    });

    it(`should destroy`, () => {
        spyOn(store, 'dispatch').and.callThrough();
        spyOn(component['_destroyed$'], 'next').and.callThrough();
        spyOn(component['_destroyed$'], 'complete').and.callThrough();
        component.ngOnDestroy();
        expect(store.dispatch).toHaveBeenCalled();
        expect(component['_destroyed$'].next).toHaveBeenCalled();
        expect(component['_destroyed$'].complete).toHaveBeenCalled();
    });

    it(`isAccordionOpenedAtleastOnce clicked should call getUsersForRoleAction`, () => {
        const dispatchSpy = spyOn(store, 'dispatch').and.callThrough();
        component.isAccordionOpenedAtleastOnce = true;
        component.loadUsers();
        fixture.detectChanges();
        expect(store.dispatch).toHaveBeenCalled();
    });

    it(`isAccordionOpenedAtleastOnce not clicked should not call getUsersForRoleAction`, () => {
        const dispatchSpy = spyOn(store, 'dispatch').and.callThrough();
        component.isAccordionOpenedAtleastOnce = false;
        component.loadUsers();
        fixture.detectChanges();
        expect(store.dispatch).not.toHaveBeenCalled();
    });
});