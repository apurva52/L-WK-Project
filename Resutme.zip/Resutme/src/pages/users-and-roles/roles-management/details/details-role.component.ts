/* tslint:disable:max-file-line-count */
/* tslint:disable:max-line-length */
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalModel } from '@ct/platform-primitives-uicomponents/modals';
import { ButtonType } from '@ct/platform-primitives-uicomponents/primitives';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { BreadcrumbItem } from '@wk/components';
import { cloneDeep } from 'lodash';
import { combineLatest, of, Subject, Subscription } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { map, take, takeUntil } from 'rxjs/operators';
import { selectIsInternal } from 'src/app/state/app.selectors';
import { AppState } from 'src/app/state/app.state';
import {
    BREADCRUMB_REFRESH_INTERVAL,
    RoleDetailsBreadcrumbItems
} from 'src/shared/config/breadcrumbsItems.config';
import { ModulePermissionsService } from 'src/shared/services/module-permissions/module-permissions.service';

import {
    createLevel,
    deleteLevel,
    editLevel
} from '../../../../shared/config/claims.config';
import { QUICK_SWITCHER_ROLES } from '../../../../shared/config/quick-switcher.config';
import { NavigationsService } from '../../../../shared/services/navigation/navigations.service';
import { selectIsAddUserModalVisible } from '../../users-management/state/user-management.selectors';
import { CreateRoleActionType } from '../components/add/components/interfaces/create-role-action-type.enum';
import { RoleType } from '../interfaces/role-type.enum';
import { Role } from '../interfaces/role.model';
import {
    AddUserRoleModalAction,
    roleManagementAddNewRoleModalAction,
    roleManagementCheckDeleteRoleModalAction,
    roleManagementDeleteRoleSuccessAction,
    roleManagementSaveNewRoleSuccessAction,
    roleManagementSelectAction,
    roleManagementToggleUpdateRoleMPModalAction,
    roleManagementUpdateRoleAction,
    roleManagementUpdateRoleFailureAction,
    roleManagementUpdateRoleSuccessAction
} from '../state/role-management.actions';
import * as selectors from '../state/role-management.selectors';

import { roleManagementGetRoleDetailsAction } from './../state/role-management.actions';
import {
    dotMenuOptions,
    roleDetailsSection,
    roleDetailsTitle,
    roleModulePermissionsTitle
} from './details-role.constants';
import {
    controlId,
    getSwitcherConfig
} from './shared/details-role.switcher.config';
import { RoleDetails, RolePermissions } from './state/role-details.state';

@Component({
    selector: 'ct-details-role',
    templateUrl: './details-role.component.html',
    styleUrls: ['./details-role.component.scss']
})
export class DetailsRoleComponent implements OnInit {
    readonly ButtonType = ButtonType;
    breadcrumbs: Array<BreadcrumbItem> = [];
    switcherConfig: any = {};
    defaultRoleId = '';
    controlId = controlId;
    rolesDetailsId = QUICK_SWITCHER_ROLES;
    updatedPermissionsInitializationCompleted = false;
    updatedPermissions: RolePermissions;

    showRoleCreatedNotification = false;
    roleNameCreated$: Observable<string> = this.store$.select(
        selectors.roleNameCreatedState
    );
    selectedRole = '';

    roleData: Array<Role>;
    selectedRoleData: Role = {} as Role;
    roleDetails: RoleDetails;
    roleDetailsLoaded$: Observable<boolean> = this.store$.select(
        selectors.roleDetailsLoaded
    );
    newValuesButtonType = ButtonType.Text;
    addValuesButtonType = ButtonType.Ghost;
    pillText: string;
    rowHeight: number = 72;
    dropDownSelectorId = '';
    roleDetailsTitle = this.translate.instant(roleDetailsTitle);
    roleModulePermissionsTitle = this.translate.instant(
        roleModulePermissionsTitle
    );
    roleDetailsSection = roleDetailsSection;
    dropdownOptions$ = of([]);
    breadcrumbsSubcription$: Subscription;
    discardModulesAndPermissionsChangesEvent = new Subject();
    isRoleUpdateNotificationVisible = false;
    roleUpdateNotificationModalModel: ModalModel = {
        title: 'userRolesModule.detailsComponent.updateRoleNotification.title',
        cancelText:
            'userRolesModule.detailsComponent.updateRoleNotification.cancelText',
        confirmText:
            'userRolesModule.detailsComponent.updateRoleNotification.confirmText'
    };
    updateRoleModalModel: ModalModel = {
        title: 'userRolesModule.detailsComponent.updateRoleModal.title',
        cancelText:
            'userRolesModule.detailsComponent.updateRoleModal.cancelText',
        confirmText:
            'userRolesModule.detailsComponent.updateRoleModal.confirmText'
    };
    displayUpdateModal: boolean = false;
    isUpdatingRole$: Observable<boolean> = this.store$.select(
        selectors.isUpdatingRole
    );
    userHasEditPermission =
        this.modulePermissionsService.doesUserHasPermission(editLevel);
    hasDeletePermission =
        this.modulePermissionsService.doesUserHasPermission(deleteLevel);
    userHasCreatePermission =
        !this.modulePermissionsService.doesUserHasPermission(createLevel);

    isInternal = null;
    deleteModalState$ = this.store$.select(
        selectors.selectedRoleManagementDeleteRoleModalState
    );
    relativePath: ActivatedRoute;
    baseURL = 'account-tools/users-and-roles/role-management';

    private _destroyed$ = new Subject();

    constructor(
        public translate: TranslateService,
        public store$: Store<AppState>,
        private route: ActivatedRoute,
        public router: Router,
        private navigationsService: NavigationsService,
        private actionsListener$: ActionsSubject,
        private modulePermissionsService: ModulePermissionsService
    ) {}

    ngOnInit(): void {
        this.store$
            .select(selectIsInternal)
            .pipe(take(1))
            .subscribe((isInternal) => {
                this.isInternal = isInternal;
                this.switcherConfig = getSwitcherConfig(this.isInternal);
            });
        this.navigationsService.hideBreadcrumbs(true);
        this.route.params.subscribe((params) => {
            this.defaultRoleId = params['id'];
            this.store$.dispatch(
                roleManagementGetRoleDetailsAction({
                    roleId: parseInt(this.defaultRoleId)
                })
            );
        });
        this.selectedRole = this.defaultRoleId;
        this.generateSelectorId();
        this.actionsListener$
            .pipe(
                ofType(roleManagementDeleteRoleSuccessAction),
                takeUntil(this._destroyed$)
            )
            .subscribe(() => this.navigateFullList());
        this.store$
            .select(selectors.roleDetailsState)
            .pipe(takeUntil(this._destroyed$))
            .subscribe((data) => (this.roleDetails = data));
        this.actionsListener$
            .pipe(
                ofType(roleManagementUpdateRoleSuccessAction),
                takeUntil(this._destroyed$)
            )
            .subscribe(() => {
                this.finishUpdateRole(true);
            });
        this.actionsListener$
            .pipe(
                ofType(roleManagementUpdateRoleFailureAction),
                takeUntil(this._destroyed$)
            )
            .subscribe(() => this.finishUpdateRole(false));
        this.actionsListener$
            .pipe(
                ofType(roleManagementSaveNewRoleSuccessAction),
                takeUntil(this._destroyed$)
            )
            .subscribe(() => {
                this.showRoleCreatedNotification = true;
            });
        this.relativePath = this.route?.parent?.parent;
        this.subscribeToBreadcrumbs();
        this.subscribeToRoleTableData();
    }

    ngOnDestroy(): void {
        this.navigationsService.hideBreadcrumbs(false);
        if (this.breadcrumbsSubcription$) {
            this.breadcrumbsSubcription$.unsubscribe();
        }
        this._destroyed$.next();
        this._destroyed$.complete();
        this.store$.dispatch(
            roleManagementToggleUpdateRoleMPModalAction({ isOpen: false })
        );
    }

    subscribeToRoleTableData(): void {
        combineLatest([
            this.store$.select(selectIsAddUserModalVisible),
            this.store$.select(selectors.selectRoleManagementStateData)
        ])
        .pipe(
            map(([isAddUserModalVisible , data]) => ({ isAddUserModalVisible, data })),
            takeUntil(this._destroyed$)
        )
        .subscribe(({ isAddUserModalVisible, data }) => {
            if (isAddUserModalVisible) { return; }
            if (data) {
                this.roleData = data.data;
                this.selectedRoleData = this.roleData.find(
                    (role) =>
                        role.role_id.toString() ===
                        this.defaultRoleId.toString()
                );
                this.setSelectedRole(this.selectedRoleData);
            } else {
                this.selectedRoleData = this.getSelectedRole();
            }
            this.selectedRoleData = {
                ...this.selectedRoleData,
                last_modified_date: [null, undefined, '', '-'].includes(
                    this.selectedRoleData?.last_modified_date
                )
                    ? '-'
                    : this.selectedRoleData.last_modified_date
            };
            this.updateDropdownOptions();
            this.roleChange(this.selectedRoleData, false);
        });
    }

    async roleChange(role: Role, isPopState: boolean = false): Promise<void> {
        this.updatedPermissionsInitializationCompleted = false;
        this.onDiscardModulesAndPermissionsChanges();
        const route = `${this.baseURL}/details/${role.role_id}`;
        this.setSelectedRole(role);
        this.selectedRole = this.defaultRoleId;
        const relatedData = this.getStoreData(role);
        this.store$.dispatch(
            roleManagementSelectAction({ selected: [relatedData], total: 1 })
        );
        this.router
            .navigate([route], {
                relativeTo: this.relativePath
            })
            .catch((err) => {
                throw new Error(
                    this.translate.instant('DefaultErrorMessages.routerError')
                );
            });

        this.defaultRoleId = role.role_id.toString();
        const newItems = RoleDetailsBreadcrumbItems(this.isInternal);
        setTimeout(() => {
            this.navigationsService.updateBreadcrumbs(newItems);
        }, BREADCRUMB_REFRESH_INTERVAL);
    }

    navigateFullList(): void {
        this.navigateTo(this.baseURL);
    }
    navigateBack(): void {
        this.navigateFullList();
    }

    setSelectedRole(role: Role): void {
        const storeData = this.getStoreData(role);
        this.clearSelectedRole();
        sessionStorage.setItem(this.selectedRole, JSON.stringify(storeData));
    }

    clearSelectedRole(): void {
        sessionStorage.removeItem(this.selectedRole);
    }

    getSelectedRole(): Role {
        const jsonString = sessionStorage.getItem(this.selectedRole);
        return jsonString ? JSON.parse(jsonString) : null;
    }

    getStoreData(role: Role): Role {
        if (role) {
            return {
                role_id: role.role_id,
                role: role.role,
                created_date: role.created_date,
                created_by_name: role.created_by_name,
                last_modified_date: role.last_modified_date,
                last_modified_by_name: role.last_modified_by_name,
                type: role.type
            };
        }
    }

    on3DotsOptionSelect(event): void {
        const copyAndCreate = this.translate.instant([...dotMenuOptions][0]);
        const assignUsers = this.translate.instant([...dotMenuOptions][1]);
        const deleteUser = this.translate.instant([...dotMenuOptions].pop());
        switch (event) {
            case copyAndCreate:
                this.openCopyAndCreateNewRole();
                break;
            case assignUsers:
                this.store$.dispatch(AddUserRoleModalAction({ value: true }));
                break;
            case deleteUser:
                this.store$.dispatch(
                    roleManagementCheckDeleteRoleModalAction({
                        roles: [this.selectedRoleData]
                    })
                );
                break;
        }
    }

    onPermissionsChanged(data: RolePermissions): void {
        if (this.updatedPermissionsInitializationCompleted) {
            if (this.roleDetails?.type === RoleType.SYSTEM) {
                this.discardModulesAndPermissionsChangesEvent.next();
                this.isRoleUpdateNotificationVisible = true;
            } else {
                this.updatedPermissions = data;
            }
        } else {
            this.updatedPermissionsInitializationCompleted = true;
        }
    }

    onCancelChanges(): void {
        this.store$.dispatch(
            roleManagementToggleUpdateRoleMPModalAction({ isOpen: true })
        );
    }

    toggleUpdateRoleModal(value: boolean): void {
        this.displayUpdateModal = value;
    }

    onUpdateRole(): void {
        this.updateRoleModalModel.confirmText =
            'userRolesModule.detailsComponent.updateRoleModal.confirmInProgressText';
        const { role, type, color } = this.roleDetails;
        const updatedRole = {
            roleId: parseInt(this.defaultRoleId),
            roleDetails: {
                role,
                type,
                color,
                ...this.updatedPermissions
            }
        };
        this.store$.dispatch(roleManagementUpdateRoleAction(updatedRole));
    }

    onDiscardModulesAndPermissionsChanges(): void {
        this.updatedPermissions = null;
        this.discardModulesAndPermissionsChangesEvent.next();
        this.store$.dispatch(
            roleManagementToggleUpdateRoleMPModalAction({ isOpen: false })
        );
    }

    openCopyAndCreateNewRole(): void {
        this.showRoleCreatedNotification = false;
        this.isRoleUpdateNotificationVisible = false;
        this.store$.dispatch(
            roleManagementAddNewRoleModalAction({
                isOpen: true,
                settings: {
                    createTypeToOpen:
                        CreateRoleActionType.COPY_AND_CREATE_NEW_ROLE,
                    existingRole: {
                        name: this.roleDetails.role,
                        id: +this.selectedRole
                    },
                    callbackAction: () => this.navigateFullList()
                }
            })
        );
    }
    private subscribeToBreadcrumbs(): void {
        this.breadcrumbsSubcription$ = this.navigationsService
            .getBreadcrumbs()
            .subscribe((list) => {
                this.breadcrumbs = cloneDeep(list);
            });
    }

    private async navigateTo(path: string): Promise<void> {
        await this.router.navigate([path], {
            relativeTo: this.relativePath,
            state: { breadcrumb: '' }
        });
    }

    private updateDropdownOptions(): void {
        const options = [...dotMenuOptions];
        const deleteOption = options.pop();
        const optionMaxLength = 3;

        if (
            this.hasDeletePermission &&
            this.selectedRoleData?.type !== RoleType.SYSTEM
        ) {
            options.push(deleteOption);
        }
        if (this.userHasCreatePermission) {
            if (options.length === optionMaxLength) {
                options.pop();
                options.shift();
            } else {
                options.shift();
            }
        }

        this.dropdownOptions$ = this.translate
            .get(options)
            .pipe(
                map((transation: { [key: string]: string }) =>
                    Object.values(transation)
                )
            );
    }

    private generateSelectorId(): void {
        const crypto = window.crypto;
        const id = crypto.getRandomValues(new Uint32Array(1))[0];
        this.dropDownSelectorId = `role-details-dropdown-${id}`;
    }

    private finishUpdateRole(result: boolean): void {
        if (result) {
            this.toggleUpdateRoleModal(false);
            this.updatedPermissions = null;
        }
        this.updateRoleModalModel.confirmText =
            'userRolesModule.detailsComponent.updateRoleModal.confirmText';
    }
}
