import {
    SwitcherConfig,
    SwitcherListItemType
} from '@ct/platform-common-uicomponents/quick-switcher';

export const controlId = 'switcher-roles-management-details';

export const getSwitcherConfig = (isInternal?: boolean): SwitcherConfig => ({
    defaultSortField: 'role',
    enableInfiniteScroll: false,
    expanded: true,
    hideFilter: true,
    i18nBase: 'userRolesModule.QuickSwitcherComponent',
    idField: 'role_id',
    searchField: '',
    rowDefinition: [
        {
            cellType: SwitcherListItemType.Text,
            propertyName: 'role'
        }
    ],
    queryParams: isInternal ? [{ field: 'type', value: 'i' }] : null
});
