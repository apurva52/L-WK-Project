export const dotMenuOptions = [
    'userRolesModule.detailsComponent.dotMenu.copyCreateNewRole',
    'userRolesModule.detailsComponent.dotMenu.assignUsers',
    'userRolesModule.detailsComponent.dotMenu.deleteRole'
];
export const roleDetailsSection = 'userRolesModule.detailsComponent';
export const newRolesLabel = 'userRolesModule.detailsComponent.newRole';
export const roleDetailsTitle = 'userRolesModule.detailsComponent.roleInfo';
export const roleModulePermissionsTitle = 'userRolesModule.detailsComponent.roleModulePermissions';
