/* tslint:disable:max-file-line-count */
import { initialAppState } from 'src/app/state/app.reducer';
import { AppState } from 'src/app/state/app.state';

import { CreateRoleActionType } from '../components/add/components/interfaces/create-role-action-type.enum';
import { RoleType } from '../interfaces/role-type.enum';

import { initialRoleManagementState } from './role-management.reducers';
import * as rolesSelectors from './role-management.selectors';
import { RoleManagementState } from './role-management.state';

const mockRolesData = {
    data: [
        {
            role_id: 123,
            role: 'Assistant Engineer',
            created_date: '2023-04-18T11:11:56',
            created_by_name: 'Dharmalingam Muniyappan',
            last_modified_date: '2023-04-18T11:11:56',
            last_modified_by_name: 'Dharmalingam Muniyappan',
            type: RoleType.INTERNAL
        },
        {
            role_id: 123,
            role: 'Assistant Engineer',
            created_date: '2023-04-18T11:11:56',
            created_by_name: 'Dharmalingam Muniyappan',
            last_modified_date: '2023-04-18T11:11:56',
            last_modified_by_name: 'Dharmalingam Muniyappan',
            type: RoleType.CUSTOMER
        }
    ],
    totalRecordCount: 0,
    page: 0,
    pageSize: 0,
    totalPages: 0
};

describe('RoleManagementState selectors', () => {
    it('should return current selectEntitiesLoadingStatus status', () => {
        const mockLoading = true;
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            loading: true
        };

        const currentData =
            rolesSelectors.selectRoleManagementStateLoadingStatus.projector(
                currentState
            );
        expect(currentData).toEqual(mockLoading);
    });

    it('should return current roles data', () => {
        const mockRolesData = {
            data: [],
            totalRecordCount: 0,
            page: 0,
            pageSize: 0,
            totalPages: 0
        };
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            rolesData: mockRolesData
        };

        const currentData =
            rolesSelectors.selectRoleManagementStateData.projector(
                currentState,
                initialAppState
            );
        expect(currentData).toEqual(mockRolesData);
    });

    it('should return only internal roles for internal users true', () => {
        const mockInsterOnlyRolesData = {
            data: [
                {
                    role_id: 123,
                    role: 'Assistant Engineer',
                    created_date: '2023-04-18T11:11:56',
                    created_by_name: 'Dharmalingam Muniyappan',
                    last_modified_date: '2023-04-18T11:11:56',
                    last_modified_by_name: 'Dharmalingam Muniyappan',
                    type: RoleType.INTERNAL
                }
            ],
            totalRecordCount: 0,
            page: 0,
            pageSize: 0,
            totalPages: 0
        };
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            rolesData: mockRolesData
        };
        const currentAppState: AppState = {
            isInternal: true,
            userTokenPayload: {},
            routeRedirectTo: 'dummy',
            breadcrumbsItems: []
        };
        const currentData =
            rolesSelectors.selectRoleManagementStateData.projector(
                currentState,
                currentAppState
            );
        expect(currentData).toEqual(mockInsterOnlyRolesData);
    });

    it('should return only all roles for External Users', () => {
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            rolesData: mockRolesData
        };
        const currentAppState: AppState = {
            isInternal: true,
            userTokenPayload: {},
            routeRedirectTo: 'dummy',
            breadcrumbsItems: []
        };
        const currentData =
            rolesSelectors.selectRoleManagementStateData.projector(
                currentState,
                currentAppState
            );
        expect(currentData).toEqual(mockRolesData);
    });

    it('should return current selected data', () => {
        const mockSelected = [];
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            selected: []
        };

        const currentData =
            rolesSelectors.selectedRoleManagementState.projector(currentState);
        expect(currentData).toEqual(mockSelected);
    });

    it('should return current delete role modal data', () => {
        const mockState = {
            isOpen: false
        };
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            deleteRoleModalState: {
                isOpen: false
            }
        };

        const currentData =
            rolesSelectors.selectedRoleManagementDeleteRoleModalState.projector(
                currentState
            );
        expect(currentData).toEqual(mockState);
    });

    it('should return current delete role modal data', () => {
        const mockState = {
            isOpen: false
        };
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            deleteRoleModalState: {
                isOpen: false
            }
        };

        const currentData =
            rolesSelectors.selectedRoleManagementDeleteRoleModalState.projector(
                currentState
            );
        expect(currentData).toEqual(mockState);
    });

    it('should return duplicate check boolean', () => {
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            isRoleNameDuplicate: true
        };

        const currentData =
            rolesSelectors.selectedDuplicateCheckState.projector(currentState);
        expect(currentData).toEqual(true);
    });

    it('should return if System Generated Roles string is Plurals', () => {
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            deleteRoleModalState: {
                isOpen: false,
                systemGeneratedRolesPlurals: 2
            }
        };

        const currentData =
            rolesSelectors.selectedSystemGeneratedRolesPlurals.projector(
                currentState
            );
        expect(currentData).toEqual(2);
    });

    it('should return duplicate check boolean if is checking state', () => {
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            isCheckingDuplicate: true
        };

        const currentData =
            rolesSelectors.selectedDuplicateCheckingState.projector(
                currentState
            );
        expect(currentData).toEqual(true);
    });

    it('should get selected roles for multiselect', () => {
        const mockRolesData = {
            data: [
                {
                    role_id: 1,
                    role: 'Test',
                    created_date: '',
                    created_by_name: 'Unit Test',
                    last_modified_date: '',
                    last_modified_by_name: 'Unit Test',
                    type: RoleType.CUSTOMER
                }
            ],
            totalRecordCount: 1,
            page: 0,
            pageSize: 1,
            totalPages: 1
        };
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            rolesData: mockRolesData
        };

        const currentData = rolesSelectors
            .selectedRolesForMultiSelect([
                { id: '1', label: 'Test', isSelected: true }
            ])
            .projector(currentState);
        expect(currentData).toBeDefined();
    });

    it('should get empty selected roles from no data', () => {
        const currentState: RoleManagementState = {
            ...initialRoleManagementState
        };
        const currentData = rolesSelectors
            .selectedRolesForMultiSelect([
                { id: '1', label: 'Test', isSelected: true }
            ])
            .projector(currentState);
        expect(currentData).toEqual([]);
    });

    it('should get roles for dropdown', () => {
        const mockRolesData = {
            data: [
                {
                    role_id: 1,
                    role: 'Test',
                    created_date: '',
                    created_by_name: 'Unit Test',
                    last_modified_date: '',
                    last_modified_by_name: 'Unit Test',
                    type: RoleType.CUSTOMER
                }
            ],
            totalRecordCount: 1,
            page: 0,
            pageSize: 1,
            totalPages: 1
        };
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            rolesData: mockRolesData
        };

        const currentData =
            rolesSelectors.rolesForSelectState.projector(currentState);
        expect(currentData).toEqual([
            {
                id: 1,
                name: 'Test'
            }
        ]);
    });
    it('should get empty list of roles from no data', () => {
        const currentState: RoleManagementState = {
            ...initialRoleManagementState
        };
        const currentData =
            rolesSelectors.rolesForSelectState.projector(currentState);
        expect(currentData).toEqual([]);
    });

    it('should get role from ID', () => {
        const mockRolesData = {
            data: [
                {
                    role_id: 1,
                    role: 'Test',
                    created_date: '',
                    created_by_name: 'Unit Test',
                    last_modified_date: '',
                    last_modified_by_name: 'Unit Test',
                    type: RoleType.CUSTOMER
                }
            ],
            totalRecordCount: 1,
            page: 0,
            pageSize: 1,
            totalPages: 1
        };
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            rolesData: mockRolesData
        };

        const currentData = rolesSelectors
            .roleFromIdState(1)
            .projector(currentState);
        expect(currentData).toEqual(mockRolesData.data[0]);
    });

    it('should not get role ID from no data', () => {
        const currentState: RoleManagementState = {
            ...initialRoleManagementState
        };
        const currentData = rolesSelectors
            .roleFromIdState(1)
            .projector(currentState);
        expect(currentData).toBeUndefined();
    });

    it('should get cancel role modules and permissions update state', () => {
        const currentState: RoleManagementState = {
            ...initialRoleManagementState
        };
        const currentData =
            rolesSelectors.cancelRoleModulesAndPermissionsUpdateState.projector(
                currentState
            );
        expect(currentData).toEqual({ isOpen: false });
    });

    it('should get isAddNewRoleModalVisible value', () => {
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            addNewRoleModalState: {
                isOpen: true
            }
        };
        const currentData =
            rolesSelectors.isAddNewRoleModalVisible.projector(currentState);
        expect(currentData).toEqual(true);
    });

    it('should get addNewRoleModalSettings value', () => {
        const settings = {
            createTypeToOpen: CreateRoleActionType.CREATE_NEW_ROLE
        };
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            addNewRoleModalState: {
                isOpen: true,
                settings: settings
            }
        };
        const currentData =
            rolesSelectors.addNewRoleModalSettings.projector(currentState);
        expect(currentData).toEqual(settings);
    });

    it('should get is updating role selector', () => {
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            updateRole: {
                ...initialRoleManagementState.updateRole,
                loading: true
            }
        };
        const currentData =
            rolesSelectors.isUpdatingRole.projector(currentState);
        expect(currentData).toBeTruthy();
    });

    it('should get is assigning role to a User', () => {
        const currentState: RoleManagementState = {
            ...initialRoleManagementState,
            assignEntityRole: {
                ...initialRoleManagementState.assignEntityRole,
                loading: true
            }
        };
        const currentData =
            rolesSelectors.isAssigningRoleToUser.projector(currentState);
        expect(currentData).toBeTruthy();
    });
});
