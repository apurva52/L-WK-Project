// tslint:disable max-file-line-count
// tslint:disable:max-line-length
import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { of, ReplaySubject, throwError } from 'rxjs';

import { AuthorizationManagementService } from '../../../../shared/services/authorization-management/authorization-management.service';
import { EntitiesService } from '../../../../shared/services/entities/entities.service';
import { GroupsService } from '../../../../shared/services/groups/groups.service';
import { RoleType } from '../interfaces/role-type.enum';
import { Role } from '../interfaces/role.model';

import { RoleManagementActionTypes } from './role-management.actions';
import { RoleManagementEffects } from './role-management.effects';

describe('RoleManagementEffects', () => {
    const actions: ReplaySubject<any> = new ReplaySubject();
    let roleManagementEffects: RoleManagementEffects;
    let result: any = null;
    let error: any = null;

    const authorizationManagementService = jasmine.createSpyObj<any>(
        'AuthorizationManagementService',
        [
            'getRolesList',
            'deleteRole',
            'getRolesList',
            'saveRole',
            'updateRole',
            'getUsersList',
            'getRoleDetails',
            'assignselectGroupsToRoleUser',
            'assignEntityGroupsToRoleUser',
            'getUsersAssignedToARole'
        ]
    );
    const groupsService = jasmine.createSpyObj<any>('GroupsService', [
        'addGroup',
        'updateGroupDetails'
    ]);
    const entitiesService = jasmine.createSpyObj<any>('EntitiesService', [
        'getEntitiesList'
    ]);
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                provideMockActions(() => actions),
                RoleManagementEffects,
                {
                    provide: AuthorizationManagementService,
                    useValue: authorizationManagementService
                },
                {
                    provide: GroupsService,
                    useValue: groupsService
                },
                {
                    provide: EntitiesService,
                    useValue: entitiesService
                }
            ]
        });
        roleManagementEffects = TestBed.inject(RoleManagementEffects);
    });

    describe('getRolesInitiate$', () => {
        it('should load roles', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.GetSuccess
            };
            authorizationManagementService.getRolesList.and.returnValue(
                of({ response: [] })
            );
            actions.next({ type: RoleManagementActionTypes.GetInitiate });
            roleManagementEffects.getRolesInitiate$.subscribe(
                (_result: any) => (result = _result)
            );
            expect(result.type).toEqual(expectedResult.type);
        });
        it('should fail loading roles', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.GetFailed
            };
            authorizationManagementService.getRolesList.and.returnValue(
                throwError('Error')
            );
            actions.next({ type: RoleManagementActionTypes.GetInitiate });
            roleManagementEffects.getRolesInitiate$.subscribe(
                (_error: any) => (error = _error)
            );
            expect(error.type).toEqual(expectedResult.type);
        });
    });

    describe('deleteRole$', () => {
        it('should check role to delete', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.DeleteRoleModal
            };
            authorizationManagementService.getUsersAssignedToARole.and.returnValue(
                of({
                    data: {
                        role_id: 1,
                        role_name: '',
                        users: [
                            {
                                contact_id: 1,
                                sf_contact_id: '1',
                                contact_name: '1',
                                email: '',
                                status: '',
                                roles: [
                                    {
                                        role_id: 2,
                                        role: 'role 2',
                                        created_date: '',
                                        created_by_name: '',
                                        last_modified_date: '',
                                        last_modified_by_name: '',
                                        type: RoleType.CUSTOMER
                                    } as Role
                                ]
                            }
                        ]
                    }
                })
            );
            actions.next({
                type: RoleManagementActionTypes.CheckAndDeleteRoleModal,
                roles: [{ role_id: 1 }]
            });
            roleManagementEffects.checkAndDeleteRoleAction$.subscribe(
                (_result: any) => (result = _result)
            );
            expect(result.type).toEqual(expectedResult.type);
        });
        it('should delete a role', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.DeleteRoleSuccess
            };
            authorizationManagementService.deleteRole.and.returnValue(
                of({ roleId: 123 })
            );
            actions.next({ type: RoleManagementActionTypes.DeleteRole });
            roleManagementEffects.deleteRole$.subscribe(
                (_result: any) => (result = _result)
            );
            expect(result.type).toEqual(expectedResult.type);
        });
        it('should fail deleting a role', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.GetFailed
            };
            authorizationManagementService.deleteRole.and.returnValue(
                throwError('Error')
            );
            actions.next({ type: RoleManagementActionTypes.DeleteRole });
            roleManagementEffects.deleteRole$.subscribe(
                (_error: any) => (error = _error)
            );
            expect(error.type).toEqual(expectedResult.type);
        });
    });

    describe('getDuplicateCheck$', () => {
        it('should check a duplicated role', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.GetDuplicateCheckSuccess
            };
            authorizationManagementService.getRolesList.and.returnValue(
                of({ roleId: 123 })
            );
            actions.next({ type: RoleManagementActionTypes.GetDuplicateCheck });
            roleManagementEffects.getDuplicateCheck$.subscribe(
                (_result: any) => (result = _result)
            );
            expect(result.type).toEqual(expectedResult.type);
        });
        it('should fail checking a duplicated role', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.GetDuplicateCheckFailed
            };
            authorizationManagementService.getRolesList.and.returnValue(
                throwError('Error')
            );
            actions.next({ type: RoleManagementActionTypes.GetDuplicateCheck });
            roleManagementEffects.getDuplicateCheck$.subscribe(
                (_error: any) => (error = _error)
            );
            expect(error.type).toEqual(expectedResult.type);
        });
    });

    describe('saveRole$', () => {
        it('should save a new role', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.SaveNewRoleSuccess
            };
            authorizationManagementService.saveRole.and.returnValue(of({}));
            actions.next({ type: RoleManagementActionTypes.SaveNewRole });
            roleManagementEffects.saveRole$.subscribe(
                (_result: any) => (result = _result)
            );
            expect(result.type).toEqual(expectedResult.type);
        });
        it('should fail saving a new role', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.SaveNewRoleFailed
            };
            authorizationManagementService.saveRole.and.returnValue(
                throwError('Error')
            );
            actions.next({ type: RoleManagementActionTypes.SaveNewRole });
            roleManagementEffects.saveRole$.subscribe(
                (_error: any) => (error = _error)
            );
            expect(error.type).toEqual(expectedResult.type);
        });
    });

    describe('loadUsersForMultiselect$', () => {
        it('should load users for multiselect', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.LoadUsersForMultiselectSuccess
            };
            authorizationManagementService.getUsersList.and.returnValue(
                of({ data: [] })
            );
            actions.next({
                type: RoleManagementActionTypes.LoadUsersForMultiselect
            });
            roleManagementEffects.loadUsersForMultiselect$.subscribe(
                (_result: any) => (result = _result)
            );
            expect(result.type).toEqual(expectedResult.type);
        });
        it('should fail loading users for multiselect', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.LoadUsersForMultiselectFailed
            };
            authorizationManagementService.getUsersList.and.returnValue(
                throwError('Error')
            );
            actions.next({
                type: RoleManagementActionTypes.LoadUsersForMultiselect
            });
            roleManagementEffects.loadUsersForMultiselect$.subscribe(
                (_error: any) => (error = _error)
            );
            expect(error.type).toEqual(expectedResult.type);
        });
    });

    describe('getRoleDetails$', () => {
        it('should load role details', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.GetRoleDetailsSuccess
            };
            authorizationManagementService.getRoleDetails.and.returnValue(
                of({})
            );
            actions.next({ type: RoleManagementActionTypes.GetRoleDetails });
            roleManagementEffects.getRoleDetails$.subscribe(
                (_result: any) => (result = _result)
            );
            expect(result.type).toEqual(expectedResult.type);
        });
        it('should fail loading role details', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.GetRoleDetailsFailure
            };
            authorizationManagementService.getRoleDetails.and.returnValue(
                throwError('Error')
            );
            actions.next({ type: RoleManagementActionTypes.GetRoleDetails });
            roleManagementEffects.getRoleDetails$.subscribe(
                (_error: any) => (error = _error)
            );
            expect(error.type).toEqual(expectedResult.type);
        });
    });

    describe('updateRole$', () => {
        it('should update a role', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.UpdateRoleSuccess
            };
            authorizationManagementService.updateRole.and.returnValue(of({}));
            actions.next({ type: RoleManagementActionTypes.UpdateRole });
            roleManagementEffects.updateRole$.subscribe(
                (_result: any) => (result = _result)
            );
            expect(result.type).toEqual(expectedResult.type);
        });
        it('should fail updating a role', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.UpdateRoleFailure
            };
            authorizationManagementService.updateRole.and.returnValue(
                throwError('Error')
            );
            actions.next({ type: RoleManagementActionTypes.UpdateRole });
            roleManagementEffects.updateRole$.subscribe(
                (_error: any) => (error = _error)
            );
            expect(error.type).toEqual(expectedResult.type);
        });
    });

    describe('usersRoleEntitiesAssign$', () => {
        it('should assign entity groups to a user role', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.UsersRoleEntitiesAssignSuccess
            };
            authorizationManagementService.assignEntityGroupsToRoleUser.and.returnValue(
                of({ result: true })
            );
            const params = {
                type: RoleManagementActionTypes.UsersRoleEntitiesAssign,
                roleId: 123,
                userIdToEntityGroups: {
                    1: [
                        {
                            edh_entity_group_type: 'C',
                            entities: [
                                {
                                    entity_id: 1
                                }
                            ]
                        }
                    ]
                }
            };
            actions.next(params);
            roleManagementEffects.usersRoleEntitiesAssign$.subscribe(
                (_result: any) => (result = _result)
            );
            expect(result.type).toEqual(expectedResult.type);
        });
        it('should assign implicit entity group to a user role', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.UsersRoleEntitiesAssignSuccess
            };
            authorizationManagementService.assignEntityGroupsToRoleUser.and.returnValue(
                of({ result: true })
            );
            groupsService.addGroup.and.returnValue(
                of({
                    data: {
                        result: {
                            EntityGroupId: 1,
                            EntityGroupGuid: 11
                        }
                    }
                })
            );
            const params = {
                type: RoleManagementActionTypes.UsersRoleEntitiesAssign,
                roleId: 123,
                userIdToEntityGroups: {
                    1: [
                        {
                            edh_entity_group_type: 'I',
                            entities: [
                                {
                                    entity_id: 1
                                }
                            ]
                        }
                    ]
                }
            };
            actions.next(params);
            roleManagementEffects.usersRoleEntitiesAssign$.subscribe(
                (_result: any) => (result = _result)
            );
            expect(result.type).toEqual(expectedResult.type);
        });
        it('should assign entities to existed user role', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.UsersRoleEntitiesAssignSuccess
            };
            authorizationManagementService.assignEntityGroupsToRoleUser.and.returnValue(
                of({ result: true })
            );
            groupsService.updateGroupDetails.and.returnValue(of(null));
            const params = {
                type: RoleManagementActionTypes.UsersRoleEntitiesAssign,
                roleId: 123,
                userIdToEntityGroups: {
                    1: [
                        {
                            edh_entity_group_id: 1,
                            edh_entity_group_type: 'I',
                            entities: [
                                {
                                    entity_id: 1
                                }
                            ]
                        },
                        {
                            edh_entity_group_id: 2,
                            edh_entity_group_type: 'C',
                            entities: [
                                {
                                    entity_id: 2
                                }
                            ]
                        }
                    ],
                    2: [
                        {
                            edh_entity_group_id: 1,
                            edh_entity_group_type: 'I',
                            entities: []
                        }
                    ]
                }
            };
            actions.next(params);
            roleManagementEffects.usersRoleEntitiesAssign$.subscribe(
                (_result: any) => (result = _result)
            );
            expect(result.type).toEqual(expectedResult.type);
        });
        it('should fail assigning entities to a user role', () => {
            const expectedResult = {
                type: RoleManagementActionTypes.UsersRoleEntitiesAssignFailure
            };
            authorizationManagementService.assignEntityGroupsToRoleUser.and.returnValue(
                of({ result: false })
            );
            groupsService.addGroup.and.returnValue(
                of({
                    data: {
                        result: {
                            EntityGroupId: 1,
                            EntityGroupGuid: 11
                        }
                    }
                })
            );
            const params = {
                type: RoleManagementActionTypes.UsersRoleEntitiesAssign,
                roleId: 123,
                userIdToEntityGroups: {
                    1: [
                        {
                            edh_entity_group_type: 'I',
                            entities: [
                                {
                                    entity_id: 1
                                }
                            ]
                        }
                    ]
                }
            };
            actions.next(params);
            roleManagementEffects.usersRoleEntitiesAssign$.subscribe(
                (_result: any) => (result = _result)
            );
            expect(result.type).toEqual(expectedResult.type);
        });
    });

    describe('getEntities$', () => {
        it('should load entities success', () => {
            const entitiesData = [{
                entity_id: 1,
                entity_guid: '1',
                entity_name: 'Test entity 1',
                entity_country: 'USA',
                domestic_jurisdiction: '',
                domestic_jurisdiction_abbr: ''
            }];
            const key = '1';
            const expectedResult = {
                type: RoleManagementActionTypes.GetEntitiesSuccess,
                data: entitiesData,
                key
            };
            entitiesService.getEntitiesList.and.returnValue(of(entitiesData));
            const params = {
                type: RoleManagementActionTypes.GetEntities,
                page: 1,
                pageSize: 100,
                key
            };
            actions.next(params);
            roleManagementEffects.getEntities$.subscribe(
                (_result: any) => (result = _result)
            );
            expect(result).toEqual(expectedResult);
        });
        it('should fail load entities', () => {
            const key = '1';
            const error = 'test error';
            const expectedResult = {
                type: RoleManagementActionTypes.GetEntitiesFailure,
                error,
                key
            };
            entitiesService.getEntitiesList.and.returnValue(throwError(error));
            const params = {
                type: RoleManagementActionTypes.GetEntities,
                page: 1,
                pageSize: 100,
                key
            };
            actions.next(params);
            roleManagementEffects.getEntities$.subscribe(
                (_result: any) => (result = _result)
            );
            expect(result).toEqual(expectedResult);
        });
    });
});
