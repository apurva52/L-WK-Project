// tslint:disable max-file-line-count
import { Injectable } from '@angular/core';
import { SwitcherRequest } from '@ct/platform-common-uicomponents/server';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { forkJoin, from, Observable, of } from 'rxjs';
import { catchError, flatMap, map, mergeMap, switchMap } from 'rxjs/operators';
import { GroupTypes } from 'src/pages/groups/shared';
import { EntitiesList } from 'src/shared/interfaces/entities.response';
import { EntitiesService } from 'src/shared/services/entities/entities.service';
import { GroupsService } from 'src/shared/services/groups/groups.service';
import { generateUUID } from 'src/shared/util';

import { AuthorizationManagementService } from '../../../../shared/services/authorization-management/authorization-management.service';
import { Entity } from '../../users-management/details/components/entities-from-role-grid/interfaces/entity';
import { EntityGroup, GridEntityGroup } from '../../users-management/details/components/entities-from-role-grid/interfaces/entity-group';
import { UserFromRole } from '../../users-management/interfaces/user.model';
import { USER_TO_ROLE_SEPARATOR } from '../interfaces/role-management.params';
import { Role } from '../interfaces/role.model';

import {
    getDuplicateCheckAction,
    getDuplicateCheckFailureAction,
    getDuplicateCheckSuccessAction,
    roleManagementCheckDeleteRoleModalAction,
    roleManagementDeleteRoleAction,
    roleManagementDeleteRoleModalAction,
    roleManagementDeleteRoleSuccessAction,
    roleManagementFailureAction,
    roleManagementGetEntitiesAction,
    roleManagementGetEntitiesFailureAction,
    roleManagementGetEntitiesSuccessAction,
    roleManagementGetRoleDetailsAction,
    roleManagementGetRoleDetailsFailureAction,
    roleManagementGetRoleDetailsSuccessAction,
    roleManagementInitiateAction,
    roleManagementLoadUsersForMultiselectAction,
    roleManagementLoadUsersForMultiselectFailureAction,
    roleManagementLoadUsersForMultiselectSuccessAction,
    roleManagementSaveNewRoleAction,
    roleManagementSaveNewRoleFailureAction,
    roleManagementSaveNewRoleSuccessAction,
    roleManagementSuccessAction,
    roleManagementUpdateRoleAction,
    roleManagementUpdateRoleFailureAction,
    roleManagementUpdateRoleSuccessAction,
    roleManagementUsersRoleEntitiesAssignAction,
    roleManagementUsersRoleEntitiesAssignFailureAction,
    roleManagementUsersRoleEntitiesAssignSuccessAction
} from './role-management.actions';

@Injectable()
export class RoleManagementEffects {
    getRolesInitiate$ = createEffect(() =>
        this.actions$.pipe(
            ofType(roleManagementInitiateAction),
            switchMap((params) => {
                return from(
                    this.authorizationManagementService.getRolesList(
                        params
                    )
                ).pipe(
                    map((response) =>
                        roleManagementSuccessAction({ response })
                    ),
                    catchError((err) =>
                        of(roleManagementFailureAction({ errorMessage: err }))
                    )
                );
            })
        )
    );

    deleteRole$ = createEffect(() =>
        this.actions$.pipe(
            ofType(roleManagementDeleteRoleAction),
            switchMap(({ roleId }) => {
                return from(
                    this.authorizationManagementService.deleteRole(roleId)
                ).pipe(
                    map((_response) =>
                        roleManagementDeleteRoleSuccessAction({ roleId })
                    ),
                    catchError((err) =>
                        of(roleManagementFailureAction({ errorMessage: err }))
                    )
                );
            })
        )
    );

    updateRole$ = createEffect(() =>
        this.actions$.pipe(
            ofType(roleManagementUpdateRoleAction),
            switchMap(({ roleId, roleDetails }) => {
                return from(
                    this.authorizationManagementService.updateRole(
                        roleId,
                        roleDetails
                    )
                ).pipe(
                    map(roleManagementUpdateRoleSuccessAction),
                    catchError((err) =>
                        of(
                            roleManagementUpdateRoleFailureAction({
                                errorMessage: err
                            })
                        )
                    )
                );
            })
        )
    );

    getDuplicateCheck$ = createEffect(() =>
        this.actions$.pipe(
            ofType(getDuplicateCheckAction),
            switchMap((_params) => {
                const records = { controlId: '', pageSize: 0, pageNumber: 1000 };
                return from(
                    this.authorizationManagementService.getRolesList(records)
                ).pipe(
                    map((response) =>
                        getDuplicateCheckSuccessAction({ response })
                    ),
                    catchError((err) =>
                        of(
                            getDuplicateCheckFailureAction({
                                errorMessage: err
                            })
                        )
                    )
                );
            })
        )
    );

    saveRole$ = createEffect(() =>
        this.actions$.pipe(
            ofType(roleManagementSaveNewRoleAction),
            switchMap((params) => {
                return from(
                    this.authorizationManagementService.saveRole(params.data)
                ).pipe(
                    map(roleManagementSaveNewRoleSuccessAction),
                    catchError((err) =>
                        of(
                            roleManagementSaveNewRoleFailureAction({
                                errorMessage: err
                            })
                        )
                    )
                );
            })
        )
    );

    loadUsersForMultiselect$ = createEffect(() =>
        this.actions$.pipe(
            ofType(roleManagementLoadUsersForMultiselectAction),
            switchMap((params) => {
                const records = 10000;
                const request: SwitcherRequest = {} as SwitcherRequest;
                request.pageSize = records;
                return from(
                    this.authorizationManagementService.getUsersList(request)
                ).pipe(
                    map((result) =>
                        roleManagementLoadUsersForMultiselectSuccessAction({
                            users: result.data
                        })
                    ),
                    catchError((err) =>
                        of(
                            roleManagementLoadUsersForMultiselectFailureAction({
                                errorMessage: err
                            })
                        )
                    )
                );
            })
        )
    );

    getRoleDetails$ = createEffect(() =>
        this.actions$.pipe(
            ofType(roleManagementGetRoleDetailsAction),
            mergeMap(({ roleId }) => {
                return from(
                    this.authorizationManagementService.getRoleDetails(roleId)
                ).pipe(
                    map((response) =>
                        roleManagementGetRoleDetailsSuccessAction({
                            roleId,
                            response
                        })
                    ),
                    catchError((err) =>
                        of(
                            roleManagementGetRoleDetailsFailureAction({
                                roleId,
                                errorMessage: err
                            })
                        )
                    )
                );
            })
        )
    );

    usersRoleEntitiesAssign$ = createEffect(() =>
        this.actions$.pipe(
            ofType(roleManagementUsersRoleEntitiesAssignAction),
            switchMap((params) => {
                const observables: Array<Observable<{ result: boolean }>> = [];
                Object.keys(params.userIdToEntityGroups).forEach(
                    (userIdGroup) => {
                        let internalGroupsRequests;
                        const entityGroups =
                            params.userIdToEntityGroups[userIdGroup];
                        const userId = userIdGroup.includes(
                            USER_TO_ROLE_SEPARATOR
                        )
                            ? userIdGroup.split(USER_TO_ROLE_SEPARATOR)[0]
                            : userIdGroup;
                        const roleId = userIdGroup.includes(
                            USER_TO_ROLE_SEPARATOR
                        )
                            ? parseInt(
                                  userIdGroup.split(USER_TO_ROLE_SEPARATOR)[1]
                              )
                            : params.roleId;
                        const customGroups = entityGroups.filter(
                            (group) => group.edh_entity_group_type !== 'I'
                        );
                        const customGroupsToAssociate = customGroups.map(
                            (item) => ({
                                group_type: item.edh_entity_group_type,
                                edh_entity_group_id: item.edh_entity_group_id,
                                edh_entity_group_guid:
                                    item.edh_entity_group_guid
                            })
                        );
                        const internalGroups = entityGroups.filter(
                            (group) => group.edh_entity_group_type === 'I'
                        );
                        if (internalGroups.length) {
                            internalGroupsRequests = [];
                            internalGroups.forEach((group: GridEntityGroup) => {
                                if (group.edh_entity_group_id >= 0 && !group.isAllEntitiesGroup) {
                                    internalGroupsRequests.push(
                                        this.updateGroupEntities(
                                            group,
                                            group.entities
                                        )
                                    );
                                } else {
                                    internalGroupsRequests.push(
                                        this.saveInternalGroup(group)
                                    );
                                }
                            });
                        }
                        if (internalGroupsRequests) {
                            observables.push(
                                forkJoin(internalGroupsRequests).pipe(
                                    flatMap((value) => {
                                        const savedInternalGroups =
                                            value.filter((item) => item);
                                        return from(
                                            this.authorizationManagementService.assignEntityGroupsToRoleUser(
                                                {
                                                    roleId,
                                                    userId,
                                                    entityGroups: [
                                                        ...customGroupsToAssociate,
                                                        ...savedInternalGroups
                                                    ] as any,
                                                    isExistedRole:
                                                        params.isExistedRole
                                                }
                                            )
                                        ).pipe(
                                            catchError((err) =>
                                                of({ result: false })
                                            )
                                        );
                                    })
                                )
                            );
                        } else {
                            observables.push(
                                from(
                                    this.authorizationManagementService.assignEntityGroupsToRoleUser(
                                        {
                                            roleId,
                                            userId,
                                            entityGroups: [
                                                ...customGroupsToAssociate
                                            ] as any,
                                            isExistedRole: params.isExistedRole
                                        }
                                    )
                                ).pipe(
                                    catchError((err) => of({ result: false }))
                                )
                            );
                        }
                    }
                );
                return forkJoin(
                    observables.length ? observables : [of({ result: false })]
                ).pipe(
                    map((response) => {
                        if (response.every((item) => !item.result)) {
                            return roleManagementUsersRoleEntitiesAssignFailureAction(
                                { errorMessage: 'error' }
                            );
                        } else {
                            return roleManagementUsersRoleEntitiesAssignSuccessAction();
                        }
                    })
                );
            })
        )
    );

    checkAndDeleteRoleAction$ = createEffect(() =>
        this.actions$.pipe(
            ofType(roleManagementCheckDeleteRoleModalAction),
            switchMap((params) => {
                const observables: Array<
                    Observable<{
                        isOpen: boolean;
                        roles?: Array<Role>;
                        usersWithAssignedOnlyRole?: Array<UserFromRole>;
                    }>
                > = [];
                params.roles.forEach((role) => {
                    observables.push(
                        from(
                            this.authorizationManagementService.getUsersAssignedToARole(
                                {
                                    roleId: `${role.role_id}`,
                                    pageNumber: 1,
                                    pageSize: 200
                                }
                            )
                        ).pipe(
                            map((response) => {
                                const usersWithAssignedOnlyRole =
                                    response.data.users.filter(
                                        (user) => user.roles?.length === 0
                                    ) || [];
                                return roleManagementDeleteRoleModalAction({
                                    isOpen: true,
                                    roles: [role],
                                    usersWithAssignedOnlyRole
                                });
                            }),
                            catchError((err) =>
                                of(
                                    roleManagementDeleteRoleModalAction({
                                        isOpen: false
                                    })
                                )
                            )
                        )
                    );
                });
                return forkJoin(
                    observables.length
                        ? observables
                        : [
                              of({
                                  isOpen: false,
                                  roles: [],
                                  usersWithAssignedOnlyRole: []
                              })
                          ]
                ).pipe(
                    map((response) => {
                        const roles: any = response.flatMap((item) => {
                            return {
                                roles: item.roles.flat(),
                                usersWithAssignedOnlyRole:
                                    item.usersWithAssignedOnlyRole
                            };
                        });
                        return roleManagementDeleteRoleModalAction({
                            isOpen: true,
                            usersWithAssignedOnlyRole:
                                roles[0].usersWithAssignedOnlyRole?.length > 0
                                    ? roles[0].usersWithAssignedOnlyRole
                                    : null,
                            roles: roles
                        });
                    })
                );
            })
        )
    );

    getEntities$ = createEffect(() =>
        this.actions$.pipe(
            ofType(roleManagementGetEntitiesAction),
            mergeMap((params) => {
                return from(
                    this.entitiesService.getEntitiesList({
                        page: params.page,
                        pageSize: params.pageSize
                    })
                ).pipe(
                    map((response: EntitiesList) =>
                        roleManagementGetEntitiesSuccessAction({ data: response, key: params.key })
                    ),
                    catchError((err) =>
                        of(roleManagementGetEntitiesFailureAction({ error: err, key: params.key }))
                    )
                );
            })
        )
    );

    constructor(
        private actions$: Actions,
        private authorizationManagementService: AuthorizationManagementService,
        private groupsSevice: GroupsService,
        private entitiesService: EntitiesService
    ) {}

    private updateGroupEntities(
        group: EntityGroup,
        entities: Array<Entity>
    ): Observable<null> {
        if (!entities?.length) {
            return of(null);
        }
        return from(
            this.groupsSevice.updateGroupDetails({
                entityGroupGuid: group.edh_entity_group_guid,
                EntityGroupName: group.edh_entity_group_name,
                EntityIds: entities.map((entity) => entity.entity_id).join(','),
                Comment: ''
            })
        ).pipe(
            map((data) => null),
            catchError((err) => of(null))
        );
    }

    private saveInternalGroup(group: GridEntityGroup): Observable<EntityGroup | null> {

        return group.isAllEntitiesGroup
            ? of({
                group_type: 'I',
                edh_entity_group_id: group.edh_entity_group_id,
                edh_entity_group_guid: group.edh_entity_group_guid
            })
            : from(
                this.groupsSevice.addGroup({
                    EntityGroupName: generateUUID(),
                    GroupType: GroupTypes.STATIC,
                    SelectBy: 'Entities',
                    CategoryJSON: null,
                    criteriaJSON: null,
                    EntityIds: group.entities
                        .map((entity) => entity.entity_id)
                        .join(','),
                    IsImplicitAuthGroup: 'Y'
                })
            ).pipe(
                map((data) => {
                    return data?.result
                        ? {
                                group_type: 'I',
                                edh_entity_group_id: data.result.entityGroupId,
                                edh_entity_group_guid: data.result.entityGroupGuid
                            }
                        : null;
                }),
                catchError((err) => of(null))
            );
    }
}
