export const ROLES_REDIRECT_COLUMNS = ['role'];

export const i18nDetailsKeys = {
    roles: 'roles',
    createdBy: 'createdBy',
    createdOn: 'createdOn',
    lastModifiedBy: 'lastModifiedBy',
    lastModifiedOn: 'lastModifiedOn',
    copyCreateNewRole: 'copyCreateNewRole',
    assignUsers: 'assignUsers',
    deleteRole: 'deleteRole',
    newRole: 'newRole',
    export: 'export'
};

export const i18nDetailsSection = {
    section: 'userRolesModule.detailsComponent',
    keys: i18nDetailsKeys
};

export function translateKeys(section: string, key: string): string {
    return `${section}.${i18nDetailsSection.keys[key]}`;
}
