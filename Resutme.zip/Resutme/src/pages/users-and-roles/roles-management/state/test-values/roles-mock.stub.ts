import { RoleType } from '../../interfaces/role-type.enum';

export const rolesResponseData = {
    totalRecordCount: 7,
    page: 1,
    pageSize: 100,
    totalPages: 1,
    data: [
        {
            role_id: 1,
            role: 'Admin',
            created_date: '07-12-2022',
            created_by_name: 'Jon Snow',
            last_modified_date: '07-12-2022',
            last_modified_by_name: 'Jon Snow',
            type: RoleType.SYSTEM
        },
        {
            role_id: 2,
            role: 'Admin 2',
            created_date: '04-18-2022',
            created_by_name: 'Rosa Kacy',
            last_modified_date: '02-12-2022',
            last_modified_by_name: 'Rosa Kacy',
            type: RoleType.CUSTOMER
        },
        {
            role_id: 3,
            role: 'Admin 3',
            created_date: '08-02-2021',
            created_by_name: 'Kacy Falkner',
            last_modified_date: '04-11-2021',
            last_modified_by_name: 'Rosa Kacy',
            type: RoleType.CUSTOMER
        },
        {
            role_id: 4,
            role: 'Admin 4',
            created_date: '02-20-2022',
            created_by_name: 'Dan Marengo',
            last_modified_date: '12-25-2021',
            last_modified_by_name: 'Dan Marengo',
            type: RoleType.CUSTOMER
        },
        {
            role_id: 5,
            role: 'Admin 5',
            created_date: '12-20-2020',
            created_by_name: 'Clemmie',
            last_modified_date: '11-27-2020',
            last_modified_by_name: 'Hyacinthia',
            type: RoleType.CUSTOMER
        },
        {
            role_id: 6,
            role: 'Admin 6',
            created_date: '10-13-2021',
            created_by_name: 'Rosco Broddy',
            last_modified_date: '12-14-2020',
            last_modified_by_name: 'Rosco Broddy',
            type: RoleType.CUSTOMER
        },
        {
            role_id: 7,
            role: 'Admin 7',
            created_date: '02-16-2022',
            created_by_name: 'Jessey Alano',
            last_modified_date: '12-09-2021',
            last_modified_by_name: 'Jessey Alano',
            type: RoleType.CUSTOMER
        },
        {
            role_id: 8,
            role: 'Admin 8',
            created_date: '02-16-2022',
            created_by_name: 'Vanessa Williams',
            last_modified_date: '12-09-2021',
            last_modified_by_name: 'Vanessa Williams',
            type: RoleType.CUSTOMER
        },
        {
            role_id: 9,
            role: 'Super User',
            created_date: '02-16-2022',
            created_by_name: '009988990',
            last_modified_date: '12-09-2021',
            last_modified_by_name: '919902',
            type: RoleType.SYSTEM
        }
    ]
};
