import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AppState, USERS_PANEL_APP_FEATURE_KEY } from 'src/app/state/app.state';

import { Role } from '../interfaces/role.model';

import { ROLE_MANAGEMENT_FEATURE_KEY, RoleManagementState } from './role-management.state';

export const selectRootFeature = createFeatureSelector<RoleManagementState>(ROLE_MANAGEMENT_FEATURE_KEY);

export const selectAppFeature = createFeatureSelector<AppState>(
    USERS_PANEL_APP_FEATURE_KEY
);

export const selectRoleManagementStateLoadingStatus = createSelector(selectRootFeature, (state: RoleManagementState) => state.loading);

export const selectRoleManagementStateData = createSelector(
    selectRootFeature, selectAppFeature, (state: RoleManagementState, appState: AppState) => {
    if (appState.isInternal) {
        const rolesDataRes = state?.rolesData;
        rolesDataRes.data = state?.rolesData.data.filter(row => row.type === 'I');
        return rolesDataRes;
    }
    else  return state?.rolesData;
});

export const selectedRoleManagementState = createSelector(selectRootFeature, (state: RoleManagementState) => state.selected);
export const selectedSystemGeneratedRoles = createSelector(
    selectRootFeature,
    (state: RoleManagementState) => state.deleteRoleModalState.systemGeneratedRoles
);
export const selectIsAddUserRoleModalVisible = createSelector(
    selectRootFeature,
    (state: RoleManagementState) => state?.isAddUserRoleModalVisible
);

export const selectedCustomGeneratedRoles = createSelector(
    selectRootFeature,
    (state: RoleManagementState) => state.deleteRoleModalState.customGeneratedRoles
);

export const selectedSystemGeneratedRolesPlurals = createSelector(
    selectRootFeature,
    (state: RoleManagementState) => state.deleteRoleModalState.systemGeneratedRolesPlurals
);

export const selectedCustomGeneratedRolesPlurals = createSelector(
    selectRootFeature,
    (state: RoleManagementState) => state.deleteRoleModalState.customGeneratedRolesPlurals
);

export const selectedDuplicateCheckState = createSelector(selectRootFeature, (state: RoleManagementState) => state?.isRoleNameDuplicate);
export const selectedDuplicateCheckingState = createSelector(selectRootFeature, (state: RoleManagementState) => state.isCheckingDuplicate);

export const selectedRoleManagementIdsState = createSelector(selectRootFeature, (state: RoleManagementState) =>
    state.selected.map((role) => role.role_id.toString())
);

export const selectedRolesForMultiSelect = (selectedRoles: Array<InputMultiselectItem>) =>
    createSelector(selectRootFeature, (state: RoleManagementState): Array<InputMultiselectItem> => {
        if (!state.rolesData?.data?.length) {
            return [];
        }
        return state.rolesData.data.map(({ role_id, role: label }) => {
            const id = role_id.toString();
            const isSelected = selectedRoles.some((selectedRole) => selectedRole.id === id);
            return { id, label, isSelected };
        });
    });

export const selectedRoleManagementDeleteRoleModalState = createSelector(
    selectRootFeature,
    (state: RoleManagementState) => state.deleteRoleModalState
);

export const rolesForSelectState = createSelector(selectRootFeature, (state: RoleManagementState): Array<{ name: string, id: number }> => {
    if (!state.rolesData?.data?.length) {
        return [];
    }
    return state.rolesData.data.map((role: Role) => ({ name: role.role, id: role.role_id }));
});

export const roleFromIdState = (roleId: number) => createSelector(selectRootFeature, (state: RoleManagementState): Role => {
    if (!state.rolesData?.data?.length) {
        return;
    }
    return state.rolesData.data.find((role: Role) => role.role_id === roleId);
});

export const roleDetailsState = createSelector(selectRootFeature, (state: RoleManagementState) => state?.roleDetailsState?.details);
export const roleDetailsLoaded = createSelector(selectRootFeature, ({ roleDetailsState }: RoleManagementState) => {
    return !roleDetailsState.loading && !!roleDetailsState.details;
});

export const roleNameCreatedState = createSelector(selectRootFeature, (state: RoleManagementState) => state.saveRole.roleName);

export const cancelRoleModulesAndPermissionsUpdateState = createSelector(
    selectRootFeature,
    (state: RoleManagementState) => state.cancelRoleModulesAndPermissionsUpdateState
);
export const isBackCheckState = createSelector(selectRootFeature, (state: RoleManagementState) => state.isBack);
export const modifiedRoleDetailsState = createSelector(selectRootFeature, (state: RoleManagementState) => state.updatedRoleDetails);
export const isAddNewRoleModalVisible = createSelector(
    selectRootFeature,
    (state: RoleManagementState) => state.addNewRoleModalState.isOpen
);
export const addNewRoleModalSettings = createSelector(
    selectRootFeature,
    (state: RoleManagementState) => state.addNewRoleModalState.settings
);
export const isUpdatingRole = createSelector(
    selectRootFeature,
    (state: RoleManagementState) => state.updateRole.loading
);
export const isAssigningRoleToUser = createSelector(
    selectRootFeature,
    (state: RoleManagementState) => state.assignEntityRole.loading
);
