export const ROLE_MANAGEMENT_FEATURE_KEY = 'roleManagementFeatureKey';
import { CgOption } from '@ct/platform-primitives-uicomponents/primitives';

import { UserFromRole } from '../../users-management/interfaces/user.model';
import { AddNewRoleModalSettings } from '../components/add/interfaces/add-new-role-modal-settings.interface';
import { RoleDetails } from '../details/state/role-details.state';
import { Role } from '../interfaces/role.model';

export const ROLES_PAGE_SIZE = 200;

export interface CgRoleOption extends Omit<CgOption, 'value'> {
    value: Role;
}

export interface PaginatedRoles {
    data: Array<Role>;
    totalRecordCount: number;
    page: number;
    pageSize: number;
    totalPages: number;
}

export interface RoleManagementState {
    loading: boolean;
    isAddUserRoleModalVisible: boolean;
    rolesData: PaginatedRoles;
    searchData: Array<{ value: string; label: string }>;
    error: {
        active: boolean;
        message: string;
    };
    selected: Array<Role>;
    deleteRoleModalState: {
        role?: Array<Role>;
        isOpen: boolean;
        systemGeneratedRoles?: string;
        customGeneratedRoles?: string;
        systemGeneratedRolesPlurals?: number;
        customGeneratedRolesPlurals?: number;
        usersWithAssignedOnlyRole?: Array<UserFromRole>;
    };
    saveRole: {
        loading: boolean;
        roleName: string;
        roleId: number;
        error: {
            active: boolean;
            message: string;
        };
    };
    updateRole: {
        loading: boolean;
        result: boolean;
        error: {
            active: boolean;
            message: string;
        };
    };
    roleDetailsState: {
        loading: boolean;
        details: RoleDetails;
        error: {
            active: boolean;
            message: string;
        };
    };
    roleNameCheck: string;
    isRoleNameDuplicate: boolean;
    isCheckingDuplicate: boolean;
    cancelRoleModulesAndPermissionsUpdateState: {
        isOpen: boolean
    };
    updatedRoleDetails: RoleDetails;
    isBack: boolean;
    addNewRoleModalState: {
        isOpen: boolean;
        settings?: AddNewRoleModalSettings;
    };
    assignEntityRole: {
        loading: boolean;
        result: boolean;
        error: {
            active: boolean;
            message: string;
        };
    };
}
