/* tslint:disable:max-line-length */
/* tslint:disable max-file-line-count */
import { SwitcherRequest } from '@ct/platform-common-uicomponents/server';
import { createAction, props } from '@ngrx/store';
import { EntitiesList } from 'src/shared/interfaces/entities.response';
import { SaveRoleRequest } from 'src/shared/interfaces/save-role.request';

import { SelectionChangeEvent } from '../../../../features/widgets/management-grid/interfaces/selection-change-event.interface';
import { EntityGroup } from '../../users-management/details/components/entities-from-role-grid/interfaces/entity-group';
import {
    User,
    UserFromRole
} from '../../users-management/interfaces/user.model';
import { AddNewRoleModalSettings } from '../components/add/interfaces/add-new-role-modal-settings.interface';
import {
    RoleDetails,
    UpdateRoleRequest
} from '../details/state/role-details.state';
import { Role } from '../interfaces/role.model';

import { PaginatedRoles } from './role-management.state';

export enum RoleManagementActionTypes {
    GetInitiate = `[Role Management] Get Roles`,
    GetFailed = `[Role Management] Get Roles Failure`,
    GetSuccess = `[Role Management] Get Roles Success`,
    Filter = `[Role Management] Filter Roles`,
    FilterFailure = `[Role Management] Filter Roles Failure`,
    FilterSuccess = `[Role Management] Filter Roles Success`,
    SelectRoles = `[Role Management] Select Roles`,
    ClearSelectRoles = `[Role Management] Clear Select Roles`,
    CheckAndDeleteRoleModal = `[Role Management] Check And Delete Role Modal`,
    DeleteRoleModal = `[User Management] Toggle Delete Role Modal`,
    DeleteRole = `[Role Management] Delete Role`,
    DeleteRoleSuccess = `[Role Management] Delete Role Success`,
    GetDuplicateCheck = `[User Users for Role] Get Duplicate Check`,
    GetDuplicateCheckFailed = `[User Users for Role] Get Duplicate Check Failure`,
    GetDuplicateCheckSuccess = `[User Users for Role] Get Duplicate Check Success`,
    ResetDuplicateCheckState = `[Role Management] Reset Duplicate Check State`,
    AddNewRoleModal = `[Role Management] Add New Role Modal`,
    SaveNewRole = `[Role Management] Save New Role`,
    SaveNewRoleFailed = `[Role Management] Save New Role Failure`,
    SaveNewRoleSuccess = `[Role Management] Save New Role Success`,
    LoadUsersForMultiselect = `[Role Management] Load Users For Multiselect`,
    LoadUsersForMultiselectFailed = `[Role Management] Load Users For Multiselect Failure`,
    LoadUsersForMultiselectSuccess = `[Role Management] Load Users For Multiselect Success`,
    GetRoleDetails = `[Role Management] Get Role Details`,
    GetRoleDetailsSuccess = `[Role Management] Get Role Details Success`,
    GetRoleDetailsFailure = `[Role Management] Get Role Details Failure`,
    UsersRoleEntitiesAssign = `[Role Management] Users Role Entities Assign`,
    UsersRoleEntitiesAssignSuccess = `[Role Management] Users Role Entities Assign Success`,
    UsersRoleEntitiesAssignFailure = `[Role Management] Users Role Entities Assign Failure`,
    ToggleCancelUpdateRoleMPModal = `[Role Management] Toggle Cancel Update Role M&P Modal`,
    CheckPreviousAction = `[Role Management] Check Previous Action`,
    getModifiedRoleDetails = '[Role Management] Get Modified Role Details',
    AddUserRoleModal = `[User Management] Toggle Add User Role Modal`,
    UpdateRole = `[Role Management] Update Role`,
    UpdateRoleSuccess = `[Role Management] Update Role Success`,
    UpdateRoleFailure = `[Role Management] Update Role Success`,
    GetEntities = `[Role Management] Get Entities`,
    GetEntitiesSuccess = `[Role Management] Get Entities Success`,
    GetEntitiesFailure = `[Role Management] Get Entities Failure`
}

export const roleManagementInitiateAction = createAction(
    RoleManagementActionTypes.GetInitiate,
    props<SwitcherRequest>()
);

export const roleManagementSuccessAction = createAction(
    RoleManagementActionTypes.GetSuccess,
    props<{ response: PaginatedRoles }>()
);

export const roleManagementFailureAction = createAction(
    RoleManagementActionTypes.GetFailed,
    props<{
        errorMessage: string;
    }>()
);
export const roleManagementSelectAction = createAction(
    RoleManagementActionTypes.SelectRoles,
    props<SelectionChangeEvent>()
);
export const roleManagementClearSelectAction = createAction(
    RoleManagementActionTypes.ClearSelectRoles
);
export const roleManagementCheckDeleteRoleModalAction = createAction(
    RoleManagementActionTypes.CheckAndDeleteRoleModal,
    props<{ roles: Array<Role> }>()
);
export const roleManagementDeleteRoleModalAction = createAction(
    RoleManagementActionTypes.DeleteRoleModal,
    props<{
        roles?: Array<Role>;
        isOpen: boolean;
        usersWithAssignedOnlyRole?: Array<UserFromRole>;
    }>()
);
export const AddUserRoleModalAction = createAction(
    RoleManagementActionTypes.AddUserRoleModal,
    props<{ value: boolean }>()
);
export const roleManagementDeleteRoleAction = createAction(
    RoleManagementActionTypes.DeleteRole,
    props<{ roleId: number }>()
);
export const roleManagementDeleteRoleSuccessAction = createAction(
    RoleManagementActionTypes.DeleteRoleSuccess,
    props<{ roleId: number }>()
);
export const getDuplicateCheckAction = createAction(
    RoleManagementActionTypes.GetDuplicateCheck,
    props<{ roleName: string }>()
);
export const getDuplicateCheckSuccessAction = createAction(
    RoleManagementActionTypes.GetDuplicateCheckSuccess,
    props<{ response: any }>()
);
export const getDuplicateCheckFailureAction = createAction(
    RoleManagementActionTypes.GetDuplicateCheckFailed,
    props<{
        errorMessage: string;
    }>()
);
export const resetDuplicateCheckStateAction = createAction(
    RoleManagementActionTypes.ResetDuplicateCheckState
);
export const roleManagementAddNewRoleModalAction = createAction(
    RoleManagementActionTypes.AddNewRoleModal,
    props<{
        isOpen: boolean;
        settings?: AddNewRoleModalSettings;
    }>()
);
export const roleManagementSaveNewRoleAction = createAction(
    RoleManagementActionTypes.SaveNewRole,
    props<{ data: SaveRoleRequest }>()
);
export const roleManagementSaveNewRoleSuccessAction = createAction(
    RoleManagementActionTypes.SaveNewRoleSuccess,
    props<{ role_id: number }>()
);
export const roleManagementSaveNewRoleFailureAction = createAction(
    RoleManagementActionTypes.SaveNewRoleFailed,
    props<{
        errorMessage: string;
    }>()
);
export const roleManagementLoadUsersForMultiselectAction = createAction(
    RoleManagementActionTypes.LoadUsersForMultiselect
);
export const roleManagementLoadUsersForMultiselectSuccessAction = createAction(
    RoleManagementActionTypes.LoadUsersForMultiselectSuccess,
    props<{ users: Array<User> }>()
);
export const roleManagementLoadUsersForMultiselectFailureAction = createAction(
    RoleManagementActionTypes.LoadUsersForMultiselectFailed,
    props<{ errorMessage: string }>()
);
export const roleManagementGetRoleDetailsAction = createAction(
    RoleManagementActionTypes.GetRoleDetails,
    props<{ roleId: number }>()
);
export const roleManagementGetRoleDetailsSuccessAction = createAction(
    RoleManagementActionTypes.GetRoleDetailsSuccess,
    props<{ roleId: number; response: any }>()
);
export const roleManagementGetRoleDetailsFailureAction = createAction(
    RoleManagementActionTypes.GetRoleDetailsFailure,
    props<{
        roleId: number;
        errorMessage: string;
    }>()
);
export const roleManagementUsersRoleEntitiesAssignAction = createAction(
    RoleManagementActionTypes.UsersRoleEntitiesAssign,
    props<{
        roleId?: number;
        userIdToEntityGroups: Record<string, Array<EntityGroup>>;
        isExistedRole?: boolean;
    }>()
);
export const roleManagementUsersRoleEntitiesAssignSuccessAction = createAction(
    RoleManagementActionTypes.UsersRoleEntitiesAssignSuccess
);
export const roleManagementUsersRoleEntitiesAssignFailureAction = createAction(
    RoleManagementActionTypes.UsersRoleEntitiesAssignFailure,
    props<{
        errorMessage: string;
    }>()
);
export const roleManagementToggleUpdateRoleMPModalAction = createAction(
    RoleManagementActionTypes.ToggleCancelUpdateRoleMPModal,
    props<{
        isOpen: boolean;
    }>()
);
export const roleManagementCheckPreviousButtonAction = createAction(
    RoleManagementActionTypes.CheckPreviousAction,
    props<{
        isBack: boolean;
    }>()
);
export const roleManagementGetModifiedRoleDetailsAction = createAction(
    RoleManagementActionTypes.getModifiedRoleDetails,
    props<{
        updatedRoleDetails: RoleDetails;
    }>()
);

export const roleManagementUpdateRoleAction = createAction(
    RoleManagementActionTypes.UpdateRole,
    props<{
        roleId: number;
        roleDetails: UpdateRoleRequest;
    }>()
);

export const roleManagementUpdateRoleSuccessAction = createAction(
    RoleManagementActionTypes.UpdateRoleSuccess,
    props<{ result: boolean }>()
);

export const roleManagementUpdateRoleFailureAction = createAction(
    RoleManagementActionTypes.UpdateRoleFailure,
    props<{
        errorMessage: string;
    }>()
);

export const roleManagementGetEntitiesAction = createAction(
    RoleManagementActionTypes.GetEntities,
    props<{
        page: number;
        pageSize: number;
        key: string;
    }>()
);

export const roleManagementGetEntitiesSuccessAction = createAction(
    RoleManagementActionTypes.GetEntitiesSuccess,
    props<{
        data: EntitiesList;
        key: string;
    }>()
);

export const roleManagementGetEntitiesFailureAction = createAction(
    RoleManagementActionTypes.GetEntitiesFailure,
    props<{
        error: any;
        key: string;
    }>()
);