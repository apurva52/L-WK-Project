/* tslint:disable:max-file-line-count */

import mockRoleDetails from '../details/state/test-values/role-details-mock.json';

import * as roleManagementActions from './role-management.actions';
import {
    initialRoleManagementState,
    roleManagementReducer
} from './role-management.reducers';
import { RoleManagementState } from './role-management.state';
import { PaginatedRoles } from './role-management.state';
import mockRoleManagement from './test-values/mock-roles.json';

describe('roles management reducer', () => {
    it('should process roles load', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementInitiateAction({
                    controlId: 'demo',
                    pageNumber: 1,
                    pageSize: 10
                })
            )
        ).toEqual({
            ...currentState,
            loading: true
        });
    });
    it('should process roles load success', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementSuccessAction({
                    response: mockRoleManagement as PaginatedRoles
                })
            )
        ).toEqual({
            ...currentState,
            loading: false,
            rolesData: mockRoleManagement as PaginatedRoles
        });
    });
    it('should process roles load failure', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementFailureAction({
                    errorMessage: 'Unit Test error'
                })
            )
        ).toEqual({
            ...currentState,
            error: {
                active: true,
                message: 'Unit Test error'
            }
        });
    });

    it('should select any roles', () => {
        const currentState = { ...initialRoleManagementState };
        const newState = {
            total: mockRoleManagement.data.length,
            selected: mockRoleManagement.data,
            deleteRoleModalState: { isOpen: false }
        };
        const expectedCustomRoles = `"A", "aa", "addda", "AfI2", "Ajith New", "Auditor Manager", "DevRole", "Diego's Role", "Diego's role from scratch", "DZ NEW", "DZ ROLE", "DZ ROLE N", "DZ ROLE N1", "DZ1", "DZ3", "DZ4", "From Scratch", "GEGE", "Guest", "junior Auditor", "Manager", "My New role", "My Role", "New  Update Role1", "New Role1 JMB", "New scr role", "New Role Save", "New Role Save1", "New Role Save2", "Test", "Test Role", "Test Role 2", "Test Role 3", "wewe"`;
        const expectedSystemRoles = `"aaademo001a", "aaademo001c", "aaademo001d", "aaademo01b", "demo001", "demo001a", "demo001c", "demo002", "saveRole", "Super User", "Test Role 1", "test role 436556", "Testing", "zzzdemo001a", "zzzdemo001b", "zzzdemo001d"`;

        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementSelectAction(newState)
            )
        ).toEqual({
            ...currentState,
            selected: mockRoleManagement.data,
            deleteRoleModalState: {
                isOpen: false,
                systemGeneratedRoles: expectedSystemRoles,
                systemGeneratedRolesPlurals: 16,
                customGeneratedRoles: expectedCustomRoles,
                customGeneratedRolesPlurals: 34
            }
        });
    });
    it('should clear roles', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementClearSelectAction()
            )
        ).toEqual({
            ...currentState,
            selected: []
        });
    });
    it('should change isOpen state for delete role modal', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementDeleteRoleModalAction({
                    roles: [],
                    isOpen: true
                })
            )
        ).toEqual({
            ...currentState,
            deleteRoleModalState: {
                role: [],
                isOpen: true,
                systemGeneratedRoles: '',
                customGeneratedRoles: '',
                systemGeneratedRolesPlurals: 0,
                customGeneratedRolesPlurals: 0,
                usersWithAssignedOnlyRole: []
            }
        });
    });

    it('should Check DuplicatesAction from the list of Roles', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.getDuplicateCheckAction({
                    roleName: 'Admin'
                })
            )
        ).toEqual({
            ...currentState,
            roleNameCheck: 'Admin',
            isRoleNameDuplicate: false,
            isCheckingDuplicate: true
        });
    });

    it('should Check DuplicatesAction from the list of Roles', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.getDuplicateCheckSuccessAction({
                    response: mockRoleManagement
                })
            )
        ).toEqual({
            ...currentState,
            isRoleNameDuplicate: false,
            isCheckingDuplicate: false
        });
    });

    it('should Check Duplicates failure', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.getDuplicateCheckFailureAction({
                    errorMessage: 'Unit Test error'
                })
            )
        ).toEqual({
            ...currentState,
            roleNameCheck: '',
            isRoleNameDuplicate: false,
            isCheckingDuplicate: false
        });
    });

    it('should call a details of Role management success', () => {
        const currentState: RoleManagementState = {
            ...initialRoleManagementState
        };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementGetRoleDetailsSuccessAction(
                    { roleId: 1, response: mockRoleDetails }
                )
            )
        ).toEqual({
            ...currentState,
            roleDetailsState: {
                ...currentState.roleDetailsState,
                loading: false,
                details: mockRoleDetails.data
            }
        });
    });

    it('should call a details of Role management failure', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementGetRoleDetailsFailureAction(
                    { roleId: 1, errorMessage: 'Unit Test error' }
                )
            )
        ).toEqual({
            ...currentState,
            roleDetailsState: {
                ...currentState.roleDetailsState,
                loading: false,
                error: {
                    ...currentState.error,
                    message: 'Unit Test error'
                }
            }
        });
    });

    it('should call a save role', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementSaveNewRoleAction({
                    data: { role: 'Unit test' } as any
                })
            )
        ).toEqual({
            ...currentState,
            saveRole: {
                ...currentState.saveRole,
                loading: true,
                roleName: 'Unit test'
            }
        });
    });

    it('should call a save role success', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementSaveNewRoleSuccessAction({
                    role_id: 1
                })
            )
        ).toEqual({
            ...currentState,
            saveRole: {
                ...currentState.saveRole,
                loading: false,
                error: null,
                roleId: 1
            }
        });
    });

    it('should call a save role failure', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementSaveNewRoleFailureAction({
                    errorMessage: 'Unit Test error'
                })
            )
        ).toEqual({
            ...currentState,
            saveRole: {
                ...currentState.saveRole,
                loading: false,
                error: 'Unit Test error'
            }
        });
    });

    it('should call a reset Duplicate CheckState Action', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.resetDuplicateCheckStateAction()
            )
        ).toEqual({
            ...currentState,
            roleNameCheck: '',
            isRoleNameDuplicate: false,
            isCheckingDuplicate: false
        });
    });

    it('should call a open cancel role modules and permissions modal action', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementToggleUpdateRoleMPModalAction(
                    { isOpen: true }
                )
            )
        ).toEqual({
            ...currentState,
            cancelRoleModulesAndPermissionsUpdateState: {
                isOpen: true
            }
        });
    });

    it('should call a open create new role modal action', () => {
        const currentState = { ...initialRoleManagementState };
        const actionProps = {
            isOpen: true,
            settings: {}
        };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementAddNewRoleModalAction(
                    actionProps
                )
            )
        ).toEqual({
            ...currentState,
            addNewRoleModalState: actionProps
        });
    });
    it('should call a update role', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementUpdateRoleAction({ roleId: 1, roleDetails: {} as any })
            )
        ).toEqual({
            ...currentState,
            updateRole: {
                ...currentState.updateRole,
                loading: true
            }
        });
    });

    it('should call a update role failure', () => {
        const currentState = { ...initialRoleManagementState };
        const errorMessage = 'Unit Test error';
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementUpdateRoleFailureAction({ errorMessage })
            )
        ).toEqual({
            ...currentState,
            updateRole: {
                ...currentState.updateRole,
                loading: false,
                error: {
                    active: true,
                    message: errorMessage
                }
            }
        });
    });

    it('should call Users Role Entities Assign', () => {
        const currentState = { ...initialRoleManagementState };
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementUsersRoleEntitiesAssignSuccessAction()
            )
        ).toEqual({
            ...currentState,
            assignEntityRole: {
                ...currentState.assignEntityRole,
                result: true,
                loading: false
            }
        });
    });

    it('should call a update role failure', () => {
        const currentState = { ...initialRoleManagementState };
        const errorMessage = 'Unit Test error';
        expect(
            roleManagementReducer(
                currentState,
                roleManagementActions.roleManagementUsersRoleEntitiesAssignFailureAction({ errorMessage })
            )
        ).toEqual({
            ...currentState,
            assignEntityRole: {
                ...currentState.assignEntityRole,
                loading: false,
                error: {
                    active: true,
                    message: errorMessage
                }
            }
        });
    });
});
