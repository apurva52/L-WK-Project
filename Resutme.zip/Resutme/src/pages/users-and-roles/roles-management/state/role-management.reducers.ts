/* tslint:disable:max-file-line-count */
import { createReducer, on } from '@ngrx/store';

import { roleDetailsInitialState } from '../details/state/role-details.state';
import { RoleType } from '../interfaces/role-type.enum';

import {
    AddUserRoleModalAction,
    getDuplicateCheckAction,
    getDuplicateCheckFailureAction,
    getDuplicateCheckSuccessAction,
    resetDuplicateCheckStateAction,
    roleManagementAddNewRoleModalAction,
    roleManagementCheckPreviousButtonAction,
    roleManagementClearSelectAction,
    roleManagementDeleteRoleModalAction,
    roleManagementFailureAction,
    roleManagementGetModifiedRoleDetailsAction,
    roleManagementGetRoleDetailsAction,
    roleManagementGetRoleDetailsFailureAction,
    roleManagementGetRoleDetailsSuccessAction,
    roleManagementInitiateAction,
    roleManagementSaveNewRoleAction,
    roleManagementSaveNewRoleFailureAction,
    roleManagementSaveNewRoleSuccessAction,
    roleManagementSelectAction,
    roleManagementSuccessAction,
    roleManagementToggleUpdateRoleMPModalAction,
    roleManagementUpdateRoleAction,
    roleManagementUpdateRoleFailureAction,
    roleManagementUpdateRoleSuccessAction,
    roleManagementUsersRoleEntitiesAssignAction,
    roleManagementUsersRoleEntitiesAssignFailureAction,
    roleManagementUsersRoleEntitiesAssignSuccessAction
} from './role-management.actions';
import { RoleManagementState } from './role-management.state';

export const initialRoleManagementState: RoleManagementState = {
    loading: false,
    rolesData: {
        data: [],
        totalRecordCount: 0,
        page: 0,
        pageSize: 0,
        totalPages: 0
    },
    searchData: [],
    error: {
        active: false,
        message: ''
    },
    selected: [],
    deleteRoleModalState: {
        isOpen: false,
        systemGeneratedRoles: '',
        customGeneratedRoles: '',
        systemGeneratedRolesPlurals: 0,
        customGeneratedRolesPlurals: 0,
        usersWithAssignedOnlyRole: []
    },
    roleNameCheck: '',
    isRoleNameDuplicate: false,
    isCheckingDuplicate: false,
    isAddUserRoleModalVisible: false,
    saveRole: {
        loading: false,
        roleName: '',
        roleId: null,
        error: {
            active: false,
            message: ''
        }
    },
    updateRole: {
        loading: false,
        result: null,
        error: {
            active: false,
            message: ''
        }
    },
    roleDetailsState: {
        details: null,
        loading: false,
        error: {
            active: false,
            message: ''
        }
    },
    assignEntityRole: {
        result: null,
        loading: false,
        error: {
            active: false,
            message: ''
        }
    },
    cancelRoleModulesAndPermissionsUpdateState: {
        isOpen: false
    },
    isBack: false,
    updatedRoleDetails: roleDetailsInitialState,
    addNewRoleModalState: {
        isOpen: false
    }
};

export const roleManagementReducer = createReducer(
    initialRoleManagementState,
    on(roleManagementInitiateAction, (state) => ({
        ...state,
        loading: true,
        rolesData: initialRoleManagementState.rolesData
    })),
    on(roleManagementSuccessAction, (state, action) => ({
        ...state,
        loading: false,
        rolesData: action.response,
        error: {
            active: false,
            message: ''
        }
    })),
    on(AddUserRoleModalAction, (state, action) => ({
        ...state,
        isAddUserRoleModalVisible: action.value
    })),
    on(roleManagementFailureAction, (state, action) => ({
        ...state,
        loading: false,
        rolesData: initialRoleManagementState.rolesData,
        error: {
            active: true,
            message: action.errorMessage
        }
    })),
    on(roleManagementSelectAction, (state, action) => {
        const systemGeneratedRoles = action.selected.filter((role) => role.type === RoleType.SYSTEM);
        const systemGeneratedRolesString = systemGeneratedRoles.map(({ role }) => `"${role}"`).join(', ');
        const customGeneratedRoles = action.selected.filter((role) => role.type === RoleType.CUSTOMER);
        const customGeneratedRolesString = customGeneratedRoles.map(({ role }) => `"${role}"`).join(', ');
        return {
            ...state,
            selected: action.selected,
            deleteRoleModalState: {
                isOpen: state.deleteRoleModalState.isOpen,
                systemGeneratedRoles: systemGeneratedRoles.length > 0 ? systemGeneratedRolesString : '',
                systemGeneratedRolesPlurals: systemGeneratedRoles.length,
                customGeneratedRoles: customGeneratedRoles.length > 0 ? customGeneratedRolesString : '',
                customGeneratedRolesPlurals: customGeneratedRoles.length
            }
        };
    }),
    on(roleManagementClearSelectAction, (state) => ({
        ...state,
        selected: []
    })),
    on(roleManagementDeleteRoleModalAction, (state, action) => ({
        ...state,
        deleteRoleModalState: {
            ...state.deleteRoleModalState,
            role: action.roles,
            isOpen: action.isOpen,
            usersWithAssignedOnlyRole: action.usersWithAssignedOnlyRole || []
        }
    })),
    on(getDuplicateCheckAction, (state, action) => ({
        ...state,
        roleNameCheck: action.roleName,
        isRoleNameDuplicate: false,
        isCheckingDuplicate: true
    })),
    on(getDuplicateCheckSuccessAction, (state, action) => {
        const isRoleNameDuplicate = action.response.data.some((d) => d.role.toUpperCase() === state.roleNameCheck.toUpperCase().trim());
        return {
            ...state,
            isRoleNameDuplicate,
            isCheckingDuplicate: false
        };
    }),
    on(getDuplicateCheckFailureAction, (state, action) => ({
        ...state,
        roleNameCheck: '',
        isRoleNameDuplicate: false,
        isCheckingDuplicate: false
    })),
    on(resetDuplicateCheckStateAction, (state, action) => ({
        ...state,
        roleNameCheck: '',
        isRoleNameDuplicate: false,
        isCheckingDuplicate: false
    })),

    on(roleManagementGetRoleDetailsAction, (state, action) => ({
        ...state,
        roleId: action.roleId,
        rolePermissions: null,
        roleDetailsState: {
            ...state.roleDetailsState,
            loading: true,
            error: null,
            details: null
        }
    })),
    on(roleManagementGetRoleDetailsSuccessAction, (state, action) => ({
        ...state,
        roleDetailsState: {
            ...state.roleDetailsState,
            loading: false,
            details: action.response.data,
            error: { active: false, message: '' }
        }
    })),
    on(roleManagementGetRoleDetailsFailureAction, (state, action) => ({
        ...state,
        roleDetailsState: {
            ...state.roleDetailsState,
            loading: false,
            error: { active: false, message: action.errorMessage }
        }
    })),
    on(roleManagementSaveNewRoleAction, (state, action) => ({
        ...state,
        saveRole: {
            ...state.saveRole,
            loading: true,
            roleName: action.data.role
        }
    })),
    on(roleManagementSaveNewRoleSuccessAction, (state, action) => ({
        ...state,
        saveRole: {
            ...state.saveRole,
            loading: false,
            error: null,
            roleId: action.role_id
        }
    })),
    on(roleManagementSaveNewRoleFailureAction, (state, action) => ({
        ...state,
        saveRole: {
            ...state.saveRole,
            loading: false,
            roleId: null,
            error: action.errorMessage
        }
    })),
    on(roleManagementToggleUpdateRoleMPModalAction, (state, action) => ({
        ...state,
        cancelRoleModulesAndPermissionsUpdateState: {
            isOpen: action.isOpen
        }
    })),
    on(roleManagementCheckPreviousButtonAction, (state, action) => ({
        ...state,
        isBack: action.isBack
    })),
    on(roleManagementGetModifiedRoleDetailsAction, (state, action) => ({
        ...state,
        updatedRoleDetails: action.updatedRoleDetails
    })),
    on(roleManagementAddNewRoleModalAction, (state, action) => ({
        ...state,
        addNewRoleModalState: {
            isOpen: action.isOpen,
            settings: action.settings
        }
    })),
    on(roleManagementUpdateRoleAction, (state) => ({
        ...state,
        updateRole: {
            ...state.updateRole,
            loading: true
        }
    })),
    on(roleManagementUpdateRoleSuccessAction, (state, { result }) => ({
        ...state,
        updateRole: {
            ...state.updateRole,
            result,
            loading: false,
            error: {
                active: false,
                message: ''
            }
        }
    })),
    on(roleManagementUpdateRoleFailureAction, (state, action) => ({
        ...state,
        updateRole: {
            ...state.updateRole,
            loading: false,
            result: null,
            error: {
                active: true,
                message: action.errorMessage
            }
        }
    })),
    on(roleManagementUsersRoleEntitiesAssignAction, (state) => ({
        ...state,
        assignEntityRole: {
            ...state.assignEntityRole,
            loading: true
        }
    })),
    on(roleManagementUsersRoleEntitiesAssignSuccessAction, (state) => ({
        ...state,
        assignEntityRole: {
            ...state.assignEntityRole,
            result: true,
            loading: false
        }
    })),
    on(roleManagementUsersRoleEntitiesAssignFailureAction, (state, action) => ({
        ...state,
        assignEntityRole: {
            ...state.assignEntityRole,
            result: null,
            loading: false,
            error: {
                active: true,
                message: action.errorMessage
            }
        }
    }))
);
