// tslint:disable max-file-line-count
// tslint:disable:max-line-length
import {
    CheckboxSelectionCallbackParams,
    GridOptions,
    HeaderCheckboxSelectionCallbackParams,
    IGetRowsParams,
    MenuItemDef
} from '@ag-grid-community/core';
import { DatePipe } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
    CTGridColumnDefinition,
    GroupLettersFilter
} from '@ct/platform-primitives-uicomponents/grid';
import { ButtonType } from '@ct/platform-primitives-uicomponents/primitives';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { Observable, Subject } from 'rxjs';
import { filter, map, takeUntil } from 'rxjs/operators';
import { appActions } from 'src/app/state/app.actions';
import { selectIsInternal } from 'src/app/state/app.selectors';
import {
    baseBreadcrumbsItems,
    BREADCRUMB_REFRESH_INTERVAL,
    roleManagementItem
} from 'src/shared/config/breadcrumbsItems.config';
import { paramsSwitcherRequest } from 'src/shared/interfaces/paramsSwitcherRequest';
import { AuthorizationManagementService } from 'src/shared/services/authorization-management/authorization-management.service';
import { ModulePermissionsService } from 'src/shared/services/module-permissions/module-permissions.service';
import { setStageBackgroundColor } from 'src/shared/util';

import {
    createLevel,
    deleteLevel,
    editLevel,
    viewLevel
} from '../../../shared/config/claims.config';
import { AvatarRendererComponent } from '../users-management/avatar-renderer/avatar-renderer';
import { userManagementSaveSuccessAction } from '../users-management/state/user-management.actions';
import {
    selectIsAddUserModalVisible,
    userSavedState
} from '../users-management/state/user-management.selectors';

import { SelectionChangeEvent } from './../../../features/widgets/management-grid/interfaces/selection-change-event.interface';
import { getUsersForRoleAction } from './details/components/users-list-from-role/state/users-from-role.actions';
import { USERS_FOR_ROLE_PAGE_SIZE } from './details/components/users-list-from-role/state/users-from-role.state';
import { RoleType } from './interfaces/role-type.enum';
import { Role } from './interfaces/role.model';
import { ROLES_COLUMNS_ROLE_NAME } from './roles-management.config';
import {
    AddUserRoleModalAction,
    roleManagementAddNewRoleModalAction,
    roleManagementCheckDeleteRoleModalAction,
    roleManagementClearSelectAction,
    roleManagementDeleteRoleSuccessAction,
    roleManagementSaveNewRoleSuccessAction,
    roleManagementSelectAction,
    roleManagementSuccessAction,
    roleManagementUsersRoleEntitiesAssignSuccessAction
} from './state/role-management.actions';
import {
    roleNameCreatedState,
    selectedRoleManagementDeleteRoleModalState,
    selectedRoleManagementIdsState,
    selectedRoleManagementState,
    selectIsAddUserRoleModalVisible,
    selectRoleManagementStateData
} from './state/role-management.selectors';
import { PaginatedRoles, ROLES_PAGE_SIZE } from './state/role-management.state';
import {
    i18nDetailsSection,
    translateKeys
} from './state/roles-management.grid.constants';

interface FilterableMenuItemDef extends MenuItemDef {
    visible?: boolean;
}

@Component({
    selector: 'ct-roles-management',
    templateUrl: './roles-management.component.html',
    styleUrls: ['./roles-management.component.scss']
})
export class RolesManagementComponent implements OnInit, OnDestroy {
    get isDeleteBulkAvailable(): boolean {
        return (
            this.userHasDeletePermission &&
            !!this._selectedRoles.filter(
                (role) => role.type !== RoleType.SYSTEM
            ).length
        );
    }
    get selectedRoleIdForBulkOptions$(): Observable<string> {
        return this.selectedRolesIds$.pipe(
            map((selectedRolesIds) => selectedRolesIds?.[0])
        );
    }
    readonly GRID_MAX_ELEMENTS = ROLES_PAGE_SIZE;
    isInternal: boolean;
    ButtonType = ButtonType;
    getRowParams: IGetRowsParams;
    roleManagementStateData$: Observable<PaginatedRoles>;
    selectedRolesIds$: Observable<Array<string>>;
    roleNameCreated$: Observable<string> =
        this.store$.select(roleNameCreatedState);
    userHasViewPermission =
        this.modulePermissionsService.doesUserHasPermission(viewLevel);
    userHasEditPermission =
        this.modulePermissionsService.doesUserHasPermission(editLevel);
    userHasCreatePermission =
        this.modulePermissionsService.doesUserHasPermission(createLevel);
    userHasDeletePermission =
        this.modulePermissionsService.doesUserHasPermission(deleteLevel);

    customCellRendererComponents = {
        avatarRenderer: AvatarRendererComponent
    };
    deleteModalState$ = this.store$.select(
        selectedRoleManagementDeleteRoleModalState
    );
    isAddUserRoleModalVisible$ = this.store$.select(
        selectIsAddUserRoleModalVisible
    );
    gridDefinition: Array<CTGridColumnDefinition> = [
        {
            colDef: {
                headerName: this.translate.instant(
                    translateKeys(
                        i18nDetailsSection.section,
                        i18nDetailsSection.keys.roles
                    )
                ),
                field: 'role',
                sortable: true,
                checkboxSelection: this.isFirstColumn,
                headerCheckboxSelection: this.isFirstColumn,
                headerCheckboxSelectionFilteredOnly: true,
                filter: true,
                filterValueGetter: (params) => params.data?.role,
                menuTabs: ['filterMenuTab', 'generalMenuTab']
            },
            cellRendererOptions: {
                useCellRenderer: 'avatarRenderer'
            },
            cellRenderedParams: {
                click: async (event: Role) => {
                    await this.router.navigate(
                        [
                            '/account-tools/users-and-roles/role-management/details',
                            event.role_id
                        ],
                        { relativeTo: this.route }
                    );
                },
                showAvatar: false
            },
            dataType: 'CUSTOM'
        },
        {
            colDef: {
                headerName: this.translate.instant(
                    translateKeys(
                        i18nDetailsSection.section,
                        i18nDetailsSection.keys.createdBy
                    )
                ),
                field: 'created_by_name',
                sortable: true,
                cellRenderer: this.getRenderedNameWIthInitialsAvatar.bind(this),
                filterFramework: GroupLettersFilter,
                cellClass: 'wk-color-style',
                menuTabs: ['filterMenuTab', 'generalMenuTab'],
                checkboxSelection: this.isFirstColumn,
                headerCheckboxSelection: this.isFirstColumn
            },
            dataType: 'CUSTOM'
        },
        {
            colDef: {
                headerName: this.translate.instant(
                    translateKeys(
                        i18nDetailsSection.section,
                        i18nDetailsSection.keys.createdOn
                    )
                ),
                field: 'created_date',
                cellRenderer: this.getFormattedDate.bind(this),
                suppressMenu: true,
                filter: false,
                sortable: true,
                cellClass: 'wk-color-style',
                checkboxSelection: this.isFirstColumn,
                headerCheckboxSelection: this.isFirstColumn
            },
            dataType: 'CUSTOM'
        },
        {
            colDef: {
                headerName: this.translate.instant(
                    translateKeys(
                        i18nDetailsSection.section,
                        i18nDetailsSection.keys.lastModifiedBy
                    )
                ),
                field: 'last_modified_by_name',
                cellRenderer: this.getRenderedNameWIthInitialsAvatar.bind(this),
                filterFramework: GroupLettersFilter,
                cellClass: 'wk-color-style',
                sortable: true,
                menuTabs: ['filterMenuTab', 'generalMenuTab'],
                checkboxSelection: this.isFirstColumn,
                headerCheckboxSelection: this.isFirstColumn
            },
            dataType: 'CUSTOM'
        },
        {
            colDef: {
                headerName: this.translate.instant(
                    translateKeys(
                        i18nDetailsSection.section,
                        i18nDetailsSection.keys.lastModifiedOn
                    )
                ),
                field: 'last_modified_date',
                sortable: true,
                cellRenderer: this.getFormattedDate.bind(this),
                suppressMenu: true,
                cellClass: 'wk-color-style',
                filter: false,
                checkboxSelection: this.isFirstColumn,
                headerCheckboxSelection: this.isFirstColumn
            },
            dataType: 'CUSTOM'
        }
    ];

    gridOptions: GridOptions = {
        rowModelType: 'infinite',
        cacheBlockSize: ROLES_PAGE_SIZE,
        rowSelection: 'multiple',
        getContextMenuItems: (params) => this.getContextMenu(params),
        getRowNodeId: (params) => this.getRowId(params),
        suppressDragLeaveHidesColumns: true,
        suppressCellSelection: true,
        suppressMultiRangeSelection: false,
        suppressMenuHide: true,
        suppressRowClickSelection: true,
        defaultColDef: {
            sortable: false,
            resizable: true,
            suppressMenu: true,
            filter: false,
            filterParams: {
                caseSensitive: false
            }
        },
        rowStyle: {
            'border-top': 'white 0px solid',
            'border-bottom': 'white 1px solid'
        }
    };
    isAddUserModalVisible = false;
    userSavedFullname$: Observable<string> = this.store$.select(userSavedState);
    showUserCreatedNotification = false;

    showRoleCreatedNotification = false;
    showRoleEntitiesAssociatedNotification = false;
    showUsersAsignedToRoleNotification = false;

    private _selectedRoles: Array<Role> = [];
    private _destroyed$ = new Subject<boolean>();

    constructor(
        private authorizationManagementService: AuthorizationManagementService,
        public store$: Store,
        private translateService: TranslateService,
        private datePipe: DatePipe,
        private router: Router,
        private translate: TranslateService,
        private route: ActivatedRoute,
        private actionsListener$: ActionsSubject,
        private modulePermissionsService: ModulePermissionsService
    ) {}
    isFirstColumn(
        params:
            | CheckboxSelectionCallbackParams
            | HeaderCheckboxSelectionCallbackParams
    ): boolean {
        const displayedColumns = params.columnApi.getAllDisplayedColumns();
        const thisIsFirstColumn = displayedColumns[0] === params.column;
        return thisIsFirstColumn;
    }

    ngOnInit(): void {
        setStageBackgroundColor('white');
        this.loadRoles(this.getRowParams).catch((err) => {
            throw new Error(
                this.translateService.instant(
                    'DefaultErrorMessages.unknownError'
                )
            );
        });
        this.roleManagementStateData$ = this.store$
            .select(selectRoleManagementStateData)
            .pipe(filter(() => !this.isAddUserModalVisible));
        this.selectedRolesIds$ = this.store$.select(
            selectedRoleManagementIdsState
        );
        this.store$
            .select(selectIsAddUserModalVisible)
            .pipe(takeUntil(this._destroyed$))
            .subscribe((value) => (this.isAddUserModalVisible = value));
        this.store$
            .select(selectedRoleManagementState)
            .pipe(takeUntil(this._destroyed$))
            .subscribe((selected) => (this._selectedRoles = selected));
        this.actionsListener$
            .pipe(
                ofType(roleManagementDeleteRoleSuccessAction),
                takeUntil(this._destroyed$)
            )
            .subscribe(() => {
                this.refreshTableData().catch((err) => {
                    throw new Error(
                        this.translateService.instant(
                            'DefaultErrorMessages.unknownError'
                        )
                    );
                });
            });
        this.actionsListener$
            .pipe(
                ofType(roleManagementSaveNewRoleSuccessAction),
                takeUntil(this._destroyed$)
            )
            .subscribe(() => {
                this.showRoleCreatedNotification = true;
                this.refreshTableData();
            });
        this.actionsListener$
            .pipe(
                ofType(roleManagementUsersRoleEntitiesAssignSuccessAction),
                takeUntil(this._destroyed$)
            )
            .subscribe(
                () => (this.showRoleEntitiesAssociatedNotification = true)
            );
        this.actionsListener$
            .pipe(
                ofType(userManagementSaveSuccessAction),
                takeUntil(this._destroyed$)
            )
            .subscribe(() => (this.showUserCreatedNotification = true));
        this.store$.select(selectIsInternal).subscribe((isInternal) => {
            this.isInternal = isInternal;
        });
        setTimeout(() => {
            this.store$.dispatch(
                appActions.updateBreadcrumbsItems({
                    breadcrumbsItems: [
                        ...baseBreadcrumbsItems(this.isInternal),
                        { ...roleManagementItem, disabled: true }
                    ]
                })
            );
        }, BREADCRUMB_REFRESH_INTERVAL);
        this.setUserRolesAccountSettings();
    }

    ngOnDestroy(): void {
        this._destroyed$.next();
        this._destroyed$.complete();
        setStageBackgroundColor('');
    }

    setUserRolesAccountSettings(): void {
        this.gridOptions.suppressRowClickSelection =
            !this.userHasEditPermission;
        this.gridDefinition[0].colDef.headerCheckboxSelection =
            this.userHasEditPermission;
        this.gridDefinition[0].colDef.checkboxSelection =
            this.userHasEditPermission;
    }

    openAddNewRoleModal(): void {
        this.store$.dispatch(
            roleManagementAddNewRoleModalAction({ isOpen: true })
        );
    }

    onSelectionChange(event: SelectionChangeEvent): void {
        this.store$.dispatch(roleManagementSelectAction(event));
    }

    onClear(): void {
        this.store$.dispatch(roleManagementClearSelectAction());
    }

    onDeleteClick(): any {
        this.store$.dispatch(
            roleManagementCheckDeleteRoleModalAction({
                roles: this._selectedRoles
            })
        );
    }

    updateRowParams(params: IGetRowsParams): void {
        this.getRowParams = params;
    }

    async loadRoles(params: IGetRowsParams): Promise<void> {
        const request: paramsSwitcherRequest = {} as paramsSwitcherRequest;
        request.pageSize = params.endRow - params.startRow;
        request.pageNumber = params.startRow / request.pageSize + 1;
        request.isInternal = this.isInternal;
        if (params.sortModel.length) {
            request.sortKey = params.sortModel[0].sort;
            request.sortBy =
                params.sortModel[0]?.colId.toLowerCase() ===
                ROLES_COLUMNS_ROLE_NAME
                    ? 'RoleName'
                    : params.sortModel[0].colId;
        }
        const response = await this.authorizationManagementService.getRolesList(
            request
        );
        this.store$.dispatch(roleManagementSuccessAction({ response }));
        if (response.totalRecordCount <= this.GRID_MAX_ELEMENTS) {
            this.gridOptions.rowModelType = 'clientSide';
        }
        const lastRow = this.getLastRow(
            response.data.length,
            request.pageNumber,
            request.pageSize
        );
        params.successCallback(response.data, lastRow);
    }

    openAssignUsersToRoleModal(): void {
        this.store$.dispatch(AddUserRoleModalAction({ value: true }));
    }

    loadAssignUsersToRole(pageNumber: number = 1): void {
        this.selectedRoleIdForBulkOptions$
            .subscribe((selectedRolesId) => {
                this.store$.dispatch(
                    getUsersForRoleAction({
                        pageNumber,
                        pageSize: USERS_FOR_ROLE_PAGE_SIZE,
                        roleId: selectedRolesId
                    })
                );
            })
            .unsubscribe();
    }

    onUsersAddedToRole(usersAdded: boolean): void {
        if (usersAdded) {
            this.showRoleEntitiesAssociatedNotification = false;
            this.showUsersAsignedToRoleNotification = true;
            this.loadAssignUsersToRole();
        }
    }

    private getRederedInitialsAvatar(fullname: string = ''): HTMLDivElement {
        const initialsFullname = fullname
            .split(' ')
            .reduce(
                (current: string, next: string) => current + next.charAt(0),
                ''
            );
        const avatar = document.createElement('div');
        avatar.classList.add('wk-avatar');
        avatar.classList.add('wk-avatar-extra-small');

        const fishbowlThumbContainer = document.createElement('div');
        fishbowlThumbContainer.classList.add('wk-fishbowl-thumbs');

        const fishbowlThumb = document.createElement('div');
        fishbowlThumb.classList.add('wk-fishbowl-organization-thumb');
        fishbowlThumb.setAttribute('title', fullname);
        fishbowlThumb.setAttribute('data-abbr', initialsFullname);

        fishbowlThumbContainer.appendChild(fishbowlThumb);
        avatar.appendChild(fishbowlThumbContainer);

        return avatar;
    }

    private getLastRow(
        rows: number,
        pageNum: number,
        pageSize: number
    ): number {
        return rows < pageSize
            ? (pageNum - 1) * pageSize + rows
            : (pageNum + 1) * pageSize;
    }

    private getRenderedNameWIthInitialsAvatar(params: any): HTMLDivElement {
        const container = document.createElement('div');
        const spanFullname = document.createElement('span');
        container.classList.add('name-container');
        spanFullname.innerHTML = params.value;

        const avatar = this.getRederedInitialsAvatar(params.value);
        container.appendChild(avatar);
        container.appendChild(spanFullname);
        return container;
    }

    private getRowId(role: Role): string {
        return role.role_id.toString();
    }

    private getFormattedDate(params: any): string {
        return this.datePipe.transform(params.value);
    }

    private getContextMenu(params): Array<MenuItemDef> {
        if (!params || !this.userHasViewPermission) {
            return;
        }
        const { api, node } = params;
        const role = node.data;
        const selectedRows = api.getSelectedRows() || [];
        if (
            selectedRows.length > 1 ||
            (selectedRows.length === 1 && !node.isSelected())
        ) {
            return;
        }

        const allMenuOpts: Array<FilterableMenuItemDef> = [
            {
                name: this.translate.instant(
                    translateKeys(
                        i18nDetailsSection.section,
                        i18nDetailsSection.keys.copyCreateNewRole
                    )
                ),
                visible: this.userHasCreatePermission
            },
            {
                name: this.translate.instant(
                    translateKeys(
                        i18nDetailsSection.section,
                        i18nDetailsSection.keys.assignUsers
                    )
                ),
                action: () => {
                    node.setSelected(true);
                    this.openAssignUsersToRoleModal();
                },
                visible: true
            },
            {
                name: this.translate.instant(
                    translateKeys(
                        i18nDetailsSection.section,
                        i18nDetailsSection.keys.deleteRole
                    )
                ),
                action: () => {
                    this.store$.dispatch(
                        roleManagementSelectAction({
                            total: 1,
                            selected: [params?.node?.data]
                        })
                    );
                    this.store$.dispatch(
                        roleManagementCheckDeleteRoleModalAction({
                            roles: [role]
                        })
                    );
                },
                visible:
                    this.userHasDeletePermission &&
                    role?.type !== RoleType.SYSTEM
            }
        ];

        return allMenuOpts.filter((menuOption) => menuOption.visible);
    }

    private async refreshTableData(): Promise<void> {
        this.onClear();
        await this.loadRoles(this.getRowParams);
    }
}
