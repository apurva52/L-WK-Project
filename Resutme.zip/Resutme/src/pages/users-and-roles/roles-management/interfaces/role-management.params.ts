export interface RoleManagementParams {
    pageNumber: number;
    pageSize: number;
    sortKey?: string;
    sortBy?: string;
}

export const USER_TO_ROLE_SEPARATOR = '___';
