export enum RoleType {
    SYSTEM = 'S',
    INTERNAL = 'I',
    CUSTOMER = 'C'
}