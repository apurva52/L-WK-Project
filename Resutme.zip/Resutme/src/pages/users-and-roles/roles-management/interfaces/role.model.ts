import { RoleType } from './role-type.enum';

export interface Role {
    role_id: number;
    role: string;
    created_date: string;
    created_by_name: string;
    last_modified_date: string;
    last_modified_by_name: string;
    type: RoleType;
}
