/* tslint:disable:max-file-line-count */
/* tslint:disable:max-line-length */
import {
    CheckboxSelectionCallbackParams,
    IGetRowsParams,
    ValueGetterFunc
} from '@ag-grid-community/core';
import { DatePipe } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterEvent } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { AbilityModule } from '@casl/angular';
import {
    AclDefinitionService,
    AuthorizationModule,
    AuthorizationService,
    CtAuthorizationEnums
} from '@ct/core-ui-ng';
import { I18nTestingModule, LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { StoreModule } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { update } from 'lodash';
import { of, ReplaySubject } from 'rxjs';
import { selectIsInternal } from 'src/app/state/app.selectors';
import { AuthorizationManagementService } from 'src/server/services/authorization-management.service.mock';
import { ModulePermissionsService } from 'src/shared/services/module-permissions/module-permissions.service';
import { NavigationsService } from 'src/shared/services/navigation/navigations.service';

import { userManagementSaveSuccessAction } from '../users-management/state/user-management.actions';
import { selectIsAddUserModalVisible } from '../users-management/state/user-management.selectors';

import { RoleType } from './interfaces/role-type.enum';
import { RolesManagementComponent } from './roles-management.component';
import { initialRoleManagementState } from './state/role-management.reducers';
import {
    selectedRoleManagementDeleteRoleModalState,
    selectRoleManagementStateData
} from './state/role-management.selectors';
import {
    ROLE_MANAGEMENT_FEATURE_KEY,
    RoleManagementState
} from './state/role-management.state';
import mockRoleManagement from './state/test-values/mock-roles.json';

const eventSubject = new ReplaySubject<RouterEvent>(1);

class Mockrouter {
    navigate = jasmine.createSpy('navigate');
    events = eventSubject.asObservable();
}
const mockNavigationsService = jasmine.createSpyObj('NavigationsService', [
    'subscribeRouteEvents',
    'getBreadcrumbs',
    'isHidden',
    'updateBreadcrumbs'
]);
describe('RolesManagementComponent', () => {
    let component: RolesManagementComponent;
    let fixture: ComponentFixture<RolesManagementComponent>;
    let store: MockStore<RoleManagementState>;
    let mockRouter: Mockrouter;
    const modulePermissionsServiceMock = jasmine.createSpyObj<any>([
        'doesUserHasPermission',
        'doesNotUserHasPermission'
    ]);
    modulePermissionsServiceMock.doesUserHasPermission.and.returnValue(true);
    const mockSelectedWithDeleteOptionShow = {
        api: {
            getSelectedRows: () => [],
            isNodeSelected: (_node) => false
        },
        node: {
            selected: false,
            setSelected: (_value) => {},
            data: {
                type: RoleType.CUSTOMER
            }
        }
    };
    const mockDisplayContextMenu = {
        api: {
            getSelectedRows: () => [],
            isNodeSelected: (_node) => false
        },
        node: {
            selected: false,
            setSelected: (_value) => {},
            data: {
                type: RoleType.CUSTOMER
            }
        }
    };
    const getAllRuleFor =
        CtAuthorizationEnums.CtModulesEnum.ACCOUNT_TOOLS +
        CtAuthorizationEnums.CtAccountToolsFieldsEnum.USER_ROLES;
    const aclDefinitionService = jasmine.createSpyObj<any>([
        'updateEntityAbility',
        'updateModuleAbility',
        'updateFieldsAbility'
    ]);

    beforeEach(async(() => {
        mockRouter = new Mockrouter();
        TestBed.configureTestingModule({
            declarations: [RolesManagementComponent],
            imports: [
                AuthorizationModule,
                AbilityModule,
                I18nTestingModule,
                LocaleTestingModule,
                TranslateModule.forRoot(),
                RouterTestingModule,
                StoreModule.forRoot({})
            ],
            providers: [
                AuthorizationService,
                AuthorizationManagementService,
                {
                    provide: AclDefinitionService,
                    useValue: aclDefinitionService
                },
                {
                    provide: ModulePermissionsService,
                    useValue: modulePermissionsServiceMock
                },
                provideMockStore({
                    initialState: {
                        [ROLE_MANAGEMENT_FEATURE_KEY]:
                            initialRoleManagementState
                    },
                    selectors: [
                        {
                            selector: selectRoleManagementStateData,
                            value: mockRoleManagement
                        },
                        {
                            selector:
                                selectedRoleManagementDeleteRoleModalState,
                            value: {
                                isOpen: false
                            }
                        },
                        {
                            selector: selectIsAddUserModalVisible,
                            value: false
                        },
                        {
                            selector: selectIsInternal,
                            value: false
                        }
                    ]
                }),
                DatePipe,
                {
                    provide: NavigationsService,
                    useValue: mockNavigationsService
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(RolesManagementComponent);
        component = fixture.componentInstance;
        spyOn(document, 'getElementsByClassName').and.returnValue([
            {
                style: {
                    'background-color': ''
                }
            }
        ] as any);
        fixture.detectChanges();
    });

    it('should create', () => {
        component.ngOnInit();
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });

    it('should get rendered name ', () => {
        const mockParams = { value: 'Unit Test Name' };
        const container =
            component['getRenderedNameWIthInitialsAvatar'](mockParams);
        expect(container.innerHTML).toContain('Unit Test Name');
    });

    it('should get Row Id from role', () => {
        const roleId = component['getRowId']({
            role_id: 1,
            role: 'Admin',
            created_date: '07-18-2022',
            created_by_name: 'Jon Snow',
            last_modified_date: '07-18-2022',
            last_modified_by_name: 'Jon Snow',
            type: RoleType.CUSTOMER
        });
        expect(roleId).toEqual('1');
    });

    it('should get formatted Date of role', () => {
        const roleId = component['getFormattedDate']({
            value: mockRoleManagement.data[0].created_date
        });
        expect(roleId).toBeDefined();
    });

    it(`should select some Roles`, () => {
        spyOn(store, 'dispatch').and.callThrough();
        component.onSelectionChange({
            total: 1,
            selected: [mockRoleManagement.data[0]]
        });
        expect(store.dispatch).toHaveBeenCalled();
    });

    it(`should clear Roles selection`, () => {
        spyOn(store, 'dispatch').and.callThrough();
        component.onClear();
        expect(store.dispatch).toHaveBeenCalled();
    });

    it('should not show context menu items due to not to have permissions', () => {
        component.userHasViewPermission = false;
        component.userHasCreatePermission = false;
        component.userHasDeletePermission = false;

        const request = component['getContextMenu'](
            mockSelectedWithDeleteOptionShow
        );
        expect(request).toBeUndefined();
    });

    it('should not show context menu items due to have more than one selected row', () => {
        component.userHasViewPermission = true;
        component.userHasCreatePermission = false;
        component.userHasDeletePermission = false;

        const request = component['getContextMenu']({
            ...mockSelectedWithDeleteOptionShow,
            api: { getSelectedRows: () => [{}, {}] }
        });
        expect(request).toBeUndefined();
    });

    it('should show full context menu items', () => {
        const expectedItemsLength = 3;
        component.userHasViewPermission = true;
        component.userHasCreatePermission = true;
        component.userHasDeletePermission = true;

        const request = component['getContextMenu'](
            mockSelectedWithDeleteOptionShow
        );
        expect(request.length).toBe(expectedItemsLength);
    });

    it('should keep only assign from [if] context menu items', () => {
        const expectedItemsLength = 1;
        component.userHasViewPermission = true;
        component.userHasCreatePermission = false;
        component.userHasDeletePermission = false;

        const request = component['getContextMenu'](
            mockSelectedWithDeleteOptionShow
        );

        expect(request.length).toBe(expectedItemsLength);
    });

    it('should hide delete option from context menu items', () => {
        const expectedItemsLength = 2;
        const mockDisplayContextMenu = {
            api: {
                getSelectedRows: () => [],
                isNodeSelected: (_node) => false
            },
            node: {
                selected: false,
                setSelected: (_value) => {},
                data: {
                    type: RoleType.CUSTOMER
                }
            }
        };

        component.userHasViewPermission = true;
        component.userHasCreatePermission = true;
        component.userHasDeletePermission = false;

        const request = component['getContextMenu'](mockDisplayContextMenu);

        expect(request.length).toBe(expectedItemsLength);
    });

    it('should keep only assign [else] option from context menu items', () => {
        const expectedItemsLength = 1;
        component.userHasViewPermission = true;
        component.userHasCreatePermission = false;
        component.userHasDeletePermission = false;

        const request = component['getContextMenu'](mockDisplayContextMenu);

        expect(request.length).toBe(expectedItemsLength);
    });

    it(`should be able or not to delete bulk`, () => {
        const role = {
            role_id: 1,
            role: 'Test',
            created_date: '07-18-2022',
            created_by_name: 'Jon Snow',
            last_modified_date: '07-18-2022',
            last_modified_by_name: 'Jon Snow',
            type: RoleType.SYSTEM
        };
        component.userHasDeletePermission = true;
        expect(component.isDeleteBulkAvailable).toBeFalsy();
        (component as any)._selectedRoles = [role];
        expect(component.isDeleteBulkAvailable).toBeFalsy();
        (component as any)._selectedRoles = [
            { ...role, type: RoleType.CUSTOMER }
        ];
        expect(component.isDeleteBulkAvailable).toBeTruthy();
    });

    it(`should open delete modal`, () => {
        const expectedCallsCount = 2;
        spyOn(store, 'dispatch').and.callThrough();
        component.onDeleteClick();
        (component as any)._selectedRoles = [
            {
                role_id: 1,
                role: 'Test',
                created_date: '07-18-2022',
                created_by_name: 'Jon Snow',
                last_modified_date: '07-18-2022',
                last_modified_by_name: 'Jon Snow',
                type: RoleType.CUSTOMER
            }
        ];
        component.onDeleteClick();
        expect(store.dispatch).toHaveBeenCalledTimes(expectedCallsCount);
    });

    it(`should dispatch action to open add new role modal`, () => {
        spyOn(store, 'dispatch').and.callThrough();
        component.openAddNewRoleModal();
        expect(store.dispatch).toHaveBeenCalled();
    });
    it('should get role name filter value', () => {
        const roleName = 'Super Admin';
        const params = {
            data: {
                role: roleName
            }
        } as any;
        const valueGetter = component.gridDefinition[0].colDef
            .filterValueGetter as ValueGetterFunc;
        expect(valueGetter({} as any)).toBeUndefined();
        expect(valueGetter(params)).toBe(roleName);
    });
    it(`if userHasViewPermission then context menu shold not be availble`, () => {
        component.userHasViewPermission = true;
        expect(component.gridOptions.suppressRowClickSelection).toBeTrue;
        expect(component.gridDefinition[0].colDef.checkboxSelection).toBeFalse;
        expect(component.gridDefinition[0].colDef.headerCheckboxSelection)
            .toBeFalse;
        expect(component.gridDefinition[0].colDef.checkboxSelection).toBeFalse;
        expect(component.gridOptions.suppressRowClickSelection).toBeTrue;
    });

    it(`first column is checkboxSelection as true always`, () => {
        component.userHasViewPermission = false;
        expect(component.gridOptions.suppressRowClickSelection).toBeTrue;
        expect(component.gridDefinition[0].colDef.checkboxSelection).toBeTrue;
        const params = { columnApi: { getAllDisplayedColumns: () => [] } };
        const actual = component.isFirstColumn(
            params as CheckboxSelectionCallbackParams
        );
        expect(actual).toBeTruthy();
        expect(component.isFirstColumn).toBeTruthy();
    });

    it(`should open assign Users to role modal`, () => {
        spyOn(store, 'dispatch');
        component.openAssignUsersToRoleModal();
        expect(store.dispatch).toBeTruthy();
    });
    it(`should open assign Users to role modal`, () => {
        spyOn(store, 'dispatch');
        component.openAssignUsersToRoleModal();
        expect(store.dispatch).toHaveBeenCalled();
    });
    it(`should load Users available for role`, () => {
        const clock = jasmine.clock();
        clock.install();
        spyOn(store, 'dispatch');
        component.loadAssignUsersToRole();
        clock.tick(1);
        clock.uninstall();
        expect(store.dispatch).toHaveBeenCalled();
    });
    it(`should show users asigned to role notification correctly`, () => {
        spyOn(store, 'dispatch');
        component.selectedRolesIds$ = of(['']);
        component.showUsersAsignedToRoleNotification = false;

        component.onUsersAddedToRole(false);
        expect(component.showUsersAsignedToRoleNotification).toBeFalsy();
        expect(store.dispatch).not.toHaveBeenCalled();

        component.onUsersAddedToRole(true);
        expect(component.showUsersAsignedToRoleNotification).toBeTruthy();
        expect(store.dispatch).toHaveBeenCalled();
    });

    it(`should show user created notification`, () => {
        component.showUserCreatedNotification = false;
        component['actionsListener$'].next(
            userManagementSaveSuccessAction({ result: true })
        );
        fixture.detectChanges();
        expect(component.showUserCreatedNotification).toBeTruthy();
    });

    it(`should show add user modal`, () => {
        expect(component.isAddUserModalVisible).toBeFalsy();
        store.overrideSelector(selectIsAddUserModalVisible, true);
        component.ngOnInit();
        expect(component.isAddUserModalVisible).toBeTruthy();
    });
    it('should update row params', () => {
        const params = {
            successCallback(
                rowsThisBlock: Array<any>,
                lastRow?: number
            ): void {},
            startRow: 20,
            endRow: 40,
            sortModel: [
                {
                    sort: 'asc',
                    colId: 'referenceDesc'
                }
            ]
        } as IGetRowsParams;
        component.updateRowParams(params);
        expect(component.getRowParams).toEqual(params);
    });

    it('should load the data', async () => {
        const params: any = {
            successCallback: (
                rowsThisBlock: Array<any>,
                lastRow?: number
            ): void => {},
            startRow: 0,
            endRow: component.GRID_MAX_ELEMENTS,
            sortModel: [{ sort: 'asc', sortBy: 'name', colId: 'role' }]
        };
        const serviceEmptyResultMock: any = {
            data: [],
            totalRecordCount: 0,
            page: 1,
            pageSize: component.GRID_MAX_ELEMENTS,
            totalPages: 1
        };
        const totalPages = 2;
        const serviceResultMock: any = {
            data: Array.from(Array(component.GRID_MAX_ELEMENTS), (_, i) => ({
                role_id: i,
                role: `${i}`
            })),
            totalRecordCount: component.GRID_MAX_ELEMENTS * totalPages,
            page: 1,
            pageSize: component.GRID_MAX_ELEMENTS,
            totalPages: totalPages
        };
        const dispatchSpy = spyOn(store, 'dispatch').and.callThrough();
        const successCallbackSpy = spyOn(
            params,
            'successCallback'
        ).and.callThrough();
        const getRolesListSpy = spyOn(
            component['authorizationManagementService'],
            'getRolesList'
        );
        const expectedCallsCount = 2;

        getRolesListSpy.and.callFake((...params) =>
            Promise.resolve(serviceResultMock)
        );
        await component.loadRoles(params);
        expect(component.gridOptions.rowModelType).toEqual('infinite');
        expect(successCallbackSpy).toHaveBeenCalledWith(
            serviceResultMock.data,
            jasmine.any(Number)
        );
        expect(params.sortModel[0].colId).toEqual('role');
        getRolesListSpy.and.callFake((...params) =>
            Promise.resolve(serviceEmptyResultMock)
        );
        await component.loadRoles(params);
        expect(component.gridOptions.rowModelType).toEqual('clientSide');
        expect(successCallbackSpy).toHaveBeenCalledWith(
            serviceEmptyResultMock.data,
            jasmine.any(Number)
        );
        expect(dispatchSpy).toHaveBeenCalledTimes(expectedCallsCount);
        expect(successCallbackSpy).toHaveBeenCalledTimes(expectedCallsCount);

        const updatedParams = {
            ...params,
            sortModel: [{ sort: 'asc', sortBy: 'name', colId: 'created_by' }]
        };
        await component.loadRoles(updatedParams);
        expect(updatedParams.sortModel[0].colId).toEqual('created_by');
    });

    it('should set max rows correctly', () => {
        const maxRowSize = 20;
        const minRowSize = 10;
        const equalDataSize = 60;
        const lessEqualDataSize = 30;
        expect((<any>component).getLastRow(maxRowSize, 2, maxRowSize))
            .withContext('data size equal to full page')
            .toBe(equalDataSize);
        expect((<any>component).getLastRow(minRowSize, 2, maxRowSize))
            .withContext('data size less than full page')
            .toBe(lessEqualDataSize);
        expect((<any>component).getLastRow(0, 2, maxRowSize))
            .withContext('data is empty')
            .toBe(maxRowSize);
    });
});
