export const ROLES_COLUMNS_ROLE_NAME = 'role';
