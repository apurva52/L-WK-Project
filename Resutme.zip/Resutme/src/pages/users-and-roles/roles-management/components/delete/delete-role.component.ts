import { Component, OnDestroy } from '@angular/core';
import { ModalModel } from '@ct/platform-primitives-uicomponents/modals';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { UserFromRole } from 'src/pages/users-and-roles/users-management/interfaces/user.model';
import { deleteLevel } from 'src/shared/config/claims.config';
import { ModulePermissionsService } from 'src/shared/services/module-permissions/module-permissions.service';

import { Role } from '../../interfaces/role.model';
import {
    roleManagementDeleteRoleAction,
    roleManagementDeleteRoleModalAction
} from '../../state/role-management.actions';
import {
    selectedCustomGeneratedRoles,
    selectedCustomGeneratedRolesPlurals,
    selectedRoleManagementDeleteRoleModalState,
    selectedRoleManagementState,
    selectedSystemGeneratedRoles,
    selectedSystemGeneratedRolesPlurals
} from '../../state/role-management.selectors';

@Component({
    selector: 'ct-delete-role',
    templateUrl: './delete-role.component.html',
    styleUrls: ['./delete-role.component.scss']
})
export class DeleteRoleComponent implements OnDestroy {
    get isLastRoleWarning(): boolean {
        return (
            this.currentRolePosition >=
            (this.deleteRoleModalState.role?.length ?? 0)
        );
    }
    deleteRoleModalState: any = {};
    currentRolePosition = 0;
    selectedRoleManagementState$ = this.store$.select(
        selectedRoleManagementState
    );
    selectedSystemGeneratedRoles$ = this.store$.select(
        selectedSystemGeneratedRoles
    );
    selectedSystemGeneratedRolesPlurals$ = this.store$.select(
        selectedSystemGeneratedRolesPlurals
    );
    selectedCustomGeneratedRoles$ = this.store$.select(
        selectedCustomGeneratedRoles
    );
    selectedCustomGeneratedRolesPlurals$ = this.store$.select(
        selectedCustomGeneratedRolesPlurals
    );

    modalModel: ModalModel = {
        title: 'userRolesModule.DeleteRoleComponent.title',
        cancelText: 'userRolesModule.DeleteRoleComponent.cancelButton',
        confirmText: 'userRolesModule.DeleteRoleComponent.confirmButton'
    };

    warningModalModel: ModalModel = {
        title: 'userRolesModule.DeleteRoleComponent.warning.title',
        confirmText: 'userRolesModule.DeleteRoleComponent.warning.confirmButton'
    };

    deleteRoleModalState$ = this.store$
        .select(selectedRoleManagementDeleteRoleModalState)
        .subscribe((deleteRoleModalState) => {
            this.deleteRoleModalState = deleteRoleModalState;
        });
    hasDeletePermission =
        this.modulePermissionsService.doesUserHasPermission(deleteLevel);

    private _destroyed$ = new Subject<boolean>();

    constructor(
        private store$: Store,
        private modulePermissionsService: ModulePermissionsService
    ) {}

    isWarningModalState(currentRolePosition: number): boolean {
        return (
            !!this.deleteRoleModalState?.role[currentRolePosition]
                ?.usersWithAssignedOnlyRole?.length ||
            this.deleteRoleModalState?.role[currentRolePosition]?.roles[0]
                ?.type === 'S'
        );
    }

    ngOnDestroy(): void {
        this._destroyed$.next();
        this._destroyed$.complete();
    }

    onCancelClick(): void {
        this.currentRolePosition++;
        this.checkForClose();
    }
    checkForClose(): void {
        if (this.isLastRoleWarning) {
            this.currentRolePosition = 0;
            this.close();
        }
    }

    onConfirmClick(role_id: number): void {
        this.store$.dispatch(
            roleManagementDeleteRoleAction({
                roleId: role_id
            })
        );
        this.currentRolePosition++;
        this.checkForClose();
    }

    getUsersContactNames(users: Array<UserFromRole>): string {
        return (users || []).map((user) => user.contact_name).join(', ');
    }
    getRolesNames(roles: Array<Role>): string {
        return (roles || []).map((role) => role.role).join(', ');
    }

    private close(): void {
        this.store$.dispatch(
            roleManagementDeleteRoleModalAction({ isOpen: false })
        );
    }
}
