// tslint:disable max-file-line-count
// tslint:disable:max-line-length
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { Ability } from '@casl/ability';
import { AbilityModule } from '@casl/angular';
import {
    AclDefinitionService,
    AuthorizationModule,
    AuthorizationService,
    CtAuthorizationEnums
} from '@ct/core-ui-ng';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { ModulePermissionsService } from 'src/shared/services/module-permissions/module-permissions.service';

import { RoleType } from '../../interfaces/role-type.enum';
import { initialRoleManagementState } from '../../state/role-management.reducers';
import {
    selectedRoleManagementDeleteRoleModalState,
    selectedRoleManagementState
} from '../../state/role-management.selectors';
import {
    ROLE_MANAGEMENT_FEATURE_KEY,
    RoleManagementState
} from '../../state/role-management.state';

import { DeleteRoleComponent } from './delete-role.component';

class FakeLoader implements TranslateLoader {
    getTranslation(_lang: string): Observable<any> {
        return of({});
    }
}

describe('DeleteRoleComponent', () => {
    const role3: any = {
        role_id: 2,
        role: 'Manager',
        created_date: '07-18-2022',
        created_by_name: 'Jon Snow',
        last_modified_date: '07-18-2022',
        last_modified_by_name: 'Jon Snow',
        type: RoleType.SYSTEM,
        usersWithAssignedOnlyRole: []
    };
    const role2: any = {
        role_id: 2,
        role: 'Manager',
        created_date: '07-18-2022',
        created_by_name: 'Jon Snow',
        last_modified_date: '07-18-2022',
        last_modified_by_name: 'Jon Snow',
        type: RoleType.CUSTOMER,
        usersWithAssignedOnlyRole: []
    };
    const role1: any = {
        role_id: 1,
        role: 'Admin',
        created_date: '07-18-2022',
        created_by_name: 'Jon Snow',
        last_modified_date: '07-18-2022',
        last_modified_by_name: 'Jon Snow',
        type: RoleType.CUSTOMER,
        usersWithAssignedOnlyRole: [],
        roles: [role2]
    };

    const mockState = {
        role: [role1],
        selected: [role1, role2],
        isOpen: true
    };
    let component: DeleteRoleComponent;
    let fixture: ComponentFixture<DeleteRoleComponent>;
    let store: MockStore<RoleManagementState>;
    let ability: Ability;
    const paramsSubject = new BehaviorSubject({
        id: 1
    });
    const modulePermissionsServiceMock = jasmine.createSpyObj<any>([
        'doesUserHasPermission',
        'doesNotUserHasPermission'
    ]);
    const aclDefinitionService = jasmine.createSpyObj<any>([
        'updateEntityAbility',
        'updateModuleAbility',
        'updateFieldsAbility'
    ]);
    const PathForUserRoles =
        CtAuthorizationEnums.CtModulesEnum.ACCOUNT_TOOLS +
        CtAuthorizationEnums.CtAccountToolsFieldsEnum.USER_ROLES;
    const emptyString = '';
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [DeleteRoleComponent],
            imports: [
                AuthorizationModule,
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot({
                    loader: { provide: TranslateLoader, useClass: FakeLoader }
                }),
                LocaleTestingModule,
                AbilityModule
            ],
            providers: [
                AuthorizationService,
                {
                    provide: AclDefinitionService,
                    useValue: aclDefinitionService
                },
                {
                    provide: Ability,
                    useValue: {
                        can: () => true,
                        cannot: () => true
                    }
                },
                provideMockStore({
                    initialState: {
                        [ROLE_MANAGEMENT_FEATURE_KEY]:
                            initialRoleManagementState
                    },
                    selectors: [
                        {
                            selector:
                                selectedRoleManagementDeleteRoleModalState,
                            value: mockState
                        },
                        {
                            selector: selectedRoleManagementState,
                            value: mockState.selected
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                },
                {
                    provide: ActivatedRoute,
                    useValue: {
                        params: paramsSubject
                    }
                },
                {
                    provide: ModulePermissionsService,
                    useValue: modulePermissionsServiceMock
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store = TestBed.inject(MockStore);
        ability = TestBed.inject(Ability);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DeleteRoleComponent);
        component = fixture.componentInstance;
        modulePermissionsServiceMock.doesUserHasPermission.and.returnValue(
            true
        );
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it(`should dispatch close modal`, () => {
        const expectedCallsCount = 2;
        spyOn(store, 'dispatch').and.callThrough();
        component['close']();
        component.onCancelClick();
        fixture.detectChanges();
        expect(store.dispatch).toHaveBeenCalledTimes(expectedCallsCount);
        expect(component.currentRolePosition).toEqual(0);
    });

    it(`should dispatch remove role and close modal`, () => {
        const role_id = 123;
        spyOn(store, 'dispatch').and.callThrough();
        const checkForClose = spyOn(
            component,
            'checkForClose'
        ).and.callThrough();
        component.onConfirmClick(role_id);
        fixture.detectChanges();
        expect(checkForClose).toHaveBeenCalled();
        expect(store.dispatch).toHaveBeenCalledTimes(2);
    });

    it(`should return users contact names as string`, () => {
        const users: Array<any> = [
            { contact_name: '1 1' },
            { contact_name: '2 2' },
            { contact_name: '3 3' }
        ];
        let result = component.getUsersContactNames(null);
        expect(result).toBe(emptyString);
        result = component.getUsersContactNames([]);
        expect(result).toBe(emptyString);
        result = component.getUsersContactNames(users);
        expect(result).toBe('1 1, 2 2, 3 3');
    });

    it(`should not return warning modal state`, () => {
        const notWarningState = {
            usersWithAssignedOnlyRole: [],
            role: [{ ...role1, usersWithAssignedOnlyRole: [] }],
            isOpen: true
        };
        component.deleteRoleModalState = notWarningState;
        expect(component.isWarningModalState(0)).toBeFalsy();
    });

    it(`should return warning modal state when System Role`, () => {
        const warningState = {
            usersWithAssignedOnlyRole: [],
            role: [{ ...role1, roles: [role3] }],
            isOpen: true
        };
        component.deleteRoleModalState = warningState;
        expect(component.isWarningModalState(0)).toBeTruthy();
    });

    it(`should return warning modal state`, () => {
        const users: Array<any> = [
            { contact_name: '1 1' },
            { contact_name: '2 2' },
            { contact_name: '3 3' }
        ];
        const warningState = {
            usersWithAssignedOnlyRole: users,
            role: [{ ...role1, usersWithAssignedOnlyRole: [users] }],
            isOpen: true
        };
        component.deleteRoleModalState = warningState;
        expect(component.isWarningModalState(0)).toBeTruthy();
    });

    it(`should return is last role position`, () => {
        spyOn(store, 'dispatch').and.callThrough();
        const roles: Array<any> = [
            { role: '1 1', roles: [] },
            { role: '2 2', roles: [] },
            { role: '3 3', roles: [] }
        ];
        component.deleteRoleModalState = {
            role: roles
        };
        component.onCancelClick();
        expect(component.isLastRoleWarning).toBeFalsy();
        component.onCancelClick();
        expect(component.isLastRoleWarning).toBeFalsy();
        component.onCancelClick();
        fixture.detectChanges();
        expect(store.dispatch).toHaveBeenCalled();
    });

    it(`should destroy component`, () => {
        const spyDestroy = spyOn(
            (component as any)._destroyed$,
            'complete'
        ).and.callThrough();
        component.ngOnDestroy();
        expect(spyDestroy).toHaveBeenCalled();
    });

    it(`should get roles names`, () => {
        const roles: Array<any> = [
            { role: '1 1' },
            { role: '2 2' },
            { role: '3 3' }
        ];
        const roleNames = component.getRolesNames(roles);
        expect(roleNames).toEqual('1 1, 2 2, 3 3');
    });
    it(`should get roles names when empty array`, () => {
        const roleNames = component.getRolesNames(null);
        expect(roleNames).toEqual(emptyString);
    });
});
