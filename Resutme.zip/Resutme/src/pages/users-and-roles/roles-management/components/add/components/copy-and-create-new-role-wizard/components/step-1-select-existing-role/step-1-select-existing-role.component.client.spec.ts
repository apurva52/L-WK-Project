import { LazyElementsModule } from '@angular-extensions/elements';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { RoleDetails } from '../../../../../../details/state/role-details.state';
import { initialRoleManagementState } from '../../../../../../state/role-management.reducers';
import {
    addNewRoleModalSettings,
    roleDetailsState,
    rolesForSelectState,
    selectedDuplicateCheckState
} from '../../../../../../state/role-management.selectors';
import { ROLE_MANAGEMENT_FEATURE_KEY } from '../../../../../../state/role-management.state';
import { CreateRoleActionType } from '../../../interfaces/create-role-action-type.enum';

import { Step1SelectExistingRoleComponent } from './step-1-select-existing-role.component';

describe('Step1SelectExistingRoleComponent', () => {
    let component: Step1SelectExistingRoleComponent;
    let fixture: ComponentFixture<Step1SelectExistingRoleComponent>;
    const expectedRoleDetails: RoleDetails = {
        role: '1',
        type: 'S',
        color: 'red',
        created_date: '1',
        created_by: '1',
        created_by_name: '1',
        last_modified_date: '1',
        last_modified_by: '1',
        last_modified_by_name: '1',
        restricted_association_groups_ids: []
    };
    const addNewRoleModalSettingsMock = {
        createTypeToOpen: CreateRoleActionType.COPY_AND_CREATE_NEW_ROLE,
        existingRole: {
            name: '1',
            id: 1
        },
        callbackAction: () => {}
    };
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [Step1SelectExistingRoleComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [ROLE_MANAGEMENT_FEATURE_KEY]: {
                            ...initialRoleManagementState,
                            roleId: 1
                        }
                    },
                    selectors: [
                        { selector: selectedDuplicateCheckState, value: false },
                        {
                            selector: rolesForSelectState,
                            value: [{ name: '1', id: '1' }]
                        },
                        {
                            selector: roleDetailsState,
                            value: expectedRoleDetails
                        },
                        {
                            selector: addNewRoleModalSettings,
                            value: addNewRoleModalSettingsMock
                        }
                    ]
                })
            ]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(Step1SelectExistingRoleComponent);
        component = fixture.componentInstance;
        component.stepForm = new FormGroup({
            existingRole: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            role: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            type: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            color: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ])
        });
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should set value from modal settings', () => {
        component.ngOnInit();
        expect(component.rolesForSelect).toEqual([
            addNewRoleModalSettingsMock.existingRole
        ]);
        expect(component.existingRoleControl.value).toEqual(
            addNewRoleModalSettingsMock.existingRole.id
        );
        expect(component.existingRoleControl.disabled).toEqual(true);
    });

    it('should select an existing role', () => {
        component.existingRoleChanged('1');
        expect(component.existingRoleControl.value).toBeDefined();
    });

    it('should call onChangehandler', () => {
        spyOn(component.showErrorOnChange, 'emit');
        component.onChangeHandler(true);
        expect(component.showErrorOnChange.emit).toHaveBeenCalled();
    });

    it('should trim whitespaces at the beginning of role name', () => {
        const testRoleName = 'test role name';

        component.roleNameControl.setValue(testRoleName);
        fixture.detectChanges();
        expect(component.roleNameControl.value).toEqual(testRoleName);

        component.roleNameControl.setValue(`  ${testRoleName}`);
        fixture.detectChanges();
        expect(component.roleNameControl.value).toEqual(testRoleName);
    });

    it('should trim whitespaces at the end of role name', () => {
        const testRoleName = 'test role name';

        component.roleNameControl.setValue(testRoleName);
        component.roleNameChanged();
        expect(component.roleNameControl.value).toEqual(testRoleName);

        component.roleNameControl.setValue(`${testRoleName}   `);
        component.roleNameChanged();
        expect(component.roleNameControl.value).toEqual(testRoleName);
    });
});
