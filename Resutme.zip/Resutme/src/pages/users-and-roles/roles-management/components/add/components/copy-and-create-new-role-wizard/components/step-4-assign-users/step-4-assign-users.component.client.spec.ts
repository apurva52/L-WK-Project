import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA, EventEmitter } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { Step4AssignUsersComponent } from './step-4-assign-users.component';

describe('Step4AssignUsersComponent', () => {
    let component: Step4AssignUsersComponent;
    let fixture: ComponentFixture<Step4AssignUsersComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [Step4AssignUsersComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    }
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(Step4AssignUsersComponent);
        component = fixture.componentInstance;
        component.stepForm = new FormGroup({
            activeAccordion: new FormControl({ value: 0, disabled: false }),
            userEntities: new FormGroup({}),
            userToApplySameCheckbox: new FormGroup({})
        });
        component.usersForm = new FormGroup({
            users: new FormControl({ value: [], disabled: false })
        });
        component.stepOneData = {
            role: 'Test Role',
            existingRole: '123',
            type: 'C',
            color: '#FFFFFF'
        };
        component.modulesForm = new FormGroup({
            modules: new FormControl({ value: {}, disabled: false }),
            sub_modules: new FormControl({ value: {}, disabled: false }),
            module_sections: new FormControl({ value: {}, disabled: false }),
            restricted_association_groups_ids: new FormControl({
                value: [],
                disabled: false
            })
        });
        component.nextEvent = new EventEmitter();
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('form should be reset', () => {
        spyOn(component.stepForm, 'reset');
        component['resetForm']();
        expect(component.stepForm.reset).toHaveBeenCalled();
    });

    it('should create from controls on ngOnInit', () => {
        const expectedControls = 2;
        component.usersForm = new FormGroup({
            users: new FormControl({
                value: [
                    {
                        id: '1',
                        label: 'Test user 1',
                        isSelected: true
                    },
                    {
                        id: '2',
                        label: 'Test user 2',
                        isSelected: true
                    }
                ],
                disabled: false
            })
        });
        component.ngOnInit();
        expect(
            Object.keys(component.userEntitiesFormGroup.controls).length
        ).toBe(expectedControls);
    });

    it('should change active accordion value', () => {
        const index = 1;
        component.onToggleEvent(index);
        expect(component.activeUsersAccordion).toBe(index);
    });

    it('should change active accordion value on Next', () => {
        component.nextEvent.emit();
        fixture.detectChanges();
        expect(component.activeUsersAccordion).toBe(0);
    });
    it('should cleanSelectedEntititesAndUsers', () => {
        const exp = 2;
        component.usersForm = new FormGroup({
            users: new FormControl({ value: [
                {
                    id: '1',
                    label: 'Test user 1',
                    isSelected: true
                },
                {
                    id: '2',
                    label: 'Test user 2',
                    isSelected: true
                }
            ], disabled: false })
        });
        component.stepForm = new FormGroup({
            activeAccordion: new FormControl({ value: 0, disabled: false }),
            userEntities: new FormGroup({
                ['1']: new FormControl( { value: 'Value 1'}),
                ['2']: new FormControl( { value: 'Value 2'}),
                ['3']: new FormControl( { }),
                ['4']: new FormControl( { })
            }),
            userToApplySameCheckbox: new FormGroup({})
        });
        component['cleanSelectedUsersAndEntities']();
        expect(Object.keys(component.userEntitiesFormGroup.controls).length).toEqual(exp);
    });
});
