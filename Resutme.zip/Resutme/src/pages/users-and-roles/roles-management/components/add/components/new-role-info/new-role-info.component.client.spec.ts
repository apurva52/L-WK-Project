import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { NewRoleInfoComponent } from './new-role-info.component';

describe('NewRoleInfoComponent', () => {
    let component: NewRoleInfoComponent;
    let fixture: ComponentFixture<NewRoleInfoComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [NewRoleInfoComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    }
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(NewRoleInfoComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should return correct pill background style', () => {
        const pillColor = '#FFFFFF';
        const expectedResult = `background-color: ${pillColor}; color: white`;
        const result = component.getPillBackgroundColor(pillColor);
        expect(result).toEqual(expectedResult);
    });
});
