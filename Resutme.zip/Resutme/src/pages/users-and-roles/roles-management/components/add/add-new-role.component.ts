import { Component, EventEmitter, Output } from '@angular/core';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';

import { selectIsInternal } from '../../../../../app/state/app.selectors';
import { roleManagementAddNewRoleModalAction } from '../../state/role-management.actions';
import { addNewRoleModalSettings, isAddNewRoleModalVisible } from '../../state/role-management.selectors';

import { CreateRoleActionType } from './components/interfaces/create-role-action-type.enum';

@Component({
    selector: 'ct-add-new-role',
    templateUrl: './add-new-role.component.html',
    styleUrls: ['./add-new-role.component.scss']
})
export class AddNewRoleComponent {
    @Output() roleSaved: EventEmitter<void> = new EventEmitter<void>();
    isModalOpen$ = this.store$.select(isAddNewRoleModalVisible);
    modalSettings$ = this.store$.select(addNewRoleModalSettings);
    isInternal$ = this.store$.select(selectIsInternal);

    isWizardOpen = false;

    createType: CreateRoleActionType;
    CreateRoleActionType = CreateRoleActionType;

    constructor(private store$: Store) { }

    onCancelModalClick(): void {
        this.createType = null;
        this.store$.dispatch(roleManagementAddNewRoleModalAction({ isOpen: false }));
    }

    onConfirmModalClick(createType: CreateRoleActionType): void {
        this.createType = createType;
        this.isWizardOpen = true;
    }

    onCancelWizardClick(roleSaved: boolean): void {
        if (roleSaved) {
            this.modalSettings$.pipe(take(1)).subscribe(settings => {
                if (settings?.callbackAction) {
                    settings.callbackAction();
                }
            });
            this.roleSaved.emit();
        }
        this.onCancelModalClick();
        this.isWizardOpen = false;
    }
}
