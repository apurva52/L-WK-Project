import { CreateRoleActionType } from '../components/interfaces/create-role-action-type.enum';

export interface AddNewRoleModalSettings {
    createTypeToOpen?: CreateRoleActionType;
    existingRole?: {
        name: string;
        id: number;
    };
    callbackAction?: Function;
}