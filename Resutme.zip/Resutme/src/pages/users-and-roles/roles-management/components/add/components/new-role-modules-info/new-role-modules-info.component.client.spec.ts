import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { NewRoleModulesInfoComponent } from './new-role-modules-info.component';

const modulesInitialData = {
    place_new_order: 0,
    activities: 0,
    compliance_events: 0
};
const subModulesInitialData = {
    compliance_events: {
        system_created: 0,
        custom_events: 0
    },
    orders: {
        all_account_orders: 0
    }
};
const moduleSectionsInitialData = {
    account_tools: {
        account_settings: {
            billing: 0
        }
    }
};

describe('NewRoleModulesInfoComponent', () => {
    let component: NewRoleModulesInfoComponent;
    let fixture: ComponentFixture<NewRoleModulesInfoComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [NewRoleModulesInfoComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    }
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(NewRoleModulesInfoComponent);
        component = fixture.componentInstance;
        component.modulesForm = new FormGroup({
            modules: new FormControl({
                value: modulesInitialData,
                disabled: false
            }),
            sub_modules: new FormControl({
                value: subModulesInitialData,
                disabled: false
            }),
            module_sections: new FormControl({
                value: moduleSectionsInitialData,
                disabled: false
            }),
            restricted_association_groups_ids: new FormControl({
                value: [],
                disabled: false
            }),
            restricted_documents_metadata: new FormControl({
                value: {},
                disabled: false
            })
        });
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('modules form should be changed', () => {
        const place_new_order = 13;
        const system_created = 8;
        const billing = 8;
        component.onPermissionsChanged({
            modules: { place_new_order },
            sub_modules: {
                compliance_events: {
                    system_created
                }
            },
            module_sections: {
                account_tools: {
                    account_settings: {
                        billing
                    }
                }
            },
            restricted_documents_metadata: {
                restricted_document_types: [],
                restricted_document_statuses: [],
                restricted_document_categories: []
            }
        });
        expect(component.modulesForm.value.modules.place_new_order).toEqual(
            place_new_order
        );
        expect(
            component.modulesForm.value.sub_modules.compliance_events
                .system_created
        ).toEqual(system_created);
        expect(
            component.modulesForm.value.module_sections.account_tools
                .account_settings.billing
        ).toEqual(billing);
    });
});
