export interface Step1RoleInfoInterface {
    roleName: string;
    pillColor: string;
    createdBy: string;
    createdOn: string;
}
