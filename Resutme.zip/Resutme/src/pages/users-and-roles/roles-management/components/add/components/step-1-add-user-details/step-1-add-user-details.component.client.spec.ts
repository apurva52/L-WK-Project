import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { selectedActiveUsersForMultiSelect } from 'src/pages/users-and-roles/users-management/state/user-management.selectors';
import { ModulePermissionsService } from 'src/shared/services/module-permissions/module-permissions.service';

import { Step1RoleUserComponent } from './step-1-add-user-details.component';

describe('Step1AddUserDetailsComponent', () => {
    let component: Step1RoleUserComponent;
    let fixture: ComponentFixture<Step1RoleUserComponent>;
    const modulePermissionsServiceMock = jasmine.createSpyObj<any>([
        'doesUserHasPermission',
        'doesNotUserHasPermission'
    ]);
    const roleId = 22;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [Step1RoleUserComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    },
                    selectors: [
                        {
                            selector: selectedActiveUsersForMultiSelect([], roleId),
                            value: []
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                },
                {
                    provide: ModulePermissionsService,
                    useValue: modulePermissionsServiceMock
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(Step1RoleUserComponent);
        component = fixture.componentInstance;
        modulePermissionsServiceMock.doesUserHasPermission.and.returnValue(
            true
        );
        component.stepForm = new FormGroup({
            users: new FormControl({ value: null, disabled: false }, [
                Validators.required
            ])
        });
        spyOn(component['store$'], 'dispatch');
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should create and load users for multiselect', () => {
        component.stepForm.setValue({
            users: [{ id: '9', label: 'Affiliate', isSelected: true }]
        });
        fixture.detectChanges();
        expect(component).toBeTruthy();
        expect(component.stepForm.value.users).toBeDefined();
    });

    xit('Should Deselect Users based on the Cancel Action', () => {
        spyOn(component['store$'], 'select');
        component.stepForm.setValue({
            users: [
                { id: '9', label: 'Affiliate', isSelected: true },
                { id: '10', label: 'Affiliate', isSelected: true }
            ]
        });
        component.removeUsers('9');
        expect(component.stepForm.value.users).toEqual([
            { id: '10', label: 'Affiliate', isSelected: true }
        ]);
        expect(component['store$'].select).toHaveBeenCalled();
    });
});
