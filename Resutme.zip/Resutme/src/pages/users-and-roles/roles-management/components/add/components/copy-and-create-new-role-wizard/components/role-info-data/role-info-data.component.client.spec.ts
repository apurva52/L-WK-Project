import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import mockRoleDetails from '../../../../../../details/state/test-values/role-details-mock.json';
import { initialRoleManagementState } from '../../../../../../state/role-management.reducers';
import { roleDetailsState } from '../../../../../../state/role-management.selectors';
import { ROLE_MANAGEMENT_FEATURE_KEY } from '../../../../../../state/role-management.state';
import { NameWithInitialsAvatarComponent } from '../../../../../name-with-initials-avatar/name-with-initials-avatar.component';

import { RoleInfoDataComponent } from './role-info-data.component';

describe('RoleInfoDataComponent', () => {
    let component: RoleInfoDataComponent;
    let fixture: ComponentFixture<RoleInfoDataComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                RoleInfoDataComponent,
                NameWithInitialsAvatarComponent
            ],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [ROLE_MANAGEMENT_FEATURE_KEY]:
                            initialRoleManagementState
                    },
                    selectors: [
                        {
                            selector: roleDetailsState,
                            value: mockRoleDetails.data
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(RoleInfoDataComponent);
        component = fixture.componentInstance;
        component.stepOneData = {
            role: 'Test Role',
            existingRole: '123',
            type: 'C',
            color: '#FFFFFF'
        };
    });

    it('should create', () => {
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });

    it('should be defined existingRoleDetails', () => {
        component.ngOnInit();
        expect(component.existingRoleDetails$).toBeDefined();
    });
});
