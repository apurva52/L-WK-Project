/* tslint:disable:max-file-line-count */
import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ScreenSizeEnum } from '@ct/platform-primitives-uicomponents/modals';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { take, takeUntil } from 'rxjs/operators';

import {
    getDuplicateCheckAction,
    getDuplicateCheckSuccessAction,
    roleManagementCheckPreviousButtonAction,
    roleManagementSaveNewRoleAction,
    roleManagementSaveNewRoleSuccessAction
} from '../../../../state/role-management.actions';
import { CreateNewRoleWizard } from '../create-new-role-wizard/create-new-role-wizard';

import * as configComponent from './copy-and-create-new-role-wizard.config';

@Component({
    selector: 'ct-copy-and-create-new-role-wizard',
    templateUrl: './copy-and-create-new-role-wizard.component.html',
    styleUrls: ['./copy-and-create-new-role-wizard.component.scss']
})
export class CopyAndCreateNewRoleWizardComponent extends CreateNewRoleWizard implements OnInit, OnDestroy {
    get formValue(): configComponent.RoleFormValue {
        return this.form.value.reduce(
            (result, stepValue) => ({
                ...result,
                ...stepValue
            }),
            {}
        );
    }

    readonly ScreenSizeEnum = ScreenSizeEnum;
    hasOverlayClickClose = false;
    @Output() roleCreated = new EventEmitter<void>();

    constructor(
        protected store$: Store,
        private translate: TranslateService,
        protected actionsListener$: ActionsSubject
    ) {
        super(store$, actionsListener$);
        this.newRoleStepsPayload = configComponent.getNewRoleStepsPayload();
        this.wizardConfig = configComponent.getWizardConfig(this.translate);
        this.form = configComponent.getInitialForm();
        this.confirmModalModel = {
            title: 'userRolesModule.newRoleWizardComponent.cancelConfirmModal.title',
            cancelText: 'userRolesModule.newRoleWizardComponent.cancelConfirmModal.cancelBtn',
            confirmText: 'userRolesModule.newRoleWizardComponent.cancelConfirmModal.confirmBtn'
        };
    }

    ngOnInit(): void {
        this.actionsListener$.pipe(ofType(roleManagementSaveNewRoleSuccessAction), take(1)).subscribe((result) => {
            if (result.hasOwnProperty('role_id')) {
                this.handleSavedRoleState(result.role_id);
            }
        });
        this.actionsListener$.pipe(ofType(getDuplicateCheckSuccessAction), takeUntil(this._destroyed$)).subscribe(() => {
            if (this.activeStep === 0 && !this.isRoleNameDuplicate) {
                this.goToNext();
            }
        });
        this.getStepForm(configComponent.STEP4INDEX)
            .controls.activeAccordion.valueChanges.pipe(takeUntil(this._destroyed$))
            .subscribe((value) => {
                this.wizardConfig.steps[configComponent.STEP4INDEX].nextLabel = this.translate.instant(value < 0
                    ? 'userRolesModule.newRoleWizardComponent.assignLabel'
                    : 'userRolesModule.newRoleWizardComponent.nextLabel'
                );
                this.wizardConfig = { ...this.wizardConfig };
            });
        this.step4SubmitLabelText = this.translate.instant('userRolesModule.newRoleWizardComponent.assignLabel');
        this.getStepForm(0).get('type').setValue(this.roleType);
    }

    ngOnDestroy(): void {
        this._destroyed$.next();
        this._destroyed$.complete();
    }

    onPrevious(): void {
        this.setStep(this.activeStep - 1);
        this.store$.dispatch(
            roleManagementCheckPreviousButtonAction({
                isBack: true
            })
        );
        if (this.newRoleStepsPayload.length > configComponent.DEFAULT_ITEM_COUNT_FORM) {
            this.newRoleStepsPayload = configComponent.getNewRoleStepsPayload();
        }
        if (this.roleSaved && this.activeStep === 1) {
            this.wizardConfig.cancelText = this.translate.instant('userRolesModule.newRoleWizardComponent.noLabel');
        }
    }

    onNext(): void {
        switch (this.activeStep) {
            case 0:
                this.firstStepSubmit();
                break;
            case 1:
                this.step2Submit();
                break;
            case configComponent.STEP4INDEX:
                this.step4Submit();
                break;
            default:
                this.goToNext();
                break;
        }
    }

    private handleSavedRoleState(roleId: number): void {
        this.roleSaved = true;
        this.getStepForm(0).addControl('role_id', new FormControl(roleId));
        this.wizardConfig.steps[this.activeStep].nextLabel = this.translate.instant(
            'userRolesModule.newRoleWizardComponent.newRoleFormStep2.yesButtonLabel'
        );
        this.wizardConfig.cancelText = this.translate.instant('userRolesModule.newRoleWizardComponent.noLabel');
    }

    private firstStepSubmit(): void {
        this.isCheckingDuplicate = true;
        this.store$.dispatch(getDuplicateCheckAction({ roleName: this.formValue.role }));
    }

    private step2Submit(): void {
        if (this.roleSaved) {
            this.openStep3();
        } else {
            this.saveNewRole();
        }
    }

    private openStep3(): void {
        this.wizardConfig.cancelText = this.translate.instant('userRolesModule.newRoleWizardComponent.cancelLabel');
        this.goToNext();
    }

    private saveNewRole(): void {
        const { role, type, color, modules, sub_modules, module_sections,
            restricted_association_groups_ids, restricted_documents_metadata } = this.formValue;
        this.store$.dispatch(
            roleManagementSaveNewRoleAction({
                data: {
                    role,
                    type,
                    color,
                    modules,
                    sub_modules,
                    module_sections,
                    restricted_association_groups_ids,
                    restricted_documents_metadata
                }
            })
        );
    }
}
