/* tslint:disable:max-file-line-count */
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { selectUserTokenPayload } from '../../../../../../../app/state/app.selectors';
import { initialRoleManagementState } from '../../../../../../../pages/users-and-roles/roles-management/state/role-management.reducers';
import { selectedDuplicateCheckState } from '../../../../../../../pages/users-and-roles/roles-management/state/role-management.selectors';
import { ROLE_MANAGEMENT_FEATURE_KEY } from '../../../../../../../pages/users-and-roles/roles-management/state/role-management.state';

import { Step1SelectExistingRoleComponent } from './components/step-1-select-existing-role/step-1-select-existing-role.component';
import { CopyAndCreateNewRoleWizardComponent } from './copy-and-create-new-role-wizard.component';
import { STEP4INDEX } from './copy-and-create-new-role-wizard.config';

describe('CopyAndCreateNewRoleWizardComponent', () => {
    let component: CopyAndCreateNewRoleWizardComponent;
    let fixture: ComponentFixture<CopyAndCreateNewRoleWizardComponent>;
    const step3index = 3;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                CopyAndCreateNewRoleWizardComponent,
                Step1SelectExistingRoleComponent
            ],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [ROLE_MANAGEMENT_FEATURE_KEY]:
                            initialRoleManagementState
                    },
                    selectors: [
                        { selector: selectedDuplicateCheckState, value: false },
                        { selector: selectUserTokenPayload, value: null }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(CopyAndCreateNewRoleWizardComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should navigate to first step', () => {
        const storeSpy = spyOn((component as any).store$, 'dispatch');
        component.setStep(0);
        component.onNext();
        fixture.detectChanges();
        expect(component.isCheckingDuplicate).toEqual(true);
        expect(storeSpy).toHaveBeenCalled();
    });

    it('should navigate to default step', () => {
        const step3Index = 3;
        component.setStep(2);
        component.onNext();
        fixture.detectChanges();
        expect(component.activeStep).toEqual(step3Index);
    });

    it('should navigate to first step', () => {
        const storeSpy = spyOn((component as any).store$, 'dispatch');
        component.setStep(0);
        component.onNext();
        fixture.detectChanges();
        expect(component.isCheckingDuplicate).toEqual(true);
        expect(storeSpy).toHaveBeenCalled();
    });
    it('should navigate to second step', () => {
        const storeSpy = spyOn((component as any).store$, 'dispatch');
        component.setStep(1);
        component.onNext();
        fixture.detectChanges();
        expect(component.isCheckingDuplicate).toEqual(false);
        expect(storeSpy).toHaveBeenCalled();
    });
    it('should navigate to second step and role is saved', () => {
        component.roleSaved = true;
        component.setStep(1);
        component.onNext();
        fixture.detectChanges();
        expect(component.isCheckingDuplicate).toEqual(false);
    });
    it('should navigate to third step and doAllUserHaveEntitiesAssociation', () => {
        const handleSpy = spyOn(
            component as any,
            'doAllUserHaveEntitiesAssociation'
        );
        handleSpy.and.callFake(() => {
            return new Promise((resolve) => {
                resolve(true);
            });
        });
        component.setStep(step3index);
        component.wizardConfig.steps[component.activeStep].nextLabel =
            'userRolesModule.newRoleWizardComponent.assignLabel';
        fixture.detectChanges();
        component.onNext();
        expect(component.isCheckingDuplicate).toEqual(false);
    });
    it('should navigate to fourth step and doAllUserHaveEntitiesAssociation', () => {
        const handleSpy = spyOn(
            component as any,
            'doAllUserHaveEntitiesAssociation'
        );
        handleSpy.and.callFake(() => {
            return new Promise((resolve) => {
                resolve(true);
            });
        });
        component.setStep(STEP4INDEX);
        component.wizardConfig.steps[component.activeStep].nextLabel =
            'userRolesModule.newRoleWizardComponent.nextLabel';
        fixture.detectChanges();
        component.onNext();
        expect(component.isCheckingDuplicate).toEqual(false);
    });

    it('should navigate to third step and NOT doAllUserHaveEntitiesAssociation', () => {
        const handleSpy = spyOn(
            component as any,
            'doAllUserHaveEntitiesAssociation'
        );
        handleSpy.and.callFake(() => {
            return new Promise((resolve) => {
                resolve(false);
            });
        });
        component.setStep(step3index);
        component.onNext();
        fixture.detectChanges();
        expect(component.isCheckingDuplicate).toEqual(false);
    });

    it('should navigate to next step', () => {
        component.setStep(0);
        component['goToNext']();
        fixture.detectChanges();
        expect(component.activeStep).toEqual(1);
    });

    it('should get child form from state', () => {
        expect(component.getStepForm(0)).toBeDefined();
    });

    it('should validate if current form is valid', () => {
        component.setStep(0);
        component.getStepForm(0).patchValue({
            existingRole: 'Unit',
            role: 'Test',
            type: 'C',
            color: 'Red'
        });
        expect(component.isCurrentFormValid).toBeTruthy();
    });

    it('On Change Handler Pass', () => {
        component.onChangeHandler(false);
        expect(component.isCheckingDuplicate).toEqual(false);
    });

    it('On Change Handler Fail', () => {
        component.onChangeHandler(true);
        expect(component.isCheckingDuplicate).toEqual(true);
    });

    it('should close wizard modal', () => {
        spyOn(component.cancel, 'emit');
        component.closeWizardModal();
        expect(component.cancel.emit).toHaveBeenCalled();
    });
    it('should allow to launch or not the confirmation modal cancel', () => {
        component.confirmCloseModal();
        fixture.detectChanges();
        expect(component.isCancelNotificationVisible).toEqual(true);

        component.roleSaved = true;
        component.setStep(1);
        component.confirmCloseModal({ isCloseButtonClick: true });
        fixture.detectChanges();
        expect(component.isCancelNotificationVisible).toEqual(false);

        component.confirmCloseModal();
        fixture.detectChanges();
        expect(component.isCancelNotificationVisible).toEqual(false);
    });
    it('should save new role', () => {
        spyOn(component['store$'], 'dispatch');
        component['saveNewRole']();
        expect(component['store$'].dispatch).toHaveBeenCalled();
    });
    it('should set a new step directly', () => {
        component.setStep(2);
        fixture.detectChanges();
        expect(component.activeStep).toEqual(2);
    });
    it('should navigate to previous step and restart wizard', () => {
        const step6Index = 6;
        const step4Index = 4;
        component.setStep(step6Index);
        component.newRoleStepsPayload.push({
            isActive: false,
            isFailed: false,
            isVisited: false,
            stepId: 5,
            description: ''
        });
        component.onPrevious();
        fixture.detectChanges();
        expect(component.newRoleStepsPayload.length).toEqual(step4Index);
    });
    it('should navigate to previous step', () => {
        component.setStep(2);
        component.onPrevious();
        fixture.detectChanges();
        expect(component.activeStep).toEqual(1);
    });
    it('should navigate to previous step and role is saved', () => {
        component.roleSaved = true;
        component.setStep(2);
        component.onPrevious();
        fixture.detectChanges();
        expect(component.isCheckingDuplicate).toEqual(false);
    });
    it('should dispatch action when moving to next step [3]', () => {
        component.setStep(step3index);
        component.onNext();
        fixture.detectChanges();
        expect(component.activeStep).toEqual(step3index);
    });
    it('should display an error when duplicates', () => {
        component.onChangeHandler(true);
        fixture.detectChanges();
        expect(component.isCheckingDuplicate).toEqual(true);
    });

    it('should close modal', () => {
        spyOn(component['store$'], 'dispatch');
        component['closeWizardModal']();
        expect(component['store$'].dispatch).toHaveBeenCalled();
    });

    it('should apply same entities for all selected users', () => {
        const selectUsersStepNumber = 2;
        const selectAssociateEntititesStepNumber = 3;
        const users = [
            {
                id: '1',
                label: 'Test user 1',
                isSelected: true
            },
            {
                id: '2',
                label: 'Test user 2',
                isSelected: true
            }
        ];
        const entities = [
            {
                edh_entity_group_id: 1,
                edh_entity_group_guid: '1',
                edh_entity_group_name: 'Group 1',
                edh_entity_group_type: 'I',
                entities: [
                    {
                        entity_id: 1,
                        entity_guid: '1',
                        entity_name: 'Entity 1',
                        entity_country: 'Test',
                        domestic_jurisdiction: 'Test'
                    }
                ]
            }
        ];
        const role_id = 123;
        component
            .getStepForm(0)
            .addControl('role_id', new FormControl(role_id));

        component.setStep(1);
        component.roleSaved = true;
        component.onNext();
        expect(component.activeStep).toBe(selectUsersStepNumber);

        component
            .getStepForm(selectUsersStepNumber)
            .controls.users.setValue(users);
        component.onNext();
        expect(component.activeStep).toBe(selectAssociateEntititesStepNumber);

        const userEntitiesFormGroup = component.getStepForm(
            selectAssociateEntititesStepNumber
        ).controls.userEntities as FormGroup;
        const userToApplySameCheckboxFromGroup = component.getStepForm(
            selectAssociateEntititesStepNumber
        ).controls.userToApplySameCheckbox as FormGroup;
        users.forEach((user, index) =>
            userEntitiesFormGroup.addControl(
                user.id,
                new FormControl(index === 0 ? entities : [])
            )
        );
        userToApplySameCheckboxFromGroup.addControl(
            users[0].id,
            new FormControl(true)
        );

        const storeDispatchSpy = spyOn((component as any).store$, 'dispatch');

        component
            .getStepForm(selectAssociateEntititesStepNumber)
            .controls.activeAccordion.setValue(-1);
        component.onNext();

        component
            .getStepForm(selectAssociateEntititesStepNumber)
            .controls.activeAccordion.setValue(0);
        component.onNext();

        Object.keys(userEntitiesFormGroup.controls).forEach((key) => {
            expect(userEntitiesFormGroup.controls[key].value).toEqual(entities);
        });
        expect(storeDispatchSpy).toHaveBeenCalledTimes(1);
    });

    it('should copy and create role for internal role', () => {
        const spyStore = spyOn((component as any).store$, 'dispatch');
        component.isInternal = true;
        component.getStepForm(0).get('type').setValue(component.roleType);
        component['saveNewRole']();
        expect(spyStore).toHaveBeenCalledWith(
            jasmine.objectContaining({data: jasmine.objectContaining({type: 'I'})})
        );
    });
});
