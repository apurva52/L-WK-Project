import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';

import {
    RoleDetails,
    RolePermissions
} from '../../../../../../details/state/role-details.state';
import { roleManagementGetModifiedRoleDetailsAction } from '../../../../../../state/role-management.actions';
import {
    isBackCheckState,
    modifiedRoleDetailsState,
    roleDetailsState
} from '../../../../../../state/role-management.selectors';
import { StepComponent } from '../../../../interfaces/step-component.model';

@Component({
    selector: 'ct-step-2-select-modules-permissions',
    templateUrl: './step-2-select-modules.component.html',
    styleUrls: ['./step-2-select-modules.component.scss']
})
export class Step2SelectModulesComponent extends StepComponent {
    @Input() stepForm: FormGroup;
    @Input() roleSaved: boolean;
    @Input() stepOneData: {
        existingRole: string;
        role: string;
        type: string;
        color: string;
    };

    selectedRoleDetails: RolePermissions;
    getStepOneDetails: RoleDetails;
    isBack: boolean;
    checkBackAction$ = this.store$
        .select(isBackCheckState)
        .subscribe((value) => {
            this.isBack = value;
        });

    selectRolePermissions$ = this.store$.select(roleDetailsState);

    selectUpdatedRolePermissions$ = this.store$.select(
        modifiedRoleDetailsState
    );

    constructor(private store$: Store) {
        super();
    }

    existingRoleChanged(event): void {
        this.store$.dispatch(
            roleManagementGetModifiedRoleDetailsAction({
                updatedRoleDetails: event
            })
        );
    }
}
