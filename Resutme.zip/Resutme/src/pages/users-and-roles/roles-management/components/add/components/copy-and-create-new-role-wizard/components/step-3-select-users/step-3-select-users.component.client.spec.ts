import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { TranslateModule } from '@ngx-translate/core';

import { Step3SelectUsersComponent } from './step-3-select-users.component';

describe('Step3SelectUsersComponent', () => {
    let component: Step3SelectUsersComponent;
    let fixture: ComponentFixture<Step3SelectUsersComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [Step3SelectUsersComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(Step3SelectUsersComponent);
        component = fixture.componentInstance;
        component.stepOneData = {
            role: 'Test Role',
            existingRole: '123',
            type: 'C',
            color: '#FFFFFF'
        };
        component.modulesForm = new FormGroup({
            modules: new FormControl({ value: {}, disabled: false }),
            sub_modules: new FormControl({ value: {}, disabled: false }),
            module_sections: new FormControl({ value: {}, disabled: false }),
            restricted_association_groups_ids: new FormControl({
                value: [],
                disabled: false
            })
        });
        component.stepForm = new FormGroup({
            users: new FormControl({ value: [], disabled: false })
        });
    });

    it('should create', () => {
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });
});
