import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';

import { CreateRoleActionType } from '../interfaces/create-role-action-type.enum';

import { AddRoleModalComponent } from './add-role-modal.component';

class FakeLoader implements TranslateLoader {
    getTranslation(_lang: string): Observable<any> {
        return of({});
    }
}

describe('AddRoleModalComponent', () => {
    let component: AddRoleModalComponent;
    let fixture: ComponentFixture<AddRoleModalComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [AddRoleModalComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AddRoleModalComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should change selection', () => {
        expect(component.selectedOption).toBeUndefined();
        component.onChange(component.controlOptions[0]);
        expect(component.selectedOption).toBeDefined();
    });

    it('should emit cancel event', () => {
        spyOn(component.cancel, 'emit');
        component.onCancelClick();
        expect(component.cancel.emit).toHaveBeenCalled();
    });

    it('should emit confirm event', () => {
        component.onChange(component.controlOptions[0]);
        spyOn(component.confirm, 'emit');
        component.onConfirmClick();
        expect(component.confirm.emit).toHaveBeenCalledWith(
            component.controlOptions[0].value as any
        );
    });

    it('should select option on activeOption change', () => {
        const optionChangeSpy = spyOn(component, 'onChange');
        const typeToCheck = CreateRoleActionType.COPY_AND_CREATE_NEW_ROLE;
        const copyAndCreateOption = component.controlOptions.find(
            (option) => option.value === typeToCheck
        );

        component.activeOption = null;
        expect(copyAndCreateOption.checked).toEqual(false);

        component.activeOption = '11231' as any;
        expect(copyAndCreateOption.checked).toEqual(false);

        component.activeOption = typeToCheck;
        expect(copyAndCreateOption.checked).toEqual(true);
        expect(optionChangeSpy).toHaveBeenCalledWith(copyAndCreateOption);
    });
});
