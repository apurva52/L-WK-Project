import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';

import { roleDetailsState } from '../../../../state/role-management.selectors';
import { InputMultiselectUser } from '../../interfaces/input-multiselect-user';
import { StepComponent } from '../../interfaces/step-component.model';

@Component({
    selector: 'ct-step-2-add-user-details',
    templateUrl: './step-2-add-user-details.component.html',
    styleUrls: ['./step-2-add-user-details.component.scss']
})
export class Step2RoleUserComponent extends StepComponent {
    @Input() stepForm: FormGroup;
    @Input() selectedUsersForm: FormGroup;
    @Output() currentUserChanged: EventEmitter<string> = new EventEmitter();
    _currentUser: InputMultiselectUser;
    rolePermissions$ = this.store$.select(roleDetailsState);

    constructor(private store$: Store) {
        super();
    }

    get pillLabel(): string {
        return this.usersControl.value?.map(item => item.label.trim()).join(', ');
    }

    get usersControl(): FormControl {
        return this.selectedUsersForm.get('users') as FormControl;
    }

    get formEntitiesGroup(): FormGroup {
        return this.stepForm.get('entities') as FormGroup;
    }

    @Input()
    set currentUser(user: InputMultiselectUser) {
        this._currentUser = user;
    }

    get currentUser(): InputMultiselectUser {
        return this._currentUser;
    }

    onToggleAccordion(roleId: string): void {
        if (this.currentUser?.id === roleId) { return; }
        this.currentUserChanged.emit(roleId);
    }
}
