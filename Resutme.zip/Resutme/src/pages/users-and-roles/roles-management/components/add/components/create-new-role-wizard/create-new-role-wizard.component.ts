// tslint:disable max-file-line-count
import { Component, OnDestroy, OnInit } from '@angular/core';
import {
    FormControl,
    FormGroup,
    ValidationErrors,
    ValidatorFn,
    Validators
} from '@angular/forms';
import { ScreenSizeEnum } from '@ct/platform-primitives-uicomponents/modals';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { take, takeUntil } from 'rxjs/operators';

import {
    getDuplicateCheckAction,
    getDuplicateCheckSuccessAction,
    roleManagementSaveNewRoleAction,
    roleManagementSaveNewRoleFailureAction,
    roleManagementSaveNewRoleSuccessAction
} from '../../../../state/role-management.actions';

import { CreateNewRoleWizard } from './create-new-role-wizard';
import * as configComponent from './create-new-role-wizard.config';
import { getAssignUsersWizardConfig } from './get-assign-users-wizard.config';
import { setWizardConfig } from './set-wizard.config';

@Component({
    selector: 'ct-create-new-role-wizard',
    templateUrl: './create-new-role-wizard.component.html',
    styleUrls: ['./create-new-role-wizard.component.scss']
})
export class CreateNewRoleWizardComponent
    extends CreateNewRoleWizard
    implements OnInit, OnDestroy
{
    readonly ScreenSizeEnum = ScreenSizeEnum;
    headerText = '';
    roleSaveInProgress = false;
    hasOverlayClickClose = false;



    constructor(
        private translate: TranslateService,
        protected store$: Store,
        protected actionsListener$: ActionsSubject
    ) {
        super(store$, actionsListener$);
        this.newRoleStepsPayload = configComponent.getNewRoleStepsPayload();
        this.confirmModalModel = {
            title: 'userRolesModule.newRoleWizardComponent.copyAndCreate.cancelConfirmModal.title',
            cancelText:
                'userRolesModule.newRoleWizardComponent.copyAndCreate.cancelConfirmModal.cancelBtn',
            confirmText:
                'userRolesModule.newRoleWizardComponent.copyAndCreate.cancelConfirmModal.confirmBtn'
        };
        this.form = configComponent.getInitialForm();
    }

    ngOnInit(): void {
        this.userTokenPayload$.pipe(take(1)).subscribe((userData: any) => {
            this.getStepForm(0).controls.created_by_name.setValue(
                userData?.name
            );
        });
        this.actionsListener$
            .pipe(
                ofType(getDuplicateCheckSuccessAction),
                takeUntil(this._destroyed$)
            )
            .subscribe(() => {
                if (this.activeStep === 0 && !this.isRoleNameDuplicate) {
                    this.goToNext();
                }
            });
        this.wizardConfig = setWizardConfig(this.translate);
        this.step4SubmitLabelText = this.translate.instant(
            'userRolesModule.newRoleWizardComponent.createLabel'
        );
    }

    ngOnDestroy(): void {
        this._destroyed$.next();
        this._destroyed$.complete();
    }

    onPrevious(): void {
        this.setStep(this.activeStep - 1);
        if (this.roleSaved && this.activeStep === 1) {
            this.wizardConfig.cancelText = this.translate.instant(
                'userRolesModule.newRoleWizardComponent.noLabel'
            );
        }
    }

    onNext(): void {
        const step4Index = 3;
        switch (this.activeStep) {
            case 0:
                this.step1Submit();
                break;
            case 1:
                this.step2Submit();
                break;
            case step4Index:
                this.step4Submit();
                break;
            default:
                this.goToNext();
                break;
        }
    }

    private step1Submit(): void {
        this.isCheckingDuplicate = true;
        const roleName = this.getStepForm(0).controls.role_name.value;
        this.store$.dispatch(getDuplicateCheckAction({ roleName: roleName }));
    }

    private step2Submit(): void {
        if (this.roleSaved) {
            this.openStep3();
        } else {
            this.saveRole();
        }
    }

    private openStep3(): void {
        if (this.isInlastStep) {
            this.newRoleStepsPayload.push(
                ...configComponent.getNewRoleAssignUsersStepsPayload()
            );
            this.wizardConfig.steps.push(
                ...getAssignUsersWizardConfig(this.translate).steps
            );
            this.form.push(
                new FormGroup({
                    users: new FormControl({ value: [], disabled: false }, [
                        Validators.required
                    ])
                })
            );
            this.form.push(
                new FormGroup(
                    {
                        activeAccordion: new FormControl({
                            value: 0,
                            disabled: false
                        }),
                        userEntities: new FormGroup({}),
                        userToApplySameCheckbox: new FormGroup({})
                    },
                    [this.userEntitiesValidation()]
                )
            );
            const lastStep = 3;
            this.getStepForm(lastStep)
                .controls.activeAccordion.valueChanges.pipe(
                    takeUntil(this._destroyed$)
                )
                .subscribe((value) => {
                    this.wizardConfig.steps[lastStep].nextLabel =
                        this.translate.instant(
                            value < 0
                                ? 'userRolesModule.newRoleWizardComponent.createLabel'
                                : 'userRolesModule.newRoleWizardComponent.nextLabel'
                        );
                    this.wizardConfig = { ...this.wizardConfig };
                });
        }
        this.wizardConfig.cancelText = this.translate.instant(
            'userRolesModule.newRoleWizardComponent.cancelLabel'
        );
        this.goToNext();
    }

    private saveRole(): void {
        this.roleSaveInProgress = true;

        const firstStepFormValue = this.getStepForm(0).value;
        const secondStepFormValue = this.getStepForm(1).value;

        this.subscribeRoleSavedState();
        this.store$.dispatch(
            roleManagementSaveNewRoleAction({
                data: {
                    role: firstStepFormValue.role_name,
                    type: this.roleType,
                    color: firstStepFormValue.role_color,
                    modules: secondStepFormValue.modules,
                    sub_modules: secondStepFormValue.sub_modules,
                    module_sections: secondStepFormValue.module_sections,
                    restricted_association_groups_ids:
                        secondStepFormValue.restricted_association_groups_ids,
                    restricted_documents_metadata:
                        secondStepFormValue.restricted_documents_metadata
                }
            })
        );
    }

    private subscribeRoleSavedState(): void {
        this.actionsListener$
            .pipe(
                ofType(
                    roleManagementSaveNewRoleSuccessAction,
                    roleManagementSaveNewRoleFailureAction
                ),
                take(1)
            )
            .subscribe((result) => {
                this.roleSaveInProgress = false;
                if (result.hasOwnProperty('role_id')) {
                    this.getStepForm(0).addControl(
                        'role_id',
                        new FormControl((result as any).role_id)
                    );
                    this.saveRoleSuccess();
                }
            });
    }

    private saveRoleSuccess(): void {
        this.roleSaved = true;
        this.wizardConfig.cancelText = this.translate.instant(
            'userRolesModule.newRoleWizardComponent.noLabel'
        );
        this.wizardConfig.steps[1].nextLabel = this.translate.instant(
            'userRolesModule.newRoleWizardComponent.newRoleFormStep2.yesButtonLabel'
        );
    }

    private userEntitiesValidation(): ValidatorFn {
        const selectedUsersFormControl = this.getStepForm(2).get('users');
        return (form: FormGroup): ValidationErrors | null => {
            const formValue = form.value;
            const activeAccordion = formValue.activeAccordion;
            const userEntities = formValue.userEntities;
            if (activeAccordion < 0) {
                return Object.keys(userEntities).some(
                    (key) => !userEntities[key].length
                )
                    ? { invalid: true }
                    : null;
            }
            const selectedUsers = selectedUsersFormControl?.value || [];
            const selectedUser = selectedUsers[activeAccordion];
            return selectedUser && userEntities[selectedUser.id]?.length
                ? null
                : { invalid: true };
        };
    }
}
