/* tslint:disable:max-file-line-count */
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { ModalModel, ScreenSizeEnum, WizardConfiguration } from '@ct/platform-primitives-uicomponents/modals';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { isEmpty } from 'lodash';
import { Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { selectIsInternal } from 'src/app/state/app.selectors';

import { clearAllData, clearRoleSelectedEntities, clearSelectedEntities, selectEntities } from '../../../../../../../features/entity-selector/state/entity-selector.actions';
import { getSelectedEntities } from '../../../../../../../features/entity-selector/state/entity-selector.selectors';
import {
    AddUserRoleModalAction,
    roleManagementUsersRoleEntitiesAssignAction,
    roleManagementUsersRoleEntitiesAssignFailureAction,
    roleManagementUsersRoleEntitiesAssignSuccessAction
} from '../../../../../../../pages/users-and-roles/roles-management/state/role-management.actions';
import { selectIsAddUserRoleModalVisible } from '../../../../../../../pages/users-and-roles/roles-management/state/role-management.selectors';
import { InputMultiselectUser } from '../../interfaces/input-multiselect-user';

import { userAddUserModalAction, userManagementInitiateAction } from './../../../../../users-management/state/user-management.actions';
import {
    getNewUserRoleStepsPayload,
    setWizardConfig
} from './add-user-role.config';

@Component({
    selector: 'ct-add-user-role-modal',
    templateUrl: './add-user-role-modal.component.html',
    styleUrls: ['./add-user-role-modal.component.scss']
})
export class AddUserRoleModalComponent implements OnInit, OnDestroy {
    get activeStep(): number {
        const step = this.newUserStepsPayload.findIndex((step) => step.isActive);
        return step > -1 ? step : 0;
    }
    get isInlastStep(): boolean {
        return this.activeStep === this.newUserStepsPayload.length - 1;
    }
    get isCurrentFormValid(): boolean {
        return this.getStepForm(this.activeStep)?.valid;
    }
    get selectedUsers(): FormControl {
        return this.getStepForm(0).get('users') as FormControl;
    }
    get groupedEntities(): FormGroup {
        return this.getStepForm(1).get('entities') as FormGroup;
    }
    get userToApplySameCheckboxFormGroup(): FormGroup {
        return this.getStepForm(1).get('userToApplySameCheckbox') as FormGroup;
    }
    get isAllowedMoveForward(): boolean {
        return (
            this.form.valid ||
            this.groupedEntities.get(this.currentSelectedUser?.id)?.valid
        );
    }
    get currentSelectedUser(): InputMultiselectUser {
        return this.usersInView.find((user) => user.isCurrent);
    }

    readonly ScreenSizeEnum = ScreenSizeEnum;

    @Input() roleId: string;
    @Output() usersAdded = new EventEmitter<boolean>();
    newUserStepsPayload = [];
    btnsVisible: boolean = true;
    wizardConfig: WizardConfiguration;
    hasOverlayClickClose: boolean = false;
    headerText: string = '';
    isAddUserModalVisible$ = this.store$.select(
        selectIsAddUserRoleModalVisible
    );
    selectedEntities$ = this.store$.select(getSelectedEntities);
    totalAditionalSteps = 0;
    usersInView: Array<InputMultiselectUser> = [];
    isReadyToSave = false;

    modalModel: ModalModel = {
        title: 'userRolesModule.AddNewRoleComponent.title',
        cancelText: 'userRolesModule.AddNewRoleComponent.cancelButton',
        confirmText: 'userRolesModule.AddNewRoleComponent.confirmButton'
    };

    isCancelNotificationVisible: boolean = false;
    confirmModalModel: ModalModel = {
        title: 'userRolesModule.AddNewRoleComponent.cancelConfirmModal.title',
        cancelText:
            'userRolesModule.AddNewRoleComponent.cancelConfirmModal.cancelBtn',
        confirmText:
            'userRolesModule.AddNewRoleComponent.cancelConfirmModal.confirmBtn'
    };
    form: FormArray = new FormArray([
        new FormGroup({
            users: new FormControl({ value: [], disabled: false }, [
                Validators.required
            ])
        }),
        new FormGroup({
            entities: new FormGroup({}, [Validators.required]),
            userToApplySameCheckbox: new FormGroup({})
        })
    ]);
    saveInProgress: boolean = false;

    get currentAditionalStep(): number {
        return this._currentAditionalStep;
    }
    set currentAditionalStep(value: number) {
        this._currentAditionalStep = value;
        this.usersInView.forEach((user, index) => user.isCurrent = this.currentAditionalStep === index);
    }
    private _currentAditionalStep = 0;
    private readonly MAX_USERS_LENGTH: number = 100000;
    private isInternal: boolean;

    private destroyed$ = new Subject<boolean>();

    constructor(private actionsListener$: ActionsSubject, private store$: Store, private translate: TranslateService) { }

    ngOnInit(): void {
        this.store$.select(selectIsInternal).pipe(take(1)).subscribe((isInternal) => {
            this.isInternal = isInternal;
            this.initialize();
        });
    }

    getStepForm(index: number): FormGroup {
        return this.form.at(index) as FormGroup;
    }

    setStep(index: number): void {
        this.newUserStepsPayload.forEach((step, i) => {
            step.isActive = i === index;
            step.isVisited = i < index;
        });
    }

    onPrevious(): void {
        if (this.isInlastStep && this.currentAditionalStep !== 0) {
            this.setReadyToSave(false);
            if (this.currentAditionalStep > 0) {
                this.moveBackwards();
            } else {
                this.currentAditionalStep = this.totalAditionalSteps;
            }
        } else {
            this.setStep(this.activeStep - 1);
        }
    }

    onNext(): void {
        if (this.isInternal) {
            this.save();
        } else {
            if (!this.isInlastStep) {
                this.setStep(this.activeStep + 1);
            } else {
                !this.isReadyToSave ? this.moveForward() : this.save();
            }
        }
    }

    closeWizardModal(userdAdded: boolean = false): void {
        this.setStep(0);
        this.store$.dispatch(AddUserRoleModalAction({ value: false }));
        this.store$.dispatch(clearAllData());
        this.usersAdded.emit(userdAdded);
    }

    onCurrentUserChanged(userId: string): void {
        this.usersInView.forEach((user, index) => {
            const hasMatch = user.id === userId;
            if (hasMatch) {
                this.setReadyToSave(false);
                this.currentAditionalStep = index;
            }
            user.isCurrent = hasMatch;
        });
    }

    openAddNewUserModal(): void {
        this.closeWizardModal();
        this.store$.dispatch(userAddUserModalAction({ value: true }));
    }

    ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private initialize(): void {
        this.newUserStepsPayload = getNewUserRoleStepsPayload(this.isInternal);
        this.wizardConfig = setWizardConfig(this.translate, this.isInternal);
        this.store$.dispatch(
            userManagementInitiateAction({
                controlId: '',
                pageSize: this.MAX_USERS_LENGTH
            })
        );
        this.subscribeSelectedEntities();
        this.subscribeUserChanges();
    }

    private subscribeUserChanges(): void {
        this.selectedUsers.valueChanges
            .pipe(takeUntil(this.destroyed$))
            .subscribe((users) => {
                this.usersInView = users.map((user, index) => ({ ...user, isCurrent: index === 0 })) as Array<InputMultiselectUser>;
                Object.keys(this.groupedEntities.controls).forEach((key) => {
                    if (!users.find((user) => user.id === key)) {
                        this.groupedEntities.removeControl(key);
                        this.store$.dispatch(clearRoleSelectedEntities({ role: key }));
                    }
                });
                users.forEach((user, index) => {
                    if (!this.groupedEntities.get(user.id)) {
                        this.groupedEntities.addControl(user.id, new FormControl([], { validators: [Validators.required] }));
                    }
                    if (index === 0) {
                        Object.keys(this.userToApplySameCheckboxFormGroup.controls).forEach((key) => {
                            this.userToApplySameCheckboxFormGroup.removeControl(key);
                        });
                        if (users.length > 1) {
                            this.userToApplySameCheckboxFormGroup.addControl(user.id, new FormControl(false));
                        }
                    }
                });
                this.setReadyToSave(false);
                this.totalAditionalSteps = users.length - 1;
                this.currentAditionalStep = 0;
            });
    }

    private subscribeSelectedEntities(): void {
        this.selectedEntities$
            .pipe(takeUntil(this.destroyed$))
            .subscribe((selectedEntities) => {
                if (isEmpty(selectedEntities)) {
                    return;
                }
                Object.entries(selectedEntities).forEach(([key, value]) => {
                    this.groupedEntities
                        .get(key)
                        .patchValue(value, { emitEvent: true });
                });
            });
    }

    private moveForward(): void {
        this.assignSameEntitiesToUsers();
        if (this.form.valid && !this.isReadyToSave) {
            this.setReadyToSave(true);
        }
        if (this.currentAditionalStep === this.totalAditionalSteps || this.currentAditionalStep < 0) {
            return;
        }
        ++this.currentAditionalStep;
    }

    private moveBackwards(): void {
        if (!this.currentAditionalStep) {
            return;
        }
        --this.currentAditionalStep;
    }

    private assignSameEntitiesToUsers(): void {
        if (this.currentAditionalStep !== 0) {
            return;
        }
        const firstUser = this.selectedUsers?.value?.[this.currentAditionalStep];
        const checkboxControl = this.userToApplySameCheckboxFormGroup.get(firstUser?.id);
        if (checkboxControl?.value) {
            const firstUserEntities = this.groupedEntities.get(firstUser.id).value;
            Object.keys(this.groupedEntities.controls).forEach((key) => {
                this.groupedEntities.get(key).setValue([...firstUserEntities]);
            });
            const selectEntitiesValue = { ...this.groupedEntities.value };
            this.store$.dispatch(clearSelectedEntities());
            this.store$.dispatch(selectEntities({ payload: selectEntitiesValue }));
            this.setReadyToSave(this.form.valid);
        }
    }

    private setReadyToSave(readyToSaveValue: boolean): void {
        if (this.isInternal) {
            return;
        }
        const newConfig = setWizardConfig(this.translate);
        if (readyToSaveValue) {
            newConfig.steps[1].nextLabel = 'Add';
            this.currentAditionalStep = -1;
        }
        this.wizardConfig = newConfig;
        this.isReadyToSave = readyToSaveValue;
    }

    private save(): void {
        this.saveInProgress = true;
        const userIdToEntityGroups = this.getStepForm(1).value.entities;
        this.subscribeEntitiesAssignedState();
        this.store$.dispatch(roleManagementUsersRoleEntitiesAssignAction({
            roleId: +this.roleId,
            userIdToEntityGroups
        }));
    }

    private subscribeEntitiesAssignedState(): void {
        this.actionsListener$
            .pipe(
                ofType(
                    roleManagementUsersRoleEntitiesAssignSuccessAction,
                    roleManagementUsersRoleEntitiesAssignFailureAction
                ),
                take(1)
            )
            .subscribe((result) => {
                this.saveInProgress = false;
                if (!(result as any).errorMessage) {
                    this.closeWizardModal(true);
                }
            });
    }
}
