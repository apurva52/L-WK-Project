import { AgGridModule } from '@ag-grid-community/angular';
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { NewRoleInfoComponent } from '../../../new-role-info/new-role-info.component';
import { NewRoleModulesInfoComponent } from '../../../new-role-modules-info/new-role-modules-info.component';

import { Step2RoleInfoComponent } from './step-2-role-info.component';

describe('Step2RoleInfoComponent', () => {
    let component: Step2RoleInfoComponent;
    let fixture: ComponentFixture<Step2RoleInfoComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                Step2RoleInfoComponent,
                NewRoleInfoComponent,
                NewRoleModulesInfoComponent
            ],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    }
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(Step2RoleInfoComponent);
        component = fixture.componentInstance;
        component.stepForm = new FormGroup({
            role_name: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            role_color: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            created_by_name: new FormControl({ value: '', disabled: false }),
            created_date: new FormControl({ value: '', disabled: false })
        });
        component.modulesForm = new FormGroup({
            modules: new FormControl({ value: {}, disabled: false }),
            sub_modules: new FormControl({ value: {}, disabled: false }),
            module_sections: new FormControl({ value: {}, disabled: false }),
            restricted_association_groups_ids: new FormControl({
                value: [],
                disabled: false
            })
        });
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('form should be reset', () => {
        spyOn(component.stepForm, 'reset');
        component['resetForm']();
        expect(component.stepForm.reset).toHaveBeenCalled();
    });
});
