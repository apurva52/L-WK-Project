import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';
import { StoreModule } from '@ngrx/store';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { Step2RoleUserComponent } from './step-2-add-user-details.component';

describe('Step2UserDetailsComponent', () => {
    let component: Step2RoleUserComponent;
    let fixture: ComponentFixture<Step2RoleUserComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [Step2RoleUserComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                StoreModule.forRoot({}),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    }
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        const mockForm = new FormGroup({
            users: new FormControl({ value: [], disabled: false }, [
                Validators.required
            ])
        });
        fixture = TestBed.createComponent(Step2RoleUserComponent);
        component = fixture.componentInstance;
        component.stepForm = mockForm;
        component.selectedUsersForm = mockForm;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should create and load users for multiselect', () => {
        const user = { id: '9', label: 'Affiliate', isSelected: true };
        component.stepForm = new FormGroup({
            entities: new FormGroup({
                '9': new FormControl({ value: '' }, [Validators.required])
            })
        });

        component.selectedUsersForm = new FormGroup({
            users: new FormControl({ value: [], disabled: false }, [
                Validators.required
            ])
        });

        component.selectedUsersForm.setValue({
            users: [user]
        });

        component.currentUser = { ...user, isCurrent: true };

        expect(component).toBeTruthy();
        expect(component.selectedUsersForm.value.users.length).toEqual(1);
        expect(component.formEntitiesGroup.get('9')).toBeTruthy();
    });

    it('should call onToggleAccordion', () => {
        spyOn(component.currentUserChanged, 'emit');
        component.currentUser = {
            id: '1',
            label: 'User 1',
            isSelected: true,
            isCurrent: false
        };
        component.onToggleAccordion('1');
        component.onToggleAccordion('2');
        expect(component.currentUserChanged.emit).toHaveBeenCalled();
    });

    it('should call onToggleAccordion and break', () => {
        spyOn(component.currentUserChanged, 'emit');
        component.currentUser = {
            id: '1',
            label: 'User 1',
            isSelected: true,
            isCurrent: false
        };
        component.onToggleAccordion('1');
        expect(component.currentUserChanged.emit).not.toHaveBeenCalled();
    });

    it('should get pillLabel from selected users', () => {
        const users: Array<InputMultiselectItem> = [
            {
                label: 'User 1',
                id: '1',
                isSelected: true
            },
            {
                label: 'User 2',
                id: '1',
                isSelected: true
            }
        ];
        component.selectedUsersForm = new FormGroup({
            users: new FormControl(users)
        });
        expect(component.pillLabel).toEqual('User 1, User 2');
    });
});
