export enum CreateRoleActionType {
    CREATE_NEW_ROLE = '1',
    COPY_AND_CREATE_NEW_ROLE = '2'
}
