/* tslint:disable:max-file-line-count */
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { selectUserTokenPayload } from '../../../../../../../app/state/app.selectors';

import { Step1RoleInfoComponent } from './components/step-1-role-info/step-1-role-info.component';
import { CreateNewRoleWizardComponent } from './create-new-role-wizard.component';

describe('CreateNewRoleWizardComponent', () => {
    let component: CreateNewRoleWizardComponent;
    let fixture: ComponentFixture<CreateNewRoleWizardComponent>;


    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                CreateNewRoleWizardComponent,
                Step1RoleInfoComponent
            ],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    },
                    selectors: [
                        {
                            selector: selectUserTokenPayload,
                            value: { name: 'user' }
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CreateNewRoleWizardComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should navigate to previous step', () => {
        component.setStep(1);
        component.onPrevious();
        fixture.detectChanges();
        expect(component.activeStep).toEqual(0);
    });

    it('should navigate to next step', () => {
        component.setStep(0);
        component['goToNext']();
        fixture.detectChanges();
        expect(component.activeStep).toEqual(1);
    });

    it('should dispatch action when navigate to second step', () => {
        const storeSpy = spyOn((component as any).store$, 'dispatch');
        component.setStep(0);
        component.onNext();
        fixture.detectChanges();
        expect(component.isCheckingDuplicate).toEqual(true);
        expect(storeSpy).toHaveBeenCalled();
    });

    it('should dispatch action when save role', () => {
        const storeSpy = spyOn((component as any).store$, 'dispatch');
        component.setStep(1);
        component.onNext();
        fixture.detectChanges();
        expect(storeSpy).toHaveBeenCalled();
    });

    it('should get child form from state', () => {
        expect(component.getStepForm(0)).toBeDefined();
    });

    it('should validate if current form is valid', () => {
        component.setStep(0);
        component.getStepForm(0).patchValue({
            role_name: 'Test role name',
            role_color: '#007AC3',
            created_by_name: 'John Smith',
            created_date: new Date()
        });
        expect(component.isCurrentFormValid).toBeTruthy();
    });

    it('should close wizard modal', () => {
        spyOn(component.cancel, 'emit');
        component.closeWizardModal();
        expect(component.cancel.emit).toHaveBeenCalled();
    });

    it('should allow to launch or not the confirmation modal cancel', () => {
        component.confirmCloseModal();
        fixture.detectChanges();
        expect(component.isCancelNotificationVisible).toEqual(true);

        component.roleSaved = true;
        component.setStep(1);
        component.confirmCloseModal({ isCloseButtonClick: true });
        fixture.detectChanges();
        expect(component.isCancelNotificationVisible).toEqual(false);

        component.confirmCloseModal();
        fixture.detectChanges();
        expect(component.isCancelNotificationVisible).toEqual(false);
    });
    it('should hide confirmation popup on step 0 if data is not filled', () => {
        component.setStep(0);
        component.getStepForm(0).patchValue({
            role_name: 'Test role name',
            role_color: '#007AC3',
            created_by_name: 'John Smith',
            created_date: new Date()
        });
        expect(component.isCancelNotificationVisible).toEqual(false);
    });

    it('should dispatch next event', () => {
        const nextEventSpy = spyOn(component.nextEvent, 'emit');
        const expectedCallsCount = 1;
        const selectUsersStepNumber = 2;
        const selectAssociateEntititesStepNumber = 3;
        const users = [
            {
                contact_id: '1',
                sf_contact_id: '1',
                contact_name: '1',
                email: '1',
                roles: []
            },
            {
                contact_id: '2',
                sf_contact_id: '2',
                contact_name: '2',
                email: '2',
                roles: []
            }
        ];

        component.setStep(1);
        component.roleSaved = true;
        component.onNext();
        expect(component.activeStep).toEqual(selectUsersStepNumber);

        component.getStepForm(selectUsersStepNumber).setValue({ users });
        component.onNext();
        expect(component.activeStep).toEqual(
            selectAssociateEntititesStepNumber
        );

        component.onNext();
        expect(component.activeStep).toEqual(
            selectAssociateEntititesStepNumber
        );

        component
            .getStepForm(selectAssociateEntititesStepNumber)
            .controls.activeAccordion.setValue(users.length - 1);
        component.onNext();
        expect(nextEventSpy).toHaveBeenCalledTimes(expectedCallsCount);
    });

    it('should navigate to previous step and role is saved', () => {
        component.newRoleStepsPayload.push({
            isActive: true,
            isVisited: true,
            stepId: 3,
            description: '',
            isFailed: false
        });
        component.setStep(2);
        component.roleSaved = true;
        component.onPrevious();
        fixture.detectChanges();
        expect(component.wizardConfig.cancelText).toEqual(
            'userRolesModule.newRoleWizardComponent.noLabel'
        );
    });
    it('should call onChangeHandle as false', () => {
        component.onChangeHandler(false);
        fixture.detectChanges();
        expect(component.isCheckingDuplicate).toEqual(false);
    });
    it('should call onChangeHandler', () => {
        component.onChangeHandler(true);
        fixture.detectChanges();
        expect(component.isCheckingDuplicate).toEqual(true);
    });

    it('should apply same entities for all selected users', () => {
        const selectUsersStepNumber = 2;
        const selectAssociateEntititesStepNumber = 3;
        const users = [
            {
                id: '1',
                label: 'Test user 1',
                isSelected: true
            },
            {
                id: '2',
                label: 'Test user 2',
                isSelected: true
            }
        ];
        const entities = [
            {
                edh_entity_group_id: 1,
                edh_entity_group_guid: '1',
                edh_entity_group_name: 'Group 1',
                edh_entity_group_type: 'I',
                entities: [
                    {
                        entity_id: 1,
                        entity_guid: '1',
                        entity_name: 'Entity 1',
                        entity_country: 'Test',
                        domestic_jurisdiction: 'Test'
                    }
                ]
            }
        ];

        component.getStepForm(0).patchValue({
            role_name: 'Test role name',
            role_color: '#007AC3',
            created_by_name: 'John Smith',
            created_date: new Date()
        });
        const role_id = 123;
        component
            .getStepForm(0)
            .addControl('role_id', new FormControl(role_id));

        component.setStep(1);
        component.roleSaved = true;
        component.onNext();
        expect(component.activeStep).toEqual(selectUsersStepNumber);

        component
            .getStepForm(selectUsersStepNumber)
            .controls.users.setValue(users);
        component.onNext();
        expect(component.activeStep).toEqual(
            selectAssociateEntititesStepNumber
        );

        const userEntitiesFormGroup = component.getStepForm(
            selectAssociateEntititesStepNumber
        ).controls.userEntities as FormGroup;
        const userToApplySameCheckboxFromGroup = component.getStepForm(
            selectAssociateEntititesStepNumber
        ).controls.userToApplySameCheckbox as FormGroup;
        users.forEach((user, index) =>
            userEntitiesFormGroup.addControl(
                user.id,
                new FormControl(index === 0 ? entities : [])
            )
        );
        userToApplySameCheckboxFromGroup.addControl(
            users[0].id,
            new FormControl(true)
        );

        const storeDispatchSpy = spyOn((component as any).store$, 'dispatch');

        component
            .getStepForm(selectAssociateEntititesStepNumber)
            .controls.activeAccordion.setValue(-1);
        component.onNext();

        component
            .getStepForm(selectAssociateEntititesStepNumber)
            .controls.activeAccordion.setValue(0);
        component.onNext();

        Object.keys(userEntitiesFormGroup.controls).forEach((key) => {
            expect(userEntitiesFormGroup.controls[key].value).toEqual(entities);
        });
        expect(storeDispatchSpy).toHaveBeenCalledTimes(1);
    });

    it('should save an Internal role', () => {
        const storeSpy = spyOn((component as any).store$, 'dispatch');
        component.isInternal = true;
        component['saveRole']();
        expect(component.roleType).toBe('I');
        expect(storeSpy).toHaveBeenCalledWith(jasmine.objectContaining({data: jasmine.objectContaining({type: 'I'})}));
    });
});
