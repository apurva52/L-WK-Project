import { WizardConfiguration } from '@ct/platform-primitives-uicomponents/modals';
import { Step } from '@ct/platform-primitives-uicomponents/primitives';
import { TranslateService } from '@ngx-translate/core';

export function getNewUserRoleStepsPayload(isInternal: boolean = false): Array<Step> {
    if (isInternal) {
        return [];
    }
    return [
        {
            isActive: true,
            isFailed: false,
            isVisited: false,
            stepId: 1,
            description: ''
        },
        {
            isActive: false,
            isFailed: false,
            isVisited: false,
            stepId: 2,
            description: ''
        }
    ];
}

export function setWizardConfig(
    translate: TranslateService,
    isInternal: boolean = false
): WizardConfiguration {
    const config = {
        label: translate.instant(
            'userRolesModule.AddNewUserRoleComponent.title'
        ),
        cancelText: translate.instant(
            'userRolesModule.newUserComponent.cancelLbl'
        ),
        cancelToRight: true,
        headerDivider: false,
        steps: [
            {
                nextLabel: translate.instant(
                    'userRolesModule.AddNewUserRoleComponent.assignButton'
                ),
                title: translate.instant(
                    'userRolesModule.AddNewUserRoleComponent.stepTitle'
                ),
                validation: false,
                previousLabel: translate.instant(
                    'userRolesModule.newUserComponent.previousLbl'
                )
            }
        ]
    };
    if (!isInternal) {
        config.steps[0].nextLabel = translate.instant(
            'userRolesModule.newUserComponent.nextLbl'
        );
        config.steps.push({
            nextLabel: translate.instant(
                'userRolesModule.assingRolesComponent.nextLbl'
            ),
            title: translate.instant(
                'userRolesModule.AddNewUserRoleComponent.associateEntitiesToUserRoleComponent.stepTitle'
            ),
            validation: false,
            previousLabel: translate.instant(
                'userRolesModule.newUserComponent.previousLbl'
            )
        });
    }
    return config;
}
