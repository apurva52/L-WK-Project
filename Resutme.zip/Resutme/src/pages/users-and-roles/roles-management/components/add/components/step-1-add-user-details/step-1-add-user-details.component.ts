import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { createLevel } from 'src/shared/config/claims.config';
import { ModulePermissionsService } from 'src/shared/services/module-permissions/module-permissions.service';

import { clearUserSelectedEntities } from '../../../../../../../features/entity-selector/state/entity-selector.actions';
import {
    selectedActiveUsersForMultiSelect,
    selectTotalUsersState,
    selectUserRolesLoadingState
} from '../../../../../../../pages/users-and-roles/users-management/state/user-management.selectors';
import { StepComponent } from '../../interfaces/step-component.model';

import { userManagementGetResetAction, userManagementInitiateAction } from './../../../../../users-management/state/user-management.actions';

@Component({
    selector: 'ct-step-1-add-user-details',
    templateUrl: './step-1-add-user-details.component.html',
    styleUrls: ['./step-1-add-user-details.component.scss']
})
export class Step1RoleUserComponent extends StepComponent implements OnInit {

    get usersDataForMultiselect(): Array<InputMultiselectItem> {
        return this.stepForm?.value?.users;
    }
    @Input() stepForm: FormGroup;
    @Input() roleId: number;
    @Output() addNewUser: EventEmitter<void> = new EventEmitter();
    userHasCreatePermission =
        this.modulePermissionsService.doesUserHasPermission(createLevel);
    usersForMultiSelect$: Observable<Array<InputMultiselectItem>>;
    usersLoading$: Observable<boolean> = this.store$.select(
        selectUserRolesLoadingState
    );
    totalUsers$: Observable<number> = this.store$.select(
        selectTotalUsersState
    );
    currentDropdownPage: number = 1;
    private readonly DROPDOWN_PAGE_SIZE: number = 40;

    constructor(
        public store$: Store,
        private modulePermissionsService: ModulePermissionsService
    ) {
        super();
    }
    ngOnInit(): void {
        this.store$.dispatch(userManagementGetResetAction());
        this.loadUsers(this.currentDropdownPage);
        this.updateUsersSelector();
    }
    removeUsers(id: string): void {
        const users = this.stepForm.value.users.filter(
            (users) => users.id != id
        );
        this.stepForm.patchValue({ users });
        this.store$.dispatch(clearUserSelectedEntities({ user: id }));
        this.updateUsersSelector();
    }

    loadUsers(currentPage: number): void {
        this.store$.dispatch(userManagementInitiateAction({ controlId: '', pageNumber: currentPage, pageSize: this.DROPDOWN_PAGE_SIZE }));
    }
    loadMoreUsers(): void {
        this.currentDropdownPage++;
        this.loadUsers(this.currentDropdownPage);
    }

    private updateUsersSelector(): void {
        this.usersForMultiSelect$ = this.store$.select(
            selectedActiveUsersForMultiSelect(
                this.usersDataForMultiselect || [],
                this.roleId
            )
        );
    }
}
