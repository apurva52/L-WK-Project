import {
    Component,
    ElementRef,
    EventEmitter,
    Input,
    OnDestroy,
    OnInit,
    Output,
    ViewChild
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { selectedDuplicateCheckState } from '../../../../../../state/role-management.selectors';
import { StepComponent } from '../../../../interfaces/step-component.model';

@Component({
    selector: 'ct-step-1-role-info',
    templateUrl: './step-1-role-info.component.html',
    styleUrls: ['./step-1-role-info.component.scss']
})
export class Step1RoleInfoComponent
    extends StepComponent
    implements OnInit, OnDestroy
{
    @Input() stepForm: FormGroup;
    @Input() showErrorMessage: boolean;
    @Output() showErrorOnChange = new EventEmitter<boolean>();
    @ViewChild('avatarContainer') avatarContainer: ElementRef;

    selectDuplicateRoleName$ = this.store$.select(selectedDuplicateCheckState);
    createdBy: string;
    private _destroyed$: Subject<boolean> = new Subject<boolean>();
    constructor(public store$: Store) {
        super();
    }

    ngOnInit(): void {
        this.showErrorMessage = false;
        if (!this.getFormControl('role_name').value) {
            this.getFormControl('role_color').disable();
        }
        this.getFormControl('role_name')
            .valueChanges.pipe(takeUntil(this._destroyed$))
            .subscribe((value) => {
                if (value) {
                    this.getFormControl('role_color').enable();
                } else {
                    this.getFormControl('role_color').disable();
                }
                if (value.startsWith(' ')) {
                    this.getFormControl('role_name').setValue(value.trimStart());
                }
            });
        this.createdBy = this.getFormControl('created_by_name').value || '';
    }

    onChangeHandler($event): void {
        this.showErrorOnChange.emit(this.showErrorMessage);
    }

    ngOnDestroy(): void {
        this._destroyed$.next();
        this._destroyed$.complete();
    }

    roleNameChanged(): void {
        const roleNameValue = this.getFormControl('role_name').value;
        if (roleNameValue.endsWith(' ')) {
            this.getFormControl('role_name').setValue(roleNameValue.trimEnd());
        }
    }
}
