import { Component, Input, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import {
    InputMultiselectItem
} from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { take } from 'rxjs/operators';
import {
    roleManagementLoadUsersForMultiselectAction,
    roleManagementLoadUsersForMultiselectFailureAction,
    roleManagementLoadUsersForMultiselectSuccessAction
} from 'src/pages/users-and-roles/roles-management/state/role-management.actions';
import { User } from 'src/pages/users-and-roles/users-management/interfaces/user.model';

@Component({
    selector: 'ct-new-role-users-multiselect',
    templateUrl: './new-role-users-multiselect.component.html',
    styleUrls: ['./new-role-users-multiselect.component.scss']
})
export class NewRoleUsersMultiselectComponent implements OnInit {
    get selectedUsers(): Array<InputMultiselectItem> {
        return this.usersFormControl.value || [];
    }
    @Input() usersFormControl: FormControl;
    usersForMultiSelect: Array<InputMultiselectItem> = [];
    private loadedUsers: Array<User> = [];

    constructor(private store$: Store,
        private actionsListener$: ActionsSubject) { }

    ngOnInit(): void {
        this.loadUsers();
    }

    removeUsers(id: string): void {
        const users = this.selectedUsers.filter(user => (user.id != id));
        this.usersFormControl.patchValue(users);
        this.updateUsersSelector();
    }

    private loadUsers(): void {
        this.subscribeUsersForMultiselectLoadedState();
        this.store$.dispatch(roleManagementLoadUsersForMultiselectAction());
    }

    private subscribeUsersForMultiselectLoadedState(): void {
        this.actionsListener$
            .pipe(
                ofType(
                    roleManagementLoadUsersForMultiselectSuccessAction,
                    roleManagementLoadUsersForMultiselectFailureAction
                ),
                take(1)
            )
            .subscribe((result) => {
                this.loadedUsers = (result as any)?.users || [];
                this.updateUsersSelector();
            });
    }

    private updateUsersSelector(): void {
        this.usersForMultiSelect = this.loadedUsers.map((user) => ({
            id: user.sf_contact_id,
            label: user.contact_name,
            isSelected: this.selectedUsers.some(selectedUser => selectedUser.id === user.sf_contact_id)
        }));
    }
}