import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { SelectedEvent } from '@ct/platform-common-uicomponents/entities-grids/shared/interfaces/selected-event.interface';
import { NotificationType } from '@ct/platform-primitives-uicomponents/primitives';
import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { USER_TO_ROLE_SEPARATOR } from 'src/pages/users-and-roles/roles-management/interfaces/role-management.params';

import {
    clearRoleSelectedEntities,
    entitySelectorChangeStatus,
    selectEntities
} from '../../../../../../../../../features/entity-selector/state/entity-selector.actions';
import { getRoleSelectedEntities } from '../../../../../../../../../features/entity-selector/state/entity-selector.selectors';
import { RoleDetails } from '../../../../../../../../../pages/users-and-roles/roles-management/details/state/role-details.state';
import { roleManagementGetRoleDetailsSuccessAction } from '../../../../../../../../../pages/users-and-roles/roles-management/state/role-management.actions';
import { roleDetailsState } from '../../../../../../../../../pages/users-and-roles/roles-management/state/role-management.selectors';
import { EntityGroup } from '../../../../../../../../../pages/users-and-roles/users-management/details/components/entities-from-role-grid/interfaces/entity-group';
import { AccordionTypes } from '../../../../../../../../../shared/interfaces/accordion-types-enum';

@Component({
    selector: 'ct-new-role-user-entities-associate',
    templateUrl: './new-role-user-entities-associate.component.html',
    styleUrls: ['./new-role-user-entities-associate.component.scss']
})
export class NewRoleUserEntitiesAssociateComponent implements OnInit {
    readonly NotificationType = NotificationType;

    @Input() isActive: boolean;
    @Input() showActiveWhenOpen: boolean;
    @Input() title: string;
    @Input() user: InputMultiselectItem;
    @Input() roleId: number;
    @Input() userEntitiesFormControl: FormControl;
    @Input() applySameForAllUsersFormControl: FormControl;
    @Input() applySameForAllCheckboxVisible: boolean = true;
    @Input() rolePermissions$: Observable<RoleDetails>;

    @Output() toggleEvent: EventEmitter<void> = new EventEmitter<void>();

    isAddEntitiesActivated: boolean = false;

    get headerType(): string {
        return this.isActive
            ? AccordionTypes.Expanded
            : AccordionTypes.Disabled;
    }

    get selectedEntititesKey(): string {
        return this.user ? `${this.user.id}${USER_TO_ROLE_SEPARATOR}${this.roleId}` : `${this.roleId}`;
    }

    initialGridData: Array<EntityGroup> = [];

    isRemoveEntitiesNotificationVisible = false;
    removeEntitiesNotificationModel = {
        title: this.translate.instant('entitiesGrid.unassignEntityWarning.title'),
        content: this.translate.instant('entitiesGrid.unassignEntityWarning.content'),
        confirmationText: this.translate.instant('entitiesGrid.unassignEntityWarning.confirmationText'),
        cancelationText: this.translate.instant('entitiesGrid.unassignEntityWarning.cancelationText')
    };

    bulkOptions = [
        {
            name: this.translate.instant('entitiesGrid.unassignActionButtonLabel'),
            icon: 'wk-icon-trash',
            handler: () => this.isRemoveEntitiesNotificationVisible = true,
            action: () => this.isRemoveEntitiesNotificationVisible = true
        }
    ];

    private checkedItems = [];
    private destroyed$: Subject<boolean> = new Subject<boolean>();
    private selectedItems$: Observable<Array<EntityGroup>>;

    constructor(
        private store$: Store,
        private actionsListener$: ActionsSubject,
        private translate: TranslateService
    ) {}

    ngOnInit(): void {
        this.selectedItems$ = this.store$.select(getRoleSelectedEntities, {
            role: this.selectedEntititesKey
        });
        this.actionsListener$
            .pipe(
                ofType(roleManagementGetRoleDetailsSuccessAction),
                takeUntil(this.destroyed$)
            )
            .subscribe(() => {
                this.store$.select(roleDetailsState).subscribe((data) => {
                    if (data) {
                        this.rolePermissions$ =
                            this.store$.select(roleDetailsState);
                    }
                });
            });
        this.initGridData();
    }

    ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    onToggleAccordion(): void {
        this.toggleEvent.emit();
    }

    onAddEntity(): void {
        this.isAddEntitiesActivated = true;
        this.store$.dispatch(entitySelectorChangeStatus({ open: true }));
    }

    onAddEntityCompleted(event): void {
        this.isAddEntitiesActivated = false;
        this.addEntities(event);
    }

    onAddEntityCanceled(): void {
        this.isAddEntitiesActivated = false;
    }

    onApplySameForAllChange(event): void {
        const value = event?.target?.checked;
        if (this.applySameForAllUsersFormControl) {
            this.applySameForAllUsersFormControl.setValue(value);
        }
    }

    onConfirmRemoveEntitiesNotification(): void {
        this.isRemoveEntitiesNotificationVisible = false;
        this.removeCheckedItems();
    }

    onCancelRemoveEntitiesNotification(): void {
        this.isRemoveEntitiesNotificationVisible = false;
    }

    onCheckedEntitiesChange(event: SelectedEvent): void {
        this.checkedItems = event.selected;
    }

    onCheckedEntitiesCleared(): void {
        this.checkedItems = [];
        this.isRemoveEntitiesNotificationVisible = false;
    }

    private initGridData(): void {
        this.selectedItems$
            .pipe(takeUntil(this.destroyed$))
            .subscribe((selected) => {
                const data = Array.isArray(selected) ? selected : [];
                this.userEntitiesFormControl.setValue(data);
                this.initialGridData = data;
            });
    }

    private addEntities(data: Array<EntityGroup>): void {
        this.store$.dispatch(
            selectEntities({ payload: { [this.selectedEntititesKey]: data } })
        );
        if (this.applySameForAllUsersFormControl) {
            this.applySameForAllUsersFormControl.setValue(false);
            this.applySameForAllUsersFormControl.enable();
        }
    }

    private removeCheckedItems(): void {
        let groups: Array<EntityGroup> = [...this.userEntitiesFormControl.value];
        this.checkedItems.forEach((checkedItem) => {
            if (checkedItem.is_group) {
                groups = groups.filter((group) => group.edh_entity_group_id !== checkedItem.entity_group.edh_entity_group_id);
            } else {
                const foundGroup = groups.find((group) => group.edh_entity_group_id === checkedItem.entity_group.edh_entity_group_id);
                if (foundGroup) {
                    foundGroup.entities = foundGroup.entities.filter((entity) => entity.entity_id !== checkedItem.entity_id);
                }
            }
        });
        this.store$.dispatch(clearRoleSelectedEntities({ role: this.selectedEntititesKey }));
        this.addEntities(groups);
    }
}
