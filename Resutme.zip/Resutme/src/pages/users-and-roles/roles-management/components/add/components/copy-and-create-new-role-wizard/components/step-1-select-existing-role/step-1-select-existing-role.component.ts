import {
    Component,
    EventEmitter,
    Input,
    OnDestroy,
    OnInit,
    Output
} from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';

import {
    roleManagementCheckPreviousButtonAction,
    roleManagementGetRoleDetailsAction
} from '../../../../../../state/role-management.actions';
import {
    addNewRoleModalSettings,
    isBackCheckState,
    rolesForSelectState,
    selectedDuplicateCheckState
} from '../../../../../../state/role-management.selectors';
import { StepComponent } from '../../../../interfaces/step-component.model';

@Component({
    selector: 'ct-step-1-select-existing-role',
    templateUrl: './step-1-select-existing-role.component.html',
    styleUrls: ['./step-1-select-existing-role.component.scss']
})
export class Step1SelectExistingRoleComponent
    extends StepComponent
    implements OnInit, OnDestroy
{
    @Input() stepForm: FormGroup;
    @Input() showErrorMessage: boolean;
    @Output() showErrorOnChange = new EventEmitter<boolean>();

    roleId: number;
    isBack: boolean;
    rolesForSelect: Array<{ name: string; id: number }>;
    selectDuplicateRoleName$ = this.store$.select(selectedDuplicateCheckState);
    checkBackAction$ = this.store$
        .select(isBackCheckState)
        .subscribe((value) => {
            this.isBack = value;
        });

    constructor(private store$: Store) {
        super();
    }

    ngOnInit(): void {
        this.showErrorMessage = false;
        this.store$
            .select(rolesForSelectState)
            .subscribe(
                (rolesForSelect) => (this.rolesForSelect = rolesForSelect)
            )
            .unsubscribe();
        this.addSubscription(
            this.store$
                .select(addNewRoleModalSettings)
                .subscribe((settings) => {
                    if (settings?.existingRole) {
                        this.rolesForSelect = [settings.existingRole];
                        this.existingRoleControl.setValue(
                            settings.existingRole.id
                        );
                        this.existingRoleControl.disable();
                    }
                })
        );
        this.addSubscription(this.roleNameControl.valueChanges.subscribe((value) => {
            if (value.startsWith(' ')) {
                this.roleNameControl.setValue(value.trimStart());
            }
        }));
    }

    existingRoleChanged(roleId: string): void {
        this.store$.dispatch(
            roleManagementGetRoleDetailsAction({
                roleId: parseInt(roleId)
            })
        );
        this.store$.dispatch(
            roleManagementCheckPreviousButtonAction({
                isBack: false
            })
        );
    }

    onChangeHandler($event): void {
        this.showErrorOnChange.emit(this.showErrorMessage);
    }

    ngOnDestroy(): void {
        this.removeAllSubscriptions();
    }

    get existingRoleControl(): FormControl {
        return this.getFormControl('existingRole');
    }
    get roleNameControl(): FormControl {
        return this.getFormControl('role');
    }
    get typeControl(): FormControl {
        return this.getFormControl('type');
    }
    get colorControl(): FormControl {
        return this.getFormControl('color');
    }

    roleNameChanged(): void {
        const roleNameValue = this.roleNameControl.value;
        if (roleNameValue.endsWith(' ')) {
            this.roleNameControl.setValue(roleNameValue.trimEnd());
        }
    }
}
