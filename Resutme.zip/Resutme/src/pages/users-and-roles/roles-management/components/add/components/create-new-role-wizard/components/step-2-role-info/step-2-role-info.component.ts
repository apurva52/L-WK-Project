import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { StepComponent } from '../../../../interfaces/step-component.model';

@Component({
    selector: 'ct-step-2-role-info',
    templateUrl: './step-2-role-info.component.html',
    styleUrls: ['./step-2-role-info.component.scss']
})
export class Step2RoleInfoComponent extends StepComponent {
    @Input() stepForm: FormGroup;
    @Input() modulesForm: FormGroup;
    @Input() roleSaved: boolean;

    constructor() {
        super();
    }
}
