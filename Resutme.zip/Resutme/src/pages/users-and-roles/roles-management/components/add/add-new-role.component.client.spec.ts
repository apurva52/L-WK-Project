import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';

import {
    addNewRoleModalSettings,
    isAddNewRoleModalVisible
} from '../../state/role-management.selectors';

import { AddNewRoleComponent } from './add-new-role.component';
import { CreateRoleActionType } from './components/interfaces/create-role-action-type.enum';

class FakeLoader implements TranslateLoader {
    getTranslation(_lang: string): Observable<any> {
        return of({});
    }
}

describe('AddNewRoleComponent', () => {
    let component: AddNewRoleComponent;
    let fixture: ComponentFixture<AddNewRoleComponent>;
    const addNewRoleModalSettingsMock = {
        createTypeToOpen: CreateRoleActionType.COPY_AND_CREATE_NEW_ROLE,
        existingRole: {
            name: '1',
            id: 1
        },
        callbackAction: jasmine.createSpy()
    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [AddNewRoleComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {},
                    selectors: [
                        { selector: isAddNewRoleModalVisible, value: true },
                        {
                            selector: addNewRoleModalSettings,
                            value: addNewRoleModalSettingsMock
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AddNewRoleComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should dispatch action to close the popup', () => {
        const dispatchSpy = spyOn(
            (component as any).store$,
            'dispatch'
        ).and.callThrough();
        component.onCancelModalClick();
        expect(dispatchSpy).toHaveBeenCalled();
    });

    it('should open wizard', () => {
        // initially wizard should not be shown
        expect(component.isWizardOpen).toEqual(false);
        // check that wizard is shown
        component.onConfirmModalClick(CreateRoleActionType.CREATE_NEW_ROLE);
        expect(component.createType).toEqual(
            CreateRoleActionType.CREATE_NEW_ROLE
        );
        expect(component.isWizardOpen).toEqual(true);
    });

    it('should close wizard', () => {
        const dispatchSpy = spyOn(
            (component as any).store$,
            'dispatch'
        ).and.callThrough();
        const expectedDispatchCalls = 2;
        component.isWizardOpen = true;
        component.onCancelWizardClick(true);
        expect(component.isWizardOpen).toEqual(false);
        expect(addNewRoleModalSettingsMock.callbackAction).toHaveBeenCalled();
        component.onCancelWizardClick(false);
        expect(component.isWizardOpen).toEqual(false);
        expect(dispatchSpy).toHaveBeenCalledTimes(expectedDispatchCalls);
    });
});
