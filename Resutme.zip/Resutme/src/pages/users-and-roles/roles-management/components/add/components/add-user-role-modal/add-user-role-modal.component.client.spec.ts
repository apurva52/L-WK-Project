/* tslint:disable:max-file-line-count */
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import {
    async,
    ComponentFixture,
    fakeAsync,
    TestBed,
    tick
} from '@angular/core/testing';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { initialAppState } from 'src/app/state/app.reducer';
import { selectIsInternal } from 'src/app/state/app.selectors';

import { AppState, USERS_PANEL_APP_FEATURE_KEY } from '../../../../../../../app/state/app.state';
import { getSelectedEntities } from '../../../../../../../features/entity-selector/state/entity-selector.selectors';
import { roleManagementUsersRoleEntitiesAssignSuccessAction } from '../../../../../../../pages/users-and-roles/roles-management/state/role-management.actions';
import { selectIsAddUserRoleModalVisible } from '../../../../../../../pages/users-and-roles/roles-management/state/role-management.selectors';
import { EntityGroup } from '../../../../../users-management/details/components/entities-from-role-grid/interfaces/entity-group';

import { AddUserRoleModalComponent } from './add-user-role-modal.component';

describe('AddUserRoleModalComponent', () => {
    let component: AddUserRoleModalComponent;
    let fixture: ComponentFixture<AddUserRoleModalComponent>;
    let debugElement: DebugElement;
    let store$: MockStore<AppState>;

    const mockUsers = [
        {
            id: '132',
            isSelected: true,
            label: 'User 1'
        },
        {
            id: '134',
            isSelected: true,
            label: 'User 3'
        }
    ];

    const mockEntityGroups: Array<EntityGroup> = [
        {
            entity_group_id: 1,
            edh_entity_group_id: 1,
            edh_entity_group_guid: '21a48570-362d-414d-a2f5-ddb0278c0b16',
            edh_entity_group_name: 'Group 100',
            edh_entity_group_type: 'C',
            entities: []
        }
    ];

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [AddUserRoleModalComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [USERS_PANEL_APP_FEATURE_KEY]: initialAppState
                    },
                    selectors: [
                        {
                            selector: selectIsAddUserRoleModalVisible,
                            value: true
                        },
                        {
                            selector: getSelectedEntities,
                            value: true
                        },
                        {
                            selector: selectIsInternal,
                            value: false
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store$ = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AddUserRoleModalComponent);
        debugElement = fixture.debugElement;
        component = fixture.componentInstance;
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should initialize', () => {
        component.ngOnInit();
        expect(component.newUserStepsPayload.length).toBeTruthy();
        expect(component.wizardConfig).toBeTruthy();
    });

    it('should validate if current form is valid', () => {
        component.setStep(0);
        component.getStepForm(0).patchValue({
            users: [{ label: 'ram', id: 2 }]
        });
        expect(component.isCurrentFormValid).toEqual(true);
    });

    it('should close wizard modal', () => {
        spyOn(component['store$'], 'dispatch');
        const closeSpy = spyOn(component, 'closeWizardModal').and.callThrough();
        component.closeWizardModal();
        expect(component['store$'].dispatch).toHaveBeenCalled();
        expect(closeSpy).toHaveBeenCalled();
    });

    xit('should launch modal confirmation for cancel action', fakeAsync(() => {
        fixture.detectChanges();
        const cancelBtn: HTMLElement = debugElement.nativeElement.querySelector(
            'button#cancel-wizard'
        );
        const closeBtn: HTMLElement = debugElement.nativeElement.querySelector(
            'span.wk-icon-filled-close'
        );
        cancelBtn.click();
        tick();

        fixture.whenStable().then(() => {
            expect(component.isCancelNotificationVisible).toEqual(true);
        });

        component.isCancelNotificationVisible = false;
        closeBtn.click();
        tick();

        fixture.whenStable().then(() => {
            expect(component.isCancelNotificationVisible).toEqual(true);
        });
    }));

    describe('Step 2', () => {
        beforeEach(() => {
            component.form = new FormArray([
                new FormGroup({
                    users: new FormControl([mockUsers], [Validators.required])
                }),
                new FormGroup({
                    entities: new FormGroup(
                        {
                            '134': new FormControl([], [Validators.required])
                        },
                        [Validators.required]
                    ),
                    userToApplySameCheckbox: new FormGroup({})
                })
            ]);

            fixture.detectChanges();
        });

        it('should move forward', () => {
            const nextStep = 1;
            component.newUserStepsPayload = [
                {
                    isActive: true,
                    isFailed: false,
                    isVisited: true,
                    stepId: 1,
                    description: 'Selecting users'
                },
                {
                    isActive: false,
                    isFailed: false,
                    isVisited: false,
                    stepId: 2,
                    description: 'Assign entities'
                }
            ];
            component.onNext();
            fixture.detectChanges();
            expect(component.activeStep).toEqual(nextStep);
        });

        it('should move forward aditional step', () => {
            component.newUserStepsPayload = [
                {
                    isActive: false,
                    isFailed: false,
                    isVisited: true,
                    stepId: 1,
                    description: 'Selecting users'
                },
                {
                    isActive: true,
                    isFailed: false,
                    isVisited: true,
                    stepId: 2,
                    description: 'Assign entities'
                }
            ];
            component.onNext();
            expect(component.form.valid).toEqual(false);
        });

        it('should move forward with valid form', () => {
            component.newUserStepsPayload = [
                {
                    isActive: false,
                    isFailed: false,
                    isVisited: true,
                    stepId: 1,
                    description: 'Selecting users'
                },
                {
                    isActive: true,
                    isFailed: false,
                    isVisited: true,
                    stepId: 2,
                    description: 'Assign entities'
                }
            ];
            component.onNext();
            expect(component.form.valid).toEqual(false);
        });

        it('should move forward aditional step and addtional step', () => {
            component.newUserStepsPayload = [
                {
                    isActive: false,
                    isFailed: false,
                    isVisited: true,
                    stepId: 1,
                    description: 'Selecting users'
                },
                {
                    isActive: true,
                    isFailed: false,
                    isVisited: true,
                    stepId: 2,
                    description: 'Assign entities'
                }
            ];
            component.selectedUsers.patchValue(mockUsers, { emitEvent: true });
            component.totalAditionalSteps = mockUsers.length - 1;
            component.usersInView = mockUsers.map((user, index) => ({ ...user, isCurrent: index === 0 }));
            fixture.detectChanges();
            component.onNext();
            expect(component.totalAditionalSteps).toBe(mockUsers.length - 1);
        });

        it('should navigate previous', () => {
            component.newUserStepsPayload = [
                {
                    isActive: false,
                    isFailed: false,
                    isVisited: true,
                    stepId: 1,
                    description: 'Selecting users'
                },
                {
                    isActive: true,
                    isFailed: false,
                    isVisited: true,
                    stepId: 2,
                    description: 'Assign entities'
                }
            ];
            fixture.detectChanges();
            component.onPrevious();
            expect(component.activeStep).toEqual(0);
        });

        it('should navigate previous aditional step', () => {
            const steps = mockUsers.length - 1;
            const closedAdditionalSteps = -1;
            component.newUserStepsPayload = [
                {
                    isActive: false,
                    isFailed: false,
                    isVisited: true,
                    stepId: 1,
                    description: 'Selecting users'
                },
                {
                    isActive: true,
                    isFailed: false,
                    isVisited: true,
                    stepId: 2,
                    description: 'Assign entities'
                }
            ];
            component.totalAditionalSteps = steps;
            component.currentAditionalStep = closedAdditionalSteps;
            component.usersInView = mockUsers.map((user) => ({ ...user, isCurrent: false }));
            component.onPrevious();
            fixture.detectChanges();
            expect(component.currentAditionalStep).toBe(steps);
            component.onPrevious();
            fixture.detectChanges();
            expect(component.currentAditionalStep).toBe(steps - 1);
        });

        it('should be ready to save and dispatch action on save call', () => {
            const dispatchSpy = spyOn(store$, 'dispatch').and.callThrough();
            component.selectedUsers.setValue([mockUsers[0]]);
            component.newUserStepsPayload = [
                {
                    isActive: false,
                    isFailed: false,
                    isVisited: true,
                    stepId: 1,
                    description: 'Selecting users'
                },
                {
                    isActive: true,
                    isFailed: false,
                    isVisited: true,
                    stepId: 2,
                    description: 'Assign entities'
                }
            ];
            fixture.detectChanges();
            expect(Object.keys(component.groupedEntities.controls).length).toBeGreaterThan(0);
            expect(Object.keys(component.userToApplySameCheckboxFormGroup.controls).length).toBe(0);
            Object.keys(component.groupedEntities.controls).forEach(key =>
                component.groupedEntities.get(key).setValue(mockEntityGroups)
            );
            fixture.detectChanges();
            component.onNext();
            expect(component.isReadyToSave).toEqual(true);
            component.onNext();
            expect(component.saveInProgress).toEqual(true);
            expect(dispatchSpy).toHaveBeenCalled();
        });

        it('should close modal after save', () => {
            const closeSpy = spyOn(component, 'closeWizardModal').and.callThrough();
            component.saveInProgress = true;
            component['subscribeEntitiesAssignedState']();
            component['actionsListener$'].next(roleManagementUsersRoleEntitiesAssignSuccessAction());
            fixture.detectChanges();
            expect(component.saveInProgress).toEqual(false);
            expect(closeSpy).toHaveBeenCalled();
        });

        describe('apply same entities', () => {
            beforeEach(() => {
                component.newUserStepsPayload = [
                    {
                        isActive: false,
                        isFailed: false,
                        isVisited: true,
                        stepId: 1,
                        description: 'Selecting users'
                    },
                    {
                        isActive: true,
                        isFailed: false,
                        isVisited: true,
                        stepId: 2,
                        description: 'Assign entities'
                    }
                ];
                component.selectedUsers.setValue(mockUsers);
                fixture.detectChanges();
                component.groupedEntities.get(component.selectedUsers.value[0].id).setValue(mockEntityGroups);
                fixture.detectChanges();
            });

            it('should not apply and move forward', () => {
                expect(Object.keys(component.groupedEntities.controls).length).toBe(mockUsers.length);
                expect(Object.keys(component.userToApplySameCheckboxFormGroup.controls).length).toBe(1);
                component.userToApplySameCheckboxFormGroup.get(component.selectedUsers.value[0].id).setValue(false);
                fixture.detectChanges();
                component.onNext();
                expect(component.isReadyToSave).toEqual(false);
                Object.keys(component.groupedEntities.controls).forEach((key, index) => {
                    if (index === 0) {
                        expect(component.groupedEntities.controls[key].value).toEqual(mockEntityGroups);
                    } else {
                        expect(component.groupedEntities.controls[key].value).not.toEqual(mockEntityGroups);
                    }
                });
            });

            it('should apply and move forward', () => {
                expect(Object.keys(component.groupedEntities.controls).length).toBe(mockUsers.length);
                expect(Object.keys(component.userToApplySameCheckboxFormGroup.controls).length).toBe(1);
                component.userToApplySameCheckboxFormGroup.get(component.selectedUsers.value[0].id).setValue(true);
                fixture.detectChanges();
                component.onNext();
                expect(component.isReadyToSave).toEqual(true);
                Object.keys(component.groupedEntities.controls).forEach(key => {
                    expect(component.groupedEntities.controls[key].value).toEqual(mockEntityGroups);
                });
            });
        });
    });

    it('should call onCurrentUserChanged', () => {
        const currentUser = 1;
        component.usersInView = mockUsers.map((user) => ({ ...user, isCurrent: false }));
        component.onCurrentUserChanged(mockUsers[currentUser].id);
        expect(component.currentAditionalStep).toBe(currentUser);
        expect(component.usersInView[currentUser].isCurrent).toEqual(true);
    });

    it('should have selected entities', () => {
        store$.overrideSelector(getSelectedEntities, { '134': mockEntityGroups });
        fixture.detectChanges();
        expect(component.groupedEntities.controls).toBeDefined();
    });

    it('should recreate controls on selected users change', () => {
        component.selectedUsers.setValue([]);
        fixture.detectChanges();
        expect(Object.keys(component.groupedEntities.controls).length).toBe(0);
        expect(Object.keys(component.userToApplySameCheckboxFormGroup.controls).length).toBe(0);

        component.selectedUsers.setValue([{
            id: '123321',
            isSelected: true,
            label: 'User Test'
        }]);
        fixture.detectChanges();
        expect(Object.keys(component.groupedEntities.controls).length).toBe(1);
        expect(Object.keys(component.userToApplySameCheckboxFormGroup.controls).length).toBe(0);

        component.selectedUsers.setValue(mockUsers);
        fixture.detectChanges();
        expect(Object.keys(component.groupedEntities.controls).length).toBe(mockUsers.length);
        expect(Object.keys(component.userToApplySameCheckboxFormGroup.controls).length).toBe(1);
    });

    it('should update users in view on currentAditionalStep change', () => {
        const currentStep = 1;
        component.usersInView = mockUsers.map((user) => ({ ...user, isCurrent: false }));
        component.currentAditionalStep = currentStep;
        fixture.detectChanges();
        expect(component.currentAditionalStep).toBe(currentStep);
        expect(component.usersInView[currentStep].isCurrent).toEqual(true);
    });

    it('should return correct active index', () => {
        component.newUserStepsPayload = [];
        expect(component.activeStep).toBe(0);

        component.newUserStepsPayload =  [
            {
                isActive: false,
                isFailed: false,
                isVisited: true,
                stepId: 1
            },
            {
                isActive: true,
                isFailed: false,
                isVisited: true,
                stepId: 2
            }
        ];
        expect(component.activeStep).toBe(component.newUserStepsPayload.length - 1);
    });

    it('should save in first step when internal', () => {
        spyOn(component['store$'], 'dispatch');
        component.newUserStepsPayload = [];
        component['isInternal'] = true;
        component.onNext();
        expect(component['store$'].dispatch).toHaveBeenCalled();
    });

    it('should close modal and dispath event to open add new user modal', () => {
        spyOn(component, 'closeWizardModal');
        spyOn(component['store$'], 'dispatch');
        component.openAddNewUserModal();
        expect(component.closeWizardModal).toHaveBeenCalled();
        expect(component['store$'].dispatch).toHaveBeenCalled();
    });
});
