import { LazyElementsModule } from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { NameWithInitialsAvatarComponent } from '../../../../../../../../../pages/users-and-roles/roles-management/components/name-with-initials-avatar/name-with-initials-avatar.component';
import { initialRoleManagementState } from '../../../../../../../../../pages/users-and-roles/roles-management/state/role-management.reducers';
import {
    isBackCheckState,
    modifiedRoleDetailsState,
    roleDetailsState
} from '../../../../../../../../../pages/users-and-roles/roles-management/state/role-management.selectors';
import { NewRoleModulesInfoComponent } from '../../../new-role-modules-info/new-role-modules-info.component';

import { Step2SelectModulesComponent } from './step-2-select-modules.component';

describe('Step2SelectModulesComponent', () => {
    let component: Step2SelectModulesComponent;
    let fixture: ComponentFixture<Step2SelectModulesComponent>;
    let store$: MockStore;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                Step2SelectModulesComponent,
                NameWithInitialsAvatarComponent,
                NewRoleModulesInfoComponent
            ],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: initialRoleManagementState,
                    selectors: [
                        {
                            selector: isBackCheckState,
                            value: { total: 0, selected: [] }
                        },
                        {
                            selector: roleDetailsState,
                            value: {
                                role: 'role',
                                type: 'C',
                                color: '#AAAAAA',
                                created_date: '',
                                created_by: '',
                                created_by_name: '',
                                last_modified_date: '',
                                last_modified_by: '',
                                last_modified_by_name: '',
                                restricted_association_groups_ids: null
                            }
                        },
                        {
                            selector: modifiedRoleDetailsState,
                            value: {
                                role: 'role',
                                type: 'C',
                                color: '#AAAAAA',
                                created_date: '',
                                created_by: '',
                                created_by_name: '',
                                last_modified_date: '',
                                last_modified_by: '',
                                last_modified_by_name: '',
                                restricted_association_groups_ids: null
                            }
                        }
                    ]
                })
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
        store$ = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(Step2SelectModulesComponent);
        component = fixture.componentInstance;
        component.stepOneData = {
            role: 'Test Role',
            existingRole: '123',
            type: 'C',
            color: '#FFFFFF'
        };
        component.stepForm = new FormGroup({
            modules: new FormControl({ value: {}, disabled: false }, [
                Validators.required
            ]),
            sub_modules: new FormControl({ value: {}, disabled: false }),
            module_sections: new FormControl({ value: {}, disabled: false }),
            restricted_association_groups_ids: new FormControl({
                value: [],
                disabled: false
            })
        });
    });

    it('should create', () => {
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });
});
