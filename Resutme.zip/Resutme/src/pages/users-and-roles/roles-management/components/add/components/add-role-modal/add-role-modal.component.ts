import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ModalModel, ScreenSizeEnum } from '@ct/platform-primitives-uicomponents/modals';
import { RadioComboboxOption } from '@ct/platform-primitives-uicomponents/primitives/radio-combobox/interfaces/radio-combobox-options.interface';
import { TranslateService } from '@ngx-translate/core';

import { CreateRoleActionType } from '../interfaces/create-role-action-type.enum';

@Component({
    selector: 'ct-add-role-modal',
    templateUrl: './add-role-modal.component.html',
    styleUrls: ['./add-role-modal.component.scss']
})
export class AddRoleModalComponent {
    @Input() isOpen: boolean = false;
    @Input()
    set activeOption(value: CreateRoleActionType) {
        if (value) {
            const foundOption = this.controlOptions.find(
                (option) => option.value === value
            );
            if (foundOption) {
                foundOption.checked = true;
                this.controlOptions.forEach(
                    (option) => (option.disabled = !option.checked)
                );
                this.onChange(foundOption);
            }
        }
    }
    @Output() cancel = new EventEmitter<void>();
    @Output() confirm = new EventEmitter<CreateRoleActionType>();

    modalModel: ModalModel = {
        title: 'userRolesModule.AddNewRoleComponent.title',
        cancelText: 'userRolesModule.AddNewRoleComponent.cancelButton',
        confirmText: 'userRolesModule.AddNewRoleComponent.confirmButton',
        modalType: ScreenSizeEnum.large
    };

    controlOptions: Array<RadioComboboxOption> = [
        {
            label: this.translate.instant(
                'userRolesModule.AddNewRoleComponent.createRoleOption'
            ),
            value: CreateRoleActionType.CREATE_NEW_ROLE,
            checked: false,
            disabled: false
        },
        {
            label: this.translate.instant(
                'userRolesModule.AddNewRoleComponent.copyAndCreateRoleOption'
            ),
            value: CreateRoleActionType.COPY_AND_CREATE_NEW_ROLE,
            checked: false,
            disabled: false
        }
    ];

    selectedOption: RadioComboboxOption;
    isCancelNotificationVisible: boolean = false;
    hasOverlayClickClose = false;
    confirmModalModel: ModalModel = {
        title: 'userRolesModule.AddNewRoleComponent.cancelConfirmModal.title',
        cancelText:
            'userRolesModule.AddNewRoleComponent.cancelConfirmModal.cancelBtn',
        confirmText:
            'userRolesModule.AddNewRoleComponent.cancelConfirmModal.confirmBtn'
    };

    constructor(private translate: TranslateService) {}

    onCancelClick(): void {
        this.cancel.emit();
    }

    onConfirmClick(): void {
        if (this.selectedOption) {
            this.confirm.emit(
                this.selectedOption.value as CreateRoleActionType
            );
        }
    }

    onChange(option: RadioComboboxOption): void {
        this.selectedOption = option;
    }
}
