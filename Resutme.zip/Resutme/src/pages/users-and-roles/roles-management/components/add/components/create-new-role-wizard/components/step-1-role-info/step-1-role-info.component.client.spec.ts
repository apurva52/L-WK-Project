import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { Step1RoleInfoComponent } from './step-1-role-info.component';

describe('Step1RoleInfoComponent', () => {
    let component: Step1RoleInfoComponent;
    let fixture: ComponentFixture<Step1RoleInfoComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [Step1RoleInfoComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    }
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(Step1RoleInfoComponent);
        component = fixture.componentInstance;
        component.stepForm = new FormGroup({
            role_name: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            role_color: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            created_by_name: new FormControl({ value: '', disabled: false }),
            created_date: new FormControl({ value: '', disabled: false })
        });
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('form should be reset', () => {
        spyOn(component.stepForm, 'reset');
        component['resetForm']();
        expect(component.stepForm.reset).toHaveBeenCalled();
    });

    it('should trim whitespaces at the beginning of role name', () => {
        const testRoleName = 'test role name';

        component.getFormControl('role_name').setValue(testRoleName);
        fixture.detectChanges();
        expect(component.getFormControl('role_name').value).toEqual(testRoleName);

        component.getFormControl('role_name').setValue(`  ${testRoleName}`);
        fixture.detectChanges();
        expect(component.getFormControl('role_name').value).toEqual(testRoleName);
    });

    it('should trim whitespaces at the end of role name', () => {
        const testRoleName = 'test role name';

        component.getFormControl('role_name').setValue(testRoleName);
        component.roleNameChanged();
        expect(component.getFormControl('role_name').value).toEqual(testRoleName);

        component.getFormControl('role_name').setValue(`${testRoleName}   `);
        component.roleNameChanged();
        expect(component.getFormControl('role_name').value).toEqual(testRoleName);
    });
});
