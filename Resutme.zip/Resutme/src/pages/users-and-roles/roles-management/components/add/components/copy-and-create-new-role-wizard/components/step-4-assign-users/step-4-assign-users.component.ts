import {
    Component,
    EventEmitter,
    Input,
    OnDestroy,
    OnInit
} from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import {
    clearRoleSelectedEntities,
    entitySelectBy,
    entitySelectorChangeStatus
} from '../../../../../../../../../features/entity-selector/state/entity-selector.actions';
import { StepComponent } from '../../../../interfaces/step-component.model';

@Component({
    selector: 'ct-step-4-assign-users',
    templateUrl: './step-4-assign-users.component.html',
    styleUrls: ['./step-4-assign-users.component.scss']
})
export class Step4AssignUsersComponent
    extends StepComponent
    implements OnInit, OnDestroy
{
    @Input() stepForm: FormGroup;
    @Input() stepOneData;
    @Input() modulesForm: FormGroup;
    @Input() usersForm: FormGroup;
    @Input() roleSaved: boolean;
    @Input() nextEvent: EventEmitter<void>;

    get selectedUsers(): Array<InputMultiselectItem> {
        return this.usersForm?.value?.users || [];
    }

    get activeUsersAccordion(): number {
        return this.getFormControl('activeAccordion')?.value;
    }

    set activeUsersAccordion(value: number) {
        this.getFormControl('activeAccordion')?.setValue(value);
    }

    get userEntitiesFormGroup(): FormGroup {
        return this.stepForm?.controls?.userEntities as FormGroup;
    }

    get userToApplySameEntitiesCheckboxFormGroup(): FormGroup {
        return this.stepForm?.controls?.userToApplySameCheckbox as FormGroup;
    }

    private destroyed$: Subject<boolean> = new Subject<boolean>();

    constructor(private store$: Store) {
        super();
    }

    ngOnInit(): void {
        this.activeUsersAccordion = 0;
        this.cleanSelectedUsersAndEntities();
        this.selectedUsers.forEach((selectedUser, i) => {
            const key = `${selectedUser.id}`;
            if (!this.userEntitiesFormGroup.get(key)) {
                this.userEntitiesFormGroup.addControl(key, new FormControl([]));
                if (this.selectedUsers.length > 1 && i === 0) {
                    this.userToApplySameEntitiesCheckboxFormGroup.addControl(
                        key,
                        new FormControl(false)
                    );
                } else {
                    this.userToApplySameEntitiesCheckboxFormGroup.removeControl(
                        key
                    );
                }
            }
        });
        this.nextEvent
            .pipe(takeUntil(this.destroyed$))
            .subscribe(() => this.changeActiveUsersAccordion());
    }

    ngOnDestroy(): void {
        this.clearEntitiesSelectorState();
    }

    onToggleEvent(index: number): void {
        this.clearEntitiesSelectorState();
        this.activeUsersAccordion = index;
    }

    private clearEntitiesSelectorState(): void {
        this.store$.dispatch(entitySelectBy({ select: undefined }));
        this.store$.dispatch(entitySelectorChangeStatus({ open: false }));
    }

    private changeActiveUsersAccordion(): void {
        if (
            Object.keys(this.userEntitiesFormGroup.controls).length >
            this.activeUsersAccordion + 1
        ) {
            this.activeUsersAccordion++;
        }
    }

    private cleanSelectedUsersAndEntities(): void {
        Object.keys(this.userEntitiesFormGroup.controls).forEach((key) => {
            if (!this.selectedUsers.find((user) => user.id === key)) {
                this.userEntitiesFormGroup.removeControl(key);
                this.userToApplySameEntitiesCheckboxFormGroup.removeControl(key);
                this.store$.dispatch(clearRoleSelectedEntities({ role: key }));
            }
        });
        this.clearEntitiesSelectorState();
    }
}
