import {
    FormArray,
    FormControl,
    FormGroup,
    ValidationErrors,
    ValidatorFn,
    Validators
} from '@angular/forms';
import { Step } from '@ct/platform-primitives-uicomponents/primitives';

import { PermissionValue } from '../../../../../../../features/modules-and-permissions-grid/interfaces/permission-module.interface';
import { rolePermissionsInitialState } from '../../../../../../../pages/users-and-roles/roles-management/details/state/role-details.state';

export function getNewRoleStepsPayload(): Array<Step> {
    return [
        {
            isActive: true,
            isFailed: false,
            isVisited: false,
            stepId: 1,
            description: ''
        },
        {
            isActive: false,
            isFailed: false,
            isVisited: false,
            stepId: 2,
            description: ''
        }
    ];
}

export function getNewRoleAssignUsersStepsPayload(): Array<Step> {
    return [
        {
            isActive: false,
            isFailed: false,
            isVisited: false,
            stepId: 3,
            description: ''
        },
        {
            isActive: false,
            isFailed: false,
            isVisited: false,
            stepId: 4,
            description: ''
        }
    ];
}

export function getInitialForm(): FormArray {
    return new FormArray([
        new FormGroup({
            role_name: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            role_color: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            created_by_name: new FormControl({ value: '', disabled: false }),
            created_date: new FormControl({
                value: new Date(),
                disabled: false
            })
        }, [firstStepEmptyDataValidation()]),
        new FormGroup(
            {
                modules: new FormControl({
                    value: rolePermissionsInitialState.modules,
                    disabled: false
                }),
                sub_modules: new FormControl({
                    value: rolePermissionsInitialState.sub_modules,
                    disabled: false
                }),
                module_sections: new FormControl({
                    value: rolePermissionsInitialState.module_sections,
                    disabled: false
                }),
                restricted_association_groups_ids: new FormControl({
                    value: [],
                    disabled: false
                }),
                restricted_documents_metadata: new FormControl({
                    value: [],
                    disabled: false
                })
            },
            [modulesValidation()]
        )
    ]);
}

export function modulesValidation(): ValidatorFn {
    return (form: FormGroup): ValidationErrors | null => {
        const formValue = form.value;
        const checkObjectPermissionValuesRecursively = (
            object: Object
        ): boolean => {
            if (typeof object[Object.keys(object)[0]] === 'number') {
                return Object.keys(object).some(
                    (key) => object[key] > +PermissionValue.NONE
                );
            } else {
                return Object.keys(object).some((key) =>
                    checkObjectPermissionValuesRecursively(object[key])
                );
            }
        };
        if (
            checkObjectPermissionValuesRecursively(formValue.modules) ||
            checkObjectPermissionValuesRecursively(formValue.sub_modules) ||
            checkObjectPermissionValuesRecursively(formValue.module_sections)
        ) {
            return null;
        }
        return { invalid: true };
    };
}

export function firstStepEmptyDataValidation(): ValidatorFn {
    return (form: FormGroup): ValidationErrors | null => {
        return !form.get('role_name').value && !form.get('role_color').value ? { empty_data_error: true } : null;
    };
}
