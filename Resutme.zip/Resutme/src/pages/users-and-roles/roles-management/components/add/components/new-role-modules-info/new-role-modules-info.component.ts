import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { RolePermissions } from './../../../../details/state/role-details.state';

@Component({
    selector: 'ct-new-role-modules-info',
    templateUrl: './new-role-modules-info.component.html',
    styleUrls: ['./new-role-modules-info.component.scss']
})
export class NewRoleModulesInfoComponent {
    @Input() titleText: string;
    @Input() modulesForm: FormGroup;
    @Input() roleSaved: boolean;
    @Input() rolePermissions: RolePermissions;
    @Input() basedOnDigitalExperience: boolean;
    @Output() permissionsChanged: EventEmitter<RolePermissions> = new EventEmitter();

    onPermissionsChanged({ modules, sub_modules, module_sections, restricted_documents_metadata }: RolePermissions): void {
        if (this.modulesForm) {
            this.modulesForm.controls.modules.setValue(modules);
            this.modulesForm.controls.sub_modules.setValue(sub_modules);
            this.modulesForm.controls.module_sections.setValue(module_sections);
            this.modulesForm.controls.restricted_documents_metadata.setValue(restricted_documents_metadata);
            this.permissionsChanged.emit({ modules, sub_modules, module_sections });
        }
    }
}
