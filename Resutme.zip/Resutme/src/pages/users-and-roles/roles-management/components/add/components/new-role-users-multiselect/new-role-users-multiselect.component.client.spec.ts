import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';

import { NewRoleUsersMultiselectComponent } from './new-role-users-multiselect.component';

describe('NewRoleUsersMultiselectComponent', () => {
    let component: NewRoleUsersMultiselectComponent;
    let fixture: ComponentFixture<NewRoleUsersMultiselectComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [NewRoleUsersMultiselectComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        'users-and-roles': {}
                    }
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(NewRoleUsersMultiselectComponent);
        component = fixture.componentInstance;
        component.usersFormControl = new FormControl({
            value: [],
            disabled: false
        });
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should dispatch action to load user on component init', () => {
        const actionSpy = spyOn((component as any).store$, 'dispatch');
        component.ngOnInit();
        expect(actionSpy).toHaveBeenCalled();
    });

    it('should remove users from selected users', () => {
        const users = [
            {
                id: '1',
                label: '1',
                isSelected: false
            },
            {
                id: '2',
                isSelected: true,
                label: '2'
            }
        ];
        (component as any).multi = users;
        component.usersFormControl.patchValue(users);

        component.removeUsers(users[0].id);

        expect(component.usersFormControl.value).toEqual([{
            id: users[1].id,
            label: users[1].label,
            isSelected: true
        }]);
    });
});
