import { Component, Input } from '@angular/core';

@Component({
    selector: 'ct-new-role-info',
    templateUrl: './new-role-info.component.html',
    styleUrls: ['./new-role-info.component.scss']
})
export class NewRoleInfoComponent {
    @Input() roleName = '';
    @Input() pillColor = '';
    @Input() createdBy = '';
    @Input() createdOn = '';

    getPillBackgroundColor(rolePillColorValue: string = 'gray'): string {
        return `background-color: ${rolePillColorValue}; color: white`;
    }
}
