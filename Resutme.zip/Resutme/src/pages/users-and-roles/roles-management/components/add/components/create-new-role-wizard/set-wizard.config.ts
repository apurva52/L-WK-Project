import { WizardConfiguration } from '@ct/platform-primitives-uicomponents/modals';
import { TranslateService } from '@ngx-translate/core';

export function setWizardConfig(
    translate: TranslateService
): WizardConfiguration {
    return {
        label: translate.instant(
            'userRolesModule.newRoleWizardComponent.title'
        ),
        subTitle: translate.instant(
            'userRolesModule.newRoleWizardComponent.subTitle'
        ),
        headerDivider: true,
        cancelToRight: true,
        cancelText: translate.instant(
            'userRolesModule.newRoleWizardComponent.cancelLabel'
        ),
        steps: [
            {
                nextLabel: translate.instant(
                    'userRolesModule.newRoleWizardComponent.nextLabel'
                ),
                title: translate.instant(
                    'userRolesModule.newRoleWizardComponent.stepTitle'
                ),
                validation: false,
                previousLabel: translate.instant(
                    'userRolesModule.newRoleWizardComponent.previousLabel'
                )
            },
            {
                nextLabel: translate.instant(
                    'userRolesModule.newRoleWizardComponent.newRoleFormStep2.createButtonLabel'
                ),
                title: translate.instant(
                    'userRolesModule.newRoleWizardComponent.newRoleFormStep2.stepTitle'
                ),
                validation: false,
                previousLabel: translate.instant(
                    'userRolesModule.newRoleWizardComponent.previousLabel'
                )
            }
        ]
    };
}
