import {
    FormArray,
    FormControl,
    FormGroup,
    ValidationErrors,
    ValidatorFn,
    Validators
} from '@angular/forms';
import { WizardConfiguration } from '@ct/platform-primitives-uicomponents/modals';
import { Step } from '@ct/platform-primitives-uicomponents/primitives';
import { TranslateService } from '@ngx-translate/core';

import { DocumentsStateForRole } from '../../../../../../../features/modules-and-permissions-grid/state/modules-and-permissions/modules-and-permissions.state';
import { RoleRestrictedAssociationGroupId } from '../../../../../../../shared/interfaces/save-role.request';
import {
    PermissionModules,
    PermissionModuleSections,
    PermissionSubModules
} from '../../../../details/state/role-details.state';
import { Role } from '../../../../interfaces/role.model';

export interface RoleFormValue {
    existingRole: { test: string; value: Role };
    role: string;
    color: string;
    type: string;
    modules: PermissionModules;
    sub_modules: PermissionSubModules;
    module_sections: PermissionModuleSections;
    restricted_association_groups_ids: Array<RoleRestrictedAssociationGroupId>;
    restricted_documents_metadata: DocumentsStateForRole;
}

export function getNewRoleStepsPayload(): Array<Step> {
    return [
        {
            isActive: true,
            isFailed: false,
            isVisited: false,
            stepId: 0,
            description: ''
        },
        {
            isActive: false,
            isFailed: false,
            isVisited: false,
            stepId: 0.5,
            description: ''
        },
        {
            isActive: false,
            isFailed: false,
            isVisited: false,
            stepId: 1,
            description: ''
        },
        {
            isActive: false,
            isFailed: false,
            isVisited: false,
            stepId: 2,
            description: ''
        }
    ];
}
export function getWizardConfig(
    translate: TranslateService
): WizardConfiguration {
    return {
        label: translate.instant(
            'userRolesModule.newRoleWizardComponent.title'
        ),
        subTitle: translate.instant(
            'userRolesModule.newRoleWizardComponent.copyAndCreate.subtitle'
        ),
        headerDivider: true,
        cancelToRight: true,
        cancelText: translate.instant(
            'userRolesModule.newRoleWizardComponent.cancelLabel'
        ),
        steps: [
            {
                nextLabel: translate.instant(
                    'userRolesModule.newRoleWizardComponent.nextLabel'
                ),
                title: '',
                validation: false,
                previousLabel: translate.instant(
                    'userRolesModule.newRoleWizardComponent.previousLabel'
                )
            },
            {
                nextLabel: translate.instant(
                    'userRolesModule.newRoleWizardComponent.createLabel'
                ),
                title: '',
                validation: false,
                previousLabel: translate.instant(
                    'userRolesModule.newRoleWizardComponent.previousLabel'
                )
            },
            {
                nextLabel: translate.instant(
                    'userRolesModule.newRoleWizardComponent.nextLabel'
                ),
                title: translate.instant(
                    'userRolesModule.newRoleWizardComponent.copyAndCreate.selectUsersTitle'
                ),
                validation: false,
                previousLabel: translate.instant(
                    'userRolesModule.newRoleWizardComponent.previousLabel'
                )
            },
            {
                nextLabel: translate.instant(
                    'userRolesModule.newRoleWizardComponent.nextLabel'
                ),
                title: translate.instant(
                    'userRolesModule.newRoleWizardComponent.newRoleFormStep4.stepTitle'
                ),
                validation: false,
                previousLabel: translate.instant(
                    'userRolesModule.newRoleWizardComponent.previousLabel'
                )
            }
        ]
    };
}

export function getInitialForm(): FormArray {
    const formArray = new FormArray([
        new FormGroup({
            existingRole: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            role: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            type: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ]),
            color: new FormControl({ value: '', disabled: false }, [
                Validators.required
            ])
        }, [firstStepEmptyDataValidation()]),
        new FormGroup({
            modules: new FormControl({ value: {}, disabled: false }, [
                Validators.required
            ]),
            sub_modules: new FormControl({ value: {}, disabled: false }),
            module_sections: new FormControl({ value: {}, disabled: false }),
            restricted_association_groups_ids: new FormControl({
                value: [],
                disabled: false
            }),
            restricted_documents_metadata: new FormControl({
                value: [],
                disabled: false
            })
        }),
        new FormGroup({
            users: new FormControl({ value: [], disabled: false }, [
                Validators.required
            ])
        }),
        new FormGroup({
            activeAccordion: new FormControl({ value: 0, disabled: false }),
            userEntities: new FormGroup({}),
            userToApplySameCheckbox: new FormGroup({})
        })
    ]);
    const usersControl = formArray
        .at(formArray.length - 2)
        .get('users') as FormControl;
    formArray
        .at(formArray.length - 1)
        .setValidators([userEntitiesValidation(usersControl)]);
    return formArray;
}

export function userEntitiesValidation(usersControl: FormControl): ValidatorFn {
    const selectedUsersFormControl = usersControl;
    return (form: FormGroup): ValidationErrors | null => {
        const formValue = form.value;
        const activeAccordion = formValue.activeAccordion;
        const userEntities = formValue.userEntities;
        if (activeAccordion < 0) {
            return Object.keys(userEntities).some(
                (key) => !userEntities[key].length
            )
                ? { invalid: true }
                : null;
        }
        const selectedUsers = selectedUsersFormControl?.value || [];
        const selectedUser = selectedUsers[activeAccordion];
        return selectedUser && userEntities[selectedUser.id]?.length
            ? null
            : { invalid: true };
    };
}

export function firstStepEmptyDataValidation(): ValidatorFn {
    return (form: FormGroup): ValidationErrors | null => {
        return Object.keys(form.controls).every(key => !form.get(key).value) ? { empty_data_error: true } : null;
    };
}

export const DEFAULT_ITEM_COUNT_FORM: number = 4;
export const STEP4INDEX: number = 3;
