import { Component, Input, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import { RoleDetails } from '../../../../../../details/state/role-details.state';
import { roleDetailsState } from '../../../../../../state/role-management.selectors';

@Component({
    selector: 'ct-copy-and-create-role-info-data',
    templateUrl: './role-info-data.component.html',
    styleUrls: ['./role-info-data.component.scss']
})
export class RoleInfoDataComponent implements OnInit {
    @Input() stepOneData: {
        existingRole: string;
        role: string;
        type: string;
        color: string;
    };

    existingRoleDetails$: Observable<RoleDetails>;

    constructor(private store$: Store) {}

    ngOnInit(): void {
        this.existingRoleDetails$ = this.store$.select(roleDetailsState);
    }
}
