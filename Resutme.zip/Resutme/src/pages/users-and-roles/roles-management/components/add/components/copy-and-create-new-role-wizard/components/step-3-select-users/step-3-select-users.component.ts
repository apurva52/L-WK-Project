import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { StepComponent } from '../../../../interfaces/step-component.model';

@Component({
    selector: 'ct-step-3-select-users',
    templateUrl: './step-3-select-users.component.html',
    styleUrls: ['./step-3-select-users.component.scss']
})
export class Step3SelectUsersComponent extends StepComponent {
    @Input() stepForm: FormGroup;
    @Input() stepOneData;
    @Input() roleSaved: boolean;
    @Input() modulesForm: FormGroup;

    constructor() {
        super();
    }
}
