// tslint:disable max-file-line-count
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import {
    ModalModel,
    WizardConfiguration
} from '@ct/platform-primitives-uicomponents/modals';
import { Step } from '@ct/platform-primitives-uicomponents/primitives';
import { ofType } from '@ngrx/effects';
import { ActionsSubject, Store } from '@ngrx/store';
import { Observable, Subject } from 'rxjs';
import { take } from 'rxjs/operators';

import { selectUserTokenPayload } from '../../../../../../../app/state/app.selectors';
import {
    clearAllData,
    selectEntities
} from '../../../../../../../features/entity-selector/state/entity-selector.actions';
import { selectedDuplicateCheckState } from '../../../..//state/role-management.selectors';
import { RoleType } from '../../../../interfaces/role-type.enum';
import {
    resetDuplicateCheckStateAction,
    roleManagementUsersRoleEntitiesAssignAction,
    roleManagementUsersRoleEntitiesAssignFailureAction,
    roleManagementUsersRoleEntitiesAssignSuccessAction
} from '../../../../state/role-management.actions';

@Component({
    template: ''
})
export abstract class CreateNewRoleWizard {
    get activeStep(): number {
        const index = this.newRoleStepsPayload.findIndex(
            (step) => step.isActive
        );
        return index < 0 ? 0 : index;
    }
    get isInlastStep(): boolean {
        return this.activeStep === this.newRoleStepsPayload.length - 1;
    }
    get isCurrentFormValid(): boolean {
        return this.getStepForm(this.activeStep)?.valid;
    }
    get hidePreviousButton(): boolean {
        return this.activeStep === 1 && this.roleSaved;
    }
    get roleType(): RoleType {
        return this.isInternal ? RoleType.INTERNAL : RoleType.CUSTOMER;
    }

    wizardConfig: WizardConfiguration;
    newRoleStepsPayload: Array<Step>;
    form: FormArray;
    isCancelNotificationVisible = false;
    roleSaved = false;
    associationInProgress = false;
    isRoleNameDuplicate = false;
    isCheckingDuplicate = false;
    nextEvent: EventEmitter<void> = new EventEmitter<void>();
    userTokenPayload$: Observable<object> = this.store$.select(
        selectUserTokenPayload
    );
    isRoleNameDuplicate$ = this.store$
        .select(selectedDuplicateCheckState)
        .subscribe((value) => {
            this.isRoleNameDuplicate = value;
        });
    confirmModalModel: ModalModel;

    @Input() isInternal: boolean;
    @Output() cancel = new EventEmitter<boolean>();

    protected step4SubmitLabelText = '';
    protected _destroyed$ = new Subject<boolean>();

    constructor(
        protected store$: Store,
        protected actionsListener$: ActionsSubject
    ) {}

    setStep(index: number): void {
        this.newRoleStepsPayload.forEach((step, i) => {
            step.isActive = i === index;
            step.isVisited = i < index;
        });
    }

    getStepForm(index: number): FormGroup {
        return this.form.at(index) as FormGroup;
    }

    onChangeHandler(value: boolean): void {
        this.isCheckingDuplicate = this.isRoleNameDuplicate ? false : value;
    }

    closeWizardModal(): void {
        this.store$.dispatch(resetDuplicateCheckStateAction());
        this.store$.dispatch(clearAllData());
        this.cancel.emit(this.roleSaved);
    }

    confirmCloseModal(event?: { isCloseButtonClick: boolean }): void {
        if (this.activeStep === 0 && this.getStepForm(this.activeStep).errors?.empty_data_error) {
            this.isCancelNotificationVisible = false;
            this.closeWizardModal();
        }
        if (this.roleSaved && this.activeStep === 1) {
            this.isCancelNotificationVisible = false;
            this.closeWizardModal();
        } else {
            this.isCancelNotificationVisible = true;
        }
    }

    protected goToNext(): void {
        this.setStep(this.activeStep + 1);
    }

    protected step4Submit(): void {
        const activeAccordion = this.getStepForm(this.activeStep).value
            .activeAccordion;
        const selectedUsersCount =
            this.getStepForm(this.activeStep - 1).value.users.length - 1;
        this.assignSameEntitiesToSelectedUsers();
        if (this.doAllUserHaveEntitiesAssociation()) {
            if (
                this.wizardConfig.steps[this.activeStep].nextLabel ===
                this.step4SubmitLabelText
            ) {
                this.addUserRoleAssignmentWithEntityGroup();
            } else {
                this.getStepForm(
                    this.activeStep
                ).controls.activeAccordion?.setValue(-1);
                this.wizardConfig.steps[this.activeStep].nextLabel =
                    this.step4SubmitLabelText;
            }
            return;
        }
        if (activeAccordion !== selectedUsersCount) {
            this.nextEvent.emit();
        } else {
            const userEntitiesForm = this.getStepForm(this.activeStep).controls
                .userEntities as FormGroup;
            const keys = Object.keys(userEntitiesForm.controls);
            for (let i = 0; i < keys.length; i++) {
                if (!userEntitiesForm.controls[keys[i]].value.length) {
                    this.getStepForm(
                        this.activeStep
                    ).controls.activeAccordion?.setValue(i);
                    break;
                }
            }
        }
    }

    protected assignSameEntitiesToSelectedUsers(): void {
        const lastStepFormGroup = this.getStepForm(this.activeStep);
        const activeAccordion = lastStepFormGroup.value.activeAccordion;
        if (activeAccordion < 0) {
            return;
        }
        const selectedUsers = this.getStepForm(this.activeStep - 1).value.users;
        const activeUser = selectedUsers[activeAccordion];
        const checkboxControl =
            lastStepFormGroup.controls.userToApplySameCheckbox.get(
                activeUser?.id
            );
        if (checkboxControl?.value) {
            const userEntities = lastStepFormGroup.controls
                .userEntities as FormGroup;
            const activeUserEntities = userEntities.get(activeUser.id).value;
            Object.keys(userEntities.controls).forEach((key) => {
                userEntities.controls[key].setValue([...activeUserEntities]);
            });
            const selectedEntitiesValue = {};
            const userEntitiesValue =
                lastStepFormGroup.controls.userEntities.value;
            Object.keys(userEntitiesValue).forEach((key) => {
                selectedEntitiesValue[
                    `${key}-${this.getStepForm(0).controls.role_id.value}`
                ] = userEntitiesValue[key];
            });
            this.store$.dispatch(
                selectEntities({ payload: selectedEntitiesValue })
            );
        }
    }

    protected addUserRoleAssignmentWithEntityGroup(): void {
        this.associationInProgress = true;
        const roleId = this.getStepForm(0).value.role_id;
        const lastStepFormValue = this.getStepForm(
            this.wizardConfig.steps.length - 1
        ).value;
        this.subscribeUsersRoleEntitiesAssignedState();
        this.store$.dispatch(
            roleManagementUsersRoleEntitiesAssignAction({
                roleId,
                userIdToEntityGroups: lastStepFormValue.userEntities
            })
        );
    }

    protected subscribeUsersRoleEntitiesAssignedState(): void {
        this.actionsListener$
            .pipe(
                ofType(
                    roleManagementUsersRoleEntitiesAssignSuccessAction,
                    roleManagementUsersRoleEntitiesAssignFailureAction
                ),
                take(1)
            )
            .subscribe((result) => {
                this.associationInProgress = false;
                if (!(result as any).errorMessage) {
                    this.closeWizardModal();
                }
            });
    }

    protected doAllUserHaveEntitiesAssociation(): boolean {
        const lastStepNumber = this.wizardConfig.steps.length - 1;
        const userEntitiesFormGroup = this.getStepForm(lastStepNumber).controls
            .userEntities as FormGroup;
        const controlKeys = Object.keys(userEntitiesFormGroup.controls);
        return (
            controlKeys.length &&
            controlKeys.every(
                (key) => !!userEntitiesFormGroup.controls[key].value?.length
            )
        );
    }
}
