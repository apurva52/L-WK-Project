// tslint:disable:max-file-line-count
import {
    LazyElementsLoaderService,
    LazyElementsModule
} from '@angular-extensions/elements';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl } from '@angular/forms';
import { LocaleTestingModule } from '@ct/core-ui-ng/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { of } from 'rxjs';

import { initialState } from '../../../../../../../../../features/entity-selector/state/entity-selector.reducers';
import { getRoleSelectedEntities } from '../../../../../../../../../features/entity-selector/state/entity-selector.selectors';
import { ENTITY_SELECTOR_FEATURE_KEY } from '../../../../../../../../../features/entity-selector/state/entity-selector.state';

import { NewRoleUserEntitiesAssociateComponent } from './new-role-user-entities-associate.component';

describe('NewRoleUserEntitiesAssociateComponent', () => {
    let component: NewRoleUserEntitiesAssociateComponent;
    let fixture: ComponentFixture<NewRoleUserEntitiesAssociateComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [NewRoleUserEntitiesAssociateComponent],
            imports: [
                LazyElementsModule.forRoot({}),
                TranslateModule.forRoot(),
                LocaleTestingModule
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [ENTITY_SELECTOR_FEATURE_KEY]: initialState
                    },
                    selectors: [
                        {
                            selector: getRoleSelectedEntities,
                            value: {
                                ['1']: [
                                    {
                                        edh_entity_group_id: 1,
                                        edh_entity_group_guid: '1',
                                        edh_entity_group_name: '1',
                                        edh_entity_group_type: 'C',
                                        entities: []
                                    }
                                ]
                            }
                        }
                    ]
                }),
                {
                    provide: LazyElementsLoaderService,
                    useClass: class extends LazyElementsLoaderService {
                        loadElement(): Promise<void> {
                            return Promise.resolve();
                        }
                    }
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(
            NewRoleUserEntitiesAssociateComponent
        );
        component = fixture.componentInstance;
        component.user = {
            id: '1',
            label: 'Test User',
            isSelected: true
        };
        component.roleId = 1;
        component.userEntitiesFormControl = new FormControl({
            value: [],
            disabled: false
        });
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should subscribe on selected entities change', () => {
        const selectSpy = spyOn(
            (component as any).store$,
            'select'
        ).and.returnValue(of([]));
        component.ngOnInit();
        fixture.detectChanges();
        expect(selectSpy).toHaveBeenCalled();
        expect((component as any).selectedItems$).toBeDefined();
    });

    it('should emit event on calling onToggleAccordion', () => {
        const emitSpy = spyOn(component.toggleEvent, 'emit');
        component.onToggleAccordion();
        expect(emitSpy).toHaveBeenCalled();
    });

    it('should activate add entities', () => {
        const dispatchSpy = spyOn((component as any).store$, 'dispatch');
        component.onAddEntity();
        expect(component.isAddEntitiesActivated).toEqual(true);
        expect(dispatchSpy).toHaveBeenCalled();
    });

    it('should deactivate add entities on complete adding entities', () => {
        const dispatchSpy = spyOn((component as any).store$, 'dispatch');
        component.onAddEntityCompleted([
            {
                id: '1',
                label: 'Test Entity',
                isSelected: true
            }
        ]);
        expect(component.isAddEntitiesActivated).toEqual(false);
        expect(dispatchSpy).toHaveBeenCalled();
    });

    it('should deactivate add entities on cancel adding entities', () => {
        component.onAddEntityCanceled();
        expect(component.isAddEntitiesActivated).toEqual(false);
    });

    it('should set value when onApplySameForAllChange called', () => {
        const event = { target: { checked: true } };
        component.applySameForAllUsersFormControl = new FormControl(false);
        component.onApplySameForAllChange(event);
        expect(component.applySameForAllUsersFormControl.value).toEqual(true);
    });

    it('should reset apply same checkbox value when onAddEntityCompleted called', () => {
        const event = [
            {
                edh_entity_group_id: 1,
                edh_entity_group_guid: '1',
                edh_entity_group_name: 'Group 1',
                edh_entity_group_type: 'I',
                entities: [
                    {
                        entity_id: 1,
                        entity_guid: '1',
                        entity_name: 'Entity 1',
                        entity_country: 'Test',
                        domestic_jurisdiction: 'Test'
                    }
                ]
            }
        ];
        component.applySameForAllUsersFormControl = new FormControl(true);
        component.onAddEntityCompleted(event);
        expect(component.applySameForAllUsersFormControl.value).toEqual(false);
    });

    it('should set and clear checked items', () => {
        const data = [{
            entity_id: '1',
            entity_guid: '1',
            entity_type: '',
            entity_country: '',
            domestic_jurisdiction: '',
            foreign_jurisdiction: [],
            entity_name: ['1'],
            entity_group: {
                edh_entity_group_id: 3,
                edh_entity_group_guid: '23f77391-b001-41a8-a528-ec3c3dc3c5a0',
                edh_entity_group_name: 'Entity Group 3',
                edh_entity_group_type: 'C',
                entity_type: 'LLC',
                entity_status: 'Active',
                jurisdiction: 'FL, GA, AL, SC, NC, MI, LA',
                entities: []
            },
            is_group: false
        }] as any;

        component.onCheckedEntitiesChange({ total: 1, selected: data });
        expect(component['checkedItems'].length).toBeTruthy();

        component.onCheckedEntitiesCleared();
        expect(component['checkedItems'].length).toBeFalsy();
    });

    it('should show and close warning notification', () => {
        component.bulkOptions[0].handler();
        expect(component.isRemoveEntitiesNotificationVisible).toBeTruthy();
        component.onCancelRemoveEntitiesNotification();
        expect(component.isRemoveEntitiesNotificationVisible).toBeFalsy();
    });

    it('should remove checked items', () => {
        const entityGroups = [
            {
                edh_entity_group_id: 1,
                edh_entity_group_guid: '3fd77391-b001-41a8-a528-ec3c3dc3c5a6',
                edh_entity_group_name: 'Entity Group 1',
                edh_entity_group_type: 'C',
                entity_type: 'LLC',
                entity_status: 'Active',
                jurisdiction: 'FL, GA, AL, SC, NC, MI, LA',
                entities: [{
                    entity_id: 96000005937,
                    entity_guid: '11f28063-f227-41a2-b1fd-cc75b2586172',
                    entity_name: 'Entity Name 1',
                    entity_type: 'Corp',
                    entity_country: 'US',
                    domestic_jurisdiction: 'Delaware',
                    foreign_jurisdiction: 'Delaware'
                }]
            },
            {
                edh_entity_group_id: 2,
                edh_entity_group_guid: '3fd77391-b001-41a8-a528-ec3c3dc3c5a7',
                edh_entity_group_name: 'Entity Group 2',
                edh_entity_group_type: 'C',
                entity_type: 'LLC',
                entity_status: 'Active',
                jurisdiction: 'FL, GA, AL, SC, NC, MI, LA',
                entities: [{
                    entity_id: 96000005938,
                    entity_guid: '11f28063-f227-41a2-b1fd-cc75b2586173',
                    entity_name: 'Entity Name 2',
                    entity_type: 'Corp',
                    entity_country: 'US',
                    domestic_jurisdiction: 'Delaware',
                    foreign_jurisdiction: 'Delaware'
                }]
            }
        ] as any;
        const data = [
            {
                entity_id: 96000005937,
                entity_guid: '11f28063-f227-41a2-b1fd-cc75b2586172',
                entity_type: 'Corp',
                entity_country: 'US',
                domestic_jurisdiction: 'Delaware',
                foreign_jurisdiction: [],
                entity_name: [entityGroups[0].edh_entity_group_name, 'Entity Name 1'],
                entity_group: entityGroups[0],
                is_group: false
            },
            {
                entity_id: 2,
                entity_guid:  '3fd77391-b001-41a8-a528-ec3c3dc3c5a7',
                entity_type: '',
                entity_country: '',
                domestic_jurisdiction: '',
                foreign_jurisdiction: [],
                entity_name: ['Entity Group 2'],
                entity_group: entityGroups[1],
                is_group: true
            }
        ] as any;
        const dispatchSpy = spyOn((component as any).store$, 'dispatch');
        const expectedcallsCount = 2;
        component.userEntitiesFormControl.setValue(entityGroups);
        component['checkedItems'] = data;
        component.onConfirmRemoveEntitiesNotification();
        expect(dispatchSpy).toHaveBeenCalledTimes(expectedcallsCount);
    });
});
