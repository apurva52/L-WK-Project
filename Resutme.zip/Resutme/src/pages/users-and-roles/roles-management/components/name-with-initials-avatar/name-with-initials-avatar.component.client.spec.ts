import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { JumpstartComponentsModule } from '@wk/components-angular11';

import { NameWithInitialsAvatarComponent } from './name-with-initials-avatar.component';

describe('NameWithInitialsAvatarComponent', () => {
    let component: NameWithInitialsAvatarComponent;
    let fixture: ComponentFixture<NameWithInitialsAvatarComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [NameWithInitialsAvatarComponent],
            imports: [JumpstartComponentsModule],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(NameWithInitialsAvatarComponent);
        component = fixture.componentInstance;
        component.name = 'John Smith';
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should calculate initials correctly', () => {
        const result = component['getNameInitials'](component.name);
        expect(result).toBe('JS');
    });
});
