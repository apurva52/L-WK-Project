import { Component, Input } from '@angular/core';

@Component({
    selector: 'ct-name-with-initials-avatar',
    templateUrl: './name-with-initials-avatar.component.html',
    styleUrls: ['./name-with-initials-avatar.component.scss']
})
export class NameWithInitialsAvatarComponent {
    @Input() name: string;

    getNameInitials(name: string): string {
        return name.split(' ').reduce((current: string, next: string) => current + next.charAt(0), '');
    }
}
