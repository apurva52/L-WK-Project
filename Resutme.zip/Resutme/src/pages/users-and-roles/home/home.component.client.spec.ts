/* tslint:disable:no-unused-variable */
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Router, RouterEvent } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { JumpstartComponentsModule } from '@wk/components-angular11';
import { ReplaySubject } from 'rxjs';

import { initialAppState } from '../../../app/state/app.reducer';
import { selectIsInternal } from '../../../app/state/app.selectors';
import {
    AppState,
    USERS_PANEL_APP_FEATURE_KEY
} from '../../../app/state/app.state';

import { HomeComponent } from './home.component';

const eventSubject = new ReplaySubject<RouterEvent>(1);
class Mockrouter {
    navigate = jasmine.createSpy('navigate');
    events = eventSubject.asObservable();
}

describe('HomeComponent', () => {
    let component: HomeComponent;
    let fixture: ComponentFixture<HomeComponent>;
    let mockRouter: Mockrouter;
    let store: MockStore<AppState>;
    let window: Window;

    beforeEach(async(() => {
        mockRouter = new Mockrouter();
        const mockWindow: Window = <any>{
            location: { assign: (url: string): void => {} }
        };

        TestBed.configureTestingModule({
            declarations: [HomeComponent],
            imports: [
                RouterTestingModule,
                JumpstartComponentsModule,
                TranslateModule.forRoot()
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [USERS_PANEL_APP_FEATURE_KEY]: initialAppState
                    },
                    selectors: [{ selector: selectIsInternal, value: true }]
                }),
                {
                    provide: Router,
                    useValue: mockRouter
                },
                {
                    provide: Window,
                    useValue: mockWindow
                }
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        })
            .overrideComponent(HomeComponent, {
                set: {
                    providers: [
                        {
                            provide: Window,
                            useFactory: () => mockWindow
                        }
                    ]
                }
            })
            .compileComponents();
        store = TestBed.inject(MockStore);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HomeComponent);
        component = fixture.componentInstance;
        window = fixture.debugElement.injector.get(Window);
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should change tab to roles', () => {
        component.tabSelected(1);
        expect(mockRouter.navigate).toHaveBeenCalledWith([
            '/account-tools/users-and-roles/role-management'
        ]);
    });

    it('should go back', async(() => {
        spyOn(window.location, 'assign').and.callThrough();
        component.goBack();
        expect(window.location.assign).toHaveBeenCalled();
    }));

    it('should change tab to roles for Users', () => {
        const spyAction = spyOn(component.store$, 'dispatch');
        component.tabSelected(0);
        fixture.detectChanges();
        expect(spyAction).toHaveBeenCalled();
    });
    it('should change tab to roles for Roles', () => {
        const spyAction = spyOn(component.store$, 'dispatch');
        component.tabSelected(1);
        fixture.detectChanges();
        expect(spyAction).toHaveBeenCalled();
    });
    it('should change tab to roles for Users for Internals', () => {
        const spyAction = spyOn(component.store$, 'dispatch');
        component.isInternal = true;
        component.tabSelected(0);
        fixture.detectChanges();
        expect(spyAction).toHaveBeenCalled();
    });
    it('should change tab to roles for Roles for Internals', () => {
        component.isInternal = true;
        const spyAction = spyOn(component.store$, 'dispatch');
        component.tabSelected(1);
        fixture.detectChanges();
        expect(spyAction).toHaveBeenCalled();
    });
});
