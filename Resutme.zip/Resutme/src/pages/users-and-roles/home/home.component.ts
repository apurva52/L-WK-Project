import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ButtonType } from '@ct/platform-primitives-uicomponents/primitives';
import { Store } from '@ngrx/store';
import { appActions } from 'src/app/state/app.actions';
import { selectIsInternal } from 'src/app/state/app.selectors';
import { AppState } from 'src/app/state/app.state';
import {
    baseBreadcrumbsItems,
    roleManagementItem,
    userManagementItem
} from 'src/shared/config/breadcrumbsItems.config';

import { UsersAndRolesTab } from '../../../shared/interfaces/users-and-roles-management-tab.interface';
import { makeWhiteBackground } from '../../../shared/util';

@Component({
    selector: 'ct-users-and-roles',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss'],
    providers: [{ provide: Window, useValue: window }]
})
export class HomeComponent implements OnInit {
    @Input() defaultTabSelected: string = '0';

    ButtonType = ButtonType;
    tabs: Array<UsersAndRolesTab> = [
        {
            label: 'User Management',
            path: '/account-tools/users-and-roles/user-management'
        },
        {
            label: 'Role Management',
            path: '/account-tools/users-and-roles/role-management'
        }
    ];
    isInternal = null;
    isInternal$ = this.store$
        .select(selectIsInternal)
        .subscribe((isInternal) => (this.isInternal = isInternal));
    constructor(
        public router: Router,
        public store$: Store<AppState>,
        private window: Window
    ) {}

    ngOnInit(): void {
        makeWhiteBackground();
    }

    async tabSelected(tabIndex: number): Promise<void> {
        const newItems = [
            ...baseBreadcrumbsItems(this.isInternal),
            tabIndex === 0 ? userManagementItem : roleManagementItem
        ];
        void this.router.navigate([this.tabs[tabIndex].path]);
        this.store$.dispatch(
            appActions.updateBreadcrumbsItems({
                breadcrumbsItems: newItems
            })
        );
    }

    goBack(): void {
        this.window.location.assign(
            this.isInternal ? `/internal-tools` : `/engage-admin/account-tools`
        );
    }
}
