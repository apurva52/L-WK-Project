import { IGetRowsParams } from '@ag-grid-community/core';

import { GroupTypes } from '../enums';
import { GroupListItem, GROUPS_FIELDS, GroupsListParams } from '../models';

export class GroupsListHelper {
    static getFormattedGroupListParams = (
        params: Partial<IGetRowsParams>
    ): GroupsListParams => {
        const request: GroupsListParams = {} as GroupsListParams;
        request.pageSize = params.endRow - params.startRow;
        request.pageNumber = params.startRow / request.pageSize + 1;

        if (params.sortModel.length) {
            request.sortKey = params.sortModel[0].sort;
            request.sortBy = params.sortModel[0].colId;
        } else {
            request.sortKey = 'asc';
            request.sortBy = 'entityGroupName';
        }

        return request;
    }

    static formatCellValues = (listItem: GroupListItem): GroupListItem => {
        GROUPS_FIELDS.forEach((prop) => {
            listItem[prop] = !!listItem[prop] ? listItem[prop] : '-';
            if (prop === 'groupType') {
                listItem[prop] =
                    listItem[prop] === GroupTypes.DYNAMIC
                        ? 'Dynamic'
                        : 'Static';
            }
        });

        return listItem;
    }

    static getLastRow = (
        rows: number,
        pageNum: number,
        pageSize: number
    ): number => {
        return rows < pageSize
            ? (pageNum - 1) * pageSize + rows
            : (pageNum + 1) * pageSize;
    }
}
