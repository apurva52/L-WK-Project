/* tslint:disable:max-file-line-count */
/* tslint:disable:max-line-length */
import { FormGroup } from '@angular/forms';
import { CustomFieldItem } from '@ct/platform-common-uicomponents/custom-fields';
import { GetCustomFieldsDetailsResponse } from '@ct/platform-common-uicomponents/custom-fields-renderer';
import { CemEntity } from '@ct/platform-common-uicomponents/entity-reference/search-and-select/shared/interfaces/cem-entity.model';
import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';
import { isObject } from 'lodash';

import { addDescriptiveInformationFormConfig } from '../config';
import {
    addGroupCategoriesMaxCount,
    groupsCategoriesJoinSymbol
} from '../constants';
import {
    CategoriesTemplates,
    dateRangesTemplate
} from '../constants/categories-json-templates';
import {
    ControlType,
    DateRagesIntervals,
    DateRangesInfo,
    DateRangesType,
    GroupCategories,
    GroupSaveStatus,
    GroupTypes,
    SelectBy
} from '../enums';
import {
    AddGroupFirstStepModel,
    AddGroupParams,
    AddGroupSecondStepModel,
    AddGroupThirdStepModel,
    DateRangesModel,
    DescriptiveInformationModel
} from '../models';

export const convertMultiselectItemsToListOfIds = (
    multiselectOption: Array<InputMultiselectItem> = []
) => {
    return multiselectOption?.map((option) => option.id);
};

export const convertCustomFieldsToListOfGuids = (
    customFields: Array<CustomFieldItem> = []
) => {
    return customFields?.map((option) => option.guid);
};

export const isOutOfLimit = (
    secondStepFormData: AddGroupSecondStepModel,
    isStatic: boolean
) => {
    const categoriesLength =
        (secondStepFormData[GroupCategories.CUSTOM_FIELDS]?.length || 0) +
        (secondStepFormData[GroupCategories.DATE_RANGES]?.length || 0) +
        (secondStepFormData[GroupCategories.DESCRIPTIVE_INFORMATION]?.length ||
            0) +
        (isStatic
            ? (secondStepFormData[GroupCategories.STOCK_INFORMATION]?.length ||
                  0) +
              (secondStepFormData[GroupCategories.ADMINISTRATION]?.length ||
                  0) +
              (secondStepFormData.entities?.length || 0)
            : 0);

    return (
        categoriesLength === 0 || categoriesLength > addGroupCategoriesMaxCount
    );
};

export const addSaveStatusToEntitiesGridData = (
    entities: Array<CemEntity>,
    saveStatus: GroupSaveStatus
) => {
    return entities?.map((entity) => ({
        ...entity,
        saveStatus
    }));
};

export const getAddGroupFormatedData = (
    { groupName, groupType }: AddGroupFirstStepModel,
    { selectBy }: AddGroupSecondStepModel,
    {
        descriptiveInformation: { comment },
        entityIdForSave,
        selectedPills,
        dateRanges
    }: AddGroupThirdStepModel
) => {
    return {
        EntityGroupName: groupName,
        GroupType: groupType,
        // For some reason comment sometimes is array, this is quick fix, need to find the real issue.
        Comment: Array.isArray(comment) ? null : comment,
        CategoryJSON:
            groupType === GroupTypes.STATIC && selectBy === SelectBy.ENTITY_NAME
                ? null
                : JSON.stringify(getCategoryJson(selectedPills, dateRanges)),
        EntityIds: (entityIdForSave || []).join(','),
        SelectBy: groupType === GroupTypes.STATIC ? selectBy : null,
        criteriaJSON:
            groupType === GroupTypes.STATIC && selectBy === SelectBy.ENTITY_NAME
                ? null
                : JSON.stringify(getCriteriaJson(selectedPills, dateRanges))
    } as AddGroupParams;
};

export const unsetPrevValidations = (form: FormGroup) => {
    for (const field in form.controls) {
        form.get(field).clearValidators();
        form.get(field).updateValueAndValidity();
    }
};

export const getCriteriaJson = (selections, dateRanges: DateRangesModel) => {
    const selectedDescriptiveInformation =
        getSelectedDescriptiveInformationKeys(selections);
    const selectedDateRanges = getSelectedDateRangesKeys(dateRanges);
    const descriptiveInformationCriteria =
        selectedDescriptiveInformation.reduce(
            (acc, key) => ({
                ...acc,
                [selections[key][0].label]: selections[key]
                    .map((type: any) => type.name)
                    .join(groupsCategoriesJoinSymbol)
            }),
            {}
        );
    const dateRangesCriteria = selectedDateRanges.reduce(
        (acc, key) => ({
            ...acc,
            [dateRanges[key].label]: dateRanges[key].value
        }),
        {}
    );

    return {
        ...descriptiveInformationCriteria,
        ...dateRangesCriteria
    };
};

export const getCategoryJson = (
    descriptiveInformation: DescriptiveInformationModel,
    dateRanges: DateRangesModel
) => {
    const selectedDescriptiveInformation =
        getSelectedDescriptiveInformationKeys(descriptiveInformation);

    return {
        Categories: {
            categoryCoreInfoList: {
                CategoryCoreInfo: [
                    ...selectedDescriptiveInformation.map((key) => {
                        return {
                            ...CategoriesTemplates[key],
                            Value: {
                                ...CategoriesTemplates[key]?.Value,
                                '#tex': descriptiveInformation[key]
                                    .map((type: any) => type.id)
                                    .join(groupsCategoriesJoinSymbol)
                            }
                        };
                    }),
                    ...getDateRangesCategoryJson(
                        dateRanges,
                        DateRangesInfo.FROM3,
                        DateRangesInfo.TO3,
                        'option3'
                    ),
                    ...getDateRangesCategoryJson(
                        dateRanges,
                        DateRangesInfo.FROM4,
                        DateRangesInfo.TO4,
                        'option4'
                    )
                ]
            }
        }
    };
};

export const getDateRangesCategoryJson = (
    dateRanges: DateRangesModel,
    fromKey: DateRangesInfo,
    toKey: DateRangesInfo,
    rangeKey: string
) => {
    const dateRangesCategories = [];
    const isSelected = Boolean(dateRanges[fromKey]?.value);

    if (
        isSelected &&
        (dateRanges[rangeKey] === DateRagesIntervals.AFTER ||
            dateRanges[rangeKey] === DateRagesIntervals.BEFORE)
    ) {
        dateRangesCategories.push({
            ...dateRangesTemplate[`${fromKey}/${DateRangesType.SINGLE}`],
            Operator: dateRanges[rangeKey],
            Value: {
                ...dateRangesTemplate[`${fromKey}/${DateRangesType.SINGLE}`]
                    .Value,
                '#tex': dateRanges[fromKey].value
            }
        });
    } else if (
        isSelected &&
        dateRanges[rangeKey] === DateRagesIntervals.BETWEEN
    ) {
        dateRangesCategories.push({
            ...dateRangesTemplate[`${fromKey}/${DateRangesType.INTERVAL}`],
            Value: {
                ...dateRangesTemplate[`${fromKey}/${DateRangesType.INTERVAL}`]
                    .Value,
                '#text': dateRanges[fromKey].value
            },
            Value2: {
                ...dateRangesTemplate[`${fromKey}/${DateRangesType.INTERVAL}`]
                    .Value2,
                '#text': dateRanges[toKey].value
            }
        });
    }

    return dateRangesCategories;
};

export const getSelectedDescriptiveInformationKeys = (
    selections: DescriptiveInformationModel
) => {
    return Object.keys(selections).filter(
        (key) => Array.isArray(selections[key]) && selections[key].length > 0
    );
};

export const getSelectedDateRangesKeys = (dateRanges: DateRangesModel) => {
    return Object.keys(dateRanges).filter((key) => isObject(dateRanges[key]));
};

export const clearUncheckedControls = (
    form: FormGroup,
    selectionList: Array<InputMultiselectItem>
) => {
    const selectionListKeys = selectionList?.map((selection) => selection.id);
    if (selectionListKeys?.length) {
        Object.keys(form.controls)
            .filter((key) => {
                return !selectionListKeys.includes(key);
            })
            .forEach((key) => {
                if (!isTextFields(key) && key !== 'radioOptions') {
                    const control = form.get(key);
                    control.patchValue([], { emitEvent: false });
                }
            });
    }
};

export const isTextFields = (key: string) => {
    const fieldConfig = addDescriptiveInformationFormConfig.find(
        (x) => x.id === key
    );

    return (
        fieldConfig &&
        [ControlType.TEXT, ControlType.TEXT_OPTIONS].includes(fieldConfig.type)
    );
};

export const convertCustomFieldsDetailsToPickList = (
    values: Array<GetCustomFieldsDetailsResponse>
) => {
    return values.reduce((acc, current) => {
        return {
            ...acc,
            [current.result.customFieldId]: current.result.pickListValue.map(
                (e) => ({
                    id: e.id?.toString(),
                    name: e.value
                })
            )
        };
    }, {});
};
