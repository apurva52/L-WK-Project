import { FormControl, FormGroup, Validators } from '@angular/forms';

import { DynamicGroupType, StaticGroupType } from '../constants/group-details';
import { GroupTypes } from '../enums';
import { GroupDetails } from '../models/group-details';

const disabledDefaultFormControl = { value: 'tes', disabled: true };

const staticGroupFormControls = {
    entityGroupName: new FormControl('', [Validators.required]),
    groupType: new FormControl(disabledDefaultFormControl),
    comment: new FormControl(''),
    createdBy: new FormControl(disabledDefaultFormControl),
    createdByName: new FormControl(disabledDefaultFormControl)
};

const dynamicGroupFormControls = {
    ...staticGroupFormControls,
    criteriaJSON: new FormControl(disabledDefaultFormControl)
};

const getForm = (groupType: string): typeof staticGroupFormControls | typeof dynamicGroupFormControls | {} => {
    if (groupType === GroupTypes.DYNAMIC) {
        return {...dynamicGroupFormControls};
    } else {
        return {...staticGroupFormControls};
    }
};

export const getFormGroup = (data: GroupDetails): FormGroup => {
    const formGroup = new FormGroup(getForm(data.groupType));
    let jsonData = '';

    formGroup.patchValue({
        ...data,
        groupType: data.groupType === GroupTypes.DYNAMIC ? DynamicGroupType : StaticGroupType
    });

    if (data.groupType === GroupTypes.DYNAMIC) {
        for (const property in data.criteriaJSON) {
            jsonData += `${property}: ${data.criteriaJSON[property]}\n`;
        }

        formGroup.patchValue({
            criteriaJSON: jsonData
        });
    }

    return formGroup;
};