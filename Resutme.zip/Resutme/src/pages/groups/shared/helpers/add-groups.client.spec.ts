import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CustomFieldItem } from '@ct/platform-common-uicomponents/custom-fields';

import {
    CategoriesInfo,
    DateRagesIntervals,
    DateRangesInfo,
    GroupCategories,
    SelectBy
} from '../enums';
import {
    categoryJsonMock,
    customFieldItems,
    dateRangesCriteriaMock,
    dateRangesFormMock,
    descriptiveInformationsMock,
    formationDateIntervalCategoryJsonMock,
    formationDateSingleCategoryJsonMock,
    mockAddGroupDateRanges
} from '../mocks';
import { DateRangesModel } from '../models';

import {
    clearUncheckedControls,
    convertCustomFieldsToListOfGuids,
    convertMultiselectItemsToListOfIds,
    getCategoryJson,
    getCriteriaJson,
    getDateRangesCategoryJson,
    getSelectedDateRangesKeys,
    getSelectedDescriptiveInformationKeys,
    isOutOfLimit,
    isTextFields,
    unsetPrevValidations
} from './add-groups';

describe('AddGroupHelper', () => {
    const selections = [
        {
            id: 'addressType',
            label: 'Address Type',
            isSelected: true
        },
        {
            id: 'businessPurpose',
            label: 'Business Purpose',
            isSelected: true
        }
    ];

    it('should convert multiselect items to list of ids', () => {
        const ids = ['1', '2', '3', '4'];
        expect(
            convertMultiselectItemsToListOfIds(mockAddGroupDateRanges)
        ).toEqual(ids);
    });

    it('should convert custom fields to list of guids', () => {
        const guids = ['guid'];
        expect(
            convertCustomFieldsToListOfGuids(
                customFieldItems as Array<CustomFieldItem>
            )
        ).toEqual(guids);
    });

    it('should check if categories are out of limit', () => {
        let categories = {
            [GroupCategories.CUSTOM_FIELDS]: [],
            [GroupCategories.DATE_RANGES]: [],
            [GroupCategories.DESCRIPTIVE_INFORMATION]: [],
            selectBy: SelectBy.ENTITY_NAME,
            entities: [],
            [GroupCategories.ADMINISTRATION]: [],
            [GroupCategories.STOCK_INFORMATION]: []
        };
        expect(isOutOfLimit(categories, false)).toEqual(true);
        categories[GroupCategories.DATE_RANGES] = [
            ...mockAddGroupDateRanges,
            ...mockAddGroupDateRanges
        ];
        expect(isOutOfLimit(categories, false)).toEqual(true);
        categories[GroupCategories.DATE_RANGES] = [...mockAddGroupDateRanges];
        expect(isOutOfLimit(categories, true)).toEqual(false);
        categories = {
            [GroupCategories.CUSTOM_FIELDS]: null,
            [GroupCategories.DATE_RANGES]: null,
            [GroupCategories.DESCRIPTIVE_INFORMATION]: null,
            [GroupCategories.ADMINISTRATION]: null,
            [GroupCategories.STOCK_INFORMATION]: null,
            selectBy: SelectBy.ENTITY_NAME,
            entities: null
        };
        expect(isOutOfLimit(categories, false)).toEqual(true);
        expect(isOutOfLimit(categories, true)).toEqual(true);
    });

    it('should unset form controlls validations', () => {
        const form: FormGroup = new FormGroup({
            businessStructureType: new FormControl([], Validators.required),
            durationType: new FormControl([], Validators.required)
        });
        unsetPrevValidations(form);
        expect(form.controls.businessStructureType.validator).toEqual(null);
        expect(form.controls.durationType.validator).toEqual(null);
    });

    it('should return selected descriptive information keys', () => {
        expect(
            getSelectedDescriptiveInformationKeys(descriptiveInformationsMock)
        ).toEqual(['businessStructureType', 'durationType']);
    });

    it('should return selected date ranges keys', () => {
        expect(getSelectedDateRangesKeys(dateRangesFormMock)).toEqual([
            'from1',
            'to1',
            'from2',
            'to2',
            'from3',
            'to3',
            'from4',
            'to4',
            'from5',
            'to5'
        ]);
    });

    it('should return criteria json of selections', () => {
        expect(
            getCriteriaJson(descriptiveInformationsMock, dateRangesFormMock)
        ).toEqual({
            'Business Structure Type: ': '(European investors)',
            'Duration Type: ': 'Perpetual',
            ...dateRangesCriteriaMock
        });
    });

    it('should return category json of selections', () => {
        expect(
            getCategoryJson(descriptiveInformationsMock, {} as DateRangesModel)
        ).toEqual(categoryJsonMock);
    });

    it('should return category json of formation date', () => {
        expect(
            getDateRangesCategoryJson(
                dateRangesFormMock,
                DateRangesInfo.FROM3,
                DateRangesInfo.TO3,
                'option3'
            )
        ).toEqual([formationDateIntervalCategoryJsonMock]);
        dateRangesFormMock.option3 = DateRagesIntervals.AFTER;
        expect(
            getDateRangesCategoryJson(
                dateRangesFormMock,
                DateRangesInfo.FROM3,
                DateRangesInfo.TO3,
                'option3'
            )
        ).toEqual([formationDateSingleCategoryJsonMock] as any);
    });

    it('should clear unselected controls values', () => {
        const form = new FormGroup({
            [CategoriesInfo.ADDRESS_TYPE]: new FormControl(),
            [CategoriesInfo.BUSINESS_PURPOSE]: new FormControl(),
            [CategoriesInfo.BUSINESS_STRUCTURE_TYPE]: new FormControl()
        });
        const formSpy = spyOn(
            form.get([CategoriesInfo.BUSINESS_STRUCTURE_TYPE]),
            'patchValue'
        );
        clearUncheckedControls(form, selections);
        expect(formSpy).toHaveBeenCalledTimes(1);
    });

    it('should not clear text controls values', () => {
        const form = new FormGroup({
            [CategoriesInfo.ENTITY_SUB_TYPE]: new FormControl('123'),
            [CategoriesInfo.BUSINESS_PURPOSE]: new FormControl(),
            [CategoriesInfo.BUSINESS_STRUCTURE_TYPE]: new FormControl()
        });
        const formSpy = spyOn(
            form.get([CategoriesInfo.ENTITY_SUB_TYPE]),
            'patchValue'
        );
        clearUncheckedControls(form, selections);
        expect(formSpy).not.toHaveBeenCalled();
    });

    it('should check for text field', () => {
        let result = isTextFields(CategoriesInfo.ENTITY_SUB_TYPE);
        expect(result).toBeTruthy();
        result = isTextFields(CategoriesInfo.BUSINESS_STRUCTURE_TYPE);
        expect(result).toBeFalsy();
    });
});
