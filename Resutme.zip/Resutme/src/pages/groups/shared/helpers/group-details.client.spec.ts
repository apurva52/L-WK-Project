import { FormGroup } from '@angular/forms';

import { groupDetails } from '../test-stubs/group-details.stub';

import { getFormGroup } from './group-details';

describe('Group details helper', () => {
    it('should return formgroup for dynamic', () => {
        const formGroup = getFormGroup(groupDetails);

        expect(formGroup.controls['criteriaJSON']).toBeDefined();
    });

    it('should return formgroup for static', () => {
        const formGroup = getFormGroup({ ...groupDetails, groupType: 'S' });

        expect(formGroup.controls['criteriaJSON']).not.toBeDefined();
    });
});
