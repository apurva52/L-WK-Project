import { IGetRowsParams } from '@ag-grid-community/core';

import { groupsListMock } from '../mocks';

import { GroupsListHelper } from './groups-list';

describe('GroupsListHelper', () => {

    it('should map entities to fill empty ticks and format dates', () => {
        const [groupItem] = groupsListMock;
        expect(GroupsListHelper.formatCellValues(groupItem)).toEqual({
            ...groupItem,
            entityGroupName: 'Smith Group',
            groupType: 'Dynamic'
        });
    });

    it('should set max rows correctly', () => {
        const maxRowSize = 20;
        const minRowSize = 10;
        const equalDataSize = 60;
        const lessEqualDataSize = 30;
        expect(GroupsListHelper.getLastRow(maxRowSize, 2, maxRowSize)).withContext('data size equal to full page').toBe(equalDataSize);
        expect(GroupsListHelper.getLastRow(minRowSize, 2, maxRowSize)).withContext('data size less than full page').toBe(lessEqualDataSize);
        expect(GroupsListHelper.getLastRow(0, 2, maxRowSize)).withContext('data is empty').toBe(maxRowSize);
    });

    it('should call a service with correct request and a callback after response', async () => {
        const params = {
            successCallback(rowsThisBlock: Array<any>, lastRow?: number): void { },
            startRow: 20,
            endRow: 40,
            sortModel: [{
                sort: 'asc',
                colId: 'entityGroupName'
            }]
        } as IGetRowsParams;
        const expectedRequest = {
            pageSize: 20,
            pageNumber: 2,
            sortKey: 'asc',
            sortBy: 'entityGroupName'
        };
        expect(GroupsListHelper.getFormattedGroupListParams(params)).toEqual(expectedRequest);
    });
});
