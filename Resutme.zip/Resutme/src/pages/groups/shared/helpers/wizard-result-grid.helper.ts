import moment from 'moment';

import { resultStatusColumn, statusIconMap } from '../constants';

export function wizardResultsCellRenderer(params): string {
    const field = params.colDef ? params.colDef.field : undefined;
    let formattedValue = params ? params.data[field] : undefined;
    const empty = '';

    if (params.colDef.colVal.dataType === 'DATE' && formattedValue !== '-') {
        if (!formattedValue) {
            return empty;
        }

        formattedValue = moment.utc(formattedValue).format('MMM D, YYYY');

        return formattedValue;
    }

    if (params.colDef.field !== resultStatusColumn) {
        return formattedValue;
    }

    return statusIconMap[formattedValue];
}
