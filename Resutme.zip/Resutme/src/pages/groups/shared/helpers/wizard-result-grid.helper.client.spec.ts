import { resultStatusColumn, statusIconMap } from '../constants';
import { GroupSaveStatus } from '../enums';

import { wizardResultsCellRenderer } from './wizard-result-grid.helper';

const mockColumn = 'test';
const mockData = 'sample';

function getMockEvent(column: string, cellData: string | number): object {
    return {
        colDef: {
            field: column,
            colVal: {
                dataType: ''
            }
        },
        data: {
            [column]: cellData
        }
    };
}

describe('group grid cell renderer', () => {
    it('should return text as is if non-result column is passed', () => {
        const mockEvent = getMockEvent(mockColumn, mockData);
        expect(wizardResultsCellRenderer(mockEvent)).toBe(mockData);
    });

    it('should return delete icon for preselected status', () => {
        const mockEvent = getMockEvent(resultStatusColumn, GroupSaveStatus.Preselected);
        expect(wizardResultsCellRenderer(mockEvent)).toBe(statusIconMap[GroupSaveStatus.Preselected]);
    });

    it('should return spinner for in-progress status', () => {
        const mockEvent = getMockEvent(resultStatusColumn, GroupSaveStatus.InProgress);
        expect(wizardResultsCellRenderer(mockEvent)).toBe(statusIconMap[GroupSaveStatus.InProgress]);
    });

    it('should return tick icon for success status', () => {
        const mockEvent = getMockEvent(resultStatusColumn, GroupSaveStatus.Success);
        expect(wizardResultsCellRenderer(mockEvent)).toBe(statusIconMap[GroupSaveStatus.Success]);
    });

    it('should return cross icon for success status', () => {
        const mockEvent = getMockEvent(resultStatusColumn, GroupSaveStatus.Failed);
        expect(wizardResultsCellRenderer(mockEvent)).toBe(statusIconMap[GroupSaveStatus.Failed]);
    });
});
