import { ModalModel } from '@ct/platform-primitives-uicomponents/modals';

export const GroupCommentModalConfig: ModalModel = {
    title: 'GroupsModule.GroupSummaryCommentComponent.title',
    confirmText: 'GroupsModule.GroupSummaryCommentComponent.confirmText',
    cancelText: 'GroupsModule.GroupSummaryCommentComponent.cancelText',
    closeText: 'GroupsModule.GroupSummaryCommentComponent.closeText',
    cancelToLeft: true
};
