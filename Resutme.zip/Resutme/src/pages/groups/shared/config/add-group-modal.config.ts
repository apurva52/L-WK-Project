import { FormControl, FormGroup, Validators } from '@angular/forms';

import { addGroupModalI18nBase } from '../constants/add-group-modal';
import { CategoriesInfo, GroupCategories, GroupTypes, SelectBy, SelectSearchBy } from '../enums';

export const dateRangeControls = {
    from1: new FormControl(),
    to1: new FormControl(),
    from2: new FormControl(),
    to2: new FormControl(),
    from3: new FormControl(),
    to3: new FormControl(),
    from4: new FormControl(),
    to4: new FormControl(),
    option3: new FormControl(),
    option4: new FormControl(),
    from5: new FormControl(),
    to5: new FormControl,
    option5: new FormControl()
};

export const descInformationControls = {
    businessStructureType: new FormControl([]),
    durationType: new FormControl([]),
    entityName: new FormControl([]),
    entityStatus: new FormControl([]),
    entityType: new FormControl([]),
    entitySubType: new FormControl(''),
    country: new FormControl([]),
    additionalCountryInfo: new FormControl(''),
    jurisdiction: new FormControl([]),
    additionalJurisdictionInfo: new FormControl(''),
    primaryResponsibleUser: new FormControl([]),
    reasonForTermination: new FormControl([]),
    addressType: new FormControl([]),
    businessPurpose: new FormControl(''),
    comment: new FormControl(''),
    securityName: new FormControl([]),
    stockExchange: new FormControl([]),
    stockIdentifier: new FormControl([]),
    stockSymbol: new FormControl(''),
    lastModifiedBy: new FormControl([]),
    radioOptions: new FormControl({}),
    [CategoriesInfo.CUSTOM_FIELD_GROUP]: new FormGroup({})
};

export const getAddGroupModalStepsConfig = (
    step: number,
    action: string,
    isStatic: boolean
): Array<{ [key: string]: Array<string> | boolean }> => {
    return Array.from(Array(step + 1))
        .map((_, index) =>
            getAddGroupModalStepConfigByOrder(index + 1, action, isStatic)
        );
};

export const getAddGroupModalStepConfigByOrder = (
    index: number,
    action: string,
    isStatic: boolean
): { [key: string]: Array<string> | boolean } => {
    return {
        nextLabel: [`${addGroupModalI18nBase}step${index}.${action}.nextLabel`,
        `${addGroupModalI18nBase}step${index}.${isStatic ? 'staticLabel.' : ''}nextLabel`],
        title: [`${addGroupModalI18nBase}step${index}.${action}.title`,
        `${addGroupModalI18nBase}step${index}.${isStatic ? 'staticLabel.' : ''}title`],
        previousLabel: [`${addGroupModalI18nBase}step${index}.${action}.previousLabel`,
        `${addGroupModalI18nBase}step${index}.previousLabel`],
        validation: false
    };
};

export const addGroupModalConfig = {
    modalTitle: `${addGroupModalI18nBase}modalTitle`,
    cancel: `${addGroupModalI18nBase}cancelText`,
    newGroup: {
        label: `${addGroupModalI18nBase}formFields.newGroup.label`,
        placeholder: `${addGroupModalI18nBase}formFields.newGroup.placeholder`
    },
    radioActions: {
        label: `${addGroupModalI18nBase}formFields.automaticalyAdded.label`,
        optionOne: `${addGroupModalI18nBase}formFields.automaticalyAdded.optionOne`,
        optionTwo: `${addGroupModalI18nBase}formFields.automaticalyAdded.optionTwo`
    },
    radioSearchActions: {
        optionOne: `${addGroupModalI18nBase}radioSearchOptions.optionOne`,
        optionTwo: `${addGroupModalI18nBase}radioSearchOptions.optionTwo`,
        optionThree: `${addGroupModalI18nBase}radioSearchOptions.optionThree`
    },
    selectBy: {
        label: `${addGroupModalI18nBase}step2.selectBy.label`,
        optionOne: `${addGroupModalI18nBase}step2.selectBy.optionOne`,
        optionTwo: `${addGroupModalI18nBase}step2.selectBy.optionTwo`
    },
    successNotification: {
        title: `${addGroupModalI18nBase}successNotification.title`,
        content: `${addGroupModalI18nBase}successNotification.content`
    },
    errorNotification: {
        title: `${addGroupModalI18nBase}errorNotification.title`,
        content: `${addGroupModalI18nBase}errorNotification.content`,
        confirmationText: `${addGroupModalI18nBase}errorNotification.confirmationText`,
        cancelationText: `${addGroupModalI18nBase}errorNotification.cancelationText`
    },
    noMatchingEntityNotification: {
        title: `${addGroupModalI18nBase}noMatchingEntityrNotification.title`,
        content: `${addGroupModalI18nBase}noMatchingEntityrNotification.content`
    }
};

export const addGroupSecondStepForm = new FormGroup({
    [GroupCategories.DATE_RANGES]: new FormControl([]),
    [GroupCategories.DESCRIPTIVE_INFORMATION]: new FormControl([]),
    [GroupCategories.CUSTOM_FIELDS]: new FormControl([]),
    selectBy: new FormControl(),
    entities: new FormControl([]),
    [GroupCategories.STOCK_INFORMATION]: new FormControl([]),
    [GroupCategories.ADMINISTRATION]: new FormControl([])
});

export const addGroupFirstStepForm = new FormGroup({
    groupName: new FormControl('', [Validators.required]),
    groupType: new FormControl('', [Validators.required])
});

export const addGroupThirdStepForm = new FormGroup({
    [GroupCategories.DATE_RANGES]: new FormGroup(dateRangeControls),
    [GroupCategories.DESCRIPTIVE_INFORMATION]: new FormGroup(descInformationControls),
    [GroupCategories.SELECTED_PILLS]: new FormControl({})
});

export const groupTypeOptions = [
    {
        label: addGroupModalConfig.radioActions.optionOne,
        value: GroupTypes.DYNAMIC,
        checked: false,
        disabled: false
    },
    {
        label: addGroupModalConfig.radioActions.optionTwo,
        value: GroupTypes.STATIC,
        checked: false,
        disabled: false
    }
];

export const selectByOptions = [
    {
        label: addGroupModalConfig.selectBy.optionOne,
        value: SelectBy.ENTITY_NAME,
        checked: true,
        disabled: false
    },
    {
        label: addGroupModalConfig.selectBy.optionTwo,
        value: SelectBy.CATEGORY,
        checked: false,
        disabled: false
    }
];

export const selectBy = [
    {
        label: addGroupModalConfig.selectBy.optionOne,
        value: SelectBy.ENTITY_NAME,
        checked: true,
        disabled: false
    },
    {
        label: addGroupModalConfig.selectBy.optionTwo,
        value: SelectBy.CATEGORY,
        checked: false,
        disabled: false
    }
];

export const selectBySearchOptions = [
    {
        label: addGroupModalConfig.radioSearchActions.optionOne,
        value: SelectSearchBy.STARTS_WITH,
        checked: true,
        disabled: false
    },
    {
        label: addGroupModalConfig.radioSearchActions.optionTwo,
        value: SelectSearchBy.ENDS_WITH,
        checked: false,
        disabled: false
    },
    {
        label: addGroupModalConfig.radioSearchActions.optionThree,
        value: SelectSearchBy.CONTAINS,
        checked: false,
        disabled: false
    }
];

export const addStaticGroupThirdStepTranslations = {
    deleteInfo: `${addGroupModalI18nBase}step3.deleteText`,
    noDataToSave: `${addGroupModalI18nBase}step3.noDataToSave`,
    noDataToSaveSecondary: `${addGroupModalI18nBase}step3.noDataToSaveSecondary`
};
