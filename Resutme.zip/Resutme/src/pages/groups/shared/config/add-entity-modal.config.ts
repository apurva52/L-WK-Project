import { ModalModel } from '@ct/platform-primitives-uicomponents/modals';

export const AddEntityModalConfig: ModalModel = {
    title: 'GroupsModule.addEntityModal.title',
    confirmText: 'GroupsModule.addEntityModal.confirmText',
    cancelText: 'GroupsModule.addEntityModal.cancelText',
    closeText: 'GroupsModule.addEntityModal.closeText',
    cancelToLeft: true
};
