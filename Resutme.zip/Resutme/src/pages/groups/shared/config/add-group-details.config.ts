import { addressType, displayText, entityId, entityName, entityTypedesc, entityTypeId, entityTypes, entityTypeShortName, keyColumn, reasonForTermination, shortName, state } from '../constants/add-group-modal';
import { CategoriesInfo, ControlType } from '../enums/desc-info-categories';
import { entityStatusMockData } from '../mocks/data/entity-status.stub';
import { primaryResponsibleMockData } from '../mocks/data/entity.stub';
import { lastModifiedByMockData } from '../mocks/data/last-modified-by.stub';
import { securityNameOptions, stockExchangeOptions, stockIdentifierOptions } from '../mocks/data/stock-info.stub';
import { ControlConfig } from '../models';

export const addDescriptiveInformationFormConfig: Array<ControlConfig> = [
    {
        id: CategoriesInfo.LAST_MODIFIED_BY,
        type: ControlType.MULTI_SELECT,
        options: lastModifiedByMockData
    },
    {
        id: CategoriesInfo.ADDRESS_TYPE,
        type: ControlType.REFERENCE_MULTI_SELECT,
        serviceParams: {
            type: addressType,
            keyColumn: keyColumn,
            displayColumn: displayText
        }
    },
    {
        id: CategoriesInfo.BUSINESS_PURPOSE,
        type: ControlType.TEXT_OPTIONS
    },
    {
        id: CategoriesInfo.BUSINESS_STRUCTURE_TYPE,
        type: ControlType.REFERENCE_MULTI_SELECT,
        serviceParams: {
            type: CategoriesInfo.BUSINESS_STRUCTURE_TYPE,
            keyColumn: keyColumn,
            displayColumn: displayText
        }
    },
    {
        id: CategoriesInfo.COMMENT,
        type: ControlType.TEXT_OPTIONS
    },
    {
        id: CategoriesInfo.DURATION_TYPE,
        type: ControlType.REFERENCE_MULTI_SELECT,
        serviceParams: {
            type: CategoriesInfo.DURATION_TYPE,
            keyColumn: keyColumn,
            displayColumn: displayText
        }
    },
    {
        id: CategoriesInfo.ENTITY_NAME,
        type: ControlType.ENTITY_MULTI_SELECT,
        options: [],
        serviceParams: {
            keyColumn: entityId,
            displayColumn: entityName
        }
    },
    {
        id: CategoriesInfo.ENTITY_STATUS,
        type: ControlType.MULTI_SELECT,
        options: entityStatusMockData

    },
    {
        id: CategoriesInfo.COUNTRY,
        type: ControlType.REFERENCE_MULTI_SELECT,
        serviceParams: {
            type: CategoriesInfo.JURISDICTION,
            lookupType: CategoriesInfo.COUNTRY,
            keyColumn: keyColumn,
            displayColumn: displayText,
            shortNameColumn: shortName
        }
    },
    {
        id: CategoriesInfo.JURISDICTION,
        type: ControlType.REFERENCE_MULTI_SELECT,
        serviceParams: {
            type: CategoriesInfo.JURISDICTION,
            lookupType: state,
            keyColumn: keyColumn,
            displayColumn: displayText,
            shortNameColumn: shortName,
            query: { 'countryId': null }
        }
    },
    {
        id: CategoriesInfo.ENTITY_TYPE,
        type: ControlType.REFERENCE_MULTI_SELECT,
        serviceParams: {
            type: entityTypes,
            keyColumn: entityTypeId,
            displayColumn: entityTypedesc,
            shortNameColumn: entityTypeShortName,
            query: { 'jurisdiction': null }
        }
    },
    {
        id: CategoriesInfo.ENTITY_SUB_TYPE,
        type: ControlType.TEXT

    },
    {
        id: CategoriesInfo.ADDITIONAL_COUNTRY_INFO,
        type: ControlType.TEXT
    },
    {
        id: CategoriesInfo.ADDITIONAL_JURISDICTION_INFO,
        type: ControlType.TEXT
    },
    {
        id: CategoriesInfo.PRIMARY_RESPONSIBLE_USER,
        type: ControlType.MULTI_SELECT,
        options: primaryResponsibleMockData,
        useTextValue: true
    },
    {
        id: CategoriesInfo.REASON_FOR_TERMINATION,
        type: ControlType.REFERENCE_MULTI_SELECT,
        serviceParams: {
            type: reasonForTermination,
            keyColumn: keyColumn,
            displayColumn: displayText
        }
    },
    {
        id: CategoriesInfo.SECURITY_NAME,
        type: ControlType.MULTI_SELECT,
        options: securityNameOptions
    },
    {
        id: CategoriesInfo.STOCK_EXCHANGE,
        type: ControlType.MULTI_SELECT,
        options: stockExchangeOptions
    },
    {
        id: CategoriesInfo.STOCK_IDENTIFIER,
        type: ControlType.MULTI_SELECT,
        options: stockIdentifierOptions
    },
    {
        id: CategoriesInfo.STOCK_SYMBOL,
        type: ControlType.TEXT
    }
];