// tslint:disable:max-file-line-count
import { CategoriesInfo, DateRangesInfo, DateRangesType } from '../enums';

export const CategoriesTemplates = {
    [CategoriesInfo.BUSINESS_STRUCTURE_TYPE]: {
        CategoryClassName: null,
        CategoryId: 'X0063UO3856AVQ12C31ACP',
        CategoryMetaId: 'CATBUSINESSSTRUCTURE',
        CategoryMetaName: 'BusinessStructure',
        CategoryType: 'MultiSelectCategory',
        CriteriaMetaList: {
            CriteriaMeta: {
                IdRef: 'catBusinessStructure',
                Title: null
            }
        },
        CustomDBFieldName: null,
        IsAdvancedSearch: 'false',
        Operator: 'In',
        Value: {
            '#tex': '',
            '@p5:type': 'q4:string'
        }
    },
    [CategoriesInfo.DURATION_TYPE]: {
        CategoryClassName: null,
        CategoryId: 'X0063UO3856AVQ0M1G06S0',
        CategoryMetaId: 'CATDURATIONTYPE',
        CategoryMetaName: 'DurationType',
        CategoryType: 'MultiSelectCategory',
        CriteriaMetaList: {
            'CriteriaMeta': {
                'IdRef': 'catDurationType',
                'Title': null
            }
        },
        CustomDBFieldName: null,
        IsAdvancedSearch: 'false',
        Operator: 'In',
        Value: {
            '#tex': '',
            '@p5:type': 'q4:string'
        }
    },
    [CategoriesInfo.REASON_FOR_TERMINATION]: {
        CategoryClassName: null,
        CategoryId: 'X0063UTNQNLHQA1FGU11A8',
        CategoryMetaId: 'CATTERMREASON',
        CategoryMetaName: 'ReasonForTermination',
        CategoryType: 'MultiSelectCategory',
        CriteriaMetaList: {
            CriteriaMeta: {
                'IdRef': 'catTermReason',
                'Title': null
            }
        },
        CustomDBFieldName: null,
        IsAdvancedSearch: 'false',
        Operator: 'In',
        Value: {
            '#tex': '',
            '@p5:type': 'q4:string'
        }
    },
    [CategoriesInfo.ENTITY_STATUS]: {
        CategoryClassName: null,
        CategoryId: 'X0063U4JB9T0NE1CN602VB',
        CategoryMetaId: 'CATENTITYSTATUS',
        CategoryMetaName: 'EntityStatus',
        CategoryType: 'MultiSelectCategory',
        CriteriaMetaList: {
            CriteriaMeta: {
                'IdRef': 'catEntityStatus',
                'Title': null
            }
        },
        CustomDBFieldName: null,
        IsAdvancedSearch: 'true',
        Operator: 'In',
        Value: {
            '#tex': '',
            '@p5:type': 'q4:string'
        }
    },
    [CategoriesInfo.ENTITY_TYPE]: {
        CategoryClassName: null,
        CategoryId: 'X003SPT04G9N8A0N2P0T9A',
        CategoryMetaId: 'CATENTITYTYPE',
        CategoryMetaName: 'EntityType',
        CategoryType: 'MultiSelectCategory',
        CriteriaMetaList: {
            CriteriaMeta: {
                'IdRef': 'catEntityType',
                'Title': null
            }
        },
        CustomDBFieldName: null,
        IsAdvancedSearch: 'true',
        Operator: 'In',
        Value: {
            '#tex': '',
            '@p5:type': 'q4:string'
        }
    },
    [CategoriesInfo.PRIMARY_RESPONSIBLE_USER]: {
        CategoryClassName: null,
        CategoryId: 'X0063UTHKQH0DJ1HQC1P20',
        CategoryMetaId: 'CATPRIMARYRESPONSIBLEUSER',
        CategoryMetaName: 'PrimaryResponsibleUser',
        CategoryType: 'MultiSelectCategory',
        CriteriaMetaList: {
            CriteriaMeta: {
                'IdRef': 'catPrimaryResponsibleUser',
                'Title': null
            }
        },
        CustomDBFieldName: null,
        IsAdvancedSearch: 'false',
        Operator: 'In',
        Value: {
            '#tex': '',
            '@p5:type': 'q4:string'
        }
    },
    [CategoriesInfo.REASON_FOR_TERMINATION]: {
        CategoryClassName: null,
        CategoryId: 'X0063UTNQNLHQA1FGU11A8',
        CategoryMetaId: 'CATTERMREASON',
        CategoryMetaName: 'ReasonForTermination',
        CategoryType: 'MultiSelectCategory',
        CriteriaMetaList: {
            CriteriaMeta: {
                'IdRef': 'catTermReason',
                'Title': null
            }
        },
        CustomDBFieldName: null,
        IsAdvancedSearch: 'false',
        Operator: 'In',
        Value: {
            '#tex': '',
            '@p5:type': 'q4:string'
        }
    },
    [CategoriesInfo.JURISDICTION]: {
        CategoryClassName: null,
        CategoryId: 'X003SPT04GBRJQ0AB50GHM',
        CategoryMetaId: 'CATUSANDCANADAJURISDICTIONS',
        CategoryMetaName: 'Jurisdiction (US & Canada)',
        CategoryType: 'MultiSelectCategory',
        CriteriaMetaList: {
            CriteriaMeta: [
                {
                    'IdRef': 'catFormation',
                    'Title': 'Formation'
                },
                {
                    'IdRef': 'catAuthorityToDoBusiness',
                    'Title': 'Authority to do Business'
                }
            ]
        },
        CustomDBFieldName: null,
        IsAdvancedSearch: 'true',
        Operator: 'In',
        'SelectedSwitches': {
            'string': [
                'catFormation',
                'catAuthorityToDoBusiness'
            ]
        },
        Value: {
            '#tex': '',
            '@p5:type': 'q5:string'
        }
    }
};

export const dateRangesTemplate = {
    [`${DateRangesInfo.FROM3}/${DateRangesType.SINGLE}`]: {
        CategoryClassName: null,
        CategoryId: 'X003SPT04G93NA1Q3U0NHF',
        CategoryMetaId: 'CATFORMATIONDATE',
        CategoryMetaName: 'Formation Date',
        CategoryType: 'DateRangeCategory',
        CriteriaMetaList: {
            CriteriaMeta: {
                'IdRef': 'catFormationDate',
                'Title': null
            }
        },
        CustomDBFieldName: null,
        IsAdvancedSearch: 'true',
        Operator: '',
        Value: {
            '#tex': '',
            '@p5:type': ''
        }
    },
    [`${DateRangesInfo.FROM3}/${DateRangesType.INTERVAL}`]: {
        CategoryClassName: null,
        CategoryId: 'X0061PV03UA4MO1MSA1AF7',
        CategoryMetaId: 'CATFORMATIONDATE',
        CategoryMetaName: 'FormationDate',
        CategoryType: 'DateRangeCategory',
        CriteriaMetaList: {
            CriteriaMeta: {
                'IdRef': 'catFormationDate',
                'Title': null
            }
        },
        CustomDBFieldName: null,
        IsAdvancedSearch: 'false',
        Operator: 'Between',
        Value: {
            '#text': '',
            '@p5:type': 'q1:dateTime'
        },
        Value2: {
            '#text': '',
            '@p5:type': 'q2:dateTime'
        }
    },
    [`${DateRangesInfo.FROM4}/Single`]: {
        CategoryClassName: null,
        CategoryId: 'X003SPT04G93NA1Q3U0NHF',
        CategoryMetaId: 'CATFORMATIONDATE',
        CategoryMetaName: 'Formation Date',
        CategoryType: 'DateRangeCategory',
        CriteriaMetaList: {
            CriteriaMeta: {
                'IdRef': 'catFormationDate',
                'Title': null
            }
        },
        CustomDBFieldName: null,
        IsAdvancedSearch: 'true',
        Operator: '',
        Value: {
            '#tex': '',
            '@p5:type': ''
        }
    },
    [`${DateRangesInfo.FROM4}/Interval`]: {
        CategoryClassName: null,
        CategoryId: 'X0061PV03UA4MO1MSA1AF7',
        CategoryMetaId: 'CATTERMINATIONDATE',
        CategoryMetaName: 'TerminationDate',
        CategoryType: 'DateRangeCategory',
        CriteriaMetaList: {
            CriteriaMeta: {
                'IdRef': 'catTerminationDate',
                'Title': null
            }
        },
        CustomDBFieldName: null,
        IsAdvancedSearch: 'false',
        Operator: 'Between',
        Value: {
            '#text': '',
            '@p5:type': 'q1:dateTime'
        },
        Value2: {
            '#text': '',
            '@p5:type': 'q2:dateTime'
        }
    }
};
