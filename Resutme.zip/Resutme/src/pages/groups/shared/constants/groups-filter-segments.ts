import { SegmentedControlOptions } from '@ct/platform-primitives-uicomponents/primitives';

import { GroupTypes } from '../enums';

export const GROUP_GRID_CLICKABLE_COLUMNS = ['entityGroupName'];
export const FILTER_TYPE = 'type';
export const segmentControlOptions: Array<SegmentedControlOptions> = [
    {
        caption: 'GroupsModule.groupsListComponent.typeFilter.dynamic',
        value: GroupTypes.DYNAMIC
    },
    {
        caption: 'GroupsModule.groupsListComponent.typeFilter.static',
        value: GroupTypes.STATIC
    },
    {
        caption: 'GroupsModule.groupsListComponent.typeFilter.all',
        value: null,
        checked: true
    }
];
