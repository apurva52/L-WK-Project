// tslint:disable:max-file-line-count
import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';

import {
    CategoriesInfo,
    DateRagesIntervals,
    GroupCategories,
    GroupSaveStatus,
    SelectBy
} from '../enums';

export const resultStatusColumn = 'saveStatus';
export const beforeAddGroupSavingStep = 2;
export const addGroupSavingStep = 3;
export const addGroupSuccessInfoStep = 3;
export const addGroupFailInfoStep = 4;
export const addgroupModalHeaderWidth = 162;
export const addGroupModalI18nBase = 'GroupsModule.addGroupModalComponent.';
export const addGroupModalStepsLength = 3;
export const addGroupCategoriesMaxCount = 5;
export const reasonForTermination = 'terminationreasonentity';
export const state = 'state';
export const keyColumn = 'id';
export const shortName = 'shortName';
export const displayText = 'name';
export const entityName = 'entityName';
export const entityId = 'entityId';
export const entityTypes = 'entity-types';
export const entityTypeId = 'entityTypeId';
export const entityTypeShortName = 'entityTypeShortName';
export const entityTypedesc = 'description';
export const selectedCustomFieldPickList = 'selectedPickList';
export const statusIconMap = {
    [GroupSaveStatus.Preselected]: '<span class="wk-icon-trash"></span>',
    [GroupSaveStatus.InProgress]:
        '<span class="wk-icon-filled-spinner-alt wk-spin wk-primary-gray"></span>',
    [GroupSaveStatus.Failed]:
        '<span class="wk-icon-close-circle wk-primary-red"></span>',
    [GroupSaveStatus.Success]:
        '<span class="wk-icon-check-circle wk-primary-green"></span>'
};
export const groupsCategoriesJoinSymbol = ',';
export const addressType = 'address-type-entity';
export const radioOptionsCntrl = 'radioOptions';

export const CalendarMonths = [
    {
        id: '1',
        label: `${addGroupModalI18nBase}monthFields.Jan`
    },
    {
        id: '2',
        label: `${addGroupModalI18nBase}monthFields.Feb`
    },
    {
        id: '3',
        label: `${addGroupModalI18nBase}monthFields.Mar`
    },
    {
        id: '4',
        label: `${addGroupModalI18nBase}monthFields.Apr`
    },
    {
        id: '5',
        label: `${addGroupModalI18nBase}monthFields.May`
    },
    {
        id: '6',
        label: `${addGroupModalI18nBase}monthFields.Jun`
    },
    {
        id: '7',
        label: `${addGroupModalI18nBase}monthFields.Jul`
    },
    {
        id: '8',
        label: `${addGroupModalI18nBase}monthFields.Aug`
    },
    {
        id: '9',
        label: `${addGroupModalI18nBase}monthFields.Sep`
    },
    {
        id: '10',
        label: `${addGroupModalI18nBase}monthFields.Oct`
    },
    {
        id: '11',
        label: `${addGroupModalI18nBase}monthFields.Nov`
    },
    {
        id: '12',
        label: `${addGroupModalI18nBase}monthFields.Dec`
    }
];
export const addGroupDurationRange = [
    {
        id: DateRagesIntervals.BETWEEN,
        label: `${addGroupModalI18nBase}durationFields.isBetween`
    },
    {
        id: DateRagesIntervals.BEFORE,
        label: `${addGroupModalI18nBase}durationFields.isBefore`
    },
    {
        id: DateRagesIntervals.AFTER,
        label: `${addGroupModalI18nBase}durationFields.isAfter`
    }
];
export const addGroupDateRanges: Array<InputMultiselectItem> = [
    {
        id: '1',
        label: `${addGroupModalI18nBase}dateRanges.bylawsMeetingMonth`,
        isSelected: false
    },
    {
        id: '2',
        label: `${addGroupModalI18nBase}dateRanges.fiscalYearEnd`,
        isSelected: false
    },
    {
        id: '3',
        label: `${addGroupModalI18nBase}dateRanges.formationDate`,
        isSelected: false
    },
    {
        id: '4',
        label: `${addGroupModalI18nBase}dateRanges.terminationDate`,
        isSelected: false
    }
];

export const addMoreGroupDescriptiveInformation: Array<InputMultiselectItem> = [
    {
        id: CategoriesInfo.ADDRESS_TYPE,
        label: `${addGroupModalI18nBase}descriptiveInformation.addressType`,
        isSelected: false
    },
    {
        id: CategoriesInfo.BUSINESS_PURPOSE,
        label: `${addGroupModalI18nBase}descriptiveInformation.businessPurpose`,
        isSelected: false
    }
];

export function addStaticGroupDescriptiveInformation(): Array<InputMultiselectItem> {
    const commentControl = [
        {
            id: CategoriesInfo.COMMENT,
            label: `${addGroupModalI18nBase}descriptiveInformation.comment`,
            isSelected: false
        }
    ];
    const firstGroupControl = [addDynamicGroupDescriptiveInformation[0]];

    return addMoreGroupDescriptiveInformation
        .concat(firstGroupControl)
        .concat(commentControl)
        .concat(
            addDynamicGroupDescriptiveInformation.filter(
                (x) => x.id !== CategoriesInfo.BUSINESS_STRUCTURE_TYPE
            )
        );
}

export const addDynamicGroupDescriptiveInformation: Array<InputMultiselectItem> =
    [
        {
            id: CategoriesInfo.BUSINESS_STRUCTURE_TYPE,
            label: `${addGroupModalI18nBase}descriptiveInformation.businessStructureType`,
            isSelected: false
        },
        {
            id: CategoriesInfo.DURATION_TYPE,
            label: `${addGroupModalI18nBase}descriptiveInformation.durationType`,
            isSelected: false
        },
        {
            id: CategoriesInfo.ENTITY_NAME,
            label: `${addGroupModalI18nBase}descriptiveInformation.entityName`,
            isSelected: false
        },
        {
            id: CategoriesInfo.ENTITY_STATUS,
            label: `${addGroupModalI18nBase}descriptiveInformation.entityStatus`,
            isSelected: false
        },
        {
            id: CategoriesInfo.COUNTRY,
            label: `${addGroupModalI18nBase}descriptiveInformation.country`,
            isSelected: false
        },
        {
            id: CategoriesInfo.JURISDICTION,
            label: `${addGroupModalI18nBase}descriptiveInformation.jurisdiction`,
            isSelected: false
        },
        {
            id: CategoriesInfo.ENTITY_TYPE,
            label: `${addGroupModalI18nBase}descriptiveInformation.entityType`,
            isSelected: false
        },
        {
            id: CategoriesInfo.ENTITY_SUB_TYPE,
            label: `${addGroupModalI18nBase}descriptiveInformation.entitySubType`,
            isSelected: false
        },
        {
            id: CategoriesInfo.ADDITIONAL_COUNTRY_INFO,
            label: `${addGroupModalI18nBase}descriptiveInformation.additionalCountryInfo`,
            isSelected: false
        },
        {
            id: CategoriesInfo.ADDITIONAL_JURISDICTION_INFO,
            label: `${addGroupModalI18nBase}descriptiveInformation.additionalJurisdictionInfo`,
            isSelected: false
        },
        {
            id: CategoriesInfo.PRIMARY_RESPONSIBLE_USER,
            label: `${addGroupModalI18nBase}descriptiveInformation.primaryResponsibleUser`,
            isSelected: false
        },
        {
            id: CategoriesInfo.REASON_FOR_TERMINATION,
            label: `${addGroupModalI18nBase}descriptiveInformation.reasonForTermination`,
            isSelected: false
        }
    ];
export const stockInformationOptions = [
    {
        id: CategoriesInfo.SECURITY_NAME,
        label: `${addGroupModalI18nBase}stockInformation.securityName`,
        isSelected: false
    },
    {
        id: CategoriesInfo.STOCK_EXCHANGE,
        label: `${addGroupModalI18nBase}stockInformation.stockExchange`,
        isSelected: false
    },
    {
        id: CategoriesInfo.STOCK_IDENTIFIER,
        label: `${addGroupModalI18nBase}stockInformation.identifier`,
        isSelected: false
    },
    {
        id: CategoriesInfo.STOCK_SYMBOL,
        label: `${addGroupModalI18nBase}stockInformation.symbol`,
        isSelected: false
    }
];
export const administrationOptions = [
    {
        id: CategoriesInfo.LAST_MODIFIED_BY,
        label: `${addGroupModalI18nBase}administration.lastModifiedBy`,
        isSelected: false
    },
    {
        id: '5',
        label: `${addGroupModalI18nBase}administration.lastModifiedDate`,
        isSelected: false
    }
];

export const clearThirdStepSelection = {
    [GroupCategories.DATE_RANGES]: {
        from1: '',
        to1: '',
        from2: '',
        to2: '',
        from3: '',
        to3: '',
        from4: '',
        to4: '',
        option3: DateRagesIntervals.BETWEEN,
        option4: DateRagesIntervals.BETWEEN,
        from5: '',
        to5: '',
        option5: '1'
    },
    [GroupCategories.DESCRIPTIVE_INFORMATION]: {
        [CategoriesInfo.LAST_MODIFIED_BY]: [],
        [CategoriesInfo.ADDRESS_TYPE]: [],
        [CategoriesInfo.BUSINESS_PURPOSE]: '',
        [CategoriesInfo.BUSINESS_STRUCTURE_TYPE]: [],
        [CategoriesInfo.DURATION_TYPE]: [],
        [CategoriesInfo.ENTITY_NAME]: [],
        [CategoriesInfo.ENTITY_STATUS]: [],
        [CategoriesInfo.ENTITY_TYPE]: [],
        [CategoriesInfo.COUNTRY]: [],
        [CategoriesInfo.JURISDICTION]: [],
        [CategoriesInfo.PRIMARY_RESPONSIBLE_USER]: [],
        [CategoriesInfo.REASON_FOR_TERMINATION]: [],
        [CategoriesInfo.ENTITY_SUB_TYPE]: '',
        [CategoriesInfo.ADDITIONAL_COUNTRY_INFO]: '',
        [CategoriesInfo.ADDITIONAL_JURISDICTION_INFO]: '',
        [CategoriesInfo.COMMENT]: '',
        [CategoriesInfo.SECURITY_NAME]: [],
        [CategoriesInfo.STOCK_EXCHANGE]: [],
        [CategoriesInfo.STOCK_IDENTIFIER]: [],
        [CategoriesInfo.STOCK_SYMBOL]: '',
        [CategoriesInfo.LAST_MODIFIED_BY]: [],
        radioOptions: {},
        [CategoriesInfo.CUSTOM_FIELD_GROUP]: {}
    },
    [GroupCategories.SELECTED_PILLS]: {}
};

export const addGroupStepsModel = {
    secondStepModel: {
        [GroupCategories.CUSTOM_FIELDS]: [],
        [GroupCategories.DATE_RANGES]: [],
        [GroupCategories.DESCRIPTIVE_INFORMATION]: [],
        selectBy: SelectBy.ENTITY_NAME,
        entities: []
    },
    thirdStepModel: {
        entityIdForSave: [],
        selectedEntities: [],
        ...clearThirdStepSelection
    }
};
