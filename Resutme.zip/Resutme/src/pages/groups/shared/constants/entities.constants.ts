// tslint:disable:max-file-line-count
import { SegmentedControlOptions } from '@ct/platform-primitives-uicomponents/primitives';

export const dotMenuOptions = [
    'GroupsModule.entitiesListComponent.dotMenu.export',
    'GroupsModule.entitiesListComponent.dotMenu.createCustomField'
];

export const activate = 'GroupsModule.entitiesListComponent.gridLabel.activate';
export const inactivate =
    'GroupsModule.entitiesListComponent.gridLabel.inactivate';

export const groupsEntitiesTitle = 'GroupsModule.entitiesListComponent.header';
export const newEntityLabel = 'GroupsModule.entitiesListComponent.newEntity';

export const ENTITY_STATUS_ACTIVE = 'A';
export const ENTITY_STATUS_INACTIVE = 'I';
export const FILTER_SELECTED_ALL = 'all';
export const FILTER_SELECTED_ACTIVE = 'active';
export const FILTER_SELECTED_INACTIVE = 'inactive';
export const SEARCH_KEY = 'statusCode';

export const segmentControlOptions: Array<SegmentedControlOptions> = [
    {
        caption: 'GroupsModule.entitiesListComponent.typeFilter.active',
        value: FILTER_SELECTED_ACTIVE,
        checked: true
    },
    {
        caption: 'GroupsModule.entitiesListComponent.typeFilter.inactive',
        value: FILTER_SELECTED_INACTIVE
    },
    {
        caption: 'GroupsModule.entitiesListComponent.typeFilter.all',
        value: FILTER_SELECTED_ALL
    }
];

export const DATE_TYPE = 'DATE';
export const STRING_TYPE = 'STRING';
export const CUSTOM_FUNCTION = 'customFunction';
export const CUSTOM_TYPE = 'CUSTOM';
export const DROPDOWNCELLRENDERER = 'dropdownCellRenderer';
export const TRUEFALSE = 'TRUE/FALSE';
export const BASICINFO = 'basicInfo';

export enum IndividualEntityContextMenuActions {
    REMOVE = 'remove'
}

export const SELECTION_LIMIT = 99999;
export const minHeaderWidth = 100;
export const maxHeaderWidth = 200;
export const ENTITIES_PAGE_SIZE = 500;

export const countTwo = 2;
export const countThree = 3;
export const apiDateFormat = 'YYYY-MM-DDTHH:mm:ss';
export const stepThroughSingleWidth = 97;
export const stepThroughBulkWidth = 162;
