export const dotMenuOptions = [
    'GroupsModule.groupDetailsComponent.summaryData.dotMenu.export'
];

export const DynamicGroupType = 'Dynamic';
export const StaticGroupType = 'Static';