import { GroupTypes } from '../enums';

export interface GroupsListParams {
    pageNumber: number;
    pageSize: number;
    sortKey: string;
    sortBy: string;
    type?: GroupTypes;
}

export interface GroupListItem {
    sfAccountId: string;
    entityGroupId: number;
    entityGroupGuid: string;
    entityGroupName: string;
    groupType: string;
    criteriaJSON: any;
    isImplicitAuthGroup: string;
    createdBy: string;
    createdByName: string;
    createdDate: string;
}
