export interface GroupDetails {
    comment: string;
    entityGroupId: number;
    entityGroupGuid: string;
    entityGroupName: string;
    groupType: string;
    criteriaJSON: {[key: string]: string};
    isImplicitAuthGroup: string;
    createdByName: string;
    createdBy: string;
    createdDate: string;
}

export interface EntityItem {
    entityId: number;
    entityGuid: string;
    entityName: string;
    entityTypeId: number;
    entityTypeDesc: string;
    countryId: number;
    countryDesc: string;
    countryShortName: string;
    domesticJurisdictionId: number;
    domesticJurisdictionDesc: string;
    domesticJurisdictionCode: string;
    activeForeignJurisCount: number;
    totalForeignJurisCount: number;
}

export type GroupDetailsResponse = Array<GroupDetails>;

export interface UpdateGroupDetailsRequest {
    entityGroupGuid: string;
    Comment: string;
    EntityGroupName: string;
    EntityIds?: string;
}

export interface UpdateGroupDetailsResponse {
    result: {
        entityGroupId: number;
        entityGroupGuid: string;
        groupType: string;
        success: boolean;
    };
}


export interface UpdateGroupEntitiesRequest {
    entityGroupGuid: string;
    EntityIds?: string;
}

export type UpdateGroupEntitiesResponse = boolean;
