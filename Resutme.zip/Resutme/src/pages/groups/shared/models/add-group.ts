import { CustomFieldItem } from '@ct/platform-common-uicomponents/custom-fields';
import { CemEntity } from '@ct/platform-common-uicomponents/entity-reference/search-and-select/shared/interfaces/cem-entity.model';
import { InputMultiselectItem } from '@ct/platform-primitives-uicomponents/primitives/input-multiselect/interfaces/multiselect-item';

import { ControlType, GroupTypes, SelectBy, SelectSearchBy } from '../enums';

export interface RadioActionItem {
    checked: boolean;
    disabled: boolean;
    label: string;
    value: string;
}

export interface AddGroupFirstStepModel {
    groupName: string;
    groupType: GroupTypes;
}

export interface AddGroupSecondStepModel {
    dateRanges: Array<InputMultiselectItem>;
    descriptiveInformation: Array<InputMultiselectItem>;
    customFields: Array<CustomFieldItem>;
    selectBy: SelectBy;
    entities: Array<CemEntity>;
}

export interface AddGroupThirdStepModel {
    dateRanges: DateRangesModel;
    descriptiveInformation: DescriptiveInformationModel;
    selectedPills: any;
    entityIdForSave: Array<number>;
    selectedEntities: Array<CemEntity>;
}

export interface CategoryDetail {
    type: string;
    label: string;
    name: string;
    index: number;
    id?: string;
    shortName?: string;
    searchBy?: SelectSearchBy;
}

export interface DateRangesModel {
    from1: any;
    to1: any;
    from2: any;
    to2: any;
    from3: any;
    to3: any;
    from4: any;
    to4: any;
    option3: string;
    option4: string;
    from5: any;
    to5: any;
    option5: string;
}

export interface DescriptiveInformationModel {
    businessStructureType: Array<InputMultiselectItem>;
    durationType: Array<InputMultiselectItem>;
    entityName: Array<InputMultiselectItem>;
    entityStatus: Array<InputMultiselectItem>;
    entityType: Array<InputMultiselectItem>;
    entitySubType: string;
    country: Array<InputMultiselectItem>;
    additionalCountryInfo: string;
    jurisdiction: Array<InputMultiselectItem>;
    additionalJurisdictionInfo: string;
    primaryResponsibleUser: Array<InputMultiselectItem>;
    reasonForTermination: Array<InputMultiselectItem>;
    comment: string;
    addressType: Array<InputMultiselectItem>;
    businessPurpose: string;
    securityName: Array<InputMultiselectItem>;
    stockExchange: Array<InputMultiselectItem>;
    stockIdentifier: Array<InputMultiselectItem>;
    stockSymbol: string;
    lastModifiedBy: Array<InputMultiselectItem>;
    radioOptions: { [key: string]: string };
    customFieldGroup: { [key: string]: string };
}

export interface ServiceParams {
    type?: string;
    lookupType?: string;
    query?: { [name: string]: string };
    shortNameColumn?: string;
    keyColumn: string | number;
    displayColumn: string;
}

export interface ControlConfig {
    id: string | number;
    type: ControlType;
    options?: Array<any>;
    serviceParams?: ServiceParams;
    texts?: TextConfig;
    useTextValue?: boolean;
}

export interface TextConfig {
    label: string;
    placeholder: string;
}

export interface AddGroupParams {
    EntityGroupName?: string;
    GroupType?: GroupTypes;
    SelectBy?: string;
    CategoryJSON?: any;
    criteriaJSON?: any;
    EntityIds?: string;
    Comment?: string;
    IsImplicitAuthGroup?: 'Y' | 'N';
}

export interface AddGroupResponse {
    entityGroupId: number;
    entityGroupGuid: string;
    GroupType: string;
    Success: boolean;
}
