export interface GroupsTotalResponse {
    totalRecordCount: number;
    createdInLast30Days: number;
}
