import { GridOptions } from '@ag-grid-community/core';

export const ROW_SCROLL_HEIGHT = 50;
export const SCROLL_CACHE_MULTIPLIER = 2;
export const SCROLL_PAGE_MULTIPLIER = 3;
export const ROW_HEIGHT = 48;
export const GRID_CLICKABLE_COLUMNS = ['entityGroupName'];
export const GROUPS_FIELDS = ['entityGroupName', 'groupType', 'createdDate', 'createdBy'];

export const GRID_OPTIONS_BASE: GridOptions = {
    debounceVerticalScrollbar: true,
    rowModelType: 'infinite',
    rowData: [],
    suppressHorizontalScroll: true,
    infiniteInitialRowCount: 1,
    components: {
        loadingCellRenderer: (params) => {
            if (params.value !== undefined) {
                return params.value;
            } else {
                return 'x';
            }
        }
    },
    defaultColDef: {
        sortable: true,
        resizable: true,
        enablePivot: false,
        filter: true
    },
    sortingOrder: ['desc', 'asc'],
    suppressRowClickSelection: true,
    rowSelection: 'single'
};
