import { CustomFieldItem } from '@ct/platform-common-uicomponents/custom-fields';
import {
    GetCustomFieldsDetailsResponse,
    GetCustomFieldsValuesResponse,
    ICustomFieldsPickList
} from '@ct/platform-common-uicomponents/custom-fields-renderer';

export const mockCustomFieldsValuesResponse: {
    [key: string]: Array<ICustomFieldsPickList>;
} = {
    1: [
        {
            id: 11600009428,
            customfieldid: 100361108,
            value: 'option one update',
            index: 1,
            description: null,
            name: 'Test 1'
        },
        {
            id: 11600009429,
            customfieldid: 100361108,
            value: 'option two update',
            index: 1,
            description: null,
            name: 'Test 2'
        }
    ]
};

export const getCustomFieldsDetails: GetCustomFieldsDetailsResponse = {
    result: {
        guid: 'a96b05e0-8767-45b5-bc16-7b35cf740005',
        customFieldId: 1,
        accountId: '00100000009MQaBAAW',
        customFieldName: 'Currency',
        typeId: 302,
        typeName: 'Pick list',
        pickListValue: [
            {
                id: 11600009428,
                customfieldid: 100361108,
                value: 'option one update',
                index: 1,
                description: null
            },
            {
                id: 11600009429,
                customfieldid: 100361108,
                value: 'option two update',
                index: 1,
                description: null
            }
        ],
        description: null,
        sectionId: 201,
        isRequired: 'N',
        fieldUIMetaJson: null,
        createdBy: null
    }
};

export const mockCustomFieldsItems: Array<CustomFieldItem> = [
    {
        guid: 'a96b05e0-8767-45b5-bc16-7b35cf740005',
        customFieldId: 1,
        accountId: '00100000009MQaBAAW',
        customFieldName: 'Currency',
        type: 302,
        description: null,
        sectionId: 201,
        isRequired: 'N',
        fieldUIMetaJson: null,
        typeName: 'Pick list',
        tiedTo: 'Entity',
        appliedTo: '22',
        appliedToCount: 22,
        isRequiredLabel: 'Optional',
        createdBy: null
    }
];

export const getCustomFieldsValuesResponse: GetCustomFieldsValuesResponse = {
    result: [
        {
            customFieldId: 1,
            accountId: '00100000001mIC1AAM',
            objectId: 1234,
            sectionId: 5,
            value: 20
        },
        {
            customFieldId: 2,
            accountId: '00100000001mIC1AAM',
            objectId: 1234,
            sectionId: 5,
            value: '01/31/2023'
        },
        {
            customFieldId: 3,
            accountId: '00100000001mIC1AAM',
            objectId: 1234,
            sectionId: 5,
            value: '300'
        },
        {
            customFieldId: 4,
            accountId: '00100000001mIC1AAM',
            objectId: 1234,
            sectionId: 5,
            value: 11600009428
        }
    ]
};
