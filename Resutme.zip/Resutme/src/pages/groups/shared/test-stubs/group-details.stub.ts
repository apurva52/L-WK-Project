import { EntitiesForSpecificGroupResponse, SpecificGroupEntityItem } from "../../../../shared/interfaces/entitites-for-specific-group.response";
import { UpdateGroupDetailsResponse } from "../models/group-details";

export const entityGroupGuid = '3fd77391-b001-41a8-a528-ec3c3dc3c5a9';
export const groupDetails = {
    "comment": "test Comment-1",
    "entityGroupId": 7,
    "entityGroupGuid": "0224c92a-2f2a-4192-8755-8515d4d62ec0",
    "entityGroupName": "Dynamci-EntityGroupTest-Validation-4",
    "groupType": "D",
    "criteriaJSON": {
        "Entity Type": "LLC",
        "Entity Status": "Active",
        "Juridiction": "FL, GA, AL, SC, NC, MI, LA"
    },
    "isImplicitAuthGroup": "N",
    "createdBy": "Ajay Thite",
    "createdByName": "Ajay Thite",
    "createdDate": "2022-09-21T10:17:27.2131172"
};
export const groupEntities = [
    {
        "entityId": 11000258230,
        "entityGuid": "8a3bf532-5fc4-4aa4-9fdb-e350db8b5a75",
        "entityName": "1270 Spring  Street Development,  LLC",
        "entityTypeId": 30006,
        "entityTypeDesc": "Association",
        "countryId": 50001,
        "countryDesc": "United States",
        "countryShortName": "USA",
        "domesticJurisdictionId": 8,
        "domesticJurisdictionDesc": "Delaware",
        "domesticJurisdictionCode": "DE",
        "activeForeignJurisCount": 1,
        "totalForeignJurisCount": 2
    },
    {
        "entityId": 11003434431,
        "entityGuid": "138ded1f-e808-45a4-9b99-84445140772c",
        "entityName": "14 East Fifty-Fifth Street New York LLC",
        "entityTypeId": 30006,
        "entityTypeDesc": "Association",
        "countryId": 50001,
        "countryDesc": "United States",
        "countryShortName": "USA",
        "domesticJurisdictionId": 8,
        "domesticJurisdictionDesc": "Delaware",
        "domesticJurisdictionCode": "DE",
        "activeForeignJurisCount": 0,
        "totalForeignJurisCount": 0
    }
];

export const entitiesList: Array<SpecificGroupEntityItem> = [
    {
        entityId: 123,
        entityGuid: '6e9237b8-02b6-4fc1-9fd2-1ab58c137387',
        entityName: 'Entity 1',
        countryId: 42,
        countryShortName: 'USA',
        countryDesc: 'United States',
        domesticJurisdictionId: 202,
        domesticJurisdictionDesc: 'Alabama',
        domesticJurisdictionCode: 'AL',
        entityTypeId: 1,
        entityTypeDesc: 'LLC',
        activeForeignJurisCount: 0,
        totalForeignJurisCount: 0
    }, {
        entityId: 456,
        entityGuid: '11111111-2222-4fc1-9fd2-1ab58c137387',
        entityName: 'Entity 2',
        countryId: 42,
        countryShortName: 'USA',
        countryDesc: 'United States',
        domesticJurisdictionId: 202,
        domesticJurisdictionDesc: 'Alabama',
        domesticJurisdictionCode: 'AL',
        entityTypeId: 1,
        entityTypeDesc: 'LLC',
        activeForeignJurisCount: 0,
        totalForeignJurisCount: 0
    }
];

export const entitiesListResponse: EntitiesForSpecificGroupResponse = {
    totalRecordCount: 2,
    page: 1,
    pageSize: 2,
    data: [...entitiesList]
}

export const updateGroupDetailsResponse: UpdateGroupDetailsResponse = {
    result: {
        entityGroupId: 1,
        entityGroupGuid: '1-1-1',
        groupType: '1',
        success: true
    }
}

export const groupEntitiesResponse: EntitiesForSpecificGroupResponse = {
    data: [...groupEntities],
    totalRecordCount: 2,
    page: 1,
    pageSize: 2
};


export const groupEntitiesDeleteResponse = {
    "result": true
};

export const groupDetailsResponse = {
    result: [
        {...groupDetails}
    ]
}
export const groupDetailsUpdateResponse = {
    "result": {
        "entityGroupId": 6,
        "entityGroupGuid": "337afc2f-b72a-4705-8e1b-0fadd73983a4",
        "groupType": "D",
        "success": true
    }
};
export const breadcrumbsStub = [
    {
        "name": "Home",
        "link": "/dashboard",
        "disabled": false,
        "alwaysPresent": true
    },
    {
        "name": "Account Tools",
        "link": "/account-tools",
        "disabled": false,
        "alwaysPresent": false
    },
    {
        "name": "Groups",
        "link": "/account-tools/groups",
        "disabled": false,
        "alwaysPresent": false
    },
    {
        "name": `Test`,
        "link": `account-tools/groups/detail/${groupDetails.entityGroupGuid}`,
        "disabled": true,
        "rel": JSON.stringify({
            entityGroupGuid: groupDetails.entityGroupGuid,
            entityGroupName: groupDetails.entityGroupName,
            groupType: groupDetails.groupType,
            createdBy: groupDetails.createdBy,
            createdDate: groupDetails.createdDate
        })
    }
];