export enum CategoriesInfo {
    LAST_MODIFIED_BY = 'lastModifiedBy',
    ADDRESS_TYPE = 'addressType',
    BUSINESS_PURPOSE = 'businessPurpose',
    BUSINESS_STRUCTURE_TYPE = 'businessStructureType',
    COMMENT = 'comment',
    DURATION_TYPE = 'durationType',
    ENTITY_NAME = 'entityName',
    ENTITY_STATUS = 'entityStatus',
    ENTITY_TYPE = 'entityType',
    ENTITY_SUB_TYPE = 'entitySubType',
    COUNTRY = 'country',
    ADDITIONAL_COUNTRY_INFO = 'additionalCountryInfo',
    JURISDICTION = 'jurisdiction',
    ADDITIONAL_JURISDICTION_INFO = 'additionalJurisdictionInfo',
    PRIMARY_RESPONSIBLE_USER = 'primaryResponsibleUser',
    REASON_FOR_TERMINATION = 'reasonForTermination',
    SECURITY_NAME = 'securityName',
    STOCK_EXCHANGE = 'stockExchange',
    STOCK_IDENTIFIER = 'stockIdentifier',
    STOCK_SYMBOL = 'stockSymbol',
    CUSTOM_FIELD_GROUP = 'customFieldGroup'
}

export enum ControlType {
    TEXT,
    TEXT_OPTIONS,
    MULTI_SELECT,
    REFERENCE_MULTI_SELECT,
    ENTITY_MULTI_SELECT,
    CUSTOM_FIELDS
}