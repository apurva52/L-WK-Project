export enum GroupTypes {
    DYNAMIC = 'D',
    STATIC = 'S'
}

export enum SelectBy {
    ENTITY_NAME = 'Entities',
    CATEGORY = 'Category'
}

export enum DuplicateStatus {
    PENDING = 'Pending',
    DONE = 'Done'
}

export enum SelectSearchBy {
    STARTS_WITH = 'starts with',
    ENDS_WITH = 'ends with',
    CONTAINS = 'contains'
}

export enum GroupSaveStatus {
    Preselected = 1,
    InProgress = 2,
    Success = 3,
    Failed = 4
}

export enum CurrentStep {
    stepOne = 0,
    stepTwo = 1,
    stepThree = 2,
    stepStaticSuccess = 3,
    stepStaticFailure = 4
}
