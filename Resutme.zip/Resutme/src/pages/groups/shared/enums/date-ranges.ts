export enum DateRangesInfo {
    FROM1 = 'from1',
    TO1 = 'to1',
    FROM2 = 'from2',
    TO2 = 'to2',
    FROM3 = 'from3',
    TO3 = 'to3',
    FROM4 = 'from4',
    TO4 = 'to4',
    FROM5 = 'from5',
    TO5 = 'to5'
}

export enum DateRagesIntervals {
    BETWEEN = 'Between',
    BEFORE = 'LessThan',
    AFTER = 'GreaterThan'
}

export enum DateRangesType {
    SINGLE = 'Single',
    INTERVAL = 'Interval'
}