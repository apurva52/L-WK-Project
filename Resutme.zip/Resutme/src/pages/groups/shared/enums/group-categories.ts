export enum GroupCategories {
    CUSTOM_FIELDS = 'customFields',
    DATE_RANGES = 'dateRanges',
    DESCRIPTIVE_INFORMATION = 'descriptiveInformation',
    STOCK_INFORMATION = 'stockInformation',
    ADMINISTRATION = 'administration',
    SELECTED_PILLS = 'selectedPills'
}
