import { ColumnApi, GridApi, GridOptions } from '@ag-grid-community/core';

import { GroupListItem } from '../models';

export const groupsListMock: Array<GroupListItem> = [
    {
        createdBy: 'John Smith',
        createdDate: '31-01-1998',
        criteriaJSON: '',
        entityGroupGuid: '1',
        entityGroupId: 1,
        entityGroupName: 'Smith Group',
        groupType: 'D',
        isImplicitAuthGroup: 'Y',
        sfAccountId: '1',
        createdByName: 'John Smith'
    }
];


export const groupsTableGridOptions: GridOptions = {
    api: new GridApi(),
    columnApi: new ColumnApi(),
    rowModelType: 'infinite',
    cacheBlockSize: 20,
    paginationPageSize: 30,
    rowData: [],
    suppressHorizontalScroll: true,
    infiniteInitialRowCount: 1,
    components: {
        loadingCellRenderer: (params) => { }
    },
    defaultColDef: {
        sortable: false,
        resizable: false,
        enablePivot: false
    },
    suppressRowClickSelection: true,
    rowSelection: 'single'
};


