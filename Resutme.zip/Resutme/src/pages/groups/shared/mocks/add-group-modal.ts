// tslint:disable:max-file-line-count
import { CustomFieldItem } from '@ct/platform-common-uicomponents/custom-fields';

import { AddGroupModalState } from '../../state/add-group-modal/add-group-modal.state';
import { addGroupStepsModel } from '../constants';
import {
    DateRagesIntervals,
    DuplicateStatus,
    GroupCategories,
    GroupTypes
} from '../enums';
import { AddGroupParams, AddGroupResponse } from '../models';

export const stubTranslatedSteps = [
    {
        nextLabel: 'Next',
        title: 'Please enter a name and define the type for the New Group',
        previousLabel: 'Previous',
        validation: false
    },
    {
        nextLabel: 'Next',
        title: 'Please choose New Group categories. A maximum of 5 categories can be selected.',
        previousLabel: 'Previous',
        validation: false
    },
    {
        nextLabel: 'Save',
        title: 'Please select criteria for each category of the New Group',
        previousLabel: 'Previous',
        validation: false
    }
];

export const mockWizardSteps = [
    {
        isActive: true,
        isFailed: false,
        isVisited: false,
        stepId: 1,
        description: ''
    },
    {
        isActive: false,
        isFailed: false,
        isVisited: false,
        stepId: 2,
        description: ''
    },
    {
        isActive: false,
        isFailed: false,
        isVisited: false,
        stepId: 3,
        description: ''
    }
];

export const mockAddGroupState: AddGroupModalState = {
    activeStep: 1,
    addGroup: 'Test',
    isGroupNameDuplicate: false,
    firstStepModel: {
        groupName: 'Group Name',
        groupType: GroupTypes.DYNAMIC
    },
    ...addGroupStepsModel,
    isOpen: true,
    loading: true,
    selectIsOutOfLimit: false,
    successNotificationOpen: false,
    errorNotificationOpen: false,
    noMatchingEntityNotificationOpen: false,
    customFieldsPickList: null,
    duplicateStatus: DuplicateStatus.PENDING
};

export const mockAddGroupDateRanges = [
    {
        id: '1',
        label: 'Date Ranges',
        isSelected: false
    },
    {
        id: '2',
        label: 'Fiscal Year End',
        isSelected: false
    },
    {
        id: '3',
        label: 'Formation Date',
        isSelected: false
    },
    {
        id: '4',
        label: 'Termination Date',
        isSelected: false
    }
];

export const mockAddGroupCountryData = [
    {
        shortName: '1',
        name: 'Option1',
        isSelected: false
    },
    {
        shortName: '2',
        name: 'Option2',
        isSelected: false
    },
    {
        shortName: '3',
        name: 'Option3',
        isSelected: false
    },
    {
        shortName: '4',
        name: 'Option4',
        isSelected: false
    }
];

export const mockAddGroupReferenceData = [
    {
        id: '1',
        name: 'Option1',
        isSelected: false
    },
    {
        id: '2',
        name: 'Option2',
        isSelected: false
    },
    {
        id: '3',
        name: 'Option3',
        isSelected: false
    },
    {
        id: '4',
        name: 'Option4',
        isSelected: false
    }
];

export const customFieldItems: Array<Partial<CustomFieldItem>> = [
    {
        guid: 'guid'
    }
];

export const groupCategoriesPipeMock = [
    {
        id: '1',
        label: 'Date Ranges',
        isSelected: false,
        index: 0,
        type: GroupCategories.DATE_RANGES
    },
    {
        id: '2',
        label: 'Fiscal Year End',
        isSelected: false,
        index: 1,
        type: GroupCategories.DATE_RANGES
    },
    {
        id: '3',
        label: 'Formation Date',
        isSelected: false,
        index: 2,
        type: GroupCategories.DATE_RANGES
    },
    {
        id: '4',
        label: 'Termination Date',
        isSelected: false,
        index: 3,
        type: GroupCategories.DATE_RANGES
    },
    {
        id: '1',
        label: 'Date Ranges',
        isSelected: false,
        index: 0,
        type: GroupCategories.DESCRIPTIVE_INFORMATION
    },
    {
        id: '2',
        label: 'Fiscal Year End',
        isSelected: false,
        index: 1,
        type: GroupCategories.DESCRIPTIVE_INFORMATION
    },
    {
        id: '3',
        label: 'Formation Date',
        isSelected: false,
        index: 2,
        type: GroupCategories.DESCRIPTIVE_INFORMATION
    },
    {
        id: '4',
        label: 'Termination Date',
        isSelected: false,
        index: 3,
        type: GroupCategories.DESCRIPTIVE_INFORMATION
    },
    {
        id: '1',
        label: 'Date Ranges',
        isSelected: false,
        index: 0,
        type: GroupCategories.STOCK_INFORMATION
    },
    {
        id: '2',
        label: 'Fiscal Year End',
        isSelected: false,
        index: 1,
        type: GroupCategories.STOCK_INFORMATION
    },
    {
        id: '3',
        label: 'Formation Date',
        isSelected: false,
        index: 2,
        type: GroupCategories.STOCK_INFORMATION
    },
    {
        id: '4',
        label: 'Termination Date',
        isSelected: false,
        index: 3,
        type: GroupCategories.STOCK_INFORMATION
    },
    {
        id: '1',
        label: 'Date Ranges',
        isSelected: false,
        index: 0,
        type: GroupCategories.ADMINISTRATION
    },
    {
        id: '2',
        label: 'Fiscal Year End',
        isSelected: false,
        index: 1,
        type: GroupCategories.ADMINISTRATION
    },
    {
        id: '3',
        label: 'Formation Date',
        isSelected: false,
        index: 2,
        type: GroupCategories.ADMINISTRATION
    },
    {
        id: '4',
        label: 'Termination Date',
        isSelected: false,
        index: 3,
        type: GroupCategories.ADMINISTRATION
    },
    {
        guid: 'guid',
        index: 0,
        type: GroupCategories.CUSTOM_FIELDS
    }
];

export const addGroupMock: AddGroupParams = {
    CategoryJSON: null,
    Comment: 'Some comment',
    criteriaJSON: null,
    EntityGroupName: null,
    EntityIds: null,
    GroupType: GroupTypes.DYNAMIC,
    SelectBy: null
};

export const addGroupResponseMock: AddGroupResponse = {
    entityGroupId: 938373543637,
    entityGroupGuid: 'ed701ee2-4680-49bd-8ebe-e8f356832167',
    GroupType: 'S',
    Success: true
};

export const descriptiveInformationsMock: any = {
    businessStructureType: [
        {
            name: '(European investors)',
            label: 'Business Structure Type: ',
            value: 510134063,
            id: 510134063
        }
    ],
    durationType: [
        {
            name: 'Perpetual',
            label: 'Duration Type: ',
            value: 80001,
            id: 80001
        }
    ],
    entityName: [],
    entityStatus: [],
    entityType: [],
    entitySubType: null,
    country: [],
    additionalCountryInfo: null,
    jurisdiction: [],
    additionalJurisdictionInfo: null,
    primaryResponsibleUser: [],
    reasonForTermination: [],
    comment: null
};

export const categoryJsonMock = {
    Categories: {
        categoryCoreInfoList: {
            CategoryCoreInfo: [
                {
                    CategoryClassName: null,
                    CategoryId: 'X0063UO3856AVQ12C31ACP',
                    CategoryMetaId: 'CATBUSINESSSTRUCTURE',
                    CategoryMetaName: 'BusinessStructure',
                    CategoryType: 'MultiSelectCategory',
                    CriteriaMetaList: {
                        CriteriaMeta: {
                            IdRef: 'catBusinessStructure',
                            Title: null
                        }
                    },
                    CustomDBFieldName: null,
                    IsAdvancedSearch: 'false',
                    Operator: 'In',
                    Value: {
                        '#tex': '510134063',
                        '@p5:type': 'q4:string'
                    }
                },
                {
                    CategoryClassName: null,
                    CategoryId: 'X0063UO3856AVQ0M1G06S0',
                    CategoryMetaId: 'CATDURATIONTYPE',
                    CategoryMetaName: 'DurationType',
                    CategoryType: 'MultiSelectCategory',
                    CriteriaMetaList: {
                        CriteriaMeta: {
                            IdRef: 'catDurationType',
                            Title: null
                        }
                    },
                    CustomDBFieldName: null,
                    IsAdvancedSearch: 'false',
                    Operator: 'In',
                    Value: {
                        '#tex': '80001',
                        '@p5:type': 'q4:string'
                    }
                }
            ]
        }
    }
};

export const dateRangesFormMock = {
    from1: {
        label: 'Bylaws Meeting Month From: ',
        value: '10'
    },
    to1: {
        label: 'Bylaws Meeting Month To: ',
        value: '1'
    },
    from2: {
        label: 'from2',
        value: '12/12/2022'
    },
    to2: {
        label: 'to2',
        value: '11/14/2022'
    },
    from3: {
        label: 'from3',
        value: '12/12/2022'
    },
    to3: {
        label: 'to3',
        value: '11/14/2022'
    },
    from4: {
        label: 'from4',
        value: '12/12/2022'
    },
    to4: {
        label: 'to4',
        value: '11/14/2022'
    },
    from5: {
        label: 'from5',
        value: '12/12/2022'
    },
    to5: {
        label: 'to5',
        value: '11/14/2022'
    },
    option3: DateRagesIntervals.BETWEEN,
    option4: DateRagesIntervals.BETWEEN,
    option5: '1'
};

export const existingDates = {
    from2: dateRangesFormMock.from2.value,
    to2: dateRangesFormMock.to2.value,
    from3: dateRangesFormMock.from3.value,
    to3: dateRangesFormMock.to3.value,
    from4: dateRangesFormMock.from4.value,
    to4: dateRangesFormMock.to4.value,
    from5: dateRangesFormMock.from5.value,
    to5: dateRangesFormMock.to5.value
};

export const formationDateIntervalCategoryJsonMock = {
    CategoryClassName: null,
    CategoryId: 'X0061PV03UA4MO1MSA1AF7',
    CategoryMetaId: 'CATFORMATIONDATE',
    CategoryMetaName: 'FormationDate',
    CategoryType: 'DateRangeCategory',
    CriteriaMetaList: {
        CriteriaMeta: {
            IdRef: 'catFormationDate',
            Title: null
        }
    },
    CustomDBFieldName: null,
    IsAdvancedSearch: 'false',
    Operator: 'Between',
    Value: {
        '#text': '12/12/2022',
        '@p5:type': 'q1:dateTime'
    },
    Value2: {
        '#text': '11/14/2022',
        '@p5:type': 'q2:dateTime'
    }
};

export const formationDateSingleCategoryJsonMock = {
    CategoryClassName: null,
    CategoryId: 'X003SPT04G93NA1Q3U0NHF',
    CategoryMetaId: 'CATFORMATIONDATE',
    CategoryMetaName: 'Formation Date',
    CategoryType: 'DateRangeCategory',
    CriteriaMetaList: {
        CriteriaMeta: {
            IdRef: 'catFormationDate',
            Title: null
        }
    },
    CustomDBFieldName: null,
    IsAdvancedSearch: 'true',
    Operator: 'GreaterThan',
    Value: {
        '#tex': '12/12/2022',
        '@p5:type': ''
    }
};

export const dateRangesCriteriaMock = {
    'Bylaws Meeting Month From: ': '10',
    'Bylaws Meeting Month To: ': '1',
    from2: '12/12/2022',
    to2: '11/14/2022',
    from3: '12/12/2022',
    to3: '11/14/2022',
    from4: '12/12/2022',
    to4: '11/14/2022',
    from5: '12/12/2022',
    to5: '11/14/2022'
};

export const mockAddGroupEntityName = [
    {
        entityId: 11000532544,
        EntityId: 11000532544,
        entityGuid: 'd4d0cf2e-fd5a-4fb6-a2cb-ca2a059c3be1',
        entityName: 'Test entity',
        ENTITY_NAME: 'Test entity',
        acronym: null,
        domesticJurisdictionId: 1,
        domesticJurisdictionCode: 'AL',
        domesticJurisdictionDesc: 'Alabama',
        DOMESTIC_JURISDICTION: 'Alabama',
        entityTypeId: 30001,
        entityTypeDesc: 'Aruba Exempt Corporation',
        status: 'Active - Non Dormant',
        formationDate: '2017-10-03T00:00:00'
    },
    {
        entityId: 11000573295,
        EntityId: 11000573295,
        entityGuid: '72d69118-0f64-4f42-b5f1-b4c43e861cdc',
        entityName: 'Test Entity 01',
        ENTITY_NAME: 'Test Entity 01',
        acronym: null,
        domesticJurisdictionId: 8,
        domesticJurisdictionCode: 'DE',
        domesticJurisdictionDesc: 'Delaware',
        DOMESTIC_JURISDICTION: 'Delaware',
        entityTypeId: 30006,
        entityTypeDesc: 'Association',
        status: 'Active - Non Dormant',
        formationDate: '2020-08-12T00:00:00'
    }
];
