// tslint:disable-next-line
export const entityStatusMockData = [{"label":"Active - Non Dormant","id":"40001"},{"label":"Inactive","id":"40003"}]