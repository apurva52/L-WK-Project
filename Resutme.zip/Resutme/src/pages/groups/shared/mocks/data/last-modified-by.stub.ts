// tslint:disable-next-lineexport 
export const lastModifiedByMockData = [
    { "id": "1", "label": "Meir Blonder" },
    { "id": "2", "label": "Amerihealth Demo" },
    { "id": "3", "label": "Amy Wood" }
]