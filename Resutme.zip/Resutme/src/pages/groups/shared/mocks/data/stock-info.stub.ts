
export const securityNameOptions = [
    {
        id: '1',
        label: 'Common Stock',
        isSelected: false
    },
    {
        id: '2',
        label: 'Economic Ownership',
        isSelected: false
    },
    {
        id:'3',
        label: 'Equity Interests',
        isSelected: false
    },
    {
        id: '4',
        label:'Legal Ownership',
        isSelected: false
    },
    {
        id: '5',
        label: 'Membership Units',
        isSelected: false
    },
    {
        id: '6',
        label: 'Non-share Ownership',
        isSelected: false
    },
    {
        id: '7',
        label: 'Percentage Ownership',
        isSelected: false
    },
    {
        id: '8',
        label: 'Profits Ownership',
        isSelected: false
    },
    {
        id: '9',
        label: 'Preferred Stock',
        isSelected: false
    }
];

export const stockExchangeOptions = [
    {
        id: '1',
        label: 'AMEX',
        isSelected: false
    },
    {
        id: '2',
        label: 'CBOE',
        isSelected: false
    },
    {
        id: '3',
        label: 'NASD',
        isSelected: false
    },
    {
        id: '4',
        label:'NYSE',
        isSelected: false
    }
];

export const stockIdentifierOptions = [
    {
        id: '1',
        label: 'CUSIP',
        isSelected: false
    },
    {
        id: '2',
        label: 'HBUC',
        isSelected: false
    }
];