import { createFeatureSelector, createSelector } from '@ngrx/store';

import { GROUPS_FEATURE_KEY, GroupsState } from './groups.state';

export const selectRootFeature = createFeatureSelector<GroupsState>(GROUPS_FEATURE_KEY);

export const selectGroupsLoading = createSelector(selectRootFeature, state => state.loading);
export const selectGroupsTotalRecordCount = createSelector(selectRootFeature, state => state.totalRecordCount);
export const selectGroupsCreatedInLast30Days = createSelector(selectRootFeature, state => state.createdInLast30Days);
export const selectSelections = createSelector(selectRootFeature, state => state.selections);
export const selectSelectionsCount = createSelector(selectRootFeature, state => state.selections.length);
export const selectedGroupItem = createSelector(selectRootFeature, state => state.selectedGroup);
export const selectGroupRemovalNotification = createSelector(selectRootFeature, state => state.isGroupDeletedSuccessfully);
export const selectIsDeleteGroupWarningNotVisible = createSelector(selectRootFeature, state => state?.isDeleteGroupWarningNotVisible);
