import { SpecificGroupEntityItem } from '../../../../shared/interfaces/entitites-for-specific-group.response';
import { GroupDetails } from '../../shared/models/group-details';

export const GROUP_DETAILS_FEATURE_KEY = 'groupsDetailsFeatureKey';

export interface GroupsDetailsState {
    isGroupDetailsLoading: boolean;
    entities: Array<SpecificGroupEntityItem>;
    entitiesTotal: number;
    entitiesSelected: Array<SpecificGroupEntityItem>;
    entitiesSelectedTotal: number;
    details: GroupDetails;
    isSummaryEditing: boolean;
    isGroupEntitiesLoading: boolean;
    isUpdateDetailsLoading: boolean;
    updateDetailsSuccessStatus: any;
    errorMessage: string;
    errorNotificationOpen: boolean;
    warningNotificationOpen: boolean;
    successNotificationOpen: boolean;
    switcherReloadRequired: boolean;
    isCommentOpen: boolean;
    isAddEntityOpen: boolean;
    deleteEntitiesWarningNotification: boolean;
}

export const initialState: GroupsDetailsState = {
    isGroupDetailsLoading: false,
    entities: [],
    entitiesTotal: 0,
    entitiesSelected: [],
    entitiesSelectedTotal: 0,
    details: null,
    isSummaryEditing: false,
    isGroupEntitiesLoading: false,
    isUpdateDetailsLoading: false,
    updateDetailsSuccessStatus: null,
    errorMessage: null,
    errorNotificationOpen: false,
    warningNotificationOpen: false,
    successNotificationOpen: false,
    switcherReloadRequired: false,
    isCommentOpen: false,
    isAddEntityOpen: false,
    deleteEntitiesWarningNotification: false
};