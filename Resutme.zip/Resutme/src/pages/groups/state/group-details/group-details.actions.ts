import { EntitySearchDataModel } from '@ct/platform-common-uicomponents/entity-reference';
import { createAction, props } from '@ngrx/store';

import { EntitiesRequest } from '../../../../shared/interfaces/entities.request';
import { EntitiesForSpecificGroupResponse } from '../../../../shared/interfaces/entitites-for-specific-group.response';
import {
    GroupDetails,
    UpdateGroupDetailsResponse
} from '../../shared/models/group-details';

import { EntitiesSelectParams } from './entities.selectParams';

export enum GroupDetailsActionTypes {
    SpecificGroupDetails = '[Group Details] Get Specific Group Details',
    SpecificGroupDetailsSuccess = '[Group Details] Get Specific Group Details Success',
    SpecificGroupDetailsFailure = '[Group Details] Get Specific Group Details Failure',
    GroupEntitiesList = '[Group Details] Get Entities List',
    GroupEntitiesListSuccess = '[Group Details] Get Entities List Success',
    GroupEntitiesListFailure = '[Group Details] Get Entities List Failure',
    GroupEntitiesSelectClearAll = `[Group Details] Clear Entities Selection`,
    GroupEntitiesSelect = `[Group Details] Select an entity`,
    EditGroupDetails = '[Group Details] Edit group details',
    UpdateGroupDetails = '[Group Details] Update group details',
    UpdateGroupDetailsSuccess = '[Group Details] Update group details Success',
    UpdateGroupDetailsFailure = '[Group Details] Update group details Failure',
    SetSuccessNotificationStatus = '[Group Details] Set Success Notification Status',
    SetErrorNotificationStatus = '[Group Details] Set Error Notification Status',
    SetWarningNotificationStatus = '[Group Details] Set Warning Notification Status',
    OpenComment = '[Group Details] Open Comment',
    CloseComment = '[Group Details] Close Comment',
    OpenAddEntityModal = '[Group Details] Open Add Entity Modal',
    CloseAddEntityModal = '[Group Details] Close Add Entity Modal',
    AddEntityToGroup = '[Group Details] Add Entity To Group',
    DeleteEntity = '[Group Details] Delete Entity',
    DeleteEntitySuccess = '[Group Details] Delete Entity Success',
    DeleteEntitiesWarningNotificationStatus = '[Group Details] Delete Bulk Entities Show Warning Notification',
    DeleteBulkEntities = '[Group Details] Delete Bulk Entities',
    DeleteBulkEntitiesSuccess = '[Group Details] Delete Bulk Entities Success',
    DeleteBulkEntitiesFailure = '[Group Details] Delete Bulk Entities Failure'
}

const groupDetails = createAction(
    GroupDetailsActionTypes.SpecificGroupDetails,
    props<{
        entityGroupGuid: string;
    }>()
);

const groupDetailsSuccess = createAction(
    GroupDetailsActionTypes.SpecificGroupDetailsSuccess,
    props<{
        result: GroupDetails;
    }>()
);

const groupDetailsFailure = createAction(
    GroupDetailsActionTypes.SpecificGroupDetailsFailure,
    props<{
        error: string;
    }>()
);

const groupEntitiesList = createAction(
    GroupDetailsActionTypes.GroupEntitiesList,
    props<EntitiesRequest>()
);

const groupEntitiesListSuccess = createAction(
    GroupDetailsActionTypes.GroupEntitiesListSuccess,
    props<{
        response: EntitiesForSpecificGroupResponse;
    }>()
);

const groupEntitiesListFailure = createAction(
    GroupDetailsActionTypes.GroupEntitiesListFailure
);

const groupEntitiesSelectClearAll = createAction(
    GroupDetailsActionTypes.GroupEntitiesSelectClearAll
);

const groupEntitiesSelect = createAction(
    GroupDetailsActionTypes.GroupEntitiesSelect,
    props<{
        entitiesSelectParams: EntitiesSelectParams;
    }>()
);

const deleteEntity = createAction(
    GroupDetailsActionTypes.DeleteEntity,
    props<{
        entityGroupGuid: string;
        entityIds: string;
    }>()
);

const deleteEntitySuccess = createAction(
    GroupDetailsActionTypes.DeleteEntitySuccess,
    props<{ result: boolean; entityId: string }>()
);

const editGroupDetails = createAction(
    GroupDetailsActionTypes.EditGroupDetails,
    props<{
        isEditing: boolean;
    }>()
);

const updateGroupDetails = createAction(
    GroupDetailsActionTypes.UpdateGroupDetails,
    props<{
        comment: string;
        entityGroupName: string;
    }>()
);

const updateGroupDetailsSuccess = createAction(
    GroupDetailsActionTypes.UpdateGroupDetailsSuccess,
    props<{
        result: UpdateGroupDetailsResponse;
    }>()
);

const updateGroupDetailsFailure = createAction(
    GroupDetailsActionTypes.UpdateGroupDetailsFailure,
    props<{
        error: string;
    }>()
);

const setSuccessNotificationOpenAction = createAction(
    GroupDetailsActionTypes.SetSuccessNotificationStatus,
    props<{
        open: boolean;
    }>()
);

const setErrorNotificationOpenAction = createAction(
    GroupDetailsActionTypes.SetErrorNotificationStatus,
    props<{
        open: boolean;
    }>()
);

const setWarningNotificationOpenAction = createAction(
    GroupDetailsActionTypes.SetWarningNotificationStatus,
    props<{
        open: boolean;
    }>()
);

const openComment = createAction(GroupDetailsActionTypes.OpenComment);

const closeComment = createAction(GroupDetailsActionTypes.CloseComment);

const openAddEntityModal = createAction(
    GroupDetailsActionTypes.OpenAddEntityModal
);

const closeAddEntityModal = createAction(
    GroupDetailsActionTypes.CloseAddEntityModal
);

const addEntityToGroup = createAction(
    GroupDetailsActionTypes.AddEntityToGroup,
    props<{
        entityGroupGuid: string;
        entitiesToAdd: Array<EntitySearchDataModel>;
    }>()
);

const deleteEntitiesWarningNotification = createAction(
    GroupDetailsActionTypes.DeleteEntitiesWarningNotificationStatus,
    props<{
        open: boolean;
    }>()
);

const deleteBulkEntities = createAction(
    GroupDetailsActionTypes.DeleteBulkEntities
);

const deleteBulkEntitiesSuccess = createAction(
    GroupDetailsActionTypes.DeleteBulkEntitiesSuccess,
    props<{
        result: boolean;
    }>()
);

const deleteBulkEntitiesFailure = createAction(
    GroupDetailsActionTypes.DeleteBulkEntitiesFailure,
    props<{
        error: string;
    }>()
);

export const groupDetailsActions = {
    groupDetails,
    groupDetailsSuccess,
    groupDetailsFailure,
    groupEntitiesList,
    groupEntitiesListSuccess,
    groupEntitiesListFailure,
    groupEntitiesSelectClearAll,
    groupEntitiesSelect,
    editGroupDetails,
    updateGroupDetails,
    updateGroupDetailsSuccess,
    updateGroupDetailsFailure,
    setSuccessNotificationOpenAction,
    setErrorNotificationOpenAction,
    setWarningNotificationOpenAction,
    openComment,
    closeComment,
    openAddEntityModal,
    closeAddEntityModal,
    addEntityToGroup,
    deleteEntity,
    deleteEntitySuccess,
    deleteEntitiesWarningNotification,
    deleteBulkEntities,
    deleteBulkEntitiesSuccess,
    deleteBulkEntitiesFailure
};
