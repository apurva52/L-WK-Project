/* tslint:disable:max-file-line-count */
/* tslint:disable:max-line-length */
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { forkJoin, from, of } from 'rxjs';
import { catchError, map, switchMap, withLatestFrom } from 'rxjs/operators';

import { EntitiesService } from '../../../../shared/services/entities/entities.service';
import { GroupsService } from '../../../../shared/services/groups/groups.service';
import { GroupTypes } from '../../shared';
import { UpdateGroupDetailsRequest } from '../../shared/models/group-details';

import { groupDetailsActions } from './group-details.actions';
import * as selectors from './group-details.selectors';

@Injectable()
export class GroupDetailsEffects {
    groupDetails$ = createEffect(() =>
        this.actions$.pipe(
            ofType(groupDetailsActions.groupDetails),
            switchMap((params) => {
                return from(
                    this.groupsService.getGroupDetails(params.entityGroupGuid)
                ).pipe(
                    map((response) =>
                        groupDetailsActions.groupDetailsSuccess({
                            result: response.result[0]
                        })
                    ),
                    catchError((err) =>
                        of(
                            groupDetailsActions.groupDetailsFailure({
                                error: err
                            })
                        )
                    )
                );
            })
        )
    );

    getEntitiesListAfterDetails$ = createEffect(() =>
        this.actions$.pipe(
            ofType(groupDetailsActions.groupDetailsSuccess),
            switchMap((detials) => {
                return of(
                    groupDetailsActions.groupEntitiesList({
                        groupGuid: detials.result.entityGroupGuid
                    })
                );
            })
        )
    );

    loadEntitiesList$ = createEffect(() =>
        this.actions$.pipe(
            ofType(groupDetailsActions.groupEntitiesList),
            switchMap((params) => {
                return from(
                    this.entitiesService.getEntitiesListForSpecificGroup(
                        params.groupGuid
                    )
                ).pipe(
                    map((response) =>
                        groupDetailsActions.groupEntitiesListSuccess({
                            response
                        })
                    ),
                    catchError((err) =>
                        of(groupDetailsActions.groupEntitiesListFailure())
                    )
                );
            })
        )
    );

    deleteEntity$ = createEffect(() =>
        this.actions$.pipe(
            ofType(groupDetailsActions.deleteEntity),
            switchMap((_params) => {
                const groupGuId = _params.entityGroupGuid;
                const entitiesGuId = _params.entityIds;

                return from(
                    this.entitiesService.deleteEntity(groupGuId, entitiesGuId)
                ).pipe(
                    map((_response) => {
                        return groupDetailsActions.deleteEntitySuccess({
                            result: _response.result,
                            entityId: entitiesGuId
                        });
                    })
                );
            })
        )
    );

    fetchGroupDetailsOnUpdate$ = createEffect(() =>
        this.actions$.pipe(
            ofType(groupDetailsActions.updateGroupDetailsSuccess),
            withLatestFrom(this.store$.select(selectors.selectGroupDetails)),
            switchMap(([action, groupDetails]) => {
                return from(
                    this.groupsService.getGroupDetails(
                        groupDetails.entityGroupGuid
                    )
                ).pipe(
                    map((response) =>
                        groupDetailsActions.groupDetailsSuccess({
                            result: response.result[0]
                        })
                    ),
                    catchError((err) =>
                        of(
                            groupDetailsActions.groupDetailsFailure({
                                error: err
                            })
                        )
                    )
                );
            })
        )
    );

    saveGroupDetails$ = createEffect(() =>
        this.actions$.pipe(
            ofType(groupDetailsActions.updateGroupDetails),
            withLatestFrom(
                this.store$.select(
                    selectors.selectUpdateGroupDetailsRequestBase
                )
            ),
            switchMap(([action, { entityGroupGuid, groupType, entityIds }]) => {
                const request: UpdateGroupDetailsRequest = {
                    EntityGroupName: action.entityGroupName,
                    Comment: action.comment,
                    entityGroupGuid: entityGroupGuid
                };

                if (groupType === GroupTypes.STATIC) {
                    request.EntityIds = entityIds;
                }

                return from(
                    this.groupsService.updateGroupDetails(request)
                ).pipe(
                    map((response) =>
                        groupDetailsActions.updateGroupDetailsSuccess({
                            result: response.result
                        })
                    ),
                    catchError((err) =>
                        of(
                            groupDetailsActions.updateGroupDetailsFailure({
                                error: err
                            })
                        )
                    )
                );
            })
        )
    );

    closeModalAfterUpdate$ = createEffect(() =>
        this.actions$.pipe(
            ofType(groupDetailsActions.updateGroupDetailsSuccess),
            switchMap((_) => {
                return of(groupDetailsActions.closeComment());
            })
        )
    );

    addGroupEntites$ = createEffect(() =>
        this.actions$.pipe(
            ofType(groupDetailsActions.addEntityToGroup),
            switchMap(({ entityGroupGuid, entitiesToAdd }) => {
                return forkJoin([
                    from(this.groupsService.getGroupDetails(entityGroupGuid)),
                    from(
                        this.entitiesService.getEntitiesListForSpecificGroup(
                            entityGroupGuid
                        )
                    )
                ]).pipe(
                    switchMap(
                        ([groupDetailsResponse, entitiesListResponse]) => {
                            const group = groupDetailsResponse?.result[0];
                            const entitiesList =
                                entitiesListResponse.data || [];
                            const uniqEntitiesIds = [
                                ...new Set([
                                    ...entitiesList.map((ent) => ent.entityId),
                                    ...entitiesToAdd.map((ent) => ent.EntityId)
                                ])
                            ];

                            return from(
                                this.groupsService.updateGroupDetails({
                                    EntityGroupName: group.entityGroupName,
                                    Comment: group.comment,
                                    EntityIds: uniqEntitiesIds.join(', '),
                                    entityGroupGuid
                                })
                            ).pipe(
                                switchMap((response) =>
                                    response.result
                                        ? [
                                              groupDetailsActions.setSuccessNotificationOpenAction(
                                                  { open: true }
                                              ),
                                              groupDetailsActions.groupDetails({
                                                  entityGroupGuid
                                              })
                                          ]
                                        : [
                                              groupDetailsActions.setErrorNotificationOpenAction(
                                                  { open: true }
                                              )
                                          ]
                                ),
                                catchError(() =>
                                    of(
                                        groupDetailsActions.setErrorNotificationOpenAction(
                                            { open: true }
                                        )
                                    )
                                )
                            );
                        }
                    ),
                    catchError((err) =>
                        of(
                            groupDetailsActions.setErrorNotificationOpenAction({
                                open: true
                            })
                        )
                    )
                );
            })
        )
    );

    deleteBulkEntities$ = createEffect(() =>
        this.actions$.pipe(
            ofType(groupDetailsActions.deleteBulkEntities),
            withLatestFrom(
                this.store$.select(
                    selectors.selectDeleteBulkEntitiesRequestBase
                )
            ),
            switchMap(([action, { entityGroupGuid, entityIds }]) => {
                return from(
                    this.entitiesService.deleteEntity(
                        entityGroupGuid,
                        entityIds
                    )
                ).pipe(
                    map((_response) => {
                        return groupDetailsActions.deleteBulkEntitiesSuccess({
                            result: _response.result
                        });
                    }),
                    catchError((err) =>
                        of(
                            groupDetailsActions.deleteBulkEntitiesFailure({
                                error: err
                            })
                        )
                    )
                );
            })
        )
    );

    reloadEntitiesList$ = createEffect(() =>
        this.actions$.pipe(
            ofType(groupDetailsActions.deleteBulkEntitiesSuccess),
            withLatestFrom(this.store$.select(selectors.selectGroupDetails)),
            switchMap(([action, groupDetails]) => {
                return from(
                    this.entitiesService.getEntitiesListForSpecificGroup(
                        groupDetails.entityGroupGuid
                    )
                ).pipe(
                    map((response) =>
                        groupDetailsActions.groupEntitiesListSuccess({
                            response
                        })
                    ),
                    catchError((err) =>
                        of(groupDetailsActions.groupEntitiesListFailure())
                    )
                );
            })
        )
    );

    constructor(
        private actions$: Actions,
        private groupsService: GroupsService,
        private entitiesService: EntitiesService,
        private store$: Store
    ) {}
}
