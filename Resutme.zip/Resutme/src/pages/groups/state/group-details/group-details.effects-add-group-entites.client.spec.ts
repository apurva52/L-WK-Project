import { TestBed } from '@angular/core/testing';
import { ExperienceConfigurationServiceNg } from '@ct/core-ui-ng';
import { EffectsModule } from '@ngrx/effects';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { Observable } from 'rxjs';
import { TestScheduler } from 'rxjs/testing';

import { EntitiesService } from '../../../../shared/services/entities/entities.service';
import { GroupsService } from '../../../../shared/services/groups/groups.service';
import { entitiesListResponse, groupDetails, groupDetailsResponse, updateGroupDetailsResponse } from '../../shared/test-stubs/group-details.stub';

import { groupDetailsActions } from './group-details.actions';
import { GroupDetailsEffects } from './group-details.effects';
import { selectGroupDetails } from './group-details.selectors';
import { GROUP_DETAILS_FEATURE_KEY, initialState } from './group-details.state';

describe('Groups details effect', () => {
    let action$: Observable<any>;
    let effects: GroupDetailsEffects;
    let testScheduler: TestScheduler;
    const mockService = jasmine.createSpyObj<any>('GroupsService', ['getGroupDetails', 'updateGroupDetails']);
    const mockEntitiesService = jasmine.createSpyObj<any>('EntitiesService', ['getEntitiesListForSpecificGroup', 'deleteEntity']);

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                EffectsModule.forRoot([GroupDetailsEffects])
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [GROUP_DETAILS_FEATURE_KEY]: initialState
                    },
                    selectors: [
                        { selector: selectGroupDetails, value: groupDetails }
                    ]
                }),
                provideMockActions(() => action$),
                {
                    provide: GroupsService,
                    useValue: mockService
                },
                {
                    provide: EntitiesService,
                    useValue: mockEntitiesService
                },
                ExperienceConfigurationServiceNg
            ]
        });
        effects = TestBed.inject(GroupDetailsEffects);
        testScheduler = new TestScheduler((actual, expected) => {
            expect(actual).toEqual(expected);
        });
    });

    it('should show success on add group entities', () => {
        const action = groupDetailsActions.addEntityToGroup({
            entityGroupGuid: '337afc2f-b72a-4705-8e1b-0fadd73983a4',
            entitiesToAdd: [ ]
        });
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('a', {
                a: action
            });
            const resultEntList$ = cold('b|', { b: { ...entitiesListResponse } });
            mockEntitiesService.getEntitiesListForSpecificGroup.and.returnValue(resultEntList$);
            const resultGroupDetails$ = cold('b|', { b: { ...groupDetailsResponse } });
            mockService.getGroupDetails.and.returnValue(resultGroupDetails$);
            const resultUpdateGroupDetails$ = cold('b|', { b: { ...updateGroupDetailsResponse } });
            mockService.updateGroupDetails.and.returnValue(resultUpdateGroupDetails$);

            expectObservable(effects.addGroupEntites$).toBe('-(bc)', {
                b: groupDetailsActions.setSuccessNotificationOpenAction({ open: true }),
                c: groupDetailsActions.groupDetails({ entityGroupGuid: '337afc2f-b72a-4705-8e1b-0fadd73983a4' })
            });
        });
    });

    it('should show error on add group entities wrong result format', () => {
        const action = groupDetailsActions.addEntityToGroup({
            entityGroupGuid: '337afc2f-b72a-4705-8e1b-0fadd73983a4',
            entitiesToAdd: [ ]
        });
        const outcome = groupDetailsActions.setErrorNotificationOpenAction({ open: true });
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('a', {
                a: action
            });
            const resultEntList$ = cold('b|', { b: { ...entitiesListResponse } });
            mockEntitiesService.getEntitiesListForSpecificGroup.and.returnValue(resultEntList$);
            const resultGroupDetails$ = cold('b|', { b: { ...groupDetailsResponse } });
            mockService.getGroupDetails.and.returnValue(resultGroupDetails$);
            const resultUpdateGroupDetails$ = cold('b|', { b: { } });
            mockService.updateGroupDetails.and.returnValue(resultUpdateGroupDetails$);

            expectObservable(effects.addGroupEntites$).toBe('-b', {
                b: outcome
            });
        });
    });

    it('should show error on add group entities updateGroupDetails fails', () => {
        const action = groupDetailsActions.addEntityToGroup({
            entityGroupGuid: '337afc2f-b72a-4705-8e1b-0fadd73983a4',
            entitiesToAdd: [ ]
        });
        const outcome = groupDetailsActions.setErrorNotificationOpenAction({ open: true });
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('a', {
                a: action
            });
            const resultEntList$ = cold('b|', { b: { ...entitiesListResponse } });
            mockEntitiesService.getEntitiesListForSpecificGroup.and.returnValue(resultEntList$);
            const resultGroupDetails$ = cold('b|', { b: { ...groupDetailsResponse } });
            mockService.getGroupDetails.and.returnValue(resultGroupDetails$);
            const resultUpdateGroupDetails$ = cold('#|', {}, '');
            mockService.updateGroupDetails.and.returnValue(resultUpdateGroupDetails$);

            expectObservable(effects.addGroupEntites$).toBe('-b', {
                b: outcome
            });
        });
    });
});