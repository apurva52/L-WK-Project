// tslint:disable max-file-line-count
import { entityGroupGuid, groupDetails, groupDetailsUpdateResponse, groupEntitiesResponse } from '../../shared/test-stubs/group-details.stub';

import { groupDetailsActions } from './group-details.actions';
import { groupDetailsReducer } from './group-details.reducers';
import { initialState } from './group-details.state';

describe('group details reducer', () => {
    it('should process group details loading', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            isGroupDetailsLoading: true,
            isSummaryEditing: false
        };
        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.groupDetails({ entityGroupGuid })
            )
        ).toEqual(expectedState);
    });

    it('should process group details load success', () => {
        const currentState = {
            ...initialState,
            isGroupDetailsLoading: true
        };
        const expectedState = {
            ...currentState,
            isGroupDetailsLoading: false,
            details: groupDetails
        };
        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.groupDetailsSuccess({
                    result: groupDetails
                })
            )
        ).toEqual(expectedState);
    });

    it('should process groups total load failure', () => {
        const errorMessage = 'Something went wrong';
        const currentState = {
            ...initialState,
            isGroupDetailsLoading: true
        };
        const expectedState = {
            ...currentState,
            isGroupDetailsLoading: false,
            errorMessage
        };
        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.groupDetailsFailure({
                    error: errorMessage
                })
            )
        ).toEqual(expectedState);
    });

    it('should process editing group details status', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            isSummaryEditing: true
        };
        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.editGroupDetails({ isEditing: true })
            )
        ).toEqual(expectedState);
    });

    it('should process update group details loading status', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            isUpdateDetailsLoading: true
        };
        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.updateGroupDetails({ comment: 'Test Comment', entityGroupName: 'Test Name' })
            )
        ).toEqual(expectedState);
    });

    it('should process update group details success', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            isUpdateDetailsLoading: false,
            isSummaryEditing: false,
            isGroupDetailsLoading: true,
            updateDetailsSuccessStatus: groupDetailsUpdateResponse,
            switcherReloadRequired: true
        };
        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.updateGroupDetailsSuccess({ result: groupDetailsUpdateResponse })
            )
        ).toEqual(expectedState);
    });

    it('should process update group details failure', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            isUpdateDetailsLoading: false,
            errorMessage: 'Something went wrong.',
            errorNotificationOpen: true
        };
        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.updateGroupDetailsFailure({ error: 'Something went wrong.' })
            )
        ).toEqual(expectedState);
    });

    it('should process error notification display status', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            errorNotificationOpen: true
        };
        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.setErrorNotificationOpenAction({ open: true })
            )
        ).toEqual(expectedState);
    });

    it('should set modal flag as open', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            isCommentOpen: true
        };

        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.openComment()
            )
        ).toEqual(expectedState);
    });

    it('should set modal flag as closed', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            isCommentOpen: false
        };

        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.closeComment()
            )
        ).toEqual(expectedState);
    });

    it('should set entities list loading on get', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            isGroupEntitiesLoading: true
        };

        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.groupEntitiesList({ groupGuid: 'whatever'})
            )
        ).toEqual(expectedState);
    });

    it('should entities list to store', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            entities: [ ...groupEntitiesResponse.data ],
            entitiesTotal: groupEntitiesResponse.totalRecordCount,
            entitiesSelected: [],
            entitiesSelectedTotal: 0,
            isGroupEntitiesLoading: false,
            errorNotificationOpen: false,
            errorMessage: null
        };

        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.groupEntitiesListSuccess({ response: { ...groupEntitiesResponse } })
            )
        ).toEqual(expectedState);
    });


    it('should set error on entities list get fail', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            isGroupEntitiesLoading: false,
            errorNotificationOpen: true,
            errorMessage: ''
        };

        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.groupEntitiesListFailure()
            )
        ).toEqual(expectedState);
    });

    it('should set entities selection', () => {
        const currentState = {
            ...initialState
        };

        const params = {
            total: 7,
            selected: []
        };

        const expectedState = {
            ...currentState,
            entitiesSelectedTotal: params.total,
            entitiesSelected: params.selected
        };

        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.groupEntitiesSelect({ entitiesSelectParams: {
                    ...params
                }})
            )
        ).toEqual(expectedState);
    });

    it('should clear entities selection', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            entitiesSelectedTotal: 0,
            entitiesSelected: []
        };

        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.groupEntitiesSelectClearAll()
            )
        ).toEqual(expectedState);
    });

    it('should delete entity', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            isGroupEntitiesLoading: true,
            warningNotificationOpen: false
        };

        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.deleteEntity({
                    entityGroupGuid: '1d1a70e0-154b-4628-9906-bb7fa61968d0',
                    entityIds: '11002496618'
                })
            )
        ).toEqual(expectedState);
    });

    it('should process warning notification display status', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            warningNotificationOpen: true
        };
        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.setWarningNotificationOpenAction({ open: true })
            )
        ).toEqual(expectedState);
    });

    it('should success delete entity', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            isGroupEntitiesLoading: false,
            entities: []
        };

        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.deleteEntitySuccess({
                    result: true,
                    entityId: '1234567'
                })
            )
        ).toEqual(expectedState);
    });

    it('should process bulk delete entities warning notification display status', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            deleteEntitiesWarningNotification: true
        };
        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.deleteEntitiesWarningNotification({ open: true })
            )
        ).toEqual(expectedState);
    });

    it('should process bulk delete entities', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            isGroupEntitiesLoading: true,
            deleteEntitiesWarningNotification: false
        };

        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.deleteBulkEntities()
            )
        ).toEqual(expectedState);
    });

    it('should process delete entities failure', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            isGroupEntitiesLoading: false,
            errorNotificationOpen: true
        };

        expect(
            groupDetailsReducer(
                currentState,
                groupDetailsActions.deleteBulkEntitiesFailure({
                    error: 'EntityId : 11002418415 should belong to the EntityGroup.'
                })
            )
        ).toEqual(expectedState);
    });

});