import { createFeatureSelector, createSelector } from '@ngrx/store';

import { GroupTypes } from '../../shared/enums/group-types';

import { GROUP_DETAILS_FEATURE_KEY, GroupsDetailsState } from './group-details.state';

export const selectRootFeature = createFeatureSelector<GroupsDetailsState>(GROUP_DETAILS_FEATURE_KEY);

export const selectGroupDetailsLoading = createSelector(selectRootFeature, state => state.isGroupDetailsLoading && !state.isCommentOpen);

export const selectGroupDetails = createSelector(selectRootFeature, state => state.details);

export const selectGroupName = createSelector(selectRootFeature, group => group.details?.entityGroupName);

export const selectIsGroupEditable = createSelector(selectGroupDetails,
    // empty criteria json identifies that the static group was created "by entities", not "by condition"
    details => (details?.groupType === GroupTypes.STATIC && details?.criteriaJSON === null)
);

export const selectIsSummaryEditing = createSelector(selectRootFeature, state => state.isSummaryEditing);

export const selectEntitiesData = createSelector(selectRootFeature, state => state.entities);

export const selectGroupEntitiesLoading = createSelector(
    selectRootFeature,
    selectGroupDetailsLoading,
    (state, isGroupDetailsLoading) => isGroupDetailsLoading || state.isGroupEntitiesLoading
);

export const selectEntitiesTotal = createSelector(selectRootFeature, state => state.entitiesTotal);

export const selectSelectedEntities = createSelector(selectRootFeature, state => state.entitiesSelected);

export const selectSelectedEntitiesTotal = createSelector(selectRootFeature, state => state?.entitiesSelectedTotal);

export const selectIsUpdateDetailsLoading = createSelector(selectRootFeature, state => state.isUpdateDetailsLoading);

export const selectErrorNotificationOpen = createSelector(selectRootFeature, state => state.errorNotificationOpen);

export const selectWarningNotificationOpen = createSelector(
    selectRootFeature,
    (state: GroupsDetailsState) => state?.warningNotificationOpen
);

export const selectUpdateGroupDetailsRequestBase = createSelector(selectRootFeature, state => ({
    entityGroupGuid: state.details?.entityGroupGuid,
    groupType: state.details?.groupType,
    entityIds: state.entities?.map(entity => entity.entityId).join(',')
}));

export const selectSwitcherReloadRequired = createSelector(selectRootFeature, state => state.switcherReloadRequired);

export const selectCommentOpen = createSelector(selectRootFeature, state => state.isCommentOpen);

export const selectIsAddEntityOpen = createSelector(selectRootFeature, state => state.isAddEntityOpen);

export const selectDeleteEntitiesWarningNotification = createSelector(selectRootFeature, state => state.deleteEntitiesWarningNotification);

export const selectDeleteBulkEntitiesRequestBase = createSelector(selectRootFeature, state => ({
    entityGroupGuid: state.details?.entityGroupGuid,
    entityIds: state.entitiesSelected?.map(entity => entity.entityId).join(',')
}));