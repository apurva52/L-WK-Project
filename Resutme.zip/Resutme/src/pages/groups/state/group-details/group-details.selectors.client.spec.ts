// tslint:disable max-file-line-count
// tslint:disable:max-line-length
import {
    groupDetails,
    groupEntities
} from '../../shared/test-stubs/group-details.stub';

import * as groupDetailsSelectors from './group-details.selectors';
import { GroupsDetailsState, initialState } from './group-details.state';

describe('Group Details selectors', () => {
    it('should return group details loading status', () => {
        const currentState: GroupsDetailsState = {
            ...initialState,
            isGroupDetailsLoading: true
        };

        const currentData =
            groupDetailsSelectors.selectGroupDetailsLoading.projector(
                currentState
            );
        expect(currentData).toEqual(true);
    });

    it('should return group details loading status as false when modal is open', () => {
        const currentState: GroupsDetailsState = {
            ...initialState,
            isCommentOpen: true,
            isGroupDetailsLoading: true
        };

        const currentData =
            groupDetailsSelectors.selectGroupDetailsLoading.projector(
                currentState
            );
        expect(currentData).toEqual(false);
    });

    it('should return group details group type as false', () => {
        const currentState: GroupsDetailsState = {
            ...initialState,
            details: groupDetails
        };

        const currentData =
            groupDetailsSelectors.selectIsGroupEditable.projector(currentState);
        expect(currentData).toEqual(false);
    });

    it('should return group details', () => {
        const currentState: GroupsDetailsState = {
            ...initialState,
            details: groupDetails
        };

        const currentData =
            groupDetailsSelectors.selectGroupDetails.projector(currentState);
        expect(currentData).toEqual(jasmine.objectContaining(groupDetails));
    });

    it('should return group summary editing status', () => {
        const currentState: GroupsDetailsState = {
            ...initialState,
            isSummaryEditing: true
        };

        const currentData =
            groupDetailsSelectors.selectIsSummaryEditing.projector(
                currentState
            );
        expect(currentData).toEqual(true);
    });

    it('should return group entities', () => {
        const currentState: GroupsDetailsState = {
            ...initialState,
            entities: groupEntities
        };

        const currentData =
            groupDetailsSelectors.selectEntitiesData.projector(currentState);
        expect(currentData).toEqual(jasmine.arrayContaining(groupEntities));
    });

    it('should return group entities loading status', () => {
        const currentState: GroupsDetailsState = {
            ...initialState,
            isGroupEntitiesLoading: true
        };

        const currentData =
            groupDetailsSelectors.selectGroupEntitiesLoading.projector(
                currentState
            );
        expect(currentData).toEqual(true);
    });

    it('should return current total from stub data', () => {
        const mockData = 0;
        const currentState: GroupsDetailsState = {
            ...initialState
        };

        const currentTotal =
            groupDetailsSelectors.selectEntitiesTotal.projector(currentState);
        expect(currentTotal).toEqual(mockData);
    });

    it('should return current selected Company Officials status', () => {
        const mockData = [];
        const currentState: GroupsDetailsState = {
            ...initialState,
            entitiesSelected: []
        };

        const currentData =
            groupDetailsSelectors.selectSelectedEntities.projector(
                currentState
            );
        expect(currentData).toEqual(mockData);
    });

    it('should return selected total from stub data', () => {
        const mockData = 0;
        const currentState: GroupsDetailsState = {
            ...initialState
        };

        const currentTotal =
            groupDetailsSelectors.selectSelectedEntitiesTotal.projector(
                currentState
            );
        expect(currentTotal).toEqual(mockData);
    });

    it('should return group update details loading status', () => {
        const currentState: GroupsDetailsState = {
            ...initialState,
            isUpdateDetailsLoading: true
        };

        const currentData =
            groupDetailsSelectors.selectIsUpdateDetailsLoading.projector(
                currentState
            );
        expect(currentData).toEqual(true);
    });

    it('should return error notification open status', () => {
        const currentState: GroupsDetailsState = {
            ...initialState,
            errorNotificationOpen: true
        };

        const currentData =
            groupDetailsSelectors.selectErrorNotificationOpen.projector(
                currentState
            );
        expect(currentData).toEqual(true);
    });

    it('should return warning notification open status', () => {
        const currentState: GroupsDetailsState = {
            ...initialState,
            warningNotificationOpen: true
        };

        const currentData =
            groupDetailsSelectors.selectWarningNotificationOpen.projector(
                currentState
            );
        expect(currentData).toEqual(true);
    });

    it('should return quick switcher reload required status', () => {
        const currentState: GroupsDetailsState = {
            ...initialState,
            switcherReloadRequired: true
        };

        const currentData =
            groupDetailsSelectors.selectSwitcherReloadRequired.projector(
                currentState
            );
        expect(currentData).toEqual(true);
    });

    it('should return group details update request base', () => {
        const newStateData = {
            entityGroupGuid: groupDetails.entityGroupGuid,
            groupType: groupDetails?.groupType,
            entityIds: '11000258230,11003434431'
        };
        const currentState: GroupsDetailsState = {
            ...initialState,
            details: groupDetails,
            entities: groupEntities
        };

        const currentData =
            groupDetailsSelectors.selectUpdateGroupDetailsRequestBase.projector(
                currentState
            );
        expect(currentData).toEqual(jasmine.objectContaining(newStateData));
    });

    it('should return comment modal state flag', () => {
        const openModalState: GroupsDetailsState = {
            ...initialState,
            isCommentOpen: true
        };
        const closedModalState: GroupsDetailsState = {
            ...initialState,
            isCommentOpen: false
        };

        const openValue =
            groupDetailsSelectors.selectCommentOpen.projector(openModalState);
        const closedValue =
            groupDetailsSelectors.selectCommentOpen.projector(closedModalState);

        expect(openValue).toEqual(true);
        expect(closedValue).toEqual(false);
    });

    it('should return warning notification open status', () => {
        const currentState: GroupsDetailsState = {
            ...initialState,
            deleteEntitiesWarningNotification: true
        };

        const currentData =
            groupDetailsSelectors.selectDeleteEntitiesWarningNotification.projector(
                currentState
            );
        expect(currentData).toEqual(true);
    });

    it('should return bulk entities remove request base', () => {
        const newStateData = {
            entityGroupGuid: groupDetails.entityGroupGuid,
            entityIds: '11000258230,11003434431'
        };
        const currentState: GroupsDetailsState = {
            ...initialState,
            details: groupDetails,
            entitiesSelected: groupEntities
        };

        const currentData =
            groupDetailsSelectors.selectDeleteBulkEntitiesRequestBase.projector(
                currentState
            );
        expect(currentData).toEqual(jasmine.objectContaining(newStateData));
    });
});
