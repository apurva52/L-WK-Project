import { createReducer, on } from '@ngrx/store';

import { groupDetailsActions } from './group-details.actions';
import { GroupsDetailsState, initialState } from './group-details.state';

export const groupDetailsReducer = createReducer(
    initialState,

    on(groupDetailsActions.groupDetails, (state): GroupsDetailsState => ({
        ...state,
        isGroupDetailsLoading: true,
        isSummaryEditing: false,
        switcherReloadRequired: false
    })),

    on(groupDetailsActions.groupDetailsSuccess, (state, action): GroupsDetailsState => ({
        ...state,
        isGroupDetailsLoading: false,
        details: action.result
    })),

    on(groupDetailsActions.groupDetailsFailure, (state, action): GroupsDetailsState => ({
        ...state,
        isGroupDetailsLoading: false,
        errorMessage: action.error
    })),

    on(groupDetailsActions.editGroupDetails, (state, action): GroupsDetailsState => ({
        ...state,
        isSummaryEditing: action.isEditing
    })),

    on(groupDetailsActions.updateGroupDetails, (state): GroupsDetailsState => ({
        ...state,
        isUpdateDetailsLoading: true
    })),

    on(groupDetailsActions.updateGroupDetailsSuccess, (state, action): GroupsDetailsState => ({
        ...state,
        isUpdateDetailsLoading: false,
        isSummaryEditing: false,
        isGroupDetailsLoading: true,
        updateDetailsSuccessStatus: action.result,
        switcherReloadRequired: true
    })),

    on(groupDetailsActions.updateGroupDetailsFailure, (state, action): GroupsDetailsState => ({
        ...state,
        isUpdateDetailsLoading: false,
        errorMessage: action.error,
        errorNotificationOpen: true
    })),

    on(groupDetailsActions.setErrorNotificationOpenAction, (state, action) => ({
        ...state,
        errorNotificationOpen: action.open,
        isAddEntityOpen: false
    })),

    on(groupDetailsActions.setWarningNotificationOpenAction, (state, action) => ({
        ...state,
        warningNotificationOpen: action.open
    })),

    on(groupDetailsActions.setSuccessNotificationOpenAction, (state, action) => ({
        ...state,
        successNotificationOpen: action.open,
        isAddEntityOpen: false
    })),

    on(groupDetailsActions.openComment, (state) => ({
        ...state,
        isCommentOpen: true
    })),

    on(groupDetailsActions.closeComment, (state) => ({
        ...state,
        isCommentOpen: false
    })),

    on(groupDetailsActions.openAddEntityModal, (state) => ({
        ...state,
        isAddEntityOpen: true
    })),

    on(groupDetailsActions.closeAddEntityModal, (state) => ({
        ...state,
        isAddEntityOpen: false
    })),

    on(groupDetailsActions.groupEntitiesList, (state, action) => ({
        ...state,
        isGroupEntitiesLoading: true,
        errorNotificationOpen: false,
        errorMessage: null
    })),

    on(groupDetailsActions.groupEntitiesListSuccess, (state, action) => ({
        ...state,
        entities: action.response.data,
        entitiesTotal: action.response.totalRecordCount,
        entitiesSelected: [],
        entitiesSelectedTotal: 0,
        isGroupEntitiesLoading: false,
        errorNotificationOpen: false,
        errorMessage: null
    })),

    on(groupDetailsActions.groupEntitiesListFailure, (state, action) => ({
        ...state,
        isGroupEntitiesLoading: false,
        errorNotificationOpen: true,
        errorMessage: ''
    })),

    on(groupDetailsActions.groupEntitiesSelect, (state, action) => ({
        ...state,
        entitiesSelectedTotal: action.entitiesSelectParams.total,
        entitiesSelected: action.entitiesSelectParams.selected
    })),

    on(groupDetailsActions.groupEntitiesSelectClearAll, (state) => ({
        ...state,
        entitiesSelectedTotal: 0,
        entitiesSelected: []
    })),

    on(groupDetailsActions.deleteEntity, (state) => ({
        ...state,
        isGroupEntitiesLoading: true,
        warningNotificationOpen: false
    })),

    on(groupDetailsActions.deleteEntitySuccess, (state, action) => ({
        ...state,
        entities: state.entities.filter(entity => entity.entityId.toString() !== action.entityId),
        isGroupEntitiesLoading: false
    })),

    on(groupDetailsActions.deleteEntitiesWarningNotification, (state, action) => ({
        ...state,
        deleteEntitiesWarningNotification: action.open
    })),

    on(groupDetailsActions.deleteBulkEntities, (state, action) => ({
        ...state,
        isGroupEntitiesLoading: true,
        deleteEntitiesWarningNotification: false
    })),

    on(groupDetailsActions.deleteBulkEntitiesFailure, (state, action) => ({
        ...state,
        isGroupEntitiesLoading: false,
        errorNotificationOpen: true
    }))

);