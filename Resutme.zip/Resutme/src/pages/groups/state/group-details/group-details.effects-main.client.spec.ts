// tslint:disable max-file-line-count
import { TestBed } from '@angular/core/testing';
import { ExperienceConfigurationServiceNg } from '@ct/core-ui-ng';
import { EffectsModule } from '@ngrx/effects';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { Observable } from 'rxjs';
import { TestScheduler } from 'rxjs/testing';

import { EntitiesService } from '../../../../shared/services/entities/entities.service';
import { GroupsService } from '../../../../shared/services/groups/groups.service';
import { entityGroupGuid, groupDetails, groupDetailsResponse, groupDetailsUpdateResponse, groupEntitiesDeleteResponse, groupEntitiesResponse } from '../../shared/test-stubs/group-details.stub';

import { groupDetailsActions } from './group-details.actions';
import { GroupDetailsEffects } from './group-details.effects';
import { selectGroupDetails } from './group-details.selectors';
import { GROUP_DETAILS_FEATURE_KEY, initialState } from './group-details.state';

describe('Groups details effect', () => {
    let action$: Observable<any>;
    let effects: GroupDetailsEffects;
    let testScheduler: TestScheduler;
    const mockService = jasmine.createSpyObj<any>('GroupsService', ['getGroupDetails', 'updateGroupDetails']);
    const mockEntitiesService = jasmine.createSpyObj<any>('EntitiesService', ['getEntitiesListForSpecificGroup', 'deleteEntity']);

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                EffectsModule.forRoot([GroupDetailsEffects])
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [GROUP_DETAILS_FEATURE_KEY]: initialState
                    },
                    selectors: [
                        { selector: selectGroupDetails, value: groupDetails }
                    ]
                }),
                provideMockActions(() => action$),
                {
                    provide: GroupsService,
                    useValue: mockService
                },
                {
                    provide: EntitiesService,
                    useValue: mockEntitiesService
                },
                ExperienceConfigurationServiceNg
            ]
        });
        effects = TestBed.inject(GroupDetailsEffects);
        testScheduler = new TestScheduler((actual, expected) => {
            expect(actual).toEqual(expected);
        });
    });

    it('should request group details success', () => {
        const action = groupDetailsActions.groupDetails({ entityGroupGuid });
        const outcome = groupDetailsActions.groupDetailsSuccess({ result: groupDetails });
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-b|', { b: groupDetailsResponse });
            mockService.getGroupDetails.and.returnValue(result$);
            expectObservable(effects.groupDetails$).toBe('--b', {
                b: outcome
            });
        });
    });

    it('should request group details failure response', () => {
        const errorMessage = 'EntityGroupGuid has to be a valid Guid.';
        const failureOutcome = groupDetailsActions.groupDetailsFailure({ error: errorMessage });
        const action = groupDetailsActions.groupDetails({ entityGroupGuid });

        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-#|', {}, errorMessage);
            mockService.getGroupDetails.and.returnValue(result$);
            expectObservable(effects.groupDetails$).toBe('--b', {
                b: failureOutcome
            });
        });
    });

    it('should request group details reload success', () => {
        const action = groupDetailsActions.updateGroupDetailsSuccess({ result: groupDetailsUpdateResponse });
        const outcome = groupDetailsActions.groupDetailsSuccess({ result: groupDetails });
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-b|', { b: groupDetailsResponse });
            mockService.getGroupDetails.and.returnValue(result$);
            expectObservable(effects.fetchGroupDetailsOnUpdate$).toBe('--b', {
                b: outcome
            });
        });
    });

    it('should request group details reload failure response', () => {
        const errorMessage = 'EntityGroupGuid has to be a valid Guid.';
        const failureOutcome = groupDetailsActions.groupDetailsFailure({ error: errorMessage });
        const action = groupDetailsActions.updateGroupDetailsSuccess({ result: groupDetailsUpdateResponse });

        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-#|', {}, errorMessage);
            mockService.getGroupDetails.and.returnValue(result$);
            expectObservable(effects.fetchGroupDetailsOnUpdate$).toBe('--b', {
                b: failureOutcome
            });
        });
    });

    it('should process update group details success response', () => {
        const action = groupDetailsActions.updateGroupDetails({ comment: 'Test comment', entityGroupName: 'Test Group Name' });
        const outcome = groupDetailsActions.updateGroupDetailsSuccess({ result: groupDetailsUpdateResponse });
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-b|', { b: { result: groupDetailsUpdateResponse } });
            mockService.updateGroupDetails.and.returnValue(result$);
            expectObservable(effects.saveGroupDetails$).toBe('--b', {
                b: outcome
            });
        });
    });

    it('should process update group details failure response', () => {
        const errorMessage = 'EntityGroupGuid has to be a valid Guid.';
        const failureOutcome = groupDetailsActions.updateGroupDetailsFailure({ error: errorMessage });
        const action = groupDetailsActions.updateGroupDetails({ comment: 'Test comment', entityGroupName: 'Test Group Name' });

        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-#|', {}, errorMessage);
            mockService.updateGroupDetails.and.returnValue(result$);
            expectObservable(effects.saveGroupDetails$).toBe('--b', {
                b: failureOutcome
            });
        });
    });

    it('should switch to loading entities after details loaded', () => {
        const action = groupDetailsActions.groupDetailsSuccess({ result: groupDetails });
        const outcome = groupDetailsActions.groupEntitiesList({ groupGuid: groupDetails.entityGroupGuid });

        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            expectObservable(effects.getEntitiesListAfterDetails$).toBe('-b', {
                b: outcome
            });
        });
    });

    it('should switch to loading entities after details loaded', () => {
        const action = groupDetailsActions.updateGroupDetailsSuccess({result: null});
        const outcome = groupDetailsActions.closeComment();

        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            expectObservable(effects.closeModalAfterUpdate$).toBe('-b', {
                b: outcome
            });
        });
    });

    it('should process group entities list success response', () => {
        const action = groupDetailsActions.groupEntitiesList({ groupGuid: groupDetails.entityGroupGuid });
        const outcome = groupDetailsActions.groupEntitiesListSuccess({ response: groupEntitiesResponse });
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-b|', { b: { ...groupEntitiesResponse } });
            mockEntitiesService.getEntitiesListForSpecificGroup.and.returnValue(result$);
            expectObservable(effects.loadEntitiesList$).toBe('--b', {
                b: outcome
            });
        });
    });

    it('should process delete entitiy success response', () => {
        const action = groupDetailsActions.deleteEntity({
            entityGroupGuid: '337afc2f-b72a-4705-8e1b-0fadd73983a4',
            entityIds: '11000258230'
        });
        const outcome = groupDetailsActions.deleteEntitySuccess({
            ...groupEntitiesDeleteResponse,
            entityId: '11000258230'
        });
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-b|', { b: { ...groupEntitiesDeleteResponse } });
            mockEntitiesService.deleteEntity.and.returnValue(result$);
            expectObservable(effects.deleteEntity$).toBe('--b', {
                b: outcome
            });
        });
    });

    it('should process bulk delete entities success response', () => {
        const action = groupDetailsActions.deleteBulkEntities();
        const outcome = groupDetailsActions.deleteBulkEntitiesSuccess({
            ...groupEntitiesDeleteResponse
        });
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-b|', { b: { ...groupEntitiesDeleteResponse } });
            mockEntitiesService.deleteEntity.and.returnValue(result$);
            expectObservable(effects.deleteBulkEntities$).toBe('--b', {
                b: outcome
            });
        });
    });

    it('should process bulk delete entities failure response', () => {
        const errorMessage = 'EntityId : 11002418415 should belong to the EntityGroup.';
        const failureOutcome = groupDetailsActions.deleteBulkEntitiesFailure({ error: errorMessage });
        const action = groupDetailsActions.deleteBulkEntities();

        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-#|', {}, errorMessage);
            mockEntitiesService.deleteEntity.and.returnValue(result$);
            expectObservable(effects.deleteBulkEntities$).toBe('--b', {
                b: failureOutcome
            });
        });
    });

    it('should process reload entities success response', () => {
        const action = groupDetailsActions.deleteBulkEntitiesSuccess({
            result: true
        });
        const outcome = groupDetailsActions.groupEntitiesListSuccess({ response: groupEntitiesResponse });
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-b|', { b: { ...groupEntitiesResponse } });
            mockEntitiesService.getEntitiesListForSpecificGroup.and.returnValue(result$);
            expectObservable(effects.reloadEntitiesList$).toBe('--b', {
                b: outcome
            });
        });
    });

    it('should process reload entities failure response', () => {
        const errorMessage = 'EntityId : 11002418415 should belong to the EntityGroup.';
        const failureOutcome = groupDetailsActions.groupEntitiesListFailure();
        const action = groupDetailsActions.deleteBulkEntitiesSuccess({
            result: true
        });

        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-#|', {}, errorMessage);
            mockEntitiesService.getEntitiesListForSpecificGroup.and.returnValue(result$);
            expectObservable(effects.reloadEntitiesList$).toBe('--b', {
                b: failureOutcome
            });
        });
    });
});
