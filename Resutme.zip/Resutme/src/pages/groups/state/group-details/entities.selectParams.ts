import { SpecificGroupEntityItem } from '../../../../shared/interfaces/entitites-for-specific-group.response';

export interface EntitiesSelectParams {
    total: number;
    selected: Array<SpecificGroupEntityItem>;
}
