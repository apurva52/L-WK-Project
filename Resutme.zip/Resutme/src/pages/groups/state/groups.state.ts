import { GroupListItem } from '../shared';

export const GROUPS_FEATURE_KEY = 'groupsFeatureKey';

export interface GroupsState {
    loading: boolean;
    totalRecordCount: number;
    createdInLast30Days: number;
    errorMessage: string;
    groupList: Array<GroupListItem>;
    selections: Array<GroupListItem>;
    selectedGroup: GroupListItem;
    isGroupDeletedSuccessfully: boolean;
    isDeleteGroupWarningNotVisible: boolean;

}

export const initialState: GroupsState = {
    loading: false,
    totalRecordCount: 0,
    createdInLast30Days: 0,
    errorMessage: '',
    groupList: [],
    selections: [],
    selectedGroup: null,
    isGroupDeletedSuccessfully: false,
    isDeleteGroupWarningNotVisible: false

};
