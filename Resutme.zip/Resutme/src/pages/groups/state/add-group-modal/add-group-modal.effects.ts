import { Injectable } from '@angular/core';
import { CustomFieldTypes } from '@ct/platform-common-uicomponents/custom-fields-renderer';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { forkJoin, from, of } from 'rxjs';
import {
    catchError,
    map,
    switchMap,
    tap,
    withLatestFrom
} from 'rxjs/operators';

import { CustomFieldsService } from '../../../../shared/services/custom-fields/customFields.service';
import { GroupsService } from '../../../../shared/services/groups/groups.service';
import {
    addGroupSecondStepForm,
    convertCustomFieldsDetailsToPickList,
    DuplicateStatus
} from '../../shared';
import * as selectors from '../add-group-modal/add-group-modal.selectors';

import { addGroupModalActions } from './add-group-modal.actions';

@Injectable()
export class AddGroupModalEffects {
    clearFormsAfterClosingModal$ = createEffect(
        () =>
            this.actions$.pipe(
                ofType(addGroupModalActions.addGroupModalOpenAction),
                tap(() => addGroupSecondStepForm.reset())
            ),
        { dispatch: false }
    );

    loadCustomFieldsDetails$ = createEffect(() =>
        this.actions$.pipe(
            ofType(addGroupModalActions.loadCustomFieldDetail),
            switchMap((params) => {
                const pickListTypeCustomFieldsRequests = params.pickListFields
                    .length
                    ? params.pickListFields
                          .filter(
                              (e) => e.typeName === CustomFieldTypes.PICK_LIST
                          )
                          .map((e) =>
                              this.customFieldService.getCustomFieldDetails(
                                  e.guid
                              )
                          )
                    : [];

                return forkJoin(pickListTypeCustomFieldsRequests).pipe(
                    map((values) => {
                        return addGroupModalActions.loadCustomFieldDetailSuccess(
                            {
                                response:
                                    convertCustomFieldsDetailsToPickList(values)
                            }
                        );
                    }),
                    catchError((error) =>
                        of(
                            addGroupModalActions.loadCustomFieldDetailFail({
                                error
                            })
                        )
                    )
                );
            })
        )
    );

    saveEntities$ = createEffect(() =>
        this.actions$.pipe(
            ofType(addGroupModalActions.saveEntities),
            withLatestFrom(
                this.store$.select(selectors.selectEntitiesGridData)
            ),
            switchMap(([_, entities]) => {
                const entitiesId = entities.map(({ entityId }) => entityId);

                return of(
                    addGroupModalActions.saveEntitiesSuccess({
                        entitiesId
                    })
                );
            })
        )
    );

    checkGroupNameDuplicate$ = createEffect(() =>
        this.actions$.pipe(
            ofType(addGroupModalActions.checkGroupNameDuplicate),
            switchMap((_params) => {
                const entityGroupName = _params.entityGroupName;

                return from(
                    this.groupsService.checkDuplicate(entityGroupName)
                ).pipe(
                    map((_response) => {
                        return addGroupModalActions.groupNameDuplicateSuccess({
                            result: _response.result,
                            duplicateStatus: DuplicateStatus.DONE,
                            activeStep: !_response.result ? 1 : 0
                        });
                    })
                );
            })
        )
    );

    constructor(
        private actions$: Actions,
        private customFieldService: CustomFieldsService,
        private store$: Store,
        private groupsService: GroupsService
    ) {}
}
