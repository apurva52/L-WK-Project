// tslint:disable:max-file-line-count
import { addGroupFailInfoStep, AddGroupFirstStepModel, AddGroupSecondStepModel, addGroupSuccessInfoStep, AddGroupThirdStepModel, beforeAddGroupSavingStep, CategoriesInfo, clearThirdStepSelection, CurrentStep, DateRagesIntervals, DateRangesModel, DescriptiveInformationModel, DuplicateStatus, GroupCategories, GroupSaveStatus, GroupTypes, mockAddGroupEntityName, mockAddGroupState, radioOptionsCntrl, SelectBy } from '../../shared';
import { mockCustomFieldsValuesResponse } from '../../shared/test-stubs/group-custom-fields.stub';
import { groupsActions } from '../groups.actions';

import { addGroupModalActions } from './add-group-modal.actions';
import { addGroupModalReducer } from './add-group-modal.reducer';
import { initialState } from './add-group-modal.state';

describe('Add group modal reducer', () => {

    it('should set add group modal open as true', () => {
        const currentState = { ...initialState };
        const params = { isOpen: true };

        expect(addGroupModalReducer(currentState, addGroupModalActions.addGroupModalOpenAction(params))).toEqual({
            ...currentState,
            ...params,
            activeStep: 0
        });
    });

    it('should decrease current step on moveToPreviousStep Action', () => {
        const currentState = { ...initialState };

        expect(addGroupModalReducer(currentState, addGroupModalActions.moveToPreviousStep())).toEqual({
            ...currentState,
            activeStep: 0
        });
    });

    it('should decrease current step on moveToNextStep Action', () => {
        const currentState = { ...initialState };

        expect(addGroupModalReducer(currentState, addGroupModalActions.moveToNextStep())).toEqual({
            ...currentState,
            activeStep: 1
        });
    });

    it('should set wizard flag to closed', () => {
        const currentState = { ...initialState, isOpen: true };
        expect(addGroupModalReducer(currentState,
            addGroupModalActions.addGroupModalCloseAction()))
            .toEqual({
                ...initialState,
                isOpen: false
            });
    });

    it('should set wizard flag to closed', () => {
        const currentState = { ...initialState, isOpen: true };
        expect(addGroupModalReducer(currentState,
            addGroupModalActions.addGroupModalCloseAction()))
            .toEqual({
                ...initialState,
                isOpen: false
            });
    });

    it('should set first step data', () => {
        const firstStepModel: AddGroupFirstStepModel = {
            groupName: 'Group Name',
            groupType: GroupTypes.DYNAMIC
        };
        const expectedState = {
            ...initialState,
            firstStepModel
        };
        expect(addGroupModalReducer(initialState,
            addGroupModalActions.updateAddGroupFirstStepModel({ formData: firstStepModel })))
            .toEqual(expectedState);
    });

    it('should set second step data', () => {
        const secondStepModel: AddGroupSecondStepModel = {
            [GroupCategories.CUSTOM_FIELDS]: [],
            [GroupCategories.DATE_RANGES]: [],
            [GroupCategories.DESCRIPTIVE_INFORMATION]: [],
            selectBy: SelectBy.ENTITY_NAME,
            entities: mockAddGroupEntityName.map((entities) => ({
                ...entities,
                saveStatus: GroupSaveStatus.Preselected
            }))
        };
        const expectedState = {
            ...initialState,
            secondStepModel,
            thirdStepModel: {
                ...initialState.thirdStepModel,
                selectedEntities: mockAddGroupEntityName.map((entities) => ({
                    ...entities,
                    saveStatus: GroupSaveStatus.Preselected
                }))
            }
        };
        expect(addGroupModalReducer(initialState,
            addGroupModalActions.updateAddGroupSecondStepModel({ formData: secondStepModel })))
            .toEqual(expectedState);
    });

    it('should set third step data', () => {
        const thirdStepModel: AddGroupThirdStepModel = {
            [GroupCategories.DATE_RANGES]: {} as DateRangesModel,
            [GroupCategories.DESCRIPTIVE_INFORMATION]: {} as DescriptiveInformationModel,
            entityIdForSave: [],
            selectedEntities: [],
            [GroupCategories.SELECTED_PILLS]: {}
        };
        const expectedState = {
            ...initialState,
            thirdStepModel
        };
        expect(addGroupModalReducer(initialState,
            addGroupModalActions.updateAddGroupThirdStepModel({ formData: thirdStepModel })))
            .toEqual(expectedState);
    });

    it('should clear state', () => {
        expect(addGroupModalReducer(mockAddGroupState,
            addGroupModalActions.clearState()))
            .toEqual({
                ...initialState,
                errorNotificationOpen: mockAddGroupState.errorNotificationOpen,
                successNotificationOpen: mockAddGroupState.successNotificationOpen
            });
    });

    it('should set success notification status on close', () => {
        const currentState = { ...initialState };
        const shouldOpen = false;

        expect(addGroupModalReducer(currentState,
            addGroupModalActions.setAddGroupSuccessNotificationOpen({ open: shouldOpen }))).toEqual({
                ...currentState,
                successNotificationOpen: shouldOpen
            });
    });

    it('should set failure notification status on close', () => {
        const currentState = { ...initialState, errorNotificationOpen: true };
        const shouldOpen = false;

        expect(addGroupModalReducer(currentState,
            addGroupModalActions.setAddGroupFailureNotificationOpen({ open: shouldOpen }))).toEqual({
                ...currentState,
                errorNotificationOpen: shouldOpen
            });
    });

    it('should set no matching entities notification status on close', () => {
        const currentState = { ...initialState };
        const shouldOpen = false;

        expect(addGroupModalReducer(currentState,
            addGroupModalActions.setAddGroupNoMatchingEntityNotificationOpen({ open: shouldOpen }))).toEqual({
                ...currentState,
                noMatchingEntityNotificationOpen: shouldOpen
            });
    });

    it('should set custom fields details', () => {
        const currentState = { ...initialState };

        expect(addGroupModalReducer(currentState,
            addGroupModalActions.loadCustomFieldDetailSuccess({ response: mockCustomFieldsValuesResponse }))).toEqual({
                ...currentState,
                customFieldsPickList: mockCustomFieldsValuesResponse
            });
    });
    it('should clear Second step', () => {
        const secondStepModel: AddGroupSecondStepModel = {
            [GroupCategories.CUSTOM_FIELDS]: [],
            [GroupCategories.DATE_RANGES]: [{ id: '1', label: 'Test', isSelected: true }],
            [GroupCategories.DESCRIPTIVE_INFORMATION]: [{ id: '1', label: 'Test', isSelected: true }],
            selectBy: SelectBy.CATEGORY,
            entities: []
        };
        const currentState = { ...initialState, secondStepModel: secondStepModel };
        expect(addGroupModalReducer(currentState,
            addGroupModalActions.clearSecondStep())).toEqual({
                ...currentState,
                secondStepModel: {
                    ...currentState.secondStepModel,
                    [GroupCategories.DATE_RANGES]: [],
                    [GroupCategories.DESCRIPTIVE_INFORMATION]: [],
                    [GroupCategories.CUSTOM_FIELDS]: [],
                    entities: [],
                    selectBy: SelectBy.ENTITY_NAME
                }
            });
    });

    it('should save all entities', () => {
        const currentState = { ...initialState };
        const shouldEntitiesId = [];

        expect(addGroupModalReducer(currentState,
            addGroupModalActions.saveEntitiesSuccess({ entitiesId: shouldEntitiesId }))).toEqual({
                ...currentState,
                thirdStepModel: {
                    ...currentState.thirdStepModel,
                    entityIdForSave: shouldEntitiesId
                }
            });
    });

    it('should remove chosen entity', () => {
        const currentState = { ...initialState };
        const shouldEntityId = 1;
        expect(addGroupModalReducer(currentState,
            addGroupModalActions.removeEntity({ entityId: shouldEntityId }))).toEqual({
                ...currentState,
                thirdStepModel: {
                    ...currentState.thirdStepModel,
                    entityIdForSave: currentState.thirdStepModel.entityIdForSave.filter(item => item !== shouldEntityId)
                }
            });
    });

    it('should clear Third step', () => {
        const thirdStepModel: AddGroupThirdStepModel = {
            [GroupCategories.DATE_RANGES]: {
                from1: '',
                to1: '',
                from2: '',
                to2: '',
                from3: '',
                to3: '',
                from4: '02/02/2002',
                to4: '02/02/2002',
                option3: DateRagesIntervals.BETWEEN,
                option4: DateRagesIntervals.BETWEEN,
                from5: '02/02/2002',
                to5: '02/02/2002',
                option5: '1'
            },
            [GroupCategories.DESCRIPTIVE_INFORMATION]: {
                [CategoriesInfo.LAST_MODIFIED_BY]: [{ id: '1', label: 'Test', isSelected: true }],
                [CategoriesInfo.ADDRESS_TYPE]: [],
                [CategoriesInfo.BUSINESS_PURPOSE]: '',
                [CategoriesInfo.BUSINESS_STRUCTURE_TYPE]: [],
                [CategoriesInfo.DURATION_TYPE]: [],
                [CategoriesInfo.ENTITY_NAME]: [],
                [CategoriesInfo.ENTITY_STATUS]: [],
                [CategoriesInfo.ENTITY_TYPE]: [],
                [CategoriesInfo.COUNTRY]: [],
                [CategoriesInfo.JURISDICTION]: [],
                [CategoriesInfo.PRIMARY_RESPONSIBLE_USER]: [{ id: '1', label: 'Test', isSelected: true }],
                [CategoriesInfo.REASON_FOR_TERMINATION]: [],
                [CategoriesInfo.ENTITY_SUB_TYPE]: '',
                [CategoriesInfo.ADDITIONAL_COUNTRY_INFO]: '',
                [CategoriesInfo.ADDITIONAL_JURISDICTION_INFO]: '',
                [CategoriesInfo.COMMENT]: '',
                [CategoriesInfo.SECURITY_NAME]: [],
                [CategoriesInfo.STOCK_EXCHANGE]: [],
                [CategoriesInfo.STOCK_IDENTIFIER]: [],
                [CategoriesInfo.STOCK_SYMBOL]: '',
                [CategoriesInfo.LAST_MODIFIED_BY]: [],
                [radioOptionsCntrl]: {},
                [CategoriesInfo.CUSTOM_FIELD_GROUP]: {}
            },
            entityIdForSave: [],
            selectedEntities: [],
            [GroupCategories.SELECTED_PILLS]: {}
        };
        const currentState = { ...initialState, thirdStepModel: thirdStepModel };
        expect(addGroupModalReducer(currentState,
            addGroupModalActions.clearThirdStep())).toEqual({
                ...currentState,
                thirdStepModel: {
                    ...currentState.thirdStepModel,
                    ...clearThirdStepSelection
                }
            });
    });

    it('should set addGroup data', () => {
        const secondStepModel: AddGroupSecondStepModel = {
            [GroupCategories.CUSTOM_FIELDS]: [],
            [GroupCategories.DATE_RANGES]: [],
            [GroupCategories.DESCRIPTIVE_INFORMATION]: [],
            selectBy: SelectBy.ENTITY_NAME,
            entities: []
        };
        const firstStepModelS = {
            groupType: GroupTypes.STATIC,
            groupName: 'test S'
        };
        const expectedStateS = {
            ...initialState,
            activeStep: addGroupSuccessInfoStep,
            firstStepModel: firstStepModelS,
            secondStepModel
        };

        expect(addGroupModalReducer({ ...initialState, firstStepModel: firstStepModelS, secondStepModel },
            groupsActions.addGroup())).toEqual(expectedStateS);

        const firstStepModelD = {
            groupType: GroupTypes.DYNAMIC,
            groupName: 'test D'
        };
        const expectedStateD = {
            ...initialState,
            activeStep: beforeAddGroupSavingStep,
            firstStepModel: firstStepModelD,
            secondStepModel
        };

        expect(addGroupModalReducer({ ...initialState, firstStepModel: firstStepModelD, secondStepModel },
            groupsActions.addGroup())).toEqual(expectedStateD);
    });

    it('should set addGroupFailure data', () => {
        const secondStepModel: AddGroupSecondStepModel = {
            [GroupCategories.CUSTOM_FIELDS]: [],
            [GroupCategories.DATE_RANGES]: [],
            [GroupCategories.DESCRIPTIVE_INFORMATION]: [],
            selectBy: SelectBy.ENTITY_NAME,
            entities: []
        };
        initialState.firstStepModel.groupType = GroupTypes.STATIC;
        const expectedStateS = {
            ...initialState,
            activeStep: addGroupFailInfoStep,
            isOpen: true,
            errorNotificationOpen: false,
            secondStepModel: secondStepModel
        };
        expect(addGroupModalReducer(initialState,
            groupsActions.addGroupFailure({ error: 'error' }))).toEqual(expectedStateS);

        initialState.firstStepModel.groupType = GroupTypes.DYNAMIC;
        const expectedStateD = {
            ...initialState,
            activeStep: addGroupFailInfoStep,
            isOpen: false,
            errorNotificationOpen: true,
            secondStepModel: secondStepModel
        };
        expect(addGroupModalReducer(initialState,
            groupsActions.addGroupFailure({ error: 'error' }))).toEqual(expectedStateD);
    });

    it('should set addGroupSuccess data', () => {
        const secondStepModel: AddGroupSecondStepModel = {
            [GroupCategories.CUSTOM_FIELDS]: [],
            [GroupCategories.DATE_RANGES]: [],
            [GroupCategories.DESCRIPTIVE_INFORMATION]: [],
            selectBy: SelectBy.ENTITY_NAME,
            entities: []
        };
        initialState.firstStepModel.groupType = GroupTypes.STATIC;
        const expectedStateS = {
            ...initialState,
            activeStep: addGroupSuccessInfoStep,
            isOpen: true,
            successNotificationOpen: false,
            secondStepModel: secondStepModel
        };
        expect(addGroupModalReducer(initialState,
            groupsActions.addGroupSuccess({
                result: {
                    entityGroupId: 11000532544,
                    entityGroupGuid: 'd4d0cf2e-fd5a-4fb6-a2cb-ca2a059c3be1',
                    GroupType: 'S',
                    Success: true
                }
            }))).toEqual(expectedStateS);
        initialState.firstStepModel.groupType = GroupTypes.DYNAMIC;
        const expectedStateD = {
            ...initialState,
            activeStep: addGroupSuccessInfoStep,
            isOpen: false,
            successNotificationOpen: true,
            secondStepModel: secondStepModel
        };

        expect(addGroupModalReducer(initialState,
            groupsActions.addGroupSuccess({
                result: {
                    entityGroupId: 11000532544,
                    entityGroupGuid: 'd4d0cf2e-fd5a-4fb6-a2cb-ca2a059c3be1',
                    GroupType: 'D',
                    Success: true
                }
            }))).toEqual(expectedStateD);
    });

    it('should set selected entities', () => {
        const currentState = { ...initialState };
        expect(addGroupModalReducer(currentState,
            addGroupModalActions.setSelectedEntities({
                selectedEntities: mockAddGroupEntityName
            }))).toEqual({
                ...currentState,
                thirdStepModel: {
                    ...currentState.thirdStepModel,
                    selectedEntities: mockAddGroupEntityName
                }
            });
    });

    it('should set grid entities', () => {
        const currentState = {
            ...initialState,
            thirdStepModel: {
                ...initialState.thirdStepModel,
                selectedEntities: mockAddGroupEntityName
            }
        };
        expect(addGroupModalReducer(currentState,
            groupsActions.setGridEntities())).toEqual({
                ...currentState,
                secondStepModel: {
                    ...currentState.secondStepModel,
                    entities: mockAddGroupEntityName
                }
            });
    });

    it('should set duplicate status on groupNameDuplicateSuccess Action', () => {
        const currentState = { ...initialState };
        expect(addGroupModalReducer(currentState, addGroupModalActions.groupNameDuplicateSuccess({
            result: true,
            duplicateStatus: DuplicateStatus.DONE,
            activeStep: 0
        }))).toEqual({
            ...currentState,
            isGroupNameDuplicate: true,
            duplicateStatus: DuplicateStatus.DONE,
            activeStep: 0
        });
    });

    it('should set duplicate status on groupNameDuplicateSuccess Action', () => {
        const currentState = { ...initialState };
        expect(addGroupModalReducer(currentState, addGroupModalActions.groupNameDuplicate({
            isGroupNameDuplicate: true
        }))).toEqual({
            ...currentState,
            isGroupNameDuplicate: true
        });
    });

    it('should reset duplicate status on groupNameDuplicateSuccess Action', () => {
        const mockName = 'test';
        const currentState = {
            ...initialState,
            duplicateStatus: DuplicateStatus.DONE,
            activeStep: CurrentStep.stepTwo
        };
        expect(addGroupModalReducer(currentState, addGroupModalActions.checkGroupNameDuplicate({
            entityGroupName: mockName
        }))).toEqual({
            ...currentState,
            duplicateStatus: DuplicateStatus.PENDING,
            activeStep: CurrentStep.stepOne
        });
    });

});
