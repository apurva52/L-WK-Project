import { CustomFieldItem } from '@ct/platform-common-uicomponents/custom-fields';
import { ICustomFieldsPickList } from '@ct/platform-common-uicomponents/custom-fields-renderer';
import { CemEntity } from '@ct/platform-common-uicomponents/server/src/entity-reference/search-and-select/shared/interfaces/cem-entity.model';
import { createAction, props } from '@ngrx/store';

import {
    AddGroupFirstStepModel,
    AddGroupSecondStepModel,
    AddGroupThirdStepModel
} from '../../shared';

export enum AddGroupModalActionTypes {
    AddGroupModalOpen = `[Add Group] Modal Open`,
    AddGroupModalClose = `[Add Group] Modal Close`,
    MoveToPreviousStep = `[Add Group] Move To Previous Step`,
    MoveToNextStep = `[Add Group] Move To Next Step`,
    UpdateAddGroupFirstStepModel = `[Add Group] Update First Step Model`,
    UpdateAddGroupSecondStepModel = `[Add Group] Update Second Step Model`,
    UpdateAddGroupThirdStepModel = `[Add Group] Update Third Step Model`,
    ClearSecondStep = `[Add Group] Clear Second Step`,
    ClearThirdStep = `[Add Group] Clear Third Step`,
    ClearState = `[Add Group] Clear State`,
    SetAddGroupSuccessNotificationOpen = '[Add Group] Open success notification',
    SetAddGroupFailureNotificationOpen = '[Add Group] Open failure notification',
    SetAddGroupNoMatchingEntityNotificationOpen = '[Add Group] Open No matching Entity notification',
    LoadCustomFieldDetail = '[Add Group] Load Custom Field Details',
    LoadCustomFieldDetailSuccess = '[Add Group] Load Custom Field Detail Success',
    LoadCustomFieldDetailFailure = '[Add Group] Load Custom Field Detail Fail',
    SaveEntities = '[Add Group] Save Entities',
    SaveEntitiesSuccess = '[Add Group] Save Entities Success',
    RemoveEntity = '[Add Group] Remove Entity',
    SetSelectedEntities = '[Add Group] Set selected Entities',
    CheckGroupNameDuplicate = '[Add Group] check group name duplicate',
    GroupNameDuplicateSuccess = '[Add Group] check group name duplicate success',
    GroupNameDuplicate = '[Add Group] set group name duplicate'
}

const addGroupModalOpenAction = createAction(
    AddGroupModalActionTypes.AddGroupModalOpen,
    props<{
        isOpen: boolean;
    }>()
);

const moveToPreviousStep = createAction(
    AddGroupModalActionTypes.MoveToPreviousStep
);

const moveToNextStep = createAction(AddGroupModalActionTypes.MoveToNextStep);

const addGroupModalCloseAction = createAction(
    AddGroupModalActionTypes.AddGroupModalClose
);

const updateAddGroupFirstStepModel = createAction(
    AddGroupModalActionTypes.UpdateAddGroupFirstStepModel,
    props<{
        formData: AddGroupFirstStepModel;
    }>()
);

const updateAddGroupSecondStepModel = createAction(
    AddGroupModalActionTypes.UpdateAddGroupSecondStepModel,
    props<{
        formData: AddGroupSecondStepModel;
    }>()
);

const updateAddGroupThirdStepModel = createAction(
    AddGroupModalActionTypes.UpdateAddGroupThirdStepModel,
    props<{
        formData: AddGroupThirdStepModel;
    }>()
);

const clearSecondStep = createAction(AddGroupModalActionTypes.ClearSecondStep);

const clearThirdStep = createAction(AddGroupModalActionTypes.ClearThirdStep);

const clearState = createAction(AddGroupModalActionTypes.ClearState);

const setAddGroupSuccessNotificationOpen = createAction(
    AddGroupModalActionTypes.SetAddGroupSuccessNotificationOpen,
    props<{
        open: boolean;
    }>()
);

const setAddGroupFailureNotificationOpen = createAction(
    AddGroupModalActionTypes.SetAddGroupFailureNotificationOpen,
    props<{
        open: boolean;
    }>()
);

const setAddGroupNoMatchingEntityNotificationOpen = createAction(
    AddGroupModalActionTypes.SetAddGroupNoMatchingEntityNotificationOpen,
    props<{
        open: boolean;
    }>()
);

const loadCustomFieldDetail = createAction(
    AddGroupModalActionTypes.LoadCustomFieldDetail,
    props<{
        pickListFields: Array<CustomFieldItem>;
    }>()
);
const loadCustomFieldDetailSuccess = createAction(
    AddGroupModalActionTypes.LoadCustomFieldDetailSuccess,
    props<{
        response: { [key: string]: Array<ICustomFieldsPickList> };
    }>()
);
const loadCustomFieldDetailFail = createAction(
    AddGroupModalActionTypes.LoadCustomFieldDetailFailure,
    props<{ error: string }>()
);

const saveEntities = createAction(AddGroupModalActionTypes.SaveEntities);

const saveEntitiesSuccess = createAction(
    AddGroupModalActionTypes.SaveEntitiesSuccess,
    props<{
        entitiesId: Array<number>;
    }>()
);

const setSelectedEntities = createAction(
    AddGroupModalActionTypes.SetSelectedEntities,
    props<{
        selectedEntities: Array<CemEntity>;
    }>()
);

const removeEntity = createAction(
    AddGroupModalActionTypes.RemoveEntity,
    props<{
        entityId: number;
    }>()
);

const checkGroupNameDuplicate = createAction(
    AddGroupModalActionTypes.CheckGroupNameDuplicate,
    props<{
        entityGroupName: string;
    }>()
);

const groupNameDuplicateSuccess = createAction(
    AddGroupModalActionTypes.GroupNameDuplicateSuccess,
    props<{
        result: boolean;
        duplicateStatus: string;
        activeStep: number;
    }>()
);

const groupNameDuplicate = createAction(
    AddGroupModalActionTypes.GroupNameDuplicate,
    props<{
        isGroupNameDuplicate: boolean;
    }>()
);

export const addGroupModalActions = {
    addGroupModalOpenAction,
    addGroupModalCloseAction,
    moveToPreviousStep,
    moveToNextStep,
    updateAddGroupFirstStepModel,
    updateAddGroupSecondStepModel,
    updateAddGroupThirdStepModel,
    clearSecondStep,
    clearThirdStep,
    clearState,
    setAddGroupSuccessNotificationOpen,
    setAddGroupFailureNotificationOpen,
    setAddGroupNoMatchingEntityNotificationOpen,
    loadCustomFieldDetail,
    loadCustomFieldDetailSuccess,
    loadCustomFieldDetailFail,
    saveEntities,
    saveEntitiesSuccess,
    removeEntity,
    setSelectedEntities,
    checkGroupNameDuplicate,
    groupNameDuplicateSuccess,
    groupNameDuplicate
};
