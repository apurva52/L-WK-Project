import { createReducer, on } from '@ngrx/store';

import {
    addGroupFailInfoStep,
    addGroupSuccessInfoStep,
    beforeAddGroupSavingStep,
    DuplicateStatus,
    GroupCategories,
    GroupSaveStatus,
    GroupTypes, isOutOfLimit, SelectBy
} from '../../shared';
import { groupsActions } from '../groups.actions';

import { addGroupModalActions } from './add-group-modal.actions';
import { initialState } from './add-group-modal.state';

export const addGroupModalReducer = createReducer(
    initialState,

    on(addGroupModalActions.addGroupModalOpenAction, (state, action) => ({
        ...state,
        isOpen: action.isOpen,
        activeStep: 0
    })),

    on(addGroupModalActions.moveToPreviousStep, (state) => ({
        ...state,
        activeStep: Math.max(state.activeStep - 1, 0)
    })),

    on(addGroupModalActions.moveToNextStep, (state) => ({
        ...state,
        activeStep: state.activeStep + 1
    })),

    on(addGroupModalActions.addGroupModalCloseAction, (state) => ({
        ...state,
        isOpen: false
    })),

    on(addGroupModalActions.updateAddGroupFirstStepModel, (state, action) => ({
        ...state,
        firstStepModel: action.formData
    })),

    on(addGroupModalActions.updateAddGroupSecondStepModel, (state, action) => ({
        ...state,
        thirdStepModel: {
            ...state.thirdStepModel,
            selectedEntities: action.formData.entities.map((entities) => ({
                ...entities,
                saveStatus: GroupSaveStatus.Preselected
            }))
        },
        secondStepModel: {
            ...action.formData,
            entities: action.formData.entities.map((entities) => ({
                ...entities,
                saveStatus: GroupSaveStatus.Preselected
            }))
        },
        selectIsOutOfLimit: isOutOfLimit(action.formData, state.firstStepModel.groupType === GroupTypes.STATIC)
    })),

    on(addGroupModalActions.updateAddGroupThirdStepModel, (state, action) => ({
        ...state,
        thirdStepModel: action.formData
    })),

    on(addGroupModalActions.clearSecondStep, (state) => ({
        ...state,
        secondStepModel: {
            ...state.secondStepModel,
            [GroupCategories.DATE_RANGES]: [],
            [GroupCategories.DESCRIPTIVE_INFORMATION]: [],
            [GroupCategories.CUSTOM_FIELDS]: [],
            selectBy: SelectBy.ENTITY_NAME,
            entities: []
        }
    })),
    on(addGroupModalActions.clearThirdStep, (state) => ({
        ...state,
        thirdStepModel: {
            ...initialState.thirdStepModel
        }
    })),

    on(addGroupModalActions.clearState, (state) => ({
        ...state,
        ...initialState,
        errorNotificationOpen: state.errorNotificationOpen,
        successNotificationOpen: state.successNotificationOpen
    })),

    on(addGroupModalActions.setAddGroupSuccessNotificationOpen, (state, action) => ({
        ...state,
        successNotificationOpen: action.open
    })),

    on(addGroupModalActions.setAddGroupFailureNotificationOpen, (state, action) => ({
        ...state,
        errorNotificationOpen: action.open
    })),

    on(addGroupModalActions.setAddGroupNoMatchingEntityNotificationOpen, (state, action) => ({
        ...state,
        noMatchingEntityNotificationOpen: action.open
    })),
    on(addGroupModalActions.loadCustomFieldDetailSuccess, (state, action) => ({
        ...state,
        customFieldsPickList: action.response
    })),
    on(addGroupModalActions.saveEntitiesSuccess, (state, action) => ({
        ...state,
        thirdStepModel: {
            ...state.thirdStepModel,
            entityIdForSave: action.entitiesId
        }
    })),
    on(addGroupModalActions.removeEntity, (state, action) => ({
        ...state,
        thirdStepModel: {
            ...state.thirdStepModel,
            entityIdForSave: state.thirdStepModel.entityIdForSave.filter(item => item !== action.entityId)
        }
    })),
    on(groupsActions.addGroup, (state) => {
        return {
            ...state,
            activeStep: (state.firstStepModel.groupType === GroupTypes.STATIC && state.secondStepModel.selectBy === SelectBy.ENTITY_NAME)
                ? addGroupSuccessInfoStep : beforeAddGroupSavingStep,
            secondStepModel: {
                ...state.secondStepModel,
                entities: state.secondStepModel.entities?.map((entities) => ({
                    ...entities,
                    saveStatus: GroupSaveStatus.InProgress
                }))
            }
        };
    }),

    on(groupsActions.addGroupSuccess, (state) => {
        return {
            ...state,
            activeStep: addGroupSuccessInfoStep,
            isOpen: state.firstStepModel.groupType === GroupTypes.STATIC && state.secondStepModel.selectBy === SelectBy.ENTITY_NAME,
            successNotificationOpen: !(state.firstStepModel.groupType === GroupTypes.STATIC &&
                state.secondStepModel.selectBy === SelectBy.ENTITY_NAME),
            secondStepModel: {
                ...state.secondStepModel,
                entities: state.secondStepModel.entities?.map((entities) => ({
                    ...entities,
                    saveStatus: GroupSaveStatus.Success
                }))
            }
        };
    }),

    on(groupsActions.addGroupFailure, (state) => {
        return {
            ...state,
            activeStep: addGroupFailInfoStep,
            isOpen: state.firstStepModel.groupType === GroupTypes.STATIC && state.secondStepModel.selectBy === SelectBy.ENTITY_NAME,
            errorNotificationOpen: !(state.firstStepModel.groupType === GroupTypes.STATIC &&
                 state.secondStepModel.selectBy === SelectBy.ENTITY_NAME),
            secondStepModel: {
                ...state.secondStepModel,
                entities: state.secondStepModel.entities?.map((entities) => ({
                    ...entities,
                    saveStatus: GroupSaveStatus.Failed
                }))
            }
        };
    }),

    on(addGroupModalActions.setSelectedEntities, (state, action) => ({
        ...state,
        thirdStepModel: {
            ...state.thirdStepModel,
            selectedEntities: action.selectedEntities
        }
    })),

    on(groupsActions.setGridEntities, (state) => ({
        ...state,
        secondStepModel: {
            ...state.secondStepModel,
            entities: state.thirdStepModel.selectedEntities
        }
    })),

    on(addGroupModalActions.checkGroupNameDuplicate, (state) => ({
        ...state,
        duplicateStatus: DuplicateStatus.PENDING,
        activeStep: 0
    })),

    on(addGroupModalActions.groupNameDuplicateSuccess, (state, action) => ({
        ...state,
        isGroupNameDuplicate: action.result,
        duplicateStatus: action.duplicateStatus,
        activeStep: action.activeStep
    })),

    on(addGroupModalActions.groupNameDuplicate, (state, action) => ({
        ...state,
        isGroupNameDuplicate: action.isGroupNameDuplicate
    }))

);
