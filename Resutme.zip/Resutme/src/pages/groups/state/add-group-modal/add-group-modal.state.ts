import { ICustomFieldsPickList } from '@ct/platform-common-uicomponents/custom-fields-renderer';

import {
    AddGroupFirstStepModel,
    AddGroupSecondStepModel,
    addGroupStepsModel,
    AddGroupThirdStepModel,
    DuplicateStatus
} from '../../shared';

export const ADD_GROUP_MODAL_FEATURE_KEY = 'addGroupModalFeatureKey';

export interface AddGroupModalState {
    addGroup: string;
    loading: boolean;
    isOpen: boolean;
    activeStep: number;
    firstStepModel: AddGroupFirstStepModel;
    secondStepModel: AddGroupSecondStepModel;
    thirdStepModel: AddGroupThirdStepModel;
    selectIsOutOfLimit: boolean;
    successNotificationOpen: boolean;
    errorNotificationOpen: boolean;
    noMatchingEntityNotificationOpen: boolean;
    customFieldsPickList: { [key: string]: Array<ICustomFieldsPickList> };
    isGroupNameDuplicate: boolean;
    duplicateStatus: string;
}

export const initialState: AddGroupModalState = {
    addGroup: null,
    loading: false,
    isOpen: false,
    activeStep: 0,
    firstStepModel: {
        groupName: '',
        groupType: null
    },
    ...addGroupStepsModel,
    selectIsOutOfLimit: true,
    successNotificationOpen: false,
    errorNotificationOpen: false,
    noMatchingEntityNotificationOpen: false,
    customFieldsPickList: null,
    isGroupNameDuplicate: false,
    duplicateStatus: DuplicateStatus.PENDING
};
