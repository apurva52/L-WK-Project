// tslint:disable:max-file-line-count
import { ICustomFieldsPickList } from '@ct/platform-common-uicomponents/custom-fields-renderer';

import {
    AddGroupFirstStepModel,
    AddGroupSecondStepModel,
    DescriptiveInformationModel,
    DuplicateStatus,
    GroupCategories,
    GroupTypes,
    SelectBy
} from '../../shared';
import {
    dateRangesFormMock,
    existingDates,
    mockAddGroupDateRanges,
    mockAddGroupState,
    mockWizardSteps
} from '../../shared/mocks/add-group-modal';

import * as addGroupModalSelectors from './add-group-modal.selectors';
import { AddGroupModalState, initialState } from './add-group-modal.state';

describe('Add group modal selectors', () => {
    it('should return add group modal open status', () => {
        const modalOpenStatus = true;
        const currentState: AddGroupModalState = {
            ...initialState,
            isOpen: modalOpenStatus
        };
        const currentData =
            addGroupModalSelectors.selectAddGroupModalOpen.projector(
                currentState
            );
        expect(currentData).toEqual(true);
    });

    it('should return current step', () => {
        const currentState: AddGroupModalState = {
            ...initialState,
            activeStep: 0
        };
        expect(
            addGroupModalSelectors.selectCurrentStep.projector(currentState)
        ).toEqual(0);
    });

    it('should return previous visible', () => {
        const currentState: AddGroupModalState = {
            ...initialState,
            activeStep: 0
        };
        expect(
            addGroupModalSelectors.selectPreviousVisible.projector(currentState)
        ).toEqual(true);
    });

    it('should return cancel visible', () => {
        const currentState: AddGroupModalState = {
            ...initialState,
            activeStep: 0
        };
        expect(
            addGroupModalSelectors.selectCancelVisible.projector(currentState)
        ).toEqual(true);
    });

    it('should return steps payload', () => {
        const currentState: AddGroupModalState = {
            ...initialState
        };
        const currentData =
            addGroupModalSelectors.selectStepsPayload.projector(currentState);
        expect(currentData).toEqual(mockWizardSteps);
    });

    it('should return first step form data', () => {
        const firstStepModel: AddGroupFirstStepModel = {
            groupName: 'Group Name',
            groupType: GroupTypes.DYNAMIC
        };
        const currentState: AddGroupModalState = {
            ...initialState,
            firstStepModel
        };
        const currentData =
            addGroupModalSelectors.selectAddGroupFirstStepFormData.projector(
                currentState
            );
        expect(currentData).toEqual(firstStepModel);
    });

    it('should return date ranges form data', () => {
        const dateRangesForm = dateRangesFormMock;
        const selectedExistingDates = existingDates;
        const currentState: AddGroupModalState = {
            ...initialState,
            thirdStepModel: {
                descriptiveInformation: {} as DescriptiveInformationModel,
                entityIdForSave: [],
                selectedEntities: [],
                dateRanges: {
                    ...dateRangesForm
                },
                selectedPills: {}
            }
        };
        const currentData =
            addGroupModalSelectors.selectedExistingDates.projector(
                currentState
            );
        expect(currentData).toEqual(selectedExistingDates);
    });

    it('should return second step form data', () => {
        const secondStepModel: AddGroupSecondStepModel = {
            [GroupCategories.CUSTOM_FIELDS]: [],
            [GroupCategories.DATE_RANGES]: [],
            [GroupCategories.DESCRIPTIVE_INFORMATION]: [],
            selectBy: SelectBy.ENTITY_NAME,
            entities: []
        };
        const currentState: AddGroupModalState = {
            ...initialState,
            secondStepModel
        };
        const currentData =
            addGroupModalSelectors.selectAddGroupSecondStepFormData.projector(
                currentState
            );
        expect(currentData).toEqual(secondStepModel);
    });

    it('should return IsOutOfLimit', () => {
        const currentState: AddGroupModalState = {
            ...initialState
        };
        const currentData =
            addGroupModalSelectors.selectIsOutOfLimit.projector(currentState);
        expect(currentData).toEqual(true);
    });

    it('should return first step data', () => {
        const firstStepModel = mockAddGroupState.firstStepModel;
        const currentState: AddGroupModalState = {
            ...initialState,
            firstStepModel
        };
        const currentData =
            addGroupModalSelectors.selectAddGroupFirstStepFormData.projector(
                currentState
            );
        expect(currentData).toEqual(firstStepModel);
    });

    it('should return second step data', () => {
        const secondStepModel = mockAddGroupState.secondStepModel;
        const currentState: AddGroupModalState = {
            ...initialState,
            secondStepModel
        };
        const currentData =
            addGroupModalSelectors.selectAddGroupSecondStepFormData.projector(
                currentState
            );
        expect(currentData).toEqual(secondStepModel);
    });

    it('should select no selection notification model', () => {
        const i18nBase =
            'GroupsModule.addGroupModalComponent.step2.notification';
        const secondStepModel = {
            ...mockAddGroupState.secondStepModel,
            [GroupCategories.ADMINISTRATION]: [],
            [GroupCategories.STOCK_INFORMATION]: [],
            [GroupCategories.CUSTOM_FIELDS]: []
        };
        const expectedResult = {
            title: `${i18nBase}.noSelection.title`,
            content: `${i18nBase}.noSelection.content`
        };
        const currentState: AddGroupModalState = {
            ...initialState,
            secondStepModel,
            firstStepModel: {
                ...initialState.firstStepModel,
                groupType: GroupTypes.DYNAMIC
            }
        };
        let currentData =
            addGroupModalSelectors.selectNotificationModel.projector(
                currentState
            );
        expect(currentData).toEqual(expectedResult);
        currentData = addGroupModalSelectors.selectNotificationModel.projector({
            ...currentState,
            firstStepModel: {
                ...initialState.firstStepModel,
                groupType: GroupTypes.STATIC
            }
        });
        expect(currentData).toEqual(expectedResult);
        currentData = addGroupModalSelectors.selectNotificationModel.projector({
            ...currentState,
            secondStepModel: {
                [GroupCategories.CUSTOM_FIELDS]: null,
                [GroupCategories.DATE_RANGES]: null,
                [GroupCategories.DESCRIPTIVE_INFORMATION]: null,
                [GroupCategories.ADMINISTRATION]: null,
                [GroupCategories.STOCK_INFORMATION]: null
            }
        });
        expect(currentData).toEqual(expectedResult);
    });

    it('should select max selection notification model', () => {
        const i18nBase =
            'GroupsModule.addGroupModalComponent.step2.notification';
        const secondStepModel = mockAddGroupState.secondStepModel;
        secondStepModel[GroupCategories.DATE_RANGES] = mockAddGroupDateRanges;
        const currentState: AddGroupModalState = {
            ...initialState,
            secondStepModel
        };
        const currentData =
            addGroupModalSelectors.selectNotificationModel.projector(
                currentState
            );
        expect(currentData).toEqual({
            title: `${i18nBase}.maxSelection.title`,
            content: `${i18nBase}.maxSelection.content`
        });
    });

    it('should return success notification open status', () => {
        const currentState: AddGroupModalState = {
            ...initialState,
            successNotificationOpen: true
        };
        const currentData =
            addGroupModalSelectors.selectAddGroupSuccessNotificationOpen.projector(
                currentState
            );
        expect(currentData).toEqual(true);
    });

    it('should return failure notification open status', () => {
        const currentState: AddGroupModalState = {
            ...initialState,
            errorNotificationOpen: true
        };
        const currentData =
            addGroupModalSelectors.selectAddGroupFailureNotificationOpen.projector(
                currentState
            );
        expect(currentData).toEqual(true);
    });

    it('should return no matching entity notification open status', () => {
        const currentState: AddGroupModalState = {
            ...initialState,
            noMatchingEntityNotificationOpen: true
        };
        const currentData =
            addGroupModalSelectors.selectAddGroupNoMatchingEntityNotificationOpen.projector(
                currentState
            );
        expect(currentData).toEqual(true);
    });

    it('should get custom picklists values', () => {
        const customListPick: ICustomFieldsPickList = {
            id: '1',
            value: 'Test'
        } as ICustomFieldsPickList;
        const currentState: AddGroupModalState = {
            ...initialState,
            customFieldsPickList: { 1: [customListPick] }
        };

        const pickListValues =
            addGroupModalSelectors.selectCustomFieldsPickList.projector(
                currentState
            );

        expect(pickListValues).toEqual({ 1: [customListPick] });
    });

    it('should return entities grid data ', () => {
        const entities = [
            {
                entityId: 11000579195,
                entityGuid: 'fae3df31-86c7-497b-81b2-e0995bc6e090',
                entityName: 'ABCB Capital Management, LP.',
                acronym: 'acronym',
                domesticJurisdictionId: 23234354,
                domesticJurisdictionCode: 'code',
                domesticJurisdictionDesc: 'desc',
                entityTypeId: 123,
                entityTypeDesc: 'type',
                status: 'status',
                formationDate: '2016-03-19T00:00:00',
                saveStatus: 1
            }
        ];
        const currentState: AddGroupModalState = {
            ...initialState,
            secondStepModel: {
                ...initialState.secondStepModel,
                entities
            }
        };
        const currentData =
            addGroupModalSelectors.selectEntitiesGridData.projector(
                currentState
            );
        expect(currentData).toEqual(entities);
    });

    it('should return selected entities id', () => {
        const entityIdForSave = [1, 2];
        const currentState: AddGroupModalState = {
            ...initialState,
            thirdStepModel: {
                ...initialState.thirdStepModel,
                entityIdForSave
            }
        };
        const currentData =
            addGroupModalSelectors.getEntitiesId.projector(currentState);
        expect(currentData).toEqual(entityIdForSave);
    });

    it('should select Add Group Modal Steps', () => {
        const selectAddGroupModalSteps = {
            steps: [
                {
                    nextLabel: [
                        'GroupsModule.addGroupModalComponent.step1.null.nextLabel',
                        'GroupsModule.addGroupModalComponent.step1.staticLabel.nextLabel'
                    ],
                    title: [
                        'GroupsModule.addGroupModalComponent.step1.null.title',
                        'GroupsModule.addGroupModalComponent.step1.staticLabel.title'
                    ],
                    previousLabel: [
                        'GroupsModule.addGroupModalComponent.step1.null.previousLabel',
                        'GroupsModule.addGroupModalComponent.step1.previousLabel'
                    ],
                    validation: false
                },
                {
                    nextLabel: [
                        'GroupsModule.addGroupModalComponent.step2.null.nextLabel',
                        'GroupsModule.addGroupModalComponent.step2.staticLabel.nextLabel'
                    ],
                    title: [
                        'GroupsModule.addGroupModalComponent.step2.null.title',
                        'GroupsModule.addGroupModalComponent.step2.staticLabel.title'
                    ],
                    previousLabel: [
                        'GroupsModule.addGroupModalComponent.step2.null.previousLabel',
                        'GroupsModule.addGroupModalComponent.step2.previousLabel'
                    ],
                    validation: false
                },
                {
                    nextLabel: [
                        'GroupsModule.addGroupModalComponent.step3.null.nextLabel',
                        'GroupsModule.addGroupModalComponent.step3.staticLabel.nextLabel'
                    ],
                    title: [
                        'GroupsModule.addGroupModalComponent.step3.null.title',
                        'GroupsModule.addGroupModalComponent.step3.staticLabel.title'
                    ],
                    previousLabel: [
                        'GroupsModule.addGroupModalComponent.step3.null.previousLabel',
                        'GroupsModule.addGroupModalComponent.step3.previousLabel'
                    ],
                    validation: false
                }
            ],
            translations: [
                'GroupsModule.addGroupModalComponent.step1.null.nextLabel',
                'GroupsModule.addGroupModalComponent.step1.staticLabel.nextLabel',
                'GroupsModule.addGroupModalComponent.step1.null.title',
                'GroupsModule.addGroupModalComponent.step1.staticLabel.title',
                'GroupsModule.addGroupModalComponent.step1.null.previousLabel',
                'GroupsModule.addGroupModalComponent.step1.previousLabel',
                'GroupsModule.addGroupModalComponent.step2.null.nextLabel',
                'GroupsModule.addGroupModalComponent.step2.staticLabel.nextLabel',
                'GroupsModule.addGroupModalComponent.step2.null.title',
                'GroupsModule.addGroupModalComponent.step2.staticLabel.title',
                'GroupsModule.addGroupModalComponent.step2.null.previousLabel',
                'GroupsModule.addGroupModalComponent.step2.previousLabel',
                'GroupsModule.addGroupModalComponent.step3.null.nextLabel',
                'GroupsModule.addGroupModalComponent.step3.staticLabel.nextLabel',
                'GroupsModule.addGroupModalComponent.step3.null.title',
                'GroupsModule.addGroupModalComponent.step3.staticLabel.title',
                'GroupsModule.addGroupModalComponent.step3.null.previousLabel',
                'GroupsModule.addGroupModalComponent.step3.previousLabel'
            ]
        };

        const firstStepModel: AddGroupFirstStepModel = {
            groupName: 'Group Name',
            groupType: GroupTypes.STATIC
        };
        const secondStepModel = mockAddGroupState.secondStepModel;
        const currentState: AddGroupModalState = {
            ...initialState,
            addGroup: null,
            activeStep: 2,
            firstStepModel,
            secondStepModel
        };
        const currentData =
            addGroupModalSelectors.selectAddGroupModalSteps.projector(
                currentState
            );
        expect(currentData).toEqual(selectAddGroupModalSteps);
    });

    it('should return empty dates', () => {
        const currentState: AddGroupModalState = {
            ...initialState,
            thirdStepModel: {
                ...initialState.thirdStepModel,
                dateRanges: {
                    from1: undefined,
                    to1: undefined,
                    from2: undefined,
                    to2: undefined,
                    from3: undefined,
                    to3: undefined,
                    from4: undefined,
                    to4: undefined,
                    from5: undefined,
                    to5: undefined,
                    option3: '',
                    option4: '',
                    option5: ''
                }
            }
        };
        const existingDates =
            addGroupModalSelectors.selectedExistingDates.projector(
                currentState
            );
        expect(existingDates.from2).toBeUndefined();
        expect(existingDates.to2).toBeUndefined();
    });

    it('should return duplicate group name status', () => {
        const currentState: AddGroupModalState = {
            ...initialState,
            isGroupNameDuplicate: true
        };
        const currentData =
            addGroupModalSelectors.selectIsGroupNameDuplicate.projector(
                currentState
            );
        expect(currentData).toEqual(true);
    });

    it('should return duplicate status', () => {
        const currentState: AddGroupModalState = {
            ...initialState,
            duplicateStatus: DuplicateStatus.DONE
        };
        const currentData =
            addGroupModalSelectors.selectDuplicateStatus.projector(
                currentState
            );
        expect(currentData).toEqual(DuplicateStatus.DONE);
    });

    it('should return group name', () => {
        const firstStepModel: AddGroupFirstStepModel = {
            groupName: 'Group Name',
            groupType: GroupTypes.STATIC
        };
        const currentState: AddGroupModalState = {
            ...initialState,
            firstStepModel
        };
        const currentData =
            addGroupModalSelectors.selectGroupName.projector(currentState);
        expect(currentData).toEqual('Group Name');
    });
});
