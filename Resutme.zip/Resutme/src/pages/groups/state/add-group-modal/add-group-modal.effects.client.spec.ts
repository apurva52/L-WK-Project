import { TestBed } from '@angular/core/testing';
import { ExperienceConfigurationServiceNg } from '@ct/core-ui-ng';
import { EffectsModule } from '@ngrx/effects';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { Observable, of, ReplaySubject, throwError } from 'rxjs';
import { TestScheduler } from 'rxjs/testing';

import { CustomFieldsService } from '../../../../shared/services/custom-fields/customFields.service';
import { GroupsService } from '../../../../shared/services/groups/groups.service';
import { addGroupSecondStepForm, DuplicateStatus } from '../../shared';
import {
    getCustomFieldsDetails,
    mockCustomFieldsItems
} from '../../shared/test-stubs/group-custom-fields.stub';

import { addGroupModalActions } from './add-group-modal.actions';
import { AddGroupModalEffects } from './add-group-modal.effects';
import {
    ADD_GROUP_MODAL_FEATURE_KEY,
    initialState
} from './add-group-modal.state';

describe('Add Groups Modal effects', () => {
    let action$: ReplaySubject<any>;
    let effects: AddGroupModalEffects;
    const mockService = jasmine.createSpyObj<any>('CustomFieldsService', [
        'getCustomFieldDetails'
    ]);

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [EffectsModule.forRoot([AddGroupModalEffects])],
            providers: [
                provideMockStore({
                    initialState: {
                        [ADD_GROUP_MODAL_FEATURE_KEY]: initialState
                    }
                }),
                provideMockActions(() => action$),
                {
                    provide: CustomFieldsService,
                    useValue: mockService
                },
                GroupsService,
                ExperienceConfigurationServiceNg
            ]
        });
        effects = TestBed.inject(AddGroupModalEffects);
    });

    it('should call form reset function when modal open or close', () => {
        action$ = new ReplaySubject(1);
        action$.next(
            addGroupModalActions.addGroupModalOpenAction({ isOpen: true })
        );
        spyOn(addGroupSecondStepForm, 'reset');
        effects.clearFormsAfterClosingModal$.subscribe();
        expect(addGroupSecondStepForm.reset).toHaveBeenCalled();
    });

    it('should request custom field details success response', (done) => {
        const effects: { addGroupModalEffects: AddGroupModalEffects } = setup({
            returnValue: of(getCustomFieldsDetails)
        });

        action$ = new ReplaySubject(1);
        action$.next(
            addGroupModalActions.loadCustomFieldDetail({
                pickListFields: mockCustomFieldsItems
            })
        );
        effects.addGroupModalEffects.loadCustomFieldsDetails$.subscribe(
            (action: any) => {
                expect(action).toEqual(
                    addGroupModalActions.loadCustomFieldDetailSuccess({
                        response: {
                            1: [
                                {
                                    id: '11600009428',
                                    name: 'option one update'
                                },
                                {
                                    id: '11600009429',
                                    name: 'option two update'
                                }
                            ]
                        }
                    })
                );
                done();
            }
        );
    });

    it('should request custom field details failure response', () => {
        action$ = new ReplaySubject(1);
        const errorMessage = 'EntityGroupGuid has to be a valid Guid.';
        mockService.getCustomFieldDetails.and.returnValue(
            throwError(errorMessage)
        );
        const failureOutcome = addGroupModalActions.loadCustomFieldDetailFail({
            error: errorMessage
        });
        action$.next(
            addGroupModalActions.loadCustomFieldDetail({
                pickListFields: mockCustomFieldsItems
            })
        );
        effects.loadCustomFieldsDetails$.subscribe((action: any) => {
            expect(action).toEqual(failureOutcome);
        });
    });

    it('should save entities id in step 3', (done) => {
        action$ = new ReplaySubject(1);
        action$.next(addGroupModalActions.saveEntities());
        effects.saveEntities$.subscribe((action) => {
            expect(action).toEqual(
                addGroupModalActions.saveEntitiesSuccess({
                    entitiesId: []
                })
            );
            done();
        });
    });

    function setup(params: { returnValue: any }): {
        addGroupModalEffects: AddGroupModalEffects;
    } {
        mockService.getCustomFieldDetails.and.returnValue(params.returnValue);

        return {
            addGroupModalEffects: TestBed.inject(AddGroupModalEffects)
        };
    }
});

describe('Add Groups Modal effects', () => {
    let action$: Observable<any>;
    let effects: AddGroupModalEffects;
    let testScheduler: TestScheduler;
    const mockService = jasmine.createSpyObj<any>('CustomFieldsService', [
        'getCustomFieldDetails'
    ]);
    const mockGroupService = jasmine.createSpyObj<any>('GroupsService', [
        'checkDuplicate'
    ]);

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [EffectsModule.forRoot([AddGroupModalEffects])],
            providers: [
                provideMockStore({
                    initialState: {
                        [ADD_GROUP_MODAL_FEATURE_KEY]: initialState
                    }
                }),
                provideMockActions(() => action$),
                {
                    provide: CustomFieldsService,
                    useValue: mockService
                },
                {
                    provide: GroupsService,
                    useValue: mockGroupService
                },
                ExperienceConfigurationServiceNg
            ]
        });
        effects = TestBed.inject(AddGroupModalEffects);
        testScheduler = new TestScheduler((actual, expected) => {
            expect(actual).toEqual(expected);
        });
    });

    it('should check group name duplicate and return next step on success', () => {
        const action = addGroupModalActions.checkGroupNameDuplicate({
            entityGroupName: 'test'
        });
        const outcome = addGroupModalActions.groupNameDuplicateSuccess({
            result: false,
            duplicateStatus: DuplicateStatus.DONE,
            activeStep: 1
        });
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-b', { b: { result: false } });
            mockGroupService.checkDuplicate.and.returnValue(result$);
            expectObservable(effects.checkGroupNameDuplicate$).toBe('--b', {
                b: outcome
            });
        });
    });

    it('should check group name duplicate and return previous step on failure', () => {
        const action = addGroupModalActions.checkGroupNameDuplicate({
            entityGroupName: 'test'
        });
        const outcome = addGroupModalActions.groupNameDuplicateSuccess({
            result: true,
            duplicateStatus: DuplicateStatus.DONE,
            activeStep: 0
        });
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-b', { b: { result: true } });
            mockGroupService.checkDuplicate.and.returnValue(result$);
            expectObservable(effects.checkGroupNameDuplicate$).toBe('--b', {
                b: outcome
            });
        });
    });
});
