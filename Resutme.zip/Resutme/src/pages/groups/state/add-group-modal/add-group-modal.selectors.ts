import { NotificationModel } from '@ct/platform-primitives-uicomponents/primitives';
import { createFeatureSelector, createSelector } from '@ngrx/store';

import {
    addGroupModalStepsLength,
    addGroupSavingStep,
    GroupCategories,
    GroupTypes,
    SelectBy
} from '../../shared';
import { getAddGroupModalStepsConfig } from '../../shared/config/add-group-modal.config';

import {
    ADD_GROUP_MODAL_FEATURE_KEY,
    AddGroupModalState
} from './add-group-modal.state';

export const selectRootFeature = createFeatureSelector<AddGroupModalState>(
    ADD_GROUP_MODAL_FEATURE_KEY
);

export const selectAddGroupModalOpen = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state?.isOpen
);

export const selectCurrentStep = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state.activeStep
);

export const selectedGroupType = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state.addGroup
);

export const selectedExistingDates = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => ({
        from2: state.thirdStepModel.dateRanges.from2?.value,
        to2: state.thirdStepModel.dateRanges.to2?.value,
        from3: state.thirdStepModel.dateRanges.from3?.value,
        to3: state.thirdStepModel.dateRanges.to3?.value,
        from4: state.thirdStepModel.dateRanges.from4?.value,
        to4: state.thirdStepModel.dateRanges.to4?.value,
        from5: state.thirdStepModel.dateRanges.from5?.value,
        to5: state.thirdStepModel.dateRanges.to5?.value
    })
);

export const selectStepsPayload = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => {
        const steps = [];
        for (let index = 0; index < addGroupModalStepsLength; index++) {
            steps.push({
                isActive: state.activeStep === index ? true : false,
                isFailed: false,
                isVisited: state.activeStep > index ? true : false,
                stepId: index + 1,
                description: ''
            });
        }

        return steps;
    }
);

export const selectAddGroupModalSteps = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => {
        const steps = getAddGroupModalStepsConfig(
            state.activeStep || 0,
            state.addGroup,
            state?.firstStepModel.groupType === GroupTypes.STATIC &&
                state?.secondStepModel.selectBy === SelectBy.ENTITY_NAME
        );

        return {
            steps,
            translations: steps.reduce(
                (acc, step) => [
                    ...acc,
                    ...(step.nextLabel as Array<string>),
                    ...(step.title as Array<string>),
                    ...(step.previousLabel as Array<string>)
                ],
                []
            )
        };
    }
);

export const selectPreviousVisible = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state.activeStep < addGroupSavingStep
);

export const selectCancelVisible = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state.activeStep < addGroupSavingStep
);

export const selectAddGroupFirstStepFormData = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state?.firstStepModel
);

export const selectAddGroupSecondStepFormData = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state?.secondStepModel
);

export const selectEntitiesGridData = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state.secondStepModel.entities
);

export const getEntitiesId = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state.thirdStepModel.entityIdForSave
);

export const selectAddGroupThirdStepFormData = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state?.thirdStepModel
);

export const selectIsOutOfLimit = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state.selectIsOutOfLimit
);

export const selectNotificationModel = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => {
        const i18nBase =
            'GroupsModule.addGroupModalComponent.step2.notification';
        let notificationType = 'maxSelection';
        const isBaseSelectionEmpty =
            !state?.secondStepModel[GroupCategories.CUSTOM_FIELDS]?.length &&
            !state.secondStepModel[GroupCategories.DATE_RANGES]?.length &&
            !state.secondStepModel[GroupCategories.DESCRIPTIVE_INFORMATION]
                ?.length;
        const isStaticSelectionEmpty =
            !state?.secondStepModel[GroupCategories.STOCK_INFORMATION]
                ?.length &&
            !state.secondStepModel[GroupCategories.ADMINISTRATION]?.length;
        if (
            state?.firstStepModel.groupType === GroupTypes.DYNAMIC
                ? isBaseSelectionEmpty
                : isBaseSelectionEmpty && isStaticSelectionEmpty
        ) {
            notificationType = 'noSelection';
        }

        return {
            title: `${i18nBase}.${notificationType}.title`,
            content: `${i18nBase}.${notificationType}.content`
        } as NotificationModel;
    }
);

export const selectAddGroupSuccessNotificationOpen = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state?.successNotificationOpen
);

export const selectAddGroupFailureNotificationOpen = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state?.errorNotificationOpen
);

export const selectAddGroupNoMatchingEntityNotificationOpen = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state?.noMatchingEntityNotificationOpen
);

export const selectCustomFieldsPickList = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state?.customFieldsPickList
);

export const selectGroupName = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state?.firstStepModel.groupName
);

export const selectIsGroupNameDuplicate = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state?.isGroupNameDuplicate
);

export const selectDuplicateStatus = createSelector(
    selectRootFeature,
    (state: AddGroupModalState) => state?.duplicateStatus
);
