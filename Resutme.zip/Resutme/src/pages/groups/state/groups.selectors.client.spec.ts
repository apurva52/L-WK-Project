import { groupsListMock } from '../shared';

import * as groupsSelectors from './groups.selectors';
import { GroupsState, initialState } from './groups.state';

describe('Groups selectors', () => {
    it('should return total records count', () => {
        const totalRecordCount = 15;
        const currentState: GroupsState = {
            ...initialState,
            totalRecordCount
        };

        const currentData =
            groupsSelectors.selectGroupsTotalRecordCount.projector(currentState);
        expect(currentData).toEqual(totalRecordCount);
    });

    it('should return last 30 days records count', () => {
        const createdInLast30Days = 10;
        const currentState: GroupsState = {
            ...initialState,
            createdInLast30Days
        };

        const currentData =
            groupsSelectors.selectGroupsCreatedInLast30Days.projector(currentState);
        expect(currentData).toEqual(createdInLast30Days);
    });

    it('should return current loading status', () => {
        const loading = true;
        const currentState: GroupsState = {
            ...initialState,
            loading
        };

        const currentData =
            groupsSelectors.selectGroupsLoading.projector(currentState);
        expect(currentData).toEqual(loading);
    });

    it('should return selections', () => {
        const selections = [];
        const currentState: GroupsState = {
            ...initialState,
            selections
        };

        const currentData =
        groupsSelectors.selectSelections.projector(currentState);
        expect(currentData).toEqual(selections);
    });

    it('should return selections count', () => {
        const selections = [];
        const currentState: GroupsState = {
            ...initialState,
            selections
        };

        const currentData =
        groupsSelectors.selectSelectionsCount.projector(currentState);
        expect(currentData).toEqual(selections.length);
    });

    it('should return selected group', () => {
        const selected = groupsListMock[0];
        const currentState: GroupsState = {
            ...initialState,
            selectedGroup: selected
        };

        const currentData =
            groupsSelectors.selectedGroupItem.projector(currentState);
        expect(currentData).toEqual(selected);
    });

    it('should return group deleting notification', () => {
        const isGroupDeletedSuccessfully = true;
        const currentState: GroupsState = {
            ...initialState,
            isGroupDeletedSuccessfully
        };

        const currentData =
            groupsSelectors.selectGroupRemovalNotification.projector(currentState);
        expect(currentData).toEqual(isGroupDeletedSuccessfully);
    });

    it('should return warning notification', () => {
        const isDeleteGroupWarningNotVisible = true;
        const currentState: GroupsState = {
            ...initialState,
            isDeleteGroupWarningNotVisible
        };

        const currentData =
            groupsSelectors.selectIsDeleteGroupWarningNotVisible.projector(currentState);
        expect(currentData).toEqual(isDeleteGroupWarningNotVisible);
    });
});
