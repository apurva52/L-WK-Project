import { createReducer, on } from '@ngrx/store';

import { groupsActions } from './groups.actions';
import { initialState } from './groups.state';

export const groupsReducer = createReducer(
    initialState,
    on(groupsActions.groupsGetTotal, (state) => ({
        ...state,
        loading: true
    })),
    on(groupsActions.groupsGetTotalSuccess, (state, action) => ({
        ...state,
        loading: false,
        createdInLast30Days: action.result.createdInLast30Days,
        totalRecordCount: action.result.totalRecordCount
    })),
    on(groupsActions.groupsGetTotalFailure, (state, action) => ({
        ...state,
        loading: false,
        errorMessage: action.error
    })),
    on(groupsActions.groupsGetList, (state) => ({
        ...state,
        loading: true
    })),
    on(groupsActions.groupsGetListSuccess, (state, action) => ({
        ...state,
        loading: false,
        groupList: [
            ...state.groupList,
            ...action.result
        ]
    })),
    on(groupsActions.groupsGetListFailure, (state, action) => ({
        ...state,
        loading: false,
        errorMessage: action.error
    })),
    on(groupsActions.clearGroupsList, (state, action) => ({
        ...state,
        groupList: []
    })),
    on(groupsActions.setSelections, (state, action) => ({
        ...state,
        selections: action.selections
    })),
    on(groupsActions.selectedGroup, (state, action) => ({
        ...state,
        selectedGroup: action.item
    })),
    on(groupsActions.deleteGroupSuccess, (state) => ({
        ...state,
        isGroupDeletedSuccessfully: true
    })),
    on(groupsActions.toggleIsGroupDeletedSuccessfully, (state, action) => ({
        ...state,
        isGroupDeletedSuccessfully: action.result
    })),
    on(groupsActions.toggleIsGroupDeletedSuccessfully, (state, action) => ({
        ...state,
        isGroupDeletedSuccessfully: action.result
    })),
    on(groupsActions.setDeleteGroupWarningNot, (state, action) => ({
        ...state,
        isDeleteGroupWarningNotVisible: action.result
    }))
);
