import { IGetRowsParams } from '@ag-grid-community/core';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ExperienceConfigurationServiceNg } from '@ct/core-ui-ng';
import { EffectsModule } from '@ngrx/effects';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { Observable } from 'rxjs';
import { TestScheduler } from 'rxjs/testing';

import { GroupsService } from '../../../shared/services/groups/groups.service';
import { addGroupResponseMock, groupsListMock, GroupTypes } from '../shared';

import { groupsActions } from './groups.actions';
import { GroupsEffects } from './groups.effects';
import { GROUPS_FEATURE_KEY, initialState } from './groups.state';

describe('Groups effect', () => {
    let action$: Observable<any>;
    let effects: GroupsEffects;
    let testScheduler: TestScheduler;
    const mockService = jasmine.createSpyObj<any>('GroupsService', ['getGroupsTotal', 'getGroupsList', 'addGroup', 'deleteGroup']);
    const totalResponse = {
        result: {
            createdInLast30Days: 15,
            totalRecordCount: 10
        }
    };

    const groupListResponse = {
        result: {
            data: groupsListMock
        }
    };

    const addGroupResponse = {
        result: addGroupResponseMock
    };

    const deleteGroupRequest = {
        groupGuId: '1'
    };

    const deleteGroupSuccessResponse = {
        result: true
    };


    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                EffectsModule.forRoot([GroupsEffects]),
                RouterTestingModule.withRoutes([])
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        [GROUPS_FEATURE_KEY]: initialState
                    }
                }),
                provideMockActions(() => action$),
                {
                    provide: GroupsService,
                    useValue: mockService
                },
                ExperienceConfigurationServiceNg
            ]
        });
        effects = TestBed.inject(GroupsEffects);
        testScheduler = new TestScheduler((actual, expected) => {
            expect(actual).toEqual(expected);
        });
    });

    it('should request groups total', () => {
        const action = groupsActions.groupsGetTotal();
        const outcome = groupsActions.groupsGetTotalSuccess(totalResponse);
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-b|', { b: totalResponse });
            mockService.getGroupsTotal.and.returnValue(result$);
            expectObservable(effects.groupsTotal$).toBe('--b', {
                b: outcome
            });
        });
    });

    it('should request groups list', () => {
        const params: Partial<IGetRowsParams> = {
            successCallback(rowsThisBlock: Array<any>, lastRow?: number): void { },
            startRow: 20,
            endRow: 40,
            sortModel: [{
                sort: 'asc',
                colId: 'entityGroupName'
            }]
        };
        const action = groupsActions.groupsGetList({ params, groupType: GroupTypes.DYNAMIC });
        const outcome = groupsActions.groupsGetListSuccess({ result: groupsListMock });
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-b|', { b: groupListResponse });
            mockService.getGroupsList.and.returnValue(result$);
            expectObservable(effects.groupsGetList$).toBe('--b', {
                b: outcome
            });
        });
    });

    xit('should request add groups', () => {
        const action = groupsActions.addGroup();
        const outcome = groupsActions.addGroupSuccess(addGroupResponse);
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-b|', { b: addGroupResponse });
            mockService.addGroup.and.returnValue(result$);
            expectObservable(effects.addGroup$).toBe('--b', {
                b: outcome
            });
        });
    });

    it('should request relete groups', () => {
        const action = groupsActions.deleteGroup(deleteGroupRequest);
        const outcome = groupsActions.deleteGroupSuccess(deleteGroupSuccessResponse);
        testScheduler.run(({ hot, cold, expectObservable }) => {
            action$ = hot('-a', {
                a: action
            });
            const result$ = cold('-b|', { b: deleteGroupSuccessResponse });
            mockService.deleteGroup.and.returnValue(result$);
            expectObservable(effects.deleteGroup$).toBe('--b', {
                b: outcome
            });
        });
    });
});
