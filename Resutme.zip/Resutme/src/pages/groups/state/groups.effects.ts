import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { from, of } from 'rxjs';
import { catchError, map, switchMap, withLatestFrom } from 'rxjs/operators';

import { GroupsService } from '../../../shared/services/groups/groups.service';
import { getAddGroupFormatedData, GroupsListHelper } from '../shared';

import * as selectors from './add-group-modal/add-group-modal.selectors';
import { groupsActions } from './groups.actions';

@Injectable()
export class GroupsEffects {
    groupsTotal$ = createEffect(() =>
        this.actions$.pipe(
            ofType(groupsActions.groupsGetTotal),
            switchMap(() =>
                from(this.groupsService.getGroupsTotal()).pipe(
                    map((response) =>
                        groupsActions.groupsGetTotalSuccess({
                            result: response.result
                        })
                    ),
                    catchError((error) =>
                        of(groupsActions.groupsGetTotalFailure({ error }))
                    )
                )
            )
        )
    );

    groupsGetList$ = createEffect(() =>
        this.actions$.pipe(
            ofType(groupsActions.groupsGetList),
            switchMap(({ params, groupType }) => {
                const request =
                    GroupsListHelper.getFormattedGroupListParams(params);

                return from(
                    this.groupsService.getGroupsList({
                        ...request,
                        type: groupType
                    })
                ).pipe(
                    map((response) => {
                        response.result.data = response.result.data.map(
                            (item) => GroupsListHelper.formatCellValues(item)
                        );
                        params.successCallback(
                            response.result.data,
                            GroupsListHelper.getLastRow(
                                response.result.data.length,
                                request.pageNumber,
                                request.pageSize
                            )
                        );

                        return groupsActions.groupsGetListSuccess({
                            result: response.result.data
                        });
                    }),
                    catchError((error) =>
                        of(groupsActions.groupsGetTotalFailure({ error }))
                    )
                );
            })
        )
    );

    addGroup$ = createEffect(() =>
        this.actions$.pipe(
            ofType(groupsActions.addGroup),
            withLatestFrom(
                this.store$.select(selectors.selectAddGroupFirstStepFormData),
                this.store$.select(selectors.selectAddGroupSecondStepFormData),
                this.store$.select(selectors.selectAddGroupThirdStepFormData)
            ),
            switchMap(([_, firstStepModel, secondStepModel, thirdStepModel]) =>
                from(
                    this.groupsService.addGroup(
                        getAddGroupFormatedData(
                            firstStepModel,
                            secondStepModel,
                            thirdStepModel
                        )
                    )
                ).pipe(
                    map((response) => {
                        return groupsActions.addGroupSuccess({
                            result: response.result
                        });
                    }),
                    catchError((error) => {
                        return of(groupsActions.addGroupFailure({ error }));
                    })
                )
            )
        )
    );

    deleteGroup$ = createEffect(() =>
        this.actions$.pipe(
            ofType(groupsActions.deleteGroup),
            switchMap((_params) => {
                const groupGuId = _params.groupGuId;

                return from(this.groupsService.deleteGroup(groupGuId)).pipe(
                    map((_response) => {
                        this.router.navigate(['account-tools/groups/'])
                            .catch(e => {throw new Error(`Error in route navigate`); });

                        return groupsActions.deleteGroupSuccess({
                            result: _response.result
                        });
                    })
                );
            })
        )
    );

    constructor(
        private actions$: Actions,
        private groupsService: GroupsService,
        private store$: Store,
        private router: Router
    ) {}
}
