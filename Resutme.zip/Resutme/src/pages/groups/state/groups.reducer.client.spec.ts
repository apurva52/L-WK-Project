import { IGetRowsParams } from '@ag-grid-community/core';

import { groupsListMock, GroupTypes } from '../shared';

import { groupsActions } from './groups.actions';
import { groupsReducer } from './groups.reducer';
import { initialState } from './groups.state';

describe('groups reducer', () => {
    const errorMessage = 'Something went wrong';
    const totalRecordCount = 10;
    const createdInLast30Days = 15;
    const isDeleted = true;

    const params: Partial<IGetRowsParams> = {};

    it('should process groups total load', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            loading: true
        };
        expect(
            groupsReducer(
                currentState,
                groupsActions.groupsGetTotal()
            )
        ).toEqual(expectedState);
    });

    it('should process groups total load success', () => {
        const currentState = {
            ...initialState,
            loading: true
        };
        const expectedState = {
            ...currentState,
            loading: false,
            totalRecordCount,
            createdInLast30Days
        };
        expect(
            groupsReducer(
                currentState,
                groupsActions.groupsGetTotalSuccess({
                    result: {
                        createdInLast30Days,
                        totalRecordCount
                    }
                })
            )
        ).toEqual(expectedState);
    });
    it('should process group delete success', () => {
        const currentState = {
            ...initialState,
            isGroupDeletedSuccessfully: false
        };
        const expectedState = {
            ...currentState,
            isGroupDeletedSuccessfully: true
        };
        expect(
            groupsReducer(
                currentState,
                groupsActions.deleteGroupSuccess({
                    result: isDeleted
                })
            )
        ).toEqual(expectedState);
    });

    it('should process toggle group delete success notification', () => {
        const currentState = {
            ...initialState,
            isGroupDeletedSuccessfully: false
        };
        const expectedState = {
            ...currentState,
            isGroupDeletedSuccessfully: true
        };
        expect(
            groupsReducer(
                currentState,
                groupsActions.toggleIsGroupDeletedSuccessfully({
                    result: isDeleted
                })
            )
        ).toEqual(expectedState);
    });

    it('should process groups total load failure', () => {
        const currentState = {
            ...initialState,
            loading: true
        };
        const expectedState = {
            ...currentState,
            loading: false,
            errorMessage
        };
        expect(
            groupsReducer(
                currentState,
                groupsActions.groupsGetTotalFailure({
                    error: errorMessage
                })
            )
        ).toEqual(expectedState);
    });

    it('should process groups list load', () => {
        const currentState = {
            ...initialState
        };
        const expectedState = {
            ...currentState,
            loading: true
        };
        expect(
            groupsReducer(
                currentState,
                groupsActions.groupsGetList({ params, groupType: GroupTypes.DYNAMIC })
            )
        ).toEqual(expectedState);
    });

    it('should process groups list load success', () => {
        const currentState = {
            ...initialState,
            loading: true
        };
        const expectedState = {
            ...currentState,
            loading: false,
            groupList: groupsListMock
        };
        expect(
            groupsReducer(
                currentState,
                groupsActions.groupsGetListSuccess({
                    result: groupsListMock
                })
            )
        ).toEqual(expectedState);
    });

    it('should process groups total load failure', () => {
        const currentState = {
            ...initialState,
            loading: true
        };
        const expectedState = {
            ...currentState,
            loading: false,
            errorMessage
        };
        expect(
            groupsReducer(
                currentState,
                groupsActions.groupsGetListFailure({
                    error: errorMessage
                })
            )
        ).toEqual(expectedState);
    });

    it('should clear groups list', () => {
        const currentState = {
            ...initialState,
            groupList: groupsListMock
        };
        const expectedState = {
            ...currentState,
            groupList: []
        };
        expect(
            groupsReducer(
                currentState,
                groupsActions.clearGroupsList()
            )
        ).toEqual(expectedState);
    });

    it('should select group', () => {
        const currentState = {
            ...initialState,
            groupList: groupsListMock,
            selectedGroup: null
        };
        const expectedState = {
            ...currentState,
            selectedGroup: groupsListMock[0]
        };
        expect(
            groupsReducer(
                currentState,
                groupsActions.selectedGroup({ item: groupsListMock[0] })
            )
        ).toEqual(expectedState);
    });

    it('should set selections', () => {
        const currentState = {
            ...initialState,
            selections: []
        };
        const expectedState = {
            ...currentState,
            selections: groupsListMock
        };
        expect(
            groupsReducer(
                currentState,
                groupsActions.setSelections({
                    selections: groupsListMock
                })
            )
        ).toEqual(expectedState);
    });

    it('should process show warning notification', () => {
        const currentState = {
            ...initialState,
            isDeleteGroupWarningNotVisible: false
        };
        const expectedState = {
            ...currentState,
            isDeleteGroupWarningNotVisible: true
        };
        expect(
            groupsReducer(
                currentState,
                groupsActions.setDeleteGroupWarningNot({
                    result: true
                })
            )
        ).toEqual(expectedState);
    });
});
