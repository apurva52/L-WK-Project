import { IGetRowsParams } from '@ag-grid-community/core';
import { createAction, props } from '@ngrx/store';

import { AddGroupResponse, GroupListItem, GroupsTotalResponse, GroupTypes } from '../shared';

export enum GroupsActionTypes {
    GroupsGetTotal = `[Groups] Total`,
    GroupsGetTotalSuccess = `[Groups] Total Success`,
    GroupsGetTotalFailure = `[Groups] Total Failure`,
    GroupsGetList = `[Groups] Get List`,
    GroupsGetListSuccess = `[Groups] Get List Success`,
    GroupsGetListFailure = `[Groups] Get List Failure`,
    ClearGroupsList = `[Groups] Clear Groups List`,
    SetSelections = `[Groups] Set Selections`,
    SelectedGroup = `[Groups] Selected Groups`,
    AddGroup = `[Groups] Create Group`,
    AddGroupSuccess = `[Groups] Create Group Success`,
    AddGroupFailure = `[Groups] Create Group Failure`,
    DeleteGroup =  `[Groups] Gelete Group`,
    DeleteGroupSuccess = `[Groups] Gelete Group Success`,
    ToggleIsGroupDeletedSuccessfully = `[Groups] Toggle Delete Group notification`,
    SetDeleteGroupWarningNot = `[Groups] Set Delete Group Warning notification`,
    SetGridEntities = '[Add Group] Set Grid Entities'
}

const groupsGetTotal = createAction(
    GroupsActionTypes.GroupsGetTotal
);

const groupsGetTotalSuccess = createAction(
    GroupsActionTypes.GroupsGetTotalSuccess,
    props<{
        result: GroupsTotalResponse
    }>()
);

const groupsGetTotalFailure = createAction(
    GroupsActionTypes.GroupsGetTotalFailure,
    props<{
        error: string
    }>()
);

const groupsGetList = createAction(
    GroupsActionTypes.GroupsGetList,
    props<{
        params: Partial<IGetRowsParams>,
        groupType: GroupTypes
    }>()
);

const groupsGetListSuccess = createAction(
    GroupsActionTypes.GroupsGetListSuccess,
    props<{
        result: Array<GroupListItem>
    }>()
);

const groupsGetListFailure = createAction(
    GroupsActionTypes.GroupsGetListFailure,
    props<{
        error: string
    }>()
);

const clearGroupsList = createAction(
    GroupsActionTypes.ClearGroupsList
);

const setSelections = createAction(
    GroupsActionTypes.SetSelections,
    props<{
        selections: Array<GroupListItem>;
    }>()
);

const selectedGroup = createAction(
    GroupsActionTypes.SelectedGroup,
    props<{
        item: GroupListItem
    }>()
);

const addGroup = createAction(
    GroupsActionTypes.AddGroup
);

const addGroupSuccess = createAction(
    GroupsActionTypes.AddGroupSuccess,
    props<{
        result: AddGroupResponse
    }>()
);

const addGroupFailure = createAction(
    GroupsActionTypes.AddGroupFailure,
    props<{
        error: string
    }>()
);

const deleteGroup = createAction(GroupsActionTypes.DeleteGroup, props<{ groupGuId: string }>());

const deleteGroupSuccess = createAction(
    GroupsActionTypes.DeleteGroupSuccess,
    props<{ result: boolean }>()
);

const toggleIsGroupDeletedSuccessfully = createAction(
    GroupsActionTypes.ToggleIsGroupDeletedSuccessfully,
    props<{ result: boolean }>()
);

const setDeleteGroupWarningNot = createAction(
    GroupsActionTypes.SetDeleteGroupWarningNot,
    props<{ result: boolean }>()
);
const setGridEntities = createAction(
    GroupsActionTypes.SetGridEntities
);

export const groupsActions = {
    groupsGetTotal,
    groupsGetTotalSuccess,
    groupsGetTotalFailure,
    groupsGetList,
    groupsGetListSuccess,
    groupsGetListFailure,
    clearGroupsList,
    setSelections,
    selectedGroup,
    addGroup,
    addGroupSuccess,
    addGroupFailure,
    deleteGroup,
    deleteGroupSuccess,
    toggleIsGroupDeletedSuccessfully,
    setDeleteGroupWarningNot,
    setGridEntities
};
